---
name: write-b2b-docs
description: >-
  Use when writing B2B technical documentation: implementation guides, API references, troubleshooting docs, how-to docs, configuration docs, developer docs, IT administrator instructions, or business software documentation. Produces clear, tested, product-specific docs with imperative mood and verified examples.
metadata:
  short-description: B2B technical docs
---

# B2B Technical Documentation

## Workflow

1. Identify doc type: quick start, concept, how-to, reference, or troubleshooting.
2. Identify audience: business user, developer, technical specialist, or IT administrator.
3. Gather product name, version, prerequisites, permissions, API endpoints, config options, error messages, integration details, examples, and success criteria.
4. Ask for missing technical details when guessing would create inaccurate docs.
5. Use imperative mood for steps: "Click Save", "Run `npm install`", "Enter your API key".
6. Test code examples when runnable in the local environment. If not runnable, state why.
7. Verify current product details, APIs, versions, limits, and error messages before asserting them.

## Structures

- Quick start: prerequisites, installation, first task, verify success, next steps.
- How-to: goal, before you begin, numbered steps, expected result, troubleshooting.
- Reference: endpoint or option, required fields, types, examples, auth, errors.
- Troubleshooting: symptom, cause, solution, prevention.
- Concept: architecture, key concepts, data model, workflows, glossary.

## Style Rules

- Use exact UI labels and API names.
- Define terms on first use.
- Keep terminology consistent across the document.
- Use active voice unless actor is irrelevant.
- Avoid "please" in instructions except support requests.
- Include OS, version, permission, quota, and environment details when relevant.
- Never fabricate endpoints, errors, version behavior, limits, or migration notes.

## Output

Return publication-ready markdown. If code examples are included, add:

```markdown
## Verification
- Code examples tested: [yes/no + command or reason]
- Product facts verified: [yes/no + source or reason]
- Missing inputs: [none/list]
```

## Final Check

- Steps are sequential and imperative.
- Prerequisites and expected result are clear.
- Examples are complete and copyable.
- Troubleshooting uses exact messages where available.
