---
name: write-humanize-blog
description: >-
  Use when transforming AI-written blog posts, casual articles, personal essays, lifestyle content, or conversational web copy into natural human writing with distinct voice, varied rhythm, sensory detail, micro-opinions, and controlled imperfection.
metadata:
  short-description: Humanize blog text
---

# Humanize Blog Writing

## Mission

Turn AI-sounding casual writing into text that feels written by a real person. Preserve the user's core meaning, but add voice, uneven rhythm, concrete detail, and believable human texture.

## Workflow

1. Identify context, audience, desired casualness, and any persona the user gave.
2. Detect AI tells: generic transitions, perfect balance, uniform sentence length, template contrasts, teacherly openers, vague emotion, polished summaries, and too many three-item lists.
3. Define a persona: stance, bias, pet peeves, casualness, rhythm, emotional valence, and 1-2 recurring verbal habits.
4. Rewrite with concrete scenes, sensory details, micro-opinions, and sentence-length variation.
5. Keep facts intact. For factual or high-stakes content, use `humanize-factual` or `humanize-de-factual` instead.
6. Verify the result does not sound more corporate, generic, or overpolished than the input.

## Human Voice Rules

- Use contractions in English casual prose.
- Mix fragments, longer rambles, and blunt short sentences.
- Add physical detail: smell, texture, sound, temperature, mess, object traces.
- Replace abstract verdicts with specific moments or reactions.
- Let the persona have preferences and mild gripes.
- Break clean "I used to X, now I Y" arcs with a messy middle or contradiction.
- Avoid overdoing chaos. Imperfections must serve voice, not readability theater.

## Remove

- "However", "furthermore", "therefore", "it is important to note".
- "It's not X, it's Y" and "not only X but also Y".
- "In today's fast-paced world".
- Smooth three-part lists everywhere.
- Generic positivity: "delightful", "robust", "transformative", "seamless" unless character-specific.

## Output

Default output:

```markdown
Text humanized successfully.

**Key transformations:**
- [3-5 concise bullets]

---

[rewritten text]
```

If user asks for rewritten text only, output only the rewritten text.

## Final Check

- Meaning is preserved.
- Voice sounds like one person.
- Rhythm varies.
- Specific detail replaces generic abstraction.
- No fake facts or fake personal experiences are added.
