---
name: pull-request-check
description: Check an open PR for issues and comments and fix those.
allowed-tools:
  - Bash
  - Read
  - Grep
  - Glob
---

## Task
Get the latest coderabbit comments on the open PR. Stop if there is no open PR.
Check for failed checks, and fix all valid issues found during validation.

Get all comments on the PR, including nitpicks. Fix all valid issues, including nitpicks. Mark resolved comments as resolved.

Then commit all edits and uncommitted changes from other sessions and push them.
