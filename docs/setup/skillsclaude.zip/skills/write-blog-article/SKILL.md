---
name: write-blog-article
description: >-
  Use when writing affiliate blog articles, SEO reviews, product comparisons, roundups, buyer guides, tutorials, or editorial reviews with optional custom persona. Produces source-grounded, persuasive markdown articles with clear CTAs, ethical affiliate framing, and human voice.
metadata:
  short-description: Affiliate blog article
---

# Affiliate Blog Article

## Workflow

1. Parse request for article count, topic, format, length, audience, search intent, tone, and persona.
2. If no persona is provided, create a plausible domain-relevant persona and briefly state it before drafting.
3. Verify current product facts, pricing, availability, specs, reviews, and alternatives before making specific claims.
4. Choose a structure per article: review, comparison, roundup, buyer guide, tutorial, editorial review, AIDA, PAS, BAB, FAB, or inverted pyramid.
5. Write source-grounded content that distinguishes factual claims from persona opinions.
6. Add ethical persuasion: reader benefit, realistic proof, clear CTA, and no fake urgency.
7. Optimize for SEO without keyword stuffing.

## Article Skeleton

- Hook intro in persona voice.
- Quick verdict or TL;DR.
- Who it is for and not for.
- Why trust this review.
- Deep dive sections matched to structure.
- Alternatives or comparisons.
- Pros and cons when useful.
- Final recommendation and CTA.

## Style Rules

- Use specific details over generic claims.
- Keep paragraphs short: 2-4 sentences.
- Vary sentence length without making prose chaotic.
- Include light micro-anecdotes only when they help the buying decision.
- Avoid "in today's fast-paced world", "not only X but also Y", fake guarantees, fake scarcity, and made-up reviews.
- Use bullets sparingly where skimming helps.

## Output

Return markdown ready for CMS paste. If multiple articles, use:

```markdown
## Article 1: [Title]
...
## Article 2: [Title]
...
```

Start with a brief plan and persona summary unless user asks for article-only output.

## Final Check

- Factual claims are verified or conservatively phrased.
- Persona is consistent.
- CTA matches intent.
- SEO terms appear naturally in title, intro, and at least one heading when relevant.
