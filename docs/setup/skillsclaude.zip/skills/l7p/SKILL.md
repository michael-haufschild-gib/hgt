---
name: l7p
description: "Use for L7+ senior-staff engineering tasks needing investigate, critique, synthesize, implement, and verify."
argument-hint: "<task description or question>"
user-invocable: true
---

Five mandatory phases. No phase may be skipped. Deliver Phases 0-3 before any code changes.

**Phases 1-3 are read-only.** Do not edit files or write code until Phase 4. Allowed tools during Phases 1-3: Serena MCP, `Read`, `Grep`, `Glob`, `WebSearch`, `Bash` (read-only commands only), `mcp__sequential-thinking__sequentialthinking`.

$ARGUMENTS

## Quality Standard

Given this task, approach it the way a Senior Staff Engineer (L7+) at Google, Amazon, or Apple would. What would they investigate? What questions would they ask? What would they verify before writing code?


## Phase 0: Contextualize
If not done yet, read the docs, serena memories, memories. State the purpose of the project in chat. What is the codebase? What does it do? What are its main features? What is the tech stack? What are key concepts and what does this project do differently to common practices and why? What could an L7+ SWE flag as wrong but is actually intentional?

**Scale Calibration**: Check CLAUDE.md for scale context. If absent, default to midsize enterprise: millions of users, reasonable team, standard infrastructure. Propose the simplest correct solution at that scale. If a more complex approach would be needed at FAANG scale (billions of requests, multi-region, custom infrastructure), mention it as a footnote — do not implement it.

## Phase 1: Approach, Investigate, and Propose
Before reading any code or running any tool, write down your approach: How would an L7+ SWE at Google, Amazon, or Apple approach this problem? What would they investigate first and why? What hypotheses would they form? Write this reasoning in chat under `## Approach`.

Then execute that approach. Investigate what this specific problem requires — not a generic sweep.

Every claim requires evidence: file path and line number, command output, or verified external source. Unverified claims must be marked `[UNVERIFIED]` or removed.

Propose your solution under `## Initial Analysis`. Describe what you would change and where, with specific file paths and line numbers. Do not make changes yet.

## Phase 2: Adversarial Critique

Use `mcp__sequential-thinking__sequentialthinking`. Minimum 2 thoughts, scale up for complex tasks.

Switch perspective. You did not write the Phase 1 proposal. Before attacking it, reason about where an L7+ SWE reviewing a colleague's design doc would focus their critique and why. Then conduct that review — the kind that prevents production incidents, not the kind that approves with minor comments.

Constraints:
- State what is wrong before what is right.
- When uncertain, say so. Do not pad uncertainty with confident language.
- Disagree with the Phase 1 proposal when evidence warrants it.
- If you found fewer than 2 issues, you are being too lenient on your own work. Go deeper.

Deliver under `## Adversarial Critique` with file paths and line numbers where applicable.

## Phase 3: Synthesis

Review your initial analysis and adversarial critique together. Before resolving findings, reason about which critiques carry the most weight, which change the approach, and which are noise. Then resolve each:

For each critique finding:
- **Accept**: valid — modify the proposal. State what changed and why.
- **Reject**: wrong — cite specific evidence (file:line, test output, documentation). "I believe the original is correct" without evidence is not a rejection.
- **Investigate**: evidence is thin for either side. Conduct additional investigation now — read files, grep for patterns, search for current practices. Then accept or reject based on findings.

Every `[UNVERIFIED]` claim from Phase 2 must be resolved: verify with evidence or remove from the final answer.

The final answer must reflect valid critiques. If the adversarial phase found real issues, the synthesis addresses them — not restates the original.

Where the initial analysis and critique conflict and evidence is ambiguous, present both positions and state which you favor and why.

State remaining uncertainty explicitly.

Deliver under `## Final Answer`. This is the implementation spec.

## Phase 4: Implementation

The Final Answer from Phase 3 is the spec. Implement exactly what it describes.

Make code changes, write tests, update configuration — whatever the Final Answer prescribes. Use `Edit`, `Write`, `Bash`, and any other tools needed.

After implementation, run verification (tests, linter, type checker, build) to confirm correctness.

If verification reveals unanticipated issues, fix them and note the discrepancy.

## Output Structure

```
## Context
[Phase 0 - Contextualization]

## Approach
[Phase 1 — how an L7+ SWE would approach this and why]

## Initial Analysis
[Phase 1 — investigation and proposal with evidence]

## Adversarial Critique
[Phase 2 — findings attacking the proposal]

## Final Answer
[Phase 3 — synthesized plan incorporating valid critiques]

[Phase 4 — implementation with verification results]
```

Scale depth to task scope. A variable rename gets concise phases. An architecture change gets thorough phases. Never skip a phase.

---

Phases 0-3: read-only tools only. Phase 2: `mcp__sequential-thinking__sequentialthinking`. Phase 3: accept, reject (with evidence), or investigate each critique finding. The Final Answer is the implementation spec — Phase 4 executes it.
