---
name: write-scientific-writing
description: >-
  Use when writing scientific literature: peer-reviewed journal articles, conference papers, preprints, empirical IMRAD papers, reviews, theoretical papers, methods sections, results sections, or academic manuscripts with citation, reproducibility, and field-specific style standards.
metadata:
  short-description: Scientific writing
---

# Scientific Writing

## Workflow

1. Identify paper type: empirical IMRAD, review, theoretical, methods, results, abstract, or cover-letter-adjacent text.
2. Identify discipline, target venue, citation style, audience expertise, research question, methods, key results, and conclusion.
3. Ask for missing research facts before drafting if they are required. Never fill gaps with invented data.
4. For empirical papers, follow IMRAD:
   - Introduction: field context, gap, research question or hypothesis.
   - Methods: design, sample, materials, procedures, software versions, analysis plan, ethics.
   - Results: findings only, no interpretation.
   - Discussion: interpretation, comparison to literature, limits, alternative explanations, implications.
5. For reviews or theory papers, use the user's target structure and make argument scope explicit.
6. Verify citations, current literature, standards, and factual claims when the user asks for real sources or recent work.

## Scientific Standards

- Never fabricate data, citations, results, effect sizes, sample sizes, approval numbers, or methods.
- Report exact statistics when provided: test type, statistic, degrees of freedom, p value, confidence interval, and effect size.
- Preserve uncertainty: use "suggest", "indicate", "consistent with", and "may" where evidence warrants it.
- Methods must be reproducible from the text.
- Do not use contractions or casual phrasing in manuscript prose.
- Use first-person plural only when appropriate for the target venue.

## Style Rules

- Physical sciences: prefer dense noun phrases and precise technical terms.
- Social sciences: allow more clausal complexity and explicit reasoning links.
- Mix concise findings with longer analytical sentences.
- Avoid generic templates like "The purpose of this study was to investigate" when a sharper sentence works.
- Mention limitations specifically, not as boilerplate.

## Output

Return the requested section or manuscript. If useful, append:

```markdown
## Verification Notes
- Missing inputs: [none/list]
- Claims needing source verification: [none/list]
- Reproducibility gaps: [none/list]
```

## Final Check

- No invented science.
- Structure fits paper type.
- Results and interpretation are separated.
- Citations are real or clearly marked as placeholders.
