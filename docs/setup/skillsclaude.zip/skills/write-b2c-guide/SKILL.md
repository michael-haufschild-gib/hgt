---
name: write-b2c-guide
description: >-
  Use when writing consumer help content: getting started guides, how-to instructions, FAQs, troubleshooting articles, onboarding docs, customer-support content, or user-facing product guides. Produces friendly, accessible, empathy-aware guides at grade 6-8 readability.
metadata:
  short-description: B2C help guides
---

# B2C User Guides

## Workflow

1. Identify content type: getting started, how-to, FAQ, or troubleshooting.
2. Identify user state: success, confused, error, or failure.
3. Identify brand personality, platform, prerequisites, task, success signal, common problems, and support path.
4. Ask for missing details only when required for accuracy or user safety.
5. Organize by user goal, not product feature.
6. Use simple numbered steps with one action per step.
7. Flag where screenshots, video, or diagrams are needed.

## Structures

- Getting started: what you need, setup, first useful task, confirmation, next step.
- How-to: what you need, steps, what happens next, troubleshooting.
- FAQ: user-voice questions, most common first.
- Troubleshooting: problem in user's words, try this, why it happens, still stuck.

## Style Rules

- Use contractions naturally: "you'll", "don't", "it's".
- Address the reader directly as "you".
- Explain jargon on first use.
- Target grade 6-8 readability; use grade 5-6 for healthcare or safety-critical content.
- Use empathy for errors without blaming the user.
- Keep steps short, usually 10-15 words.
- Mention screenshots for non-obvious UI steps with alt text guidance.

## Safety

- Do not invent UI labels, support SLAs, platform behavior, or policy details.
- Verify current app behavior, pricing, compatibility, and support instructions when needed.
- For safety, health, legal, or financial guidance, verify with current authoritative sources and avoid overclaiming.

## Output

Return user-ready markdown. Include screenshot placeholders only when helpful:

```markdown
![Screenshot showing ...](screenshot-needed)
```

## Final Check

- User can complete task without prior technical knowledge.
- Tone matches user state.
- Success indicator is explicit.
- Troubleshooting gives concrete next actions.
