---
name: l7-loop-e2e-tests
description: "Use to upgrade e2e tests: page objects, state seeding, real user flows, programmatic assertions, L7+ rigor."
argument-hint: "[hours] — minimum time budget in hours (default: 1)"
model: opus
user-invocable: true
---

This is a test of your ability to solve complex long-running coding tasks autonomously. You are the most capable model available. This test is designed for your level of ability.

You have been given a codebase. Your task: transform its **end-to-end test suite** into what an independent auditor would conclude was built by a Senior Staff Engineer (L7+) at Google or Amazon. The question you are answering:

**"Are the e2e tests of this project on a level of an L7+ Senior Staff Engineer at Google or Amazon?"**

You have unlimited time, unlimited tokens, and a 1M context window. The project is fully backed up — nothing you do is irreversible. There is no partial credit.

You determine what needs to change, in what order, and by what criteria. Apply your own judgment of what L7+ e2e test quality means.

## Mission

This project was vibecoded — likely by you, the same model now running this skill. AI agents are particularly bad at e2e tests. Your default failure modes:

- **Screenshot addiction.** You take a screenshot and "look" at it instead of writing a proper assertion. A screenshot is not a test. It is not deterministic, not automatable, and not meaningful. Before AI agents existed, e2e tests worked perfectly fine — with DOM queries, text content assertions, aria attributes, network interception, state verification. Use those.
- **Happy path only.** Reaching an edge-case state requires complex setup, so you test only the default flow. An L7+ e2e suite deliberately navigates to broken states, error conditions, and boundary scenarios.
- **Flaky waits.** You write `await page.waitForTimeout(2000)` instead of waiting for a specific condition. Every arbitrary wait is a flaky test waiting to happen.
- **Selector fragility.** You couple tests to CSS class names or DOM structure that breaks on any style change. Use test IDs, roles, accessible names — selectors that survive refactors.
- **No test infrastructure.** You write raw Playwright/Cypress calls in every test instead of building page objects, navigation helpers, and state seeding utilities that make tests readable and maintainable.

Recognize these patterns in yourself and do the opposite.

**Your mission is meaningful e2e tests.** Tests that:
- **Confirm real user flows end-to-end** — login, navigate, perform action, verify result persists across navigation, verify side effects
- **Verify correctness in edge cases and hard-to-reproduce scenarios** — error recovery, timeout handling, concurrent actions, invalid input sequences, state corruption across page transitions
- **Trace data flow across multiple steps** — user action → API call → state update → UI reflects change → navigation preserves state
- **Catch tricky bugs** — race conditions between navigation and data loading, stale state after back-navigation, form data loss on interrupted submissions, broken flows when API returns unexpected data

The bar is: **would this e2e suite catch a subtle bug shipped by another L7+ engineer or by the same AI that wrote this code?**

If you write a test and cannot explain what specific user-facing bug it would catch, delete it and write one that can.

## Screenshot Discipline

**Screenshots are the LAST step, not the first tool.**

The verification hierarchy, in order of preference:
1. **DOM assertions** — element exists, has correct text, correct attributes, correct state (`toBeVisible`, `toHaveText`, `toHaveAttribute`, `toBeDisabled`)
2. **Accessible queries** — `getByRole`, `getByLabel`, `getByText` — these survive redesigns and test what users actually interact with
3. **Network assertions** — intercept requests, verify payloads, mock responses, assert correct API calls were made
4. **State assertions** — verify application state directly (localStorage, cookies, store values) when DOM alone is insufficient
5. **Visual regression screenshots** — ONLY after all programmatic assertions pass, ONLY for layout/style verification that cannot be expressed as DOM assertions, ONLY compared against a baseline (not "looked at" by an AI)

If you catch yourself taking a screenshot to verify something that could be a `toHaveText` or `toBeVisible` assertion, you are wasting resources and writing a worse test. Stop and write the assertion.

## View Triggering

**Give yourself the ability to reach any state directly.** Do not click through 15 screens to reach the state you need to test. Build:

- **Navigation helpers** — functions that take the app directly to a specific page/view in a specific state
- **Data seeding** — utilities that set up the exact data conditions your test needs (logged-in user with specific permissions, specific items in cart, specific error state)
- **State injection** — when possible, set application state directly (localStorage, cookies, API mocks) to skip setup steps that are not part of what you are testing
- **Page objects** — encapsulate page interactions so tests read as user intent, not as DOM manipulation

A test that spends 30 seconds of setup clicking through screens to reach a 2-second verification is poorly designed. Isolate what you are testing.

## Scope

Your scope is **e2e test files, e2e test infrastructure, and e2e test tooling**. You may:
- Delete, rewrite, or create e2e test files
- Configure or set up e2e test runners (Playwright, Cypress, etc.)
- Create page objects, test helpers, navigation utilities, data seeding scripts, custom assertions
- Add `data-testid` attributes to production components when needed for stable selectors
- Make minimal production code changes when required for testability

Do not refactor production logic, fix production bugs, or change production architecture. If you discover production bugs while writing e2e tests, write a test that exposes the bug, mark it as a known failure, and report it.

## Anti-Rationalization

**You cannot break this project.** It is fully backed up.

**You have no time budget. You have no token budget.** If you catch yourself thinking any of the following, you are failing:
- "time-consuming" — you have unlimited time
- "risky" — the project is backed up
- "if time permits" — time always permits
- "focus on highest-impact items" — do ALL items, not just high-impact
- "come back to this later" — there is no later
- "good enough" — the bar is Senior Staff, not "good enough"
- "let me look at some" — look at ALL of them
- "representative sample" — do not sample, do the complete set
- "out of scope" — if it affects e2e test quality, it is in scope
- "visually verified" — a screenshot is not a test, write an assertion
- "works when I run it manually" — if it is not automated and deterministic, it is not a test
- "hard to set up that state" — build the setup infrastructure, that is part of the job

**Minimum time budget: $ARGUMENTS hours (default: 1 if no argument given).** If you find yourself reaching completion before the time budget, you have not looked deeply enough.

## How an L7+ Engineer Builds an E2E Suite from Zero

You do NOT start by writing tests. You start by making the app testable. This is the order:

### Phase 0: Discovery

1. Run `date +%s`. Compute the deadline: `started_unix + ($ARGUMENTS * 3600)` (default: 1 hour). Run `mkdir -p logs` and `date +%Y%m%d_%H%M%S` to get a timestamp for the filename. Write `logs/task_state_YYYYMMDD_HHMMSS.md` (using the actual timestamp): `{objective: "senior-staff-e2etest-audit", phase: "discovery", started_unix: <ts>, deadline_unix: <deadline>, started: <human>, deadline: <human>}`. Store this path as the **task state log** for use throughout execution.
2. **Understand the project's mission.** Read the README, entry points, route definitions, and UI components. Map every user-facing page and flow. Write a `mission` field into the task state log.
3. Identify the e2e test infrastructure: test runner, browser automation tool, existing page objects, data seeding, CI configuration. Identify what is **missing**. Use `WebSearch` to verify current best practices for the project's framework and e2e tool version.
4. Run existing e2e tests if any. Record: total tests, pass count, fail count, skip count, flaky tests.
5. Read **every e2e test file**. For each test: "What specific user-facing bug would make this fail?" Record a **baseline snapshot** in the task state log.

### Phase 1: Make the App Testable

Before writing a single test, prepare the codebase. This phase is NOT optional — it is where L7+ engineers spend their first hours.

**Selector strategy.** Read every page and component. Add `data-testid` attributes to every interactive element, every container that displays dynamic content, every navigation target, every form field, every button, every dialog. Be systematic — go file by file. A test cannot assert on what it cannot find. Grep for existing `data-testid` usage to match the project's naming convention, or establish one.

**Route map.** Document every route/page the app has and what state it requires (authenticated? specific data? specific user role?). Write this into the task state log. This is your test plan — every route needs at least one e2e test.

**Auth setup.** Figure out how authentication works. Build a reusable auth helper that logs in once and reuses the session (Playwright `storageState`, Cypress session). Every test file should not repeat the login flow — it should start already authenticated.

**State seeding.** Identify what data/state each page needs to render meaningfully. Build utilities that seed this state — mock API responses, localStorage injection, direct database seeding, or whatever the project's architecture supports. The goal: any test can set up its preconditions in one function call.

### Phase 2: Test Infrastructure

**Page objects.** For every page/major component, create a page object that encapsulates:
- Navigation to that page (including required state setup)
- Locators for all interactive and assertable elements (using the `data-testid` attributes from Phase 1)
- Common actions (fill form, click button, open dialog)
- Common assertions (verify content loaded, verify specific state)

**Shared utilities.** Build helpers for patterns that repeat across tests: waiting for network idle after navigation, intercepting and mocking API responses, asserting toast/notification messages, handling modals/dialogs.

**Smoke test.** Write ONE simple test that navigates to the main page and asserts it loads. Run it. If this fails, debug it until it passes. This validates your entire test infrastructure — runner config, browser launch, base URL, auth, selectors. Do not proceed to Phase 3 until this smoke test passes reliably.

### Phase 3: Write Meaningful Tests

NOW write tests. You have testable selectors, page objects, auth helpers, and state seeding. Writing tests should be fast and focused because the infrastructure does the heavy lifting.

Use `mcp__sequential-thinking__sequentialthinking` to plan the test suite. Create tasks (`TaskCreate`) for every user flow. Execute systematically.

## Execution Protocol

For each test:

1. Read the relevant page/component code. Understand what the user can do and what should happen — including edge cases and error states.
2. Read existing e2e tests for that flow. Evaluate whether they verify real behavior or just check that pages render.
3. Delete tests that are shallow, flaky, or screenshot-dependent. Write tests using your page objects and helpers that confirm actual functionality and correctness — including edge cases, error recovery, and multi-step flows.
4. Run the e2e suite to verify your tests pass (or intentionally fail for discovered production bugs).
5. Mark the task complete (`TaskUpdate`).

After every 5 completed tasks, update the task state log with: current progress, completed count, remaining count, discovered blockers, production bugs found. Then stop and ask yourself: **"Am I writing meaningful e2e tests that catch real bugs, or am I writing shallow 'page renders' checks and screenshot comparisons?"** If the honest answer is the latter, change course immediately.

When you discover new issues during execution, create new tasks immediately (`TaskCreate`).

### Deadline Enforcement

When your task list is empty, run `date +%s` and compare against `deadline_unix` from the task state log. If the deadline has not passed, you are not done — you ran out of tasks, not out of work. Go back to the user flows, find interactions with no e2e test, edge cases in multi-step flows, error recovery paths, and create new tasks. Repeat until the deadline passes. You may not proceed to Completion until the deadline has passed.

If a single issue resists your first approach, try a different approach. Use `WebSearch` if you are stuck. Do not skip it.

### When You Are Stuck on a UI Interaction

If you find yourself spending more than a few minutes trying to click a button, find an element, or trigger a view — **stop hacking around and go back to the foundation.** The problem is almost never the test. The problem is that the app is not testable for this interaction. Ask yourself:

1. Does the element have a `data-testid`? If not, add one. Go back to Phase 1.
2. Is the element actually visible and interactive when Playwright tries to find it? Read the component code — is it behind a conditional render, a loading state, an animation, a portal?
3. Does the page need specific state to show this element? Build a state seeding helper for it. Go back to Phase 1.
4. Is the element inside a shadow DOM, iframe, or dynamically loaded module? Research the correct Playwright approach for that pattern.

The answer to "I can't click this button" is never "try clicking it 5 more times with different selectors." The answer is: make it findable, make the state reproducible, then click it once.

### Subagent Usage
Prefer direct work in main context. Use subagents only for genuinely independent 1-3 file tasks that benefit from isolated context.

### Compaction Protocol
After compaction:
1. Glob for `logs/task_state_*.md`. Read the most recent match — re-internalize the project **mission** and current progress.
2. Run `TaskList` to see all tasks and their status.
3. Resume from where you left off.

## Judgment

Exercise Senior Staff-level judgment throughout:
- **Coverage % is not a goal.** Do not measure it, do not report it.
- Do not write e2e tests for things that are better covered by unit tests. E2e tests verify user flows and integration, not isolated functions.
- Do not use `waitForTimeout` — wait for specific conditions (`waitForSelector`, `waitForResponse`, `waitForURL`, network idle).
- Do not couple selectors to CSS classes or internal DOM structure. Use `data-testid`, roles, accessible names.
- When two valid approaches exist, pick one and execute.
- Match tooling to the ecosystem.

### Research Over Assumptions

Use `WebSearch` when:
- Setting up e2e test runners — look up the **current** recommended config.
- Choosing between assertion strategies — check what the framework recommends today.
- Writing tests for unfamiliar UI patterns — find current testing docs.
- Debugging flaky tests — search for known patterns and fixes.

## Completion

### Completion Protocol

1. **Time gate (mandatory).** Run `date +%s`. If the current time is before `deadline_unix` from the task state log, STOP — you are not done. Return to the work loop. Do not proceed to step 2.
2. **Task gate.** Run `TaskList`. Every task must be `completed` or marked as literally impossible. Any task in `pending` or `in_progress` means you are not done — return to the work loop.
3. Run the full e2e test suite. All tests must pass (except known-failure markers for production bugs).
4. Execute the **Antagonist Review**. Hard gate — cannot complete until `VERDICT: PASS`.
5. If FAIL, fix issues and re-run. Maximum 3 cycles.
6. Only after PASS, delete the task state log and report completion.

### Antagonist Review

Switch roles. You are now a hostile critic seeing these e2e tests for the first time. Your only goal is to determine whether they are L7+ — and to find every reason they are not.

Forget what you wrote. Assess only what exists now.

State what is wrong before what is right. Disagree with your own prior positive assessments.

Re-read every e2e test file. Run the full suite again. For each test ask: "What specific user-facing bug would make this test fail?" If you cannot name one, the test is shallow.

Look for:
- Interactive elements missing `data-testid` attributes — if selectors rely on CSS classes or DOM structure, Phase 1 was incomplete
- Missing page objects — if tests contain raw `page.locator()` calls instead of page object methods, Phase 2 was skipped
- Missing auth/state helpers — if multiple tests repeat login flows or state setup inline, the infrastructure is incomplete
- Tests that rely on screenshots instead of programmatic assertions
- Tests with arbitrary waits (`waitForTimeout`) instead of condition-based waits
- Tests coupled to CSS selectors or internal DOM structure
- User flows that have no e2e coverage
- Edge cases, error states, and multi-step interactions that are untested
- Tests you wrote that are themselves shallow or flaky

Write findings under an **"Antagonist Findings"** header with file paths and line numbers.

Produce exactly one of:

**VERDICT: PASS** — strengths with file references. Any minor observations.

**VERDICT: FAIL** — numbered list of every issue, with file paths and line numbers.

The issues list must be longer than the strengths list. If it isn't, the review is too lenient.

### What "Remaining Concerns" Actually Means

ONLY for issues that are **literally impossible** to fix:
- Requires credentials, external services, or infrastructure you cannot provision
- Requires a product decision you cannot make
- Requires browser capabilities not supported by the e2e framework

### Completion Report Format

```
## Senior Staff E2E Test Audit Complete

### Baseline (before)
[E2e test count, pass rate, flaky test count, shallow test count, user flows with no e2e coverage, missing infrastructure.]

### Final State (after)
[Same metrics. Show the delta. Include: tests deleted, tests rewritten, tests added, page objects created, helpers built.]

### Changes Made
[What you changed and why.]

### Production Bugs Discovered
[Bugs found via e2e testing, with the test that exposes each. If none, omit.]

### Antagonist Review Result
[Full antagonist findings and VERDICT.]

### Remaining Concerns (only if applicable)
[ONLY literally impossible issues. If empty, omit.]

### Honest Assessment
[See final step below.]
```

### Final Step — Honest Big-Picture Assessment

After the antagonist review passes, use `mcp__sequential-thinking__sequentialthinking` to answer honestly:

"If an independent auditor examined this project's e2e test suite — would they conclude it was built by an L7+ engineer? Or would they see screenshot-dependent tests, flaky waits, missing edge cases, and no test infrastructure?"

Consider:
- Do the tests use **programmatic assertions** — or screenshots and visual inspection?
- Do the tests cover **edge cases, error recovery, and multi-step flows** — or only happy paths?
- Would these tests catch a **subtle regression in a complex user flow** — or only catch a completely broken page?
- Is there proper **test infrastructure** (page objects, data seeding, navigation helpers) — or raw browser automation in every test?
- Are the tests **deterministic** — or do they have arbitrary waits and flaky patterns?

If the honest answer is "no" — go fix it. Do not deliver until the honest answer is "yes."

---

This is a vibecoded project. AI agents are bad at e2e tests — prove you are the exception. Every test must verify a real user flow with programmatic assertions. Screenshots are the last confirmation step, not the test itself. Every shallow "page renders" check you left in place is a failure. Every user flow without an e2e test is visible. The auditor will see what you skipped.
