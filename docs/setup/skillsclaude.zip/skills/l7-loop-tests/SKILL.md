---
name: l7-loop-tests
description: "Use to upgrade unit/integration tests: remove shallow tests, edge cases, bug-catching assertions, tooling, L7+ rigor."
argument-hint: "[hours] — minimum time budget in hours (default: 1)"
model: opus
user-invocable: true
---

This is a test of your ability to solve complex long-running coding tasks autonomously. You are the most capable model available. This test is designed for your level of ability.

You have been given a codebase. Your task: transform its test suites into what an independent auditor — with no knowledge of who wrote them — would conclude were built and maintained by a Senior Staff Engineer (L7+) at Google or Amazon. The question you are answering:

**"Are the test suites of this project on a level of an L7+ Senior Staff Engineer at Google or Amazon?"**

You have unlimited time, unlimited tokens, and a 1M context window. The project is fully backed up — nothing you do is irreversible. There is no partial credit: when you say "I'm done," the test suites either pass the audit or they do not.

You determine what needs to change, in what order, and by what criteria. No rubric is provided. Apply your own judgment of what L7+ test quality means — you know what a Senior Staff engineer's test suite looks like.

Do not ask the user for guidance during execution. Make every decision autonomously. You own the test suites — every shallow test, every missing edge case, every coverage-padding assertion is yours to fix.

## Mission

This project was vibecoded — likely by you, the same model now running this skill. That means you have a blind spot: you are biased toward believing your own code works. You wrote it to work, so your default instinct is to write tests that confirm it works — happy-path tests that pass because the code does what you intended. That is the opposite of what is needed.

Your job is to write tests that **distrust** the production code. Tests that assume bugs exist and hunt for them. Tests that probe the specific failure modes AI-generated code is prone to: plausible-looking logic that handles the common case but breaks on edge cases, error paths that were never exercised, async flows that work in sequence but fail under concurrency, state management that looks correct in isolation but corrupts across call chains.

**Your mission is meaningful tests.** Not coverage numbers. Not test count. Meaningful tests that:
- **Confirm functionality and correctness** — including edge cases, boundary values, and error conditions
- **Trace data flow and execution paths across multiple steps** — not just isolated unit calls, but sequences where step 1's output feeds step 2 which triggers step 3
- **Catch tricky, rare bugs that are hard to reproduce** — race conditions, off-by-one errors, null propagation through call chains, state corruption across async boundaries, malformed input that passes validation but breaks downstream, timing-dependent failures, resource leaks under repeated operations

The bar is not "would this catch a junior dev's bad PR." The bar is: **would this catch a subtle bug shipped by another L7+ engineer or by the same AI that wrote this code?** Those bugs are not obvious — they hide in edge cases, in implicit assumptions, in interactions between components that were never tested together.

If you write a test and cannot explain what specific production bug it would catch, delete it and write one that can.

## Scope

Your scope is **test files, test infrastructure, and test tooling**. You may:
- Delete, rewrite, or create test files
- Configure or set up test runners, coverage tools, and test utilities
- Create test helpers, factories, fixtures, and custom matchers
- Make minimal production code changes **only** when required for testability (e.g., exporting a function, adding dependency injection)

Do not refactor production logic, fix production bugs, or change production architecture. If you discover production bugs while writing tests, write a test that exposes the bug, mark it as a known failure using the ecosystem's convention (xfail, skip with explanation, .todo), and report it in the completion report.

## Anti-Rationalization

**You cannot break this project.** It is fully backed up. Do not avoid rewriting a test file because "the existing tests might be testing something subtle." Read them, understand them, and if they are shallow, replace them.

**You have no time budget. You have no token budget. You are not being economical — you are being tested.** If you catch yourself thinking any of the following, you are failing the test:
- "time-consuming" — you have unlimited time
- "risky" — the project is backed up
- "if time permits" — time always permits
- "focus on highest-impact items" — do ALL items, not just high-impact
- "come back to this later" — there is no later
- "good start" / "good enough" — the bar is Senior Staff, not "a good start"
- "let me look at some" — look at ALL of them
- "inspect key..." / "check the key..." — check EVERY one, not just "key" ones
- "highest impact" / "most important" — everything in scope matters equally
- "representative sample" / "representative files" — do not sample, do the complete set
- "out of scope" — if it affects test quality, it is in scope
- "sufficient coverage" — coverage numbers mean nothing if the assertions are shallow

Every one of these phrases is you rationalizing doing less work. When you notice this pattern, stop, recognize it, and do the work you were about to skip.

**Minimum time budget: $ARGUMENTS hours (default: 1 if no argument given).** Expect this to take hours, not minutes. If you find yourself reaching completion before the time budget, you have not looked deeply enough.

## Startup

1. Record the current time: run `date +%s`. Compute the deadline: `started_unix + ($ARGUMENTS * 3600)` (default: 1 hour if no argument given). Run `mkdir -p logs` and `date +%Y%m%d_%H%M%S` to get a timestamp for the filename. Write `logs/task_state_YYYYMMDD_HHMMSS.md` (using the actual timestamp): `{objective: "senior-staff-test-audit", phase: "discovery", started_unix: <unix_timestamp>, deadline_unix: <deadline_timestamp>, started: <human-readable>, deadline: <human-readable>}`. Store this path as the **task state log** for use throughout execution.
2. **Understand the project's mission.** Read the README, entry points, route definitions, and core modules. You need to understand what the code does before you can evaluate whether the tests verify it. Write a `mission` field into the task state log.
3. Identify the test infrastructure: test runner, assertion library, coverage tool, mocking framework, test configuration. Identify what is **missing**. Use `WebSearch` to verify current best practices for the project's framework and version.
4. Run the existing test suite. Record: total tests, pass count, fail count, skip count.
5. Read **every test file**. Read **every source file** the tests cover (and should cover). For each test, answer: "What specific bug would make this test fail?" If you cannot name the bug, the test is shallow. Record a **baseline snapshot** in the task state log: test count, pass rate, shallow test count (tests that do not verify a specific behavior), untested source files, untested behaviors in tested files, test infrastructure gaps.
6. Use `mcp__sequential-thinking__sequentialthinking` to assess the gap between current test quality and L7+. Be adversarial — assume the tests are worse than they look.
7. Create tasks (`TaskCreate`) for every remediation item. Execute systematically — test infrastructure before individual test files.

## Execution Protocol

Work through tasks systematically:

1. Read the relevant source code. Understand what the function/module/feature actually does — its contracts, edge cases, failure modes, and interactions.
2. Read the existing tests for that code. Evaluate whether they verify behavior or just pad coverage.
3. Delete tests that are shallow, redundant, or misleading. Rewrite or create tests that confirm actual functionality and correctness.
4. Run the test suite to verify your changes pass (or intentionally fail for discovered production bugs).
5. Mark the task complete (`TaskUpdate`).

After every 5 completed tasks, update the task state log with: current progress, completed count, remaining count, discovered blockers, production bugs found. Then stop and ask yourself: **"Am I making the tests better like an L7+ engineer, or am I just trying to hit coverage targets?"** If the honest answer is coverage targets, change course immediately.

When you discover new issues during execution, create new tasks immediately (`TaskCreate`). Do not track them mentally.

### Deadline Enforcement

When your task list is empty, run `date +%s` and compare against `deadline_unix` from the task state log. If the deadline has not passed, you are not done — you ran out of tasks, not out of work. Go back to the source files, find behaviors that have no test, edge cases with no coverage, error paths never exercised, and create new tasks. Repeat until the deadline passes. You may not proceed to Completion until the deadline has passed.

If a single issue resists your first approach, try a different approach. Use `WebSearch` if you are stuck. Use `mcp__sequential-thinking__sequentialthinking` to reason through the problem. Do not skip it.

### Subagent Usage
Prefer direct work in main context. Use subagents only for genuinely independent 1-3 file tasks that benefit from isolated context.

### Compaction Protocol
Your context window will be automatically compacted as it approaches its limit. Do not stop work early due to context concerns.

After compaction:
1. Glob for `logs/task_state_*.md`. Read the most recent match — re-internalize the project **mission** and current progress.
2. Run `TaskList` to see all tasks and their status.
3. Resume from where you left off.

## Judgment

Exercise Senior Staff-level judgment throughout:
- **Coverage % is not a goal and not a metric you track.** Do not measure it, do not report it, do not optimize for it. A 40% coverage suite where every test verifies a specific behavior is superior to 95% coverage achieved through shallow assertions. If you catch yourself checking or mentioning coverage percentages, you are optimizing the wrong thing.
- Do not write tests for trivial getters/setters that cannot meaningfully break.
- Do not mock everything — integration tests that hit real boundaries catch bugs that unit tests with mocks miss.
- Do not write tests that are tightly coupled to implementation details — test behavior, not internals.
- When two valid test approaches exist, pick one and execute.
- Match test tooling to the ecosystem.

### Research Over Assumptions

You have full access to `WebSearch`. Use it. Your training data may reflect outdated patterns, deprecated APIs, or superseded library versions.

Use `WebSearch` when:
- Setting up test runners or coverage tools — look up the **current** recommended config for the project's framework and version.
- Choosing between test patterns — check what the ecosystem recommends today.
- Writing tests for unfamiliar libraries or frameworks — find current testing docs.
- Configuring CI test pipelines — look up the current starter template.

## Completion

### Completion Protocol

1. **Time gate (mandatory).** Run `date +%s`. If the current time is before `deadline_unix` from the task state log, STOP — you are not done. Return to the work loop. Do not proceed to step 2.
2. **Task gate.** Run `TaskList`. Every task must be `completed` or marked as literally impossible (requires credentials, external access, or product decisions). Any task skipped for other reasons means you are not done — return to the work loop.
3. Run the full test suite. All tests must pass (except those intentionally marked as known-failure for production bugs).
4. Execute the **Antagonist Review** (see below). This is a hard gate — you cannot report completion until the review returns `VERDICT: PASS`.
5. If the review returns `VERDICT: FAIL`, fix every issue and re-run the review. Maximum 3 cycles.
6. Only after `VERDICT: PASS`, delete the task state log and report completion.

### Antagonist Review

Switch roles. You are no longer the engineer who improved these test suites. You are now a hostile, independent critic seeing them for the first time. Your only goal is to determine whether these test suites are the work of a Senior Staff Engineer (L7+) at Google or Amazon — and to find every reason they are not.

Forget what you changed. Forget what you fixed. Assess only what exists in the files right now.

State what is wrong before what is right. When uncertain, say so explicitly. Disagree with your own prior positive assessments when evidence warrants it.

Re-read every test file with fresh eyes. Run the full test suite again. Apply your own judgment — you decide what matters at L7+ test quality.

For every area where you previously felt satisfied with your work:
- Challenge it. Do the tests actually catch bugs or just exercise code paths?
- Look for tests you wrote that are themselves shallow, redundant, or missing edge cases.
- Search for systemic problems — test patterns that appear acceptable in isolation but indicate a superficial test strategy when viewed together.

Write findings under an **"Antagonist Findings"** header with file paths and line numbers.

Then produce exactly one of:

**VERDICT: PASS** — strengths with file references. Any minor observations.

**VERDICT: FAIL** — numbered list of every issue, with file paths and line numbers.

The issues list must be longer than the strengths list. If it isn't, the review is too lenient.

"Looks good" is never an acceptable finding. If nothing was found wrong, you are being too kind to your own work — go deeper.

### What "Remaining Concerns" Actually Means

"Remaining Concerns" is NOT for work you identified but chose to skip. It is ONLY for issues that are **literally impossible** to fix in this context:
- Requires access credentials you do not have (e.g., production database, paid API key for integration tests)
- Requires a decision only a product owner can make (e.g., "is this behavior intentional or a bug?")
- Requires hardware or infrastructure you cannot provision (e.g., "needs a browser for e2e tests")

"It might break things" is NOT a valid remaining concern — make the change and fix what breaks.
"It's a large rewrite" is NOT a valid remaining concern — you have unlimited time.
"It could be done in a future session" is NOT a valid remaining concern — this IS that session.

### Completion Report Format

```
## Senior Staff Test Audit Complete

### Baseline (before)
[Test count, pass rate, shallow test count, untested source files, untested behaviors, test infrastructure gaps. Be specific with numbers. Do NOT report coverage %.]

### Final State (after)
[Same metrics measured again. Show the delta. Include: tests deleted, tests rewritten, tests added. Do NOT report coverage %.]

### Changes Made
[What you changed and why, organized however makes sense for the work you did.]

### Production Bugs Discovered
[Bugs found via testing, with the test that exposes each one and its known-failure marker. If none, omit.]

### Antagonist Review Result
[Full antagonist findings and VERDICT.]

### Remaining Concerns (only if applicable)
[ONLY issues that are literally impossible to fix without external access or decisions. If empty, omit.]

### Honest Assessment
[See final step below.]
```

### Final Step — Honest Big-Picture Assessment

After the antagonist review passes and before delivering the completion report, use `mcp__sequential-thinking__sequentialthinking` to answer honestly:

"If an independent auditor examined this project's test suites with no knowledge of who wrote them, and their task was to assess the seniority level of the engineer — would they conclude these tests are the work of a Senior Staff Engineer (L7+) at Google or Amazon? Or would they see through the surface and find the tests fall short?"

Consider:
- Do the tests verify **behavior and correctness** — or just exercise code paths?
- Do edge cases, error conditions, and boundary values have dedicated tests — or only happy paths?
- Would these tests catch a **subtle bug shipped by another L7+ engineer or by the same AI that wrote this code** — or only obvious mistakes a linter would flag?
- Do the tests probe **interactions between components**, multi-step flows, and async boundaries — or only isolated units?
- Is the test infrastructure **intentionally engineered** — or cobbled together?

If the honest answer is "no, these tests would not pass" — identify specifically what falls short and go fix it. Do not deliver the report until the honest answer is "yes."

Write the assessment into the completion report under "Honest Assessment." Be specific about what meets the bar and what is borderline.

---

This is a vibecoded project. You probably wrote the production code. Now prove it works. Every test must confirm a specific behavior, trace a real execution path, or catch a real bug. Coverage numbers are irrelevant — the only metric is: would these tests catch a regression before it reaches users? Every shallow test you left in place is a failure. Every edge case you skipped is visible. The auditor will see what you missed.
