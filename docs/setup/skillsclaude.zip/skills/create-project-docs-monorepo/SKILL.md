---
name: create-project-docs-monorepo
description: "Create or refresh pattern-focused documentation for LLM agents in a monorepo (root + per-package, progressive). Bootstraps the two-tier doc stack from scratch — or audits existing docs (ADRs, root and package docs, namespaced Serena memories, CLAUDE.md, AGENTS.md), updates stale content, and cleans up obsolete files (log-style memories, logs, test screenshots, test artifacts)."
argument-hint: "[optional: create | refresh]"
---

# Monorepo Agent Documentation — Create or Refresh (Serena-Aware)

Maintain a **two-tier layered context architecture** for LLM coding agents working in a monorepo:

- **Root tier** — monorepo-wide identity, cross-cutting boundaries, shared style. Always loaded.
- **Package tier** — per-package identity, local conventions, package-unique patterns. Auto-loaded by Claude Code when the agent works inside that package directory (it walks up from cwd, picking up the nearest `CLAUDE.md` and any `docs/*.md` referenced via `@import`).
- **On-demand tier** — Serena memories, namespaced per package. Loaded only when explicitly requested.

Two modes, auto-detected in Phase 0 (or forced via `$ARGUMENTS`):

- **CREATE** — no agent docs exist. Discover patterns, write both tiers (Phases 1–6).
- **REFRESH** — docs exist. Audit both tiers against the current codebase, update stale content, create missing pieces, delete obsolete docs, memories, and artifacts (Phases 1, R1–R5, 6).

## Context Architecture

| Layer | Location | Loaded | Budget |
|-------|----------|--------|--------|
| Monorepo identity, shared constraints, package map | `CLAUDE.md` (root) | Always | 60-120 lines |
| Cross-cutting patterns (architecture, testing, style) | `docs/*.md` at root (via `@import`) | Always | 150-300 lines each |
| Immutable style rules (shared) | `docs/meta/styleguide.md` (via `@import`) | Always | 60-100 lines |
| Package identity, local commands, local patterns | `packages/<name>/CLAUDE.md` | Auto when cwd is in that package | 30-80 lines |
| Package-unique patterns (only if needed) | `packages/<name>/docs/*.md` (via `@import`) | Auto when cwd is in that package | ≤200 lines each |
| Decision records | `docs/adr/` at root (and per-package, if used) | Never auto-loaded | No limit, append-only |
| Detailed examples, conventions | Serena memories (namespaced per package) | On demand | No limit |

**Goal**: An agent working in `packages/foo/` loads root context + foo's context, and **nothing else**. An agent reasoning across packages reads only the root layer plus whatever it explicitly opens.

---

## Phase 0: Detect Monorepo Layout + Determine Mode

### Monorepo detection

Determine whether this is a monorepo, and where packages live. Read (use Serena `list_dir` and `read_file`):

| Signal | Where |
|--------|-------|
| `workspaces` field | root `package.json` |
| `pnpm-workspace.yaml` | root |
| `lerna.json`, `turbo.json`, `nx.json`, `rush.json` | root |
| `Cargo.toml` `[workspace]` | root (Rust) |
| `go.work` | root (Go) |
| Top-level `packages/`, `apps/`, `services/`, `libs/`, `crates/` | root |

**Output**: a list of packages with paths, languages, and frameworks. Example:

```
packages/game-engine    Java + Spring Boot
packages/game-client    SolidJS + Vite
packages/game-studio    React + Vite
packages/backoffice     React + Vite
```

If no monorepo signals are present: stop and tell the user to run `/create-project-docs` instead.

If only one package matters and the rest are scaffolding (e.g. `examples/`, `config/`, `eslint-rules/`): note them as "non-app" — they get listed in the root package map but do NOT get a per-package `CLAUDE.md` unless the user requests it.

### Mode detection

| Check | Tool |
|-------|------|
| Root `CLAUDE.md`, `AGENTS.md`, root `docs/` | Read / `mcp__serena__list_dir` |
| ADR dirs: `docs/adr/`, `docs/decisions/`, `adr/` (root and per-package) | `mcp__serena__list_dir` |
| Per-package `CLAUDE.md` / `docs/` | `mcp__serena__list_dir` |
| Serena memories | `mcp__serena__list_memories` |

- Nothing exists → **CREATE**.
- Docs or memories exist → **REFRESH**.
- Partial (e.g. root docs exist, some packages undocumented) → REFRESH what exists, CREATE what's missing — run both phase sets.

---

## Phase 1: Discover Patterns (both modes, root + per-package)

Use Serena tools for discovery. Do NOT use bash `cat`, `grep`, `find`, or `tree`.

| Need | Serena Tool |
|------|-------------|
| Folder structure | `mcp__serena__list_dir` |
| Base classes, interfaces, patterns | `mcp__serena__get_symbols_overview` |
| Specific abstractions | `mcp__serena__find_symbol` |
| Conventions, naming patterns | `mcp__serena__search_for_pattern` |

Also read root `package.json`, root `CLAUDE.md` (if it exists), root `docs/`, root `.claude/rules/`, and inside each package: `package.json` (or `pom.xml`, `Cargo.toml`, etc.), any existing `README.md` or `CLAUDE.md`, the package's top-level source tree.

### Root-level discovery (cross-cutting)

1. **Repo identity**: what does the monorepo as a whole produce?
2. **Package map**: name → path → language → framework → role.
3. **Cross-package boundaries**: which packages may import which? Are there shared packages (e.g. `@scope/config`, `@scope/ui`)?
4. **Shared tech**: language versions, package manager, monorepo tool (turbo/nx/lerna/pnpm).
5. **Shared commands**: install, build-all, test-all, lint-all, typecheck-all.
6. **Shared style / lint / formatter rules** that apply to every package.
7. **Shared testing infra** (e.g. one Playwright suite across packages, one Vitest config root).

### Per-package discovery (local)

For each package, capture only what is **unique to that package**:

1. **Local folder structure**: where new code of each type goes inside *this* package.
2. **Local framework conventions**: e.g. SolidJS signals vs React hooks, Spring Boot vs Express.
3. **Local base abstractions**: classes, interfaces, primitive components specific to the package.
4. **Local commands** (dev, test, build) — only if they differ from the root commands.
5. **Local anti-patterns** — mistakes specific to this package's stack.

**Critical rule**: anything that applies to *every* package is root-tier. Anything that applies to *one* package is package-tier. If you find yourself writing the same paragraph twice, it belongs at the root.

### REFRESH mode: additionally collect staleness evidence

| Evidence | How |
|----------|-----|
| Code changed since docs last touched | `git log -1 --format=%H -- docs/ CLAUDE.md '**/CLAUDE.md'`, then `git log --stat <sha>..HEAD` scoped to each package |
| Commands drifted | Diff root and package command tables against the actual `package.json` scripts (or equivalents) |
| Package map drifted | Packages added, removed, renamed, or re-pathed since the map was written |
| Dead references | Every file path, symbol, command, and import alias mentioned in any doc or memory — verify it still exists |
| New undocumented patterns | New packages, new base abstractions, new test setups since the last doc update |

---

## CREATE — Phase 2: Write Always-Loaded Root Docs

### Required (4)

1. **`CLAUDE.md`** (root) (60-120 lines) — monorepo identity, shared constraints, package map, root commands, required reading imports.
2. **`docs/architecture.md`** (150-300 lines) — monorepo layout, package responsibilities, cross-package import rules, where new packages go, decision tree: "I need to add code — which package?".
3. **`docs/testing.md`** (100-250 lines) — shared test stack, repo-wide commands, where tests live per package type, shared testing utilities.
4. **`docs/meta/styleguide.md`** (60-100 lines) — immutable style rules that apply to **all** packages.

### Optional Root Docs

Create only if **truly cross-cutting**:

| Project has... | Create root doc |
|---------------|-----------------|
| Shared API contract across packages | `docs/api.md` |
| Shared database/schema layer | `docs/database.md` |
| Multiple frontend packages with shared design system | `docs/frontend.md` |

If a "frontend" concern lives in exactly one package, do **not** create `docs/frontend.md` at root — put it in that package's docs.

### Token Efficiency Rules

| Do | Do Not |
|----|--------|
| Provide the PATTERN for creating new things | List every existing file, component, or endpoint |
| State the current convention | Explain historical decisions |
| Use tables, bullets, decision trees | Write prose paragraphs |
| Reference Serena memories for details | Duplicate detailed examples inline |
| Keep each doc under its budget | Let any doc exceed 300 lines |

### Root Structure Template

```markdown
# [Monorepo Name]

## Identity
[One sentence: what the monorepo as a whole produces]

## Packages
| Package | Path | Language | Role |
|---------|------|----------|------|
| [name]  | `packages/[name]` | [lang]   | [one-line role] |

## Shared Constraints (Immutable)
| Constraint | Rule |
|-----------|------|
| [shared rule] | [detail] |

## Required Reading (always)
@docs/architecture.md
@docs/testing.md
@docs/meta/styleguide.md
[+ any cross-cutting domain docs]

## Per-Package Context
When you start work in a package, Claude Code auto-loads `packages/<name>/CLAUDE.md`.
Do NOT preload all package docs — open them only when you enter that package.

## Root Commands
| Command | Purpose |
|---------|---------|
| [cmd]   | [what it does] |
```

Do NOT duplicate doc content in root `CLAUDE.md` — use `@import` only.

### AGENTS.md policy

If `AGENTS.md` exists (or the repo is used with non-Claude agents like Codex): generate it from the root `CLAUDE.md`, replacing `@import` lines with plain markdown links (other tools do not resolve `@import`). The two files must never drift — regenerate `AGENTS.md` whenever `CLAUDE.md` changes. Do not maintain independent content in both. Apply the same rule to any per-package `AGENTS.md`.

---

## CREATE — Phase 3: Write `docs/meta/styleguide.md` (Root)

This doc contains **immutable rules** that apply across **every** package. Structure:

1. Shared lint / formatter / typecheck rules
2. Shared import patterns (path aliases, no cross-package imports unless explicitly allowed, barrel re-exports)
3. Shared JSDoc / Javadoc / Rustdoc requirement (one-liner + Serena memory reference)
4. Cross-package boundary rules (what's allowed to import what)
5. On-Demand References table (pointing to Serena memories)

Keep under 100 lines. Package-specific style rules (e.g. CSS in a frontend package, package-local lint configs) go in **that package's** docs, not here.

---

## CREATE — Phase 4: Write Per-Package Docs

For each app/library package identified in Phase 0, create:

### Required: `packages/<name>/CLAUDE.md` (30-80 lines)

This is a **short** file. It augments — never restates — the root context. Template:

```markdown
# [Package Name]

## Identity
[One sentence: what this package produces, who consumes it]

## Stack
[Language + key framework + key libraries — one line each, max 4 lines]

## Local Constraints (only if different from root)
| Constraint | Rule |
|-----------|------|
| [local rule] | [detail] |

## Folder Layout
| Code Type | Location |
|-----------|----------|
| [type]    | `src/[path]` |

## Local Commands (only if different from root)
| Command | Purpose |
|---------|---------|
| [cmd]   | [purpose] |

## Required Reading (when working in this package)
@docs/patterns.md         # only if you created package docs in Phase 4b

## See Root For
- Shared style rules → root `docs/meta/styleguide.md`
- Cross-package boundaries → root `docs/architecture.md`
- Shared test commands → root `docs/testing.md`

## On-Demand References
| Domain | Serena Memory |
|--------|---------------|
| [topic] | `<package>_<topic>` |
```

**Rules for package CLAUDE.md**:
- 80 lines max. If it's growing, push detail into a package `docs/*.md` or a Serena memory.
- Do **not** repeat anything in the root CLAUDE.md or root docs. If a rule applies everywhere, it lives at root.
- "See Root For" section is mandatory — it tells the agent where shared context lives without inlining it.

### Optional: `packages/<name>/docs/*.md`

Create a package-local doc **only** when the package has enough unique convention to justify it. Heuristic: if you find yourself writing more than 30 lines of "Common Tasks" or "Templates" specific to this package, lift them into a doc.

Common cases:

| Trigger | File | Budget |
|---------|------|--------|
| Package has its own UI primitives, components, screens | `docs/patterns.md` | ≤250 lines |
| Package has a non-standard test setup (e.g. its own Playwright config) | `docs/testing.md` | ≤200 lines |
| Package owns an API surface different from the root API doc | `docs/api.md` | ≤200 lines |

If you create them, import them from the package's `CLAUDE.md` via `@docs/...`.

**Never** copy root content into a package doc. Cross-reference instead.

### Per-package structure template

```markdown
# [Package] [Topic] Guide for LLM Coding Agents

**Purpose**: Instructions for [specific task in this package].
**Read This When**: working inside `packages/<name>/`.
**Stack**: [package-specific tech]

## [Core Section]
[Table or decision tree — not prose]

## How to [Common Task in this package]
**Template**:
[Copy-paste code template]

**Steps**:
1. [Concrete step]
2. [Concrete step]

## Common Mistakes (specific to this package)
- **Don't**: [package-specific anti-pattern]. **Do**: [correct pattern].

## On-Demand References
| Domain | Serena Memory |
|--------|---------------|
| [detail topic] | `<package>_<memory_name>` |
```

---

## CREATE — Phase 5: Create Serena Memories (Namespaced)

For each domain with conventions worth preserving, create a Serena memory:

```
mcp__serena__write_memory  name="<package>_<topic>"  content="..."
```

**Naming convention**: prefix every package-scoped memory with the package identifier (`backoffice_feature_patterns`, `game_engine_service_patterns`, `game_client_pixi_renderer`). Repo-wide memories use no prefix (`code_style_conventions`, `cross_package_boundaries`).

### Standard Memories (create if applicable)

| Memory Name | Scope | Content |
|------------|-------|---------|
| `code_style_conventions` | Repo | File naming, language config, repo-wide patterns |
| `cross_package_boundaries` | Repo | What imports what, why, enforcement mechanism |
| `<package>_structure` | Package | Detailed folder map for that package |
| `<package>_patterns` | Package | Templates, examples, anti-patterns specific to that package |

### Memory Content Rules

- Include concrete code examples (this is where detail lives)
- Include anti-patterns with corrections
- Cross-reference related memories
- No token budget constraint (loaded on-demand only)
- **Never** create log-style memories: no session handoffs, no "what was done" records, no dated snapshots. Memories teach patterns; git history records events.

---

## REFRESH — Phase R1: Audit Root Docs

Process **every** root doc — `CLAUDE.md`, `AGENTS.md`, every file in root `docs/` (ADRs handled in R3). No sampling.

For each doc, classify every section:

| Verdict | Meaning | Action |
|---------|---------|--------|
| ACCURATE | Matches current codebase | Keep |
| STALE | Right topic, wrong details (paths, commands, package map, boundaries) | Update in place |
| OBSOLETE | Documents a removed feature, pattern, or package | Delete the section (or the whole doc) |
| MISSING | Pattern exists in code but is undocumented | Write it using the CREATE templates above |

Root-specific duties:

- **Package map**: every listed package exists at its listed path; every real package is listed. Fix adds/removes/renames.
- Verify every command against root `package.json` scripts (or equivalent); fix or remove dead ones
- Verify every file path and import alias resolves
- Confirm budgets (root CLAUDE.md ≤ 120, architecture ≤ 300, testing ≤ 250, styleguide ≤ 100). Over budget → move detail into Serena memories
- Rules that now apply to every package but live in one package doc → lift to root
- After CLAUDE.md changes: regenerate `AGENTS.md` per the policy in Phase 2

---

## REFRESH — Phase R2: Audit Per-Package Docs

For **every** package in the Phase 0 map:

1. **Package removed from repo** → delete its `CLAUDE.md`/`docs/`, remove it from the root package map, flag its memories for R4.
2. **New package with no `CLAUDE.md`** → create one (Phase 4 template).
3. **Existing package docs** → same ACCURATE/STALE/OBSOLETE/MISSING classification as R1, plus:
   - ≤80-line budget for package CLAUDE.md; over → push detail to package docs or memories
   - No restated root rules (if found, delete the package copy and cross-reference root)
   - Rule duplicated across two package docs → lift to root, delete both copies
   - "See Root For" section present and accurate
   - Local command tables match the package's actual `package.json` scripts (or equivalent)
4. Per-package `AGENTS.md` (if any) → regenerate from that package's `CLAUDE.md`.

---

## REFRESH — Phase R3: ADRs

Check root ADR dirs (`docs/adr/`, `docs/adrs/`, `docs/decisions/`, `docs/architecture/decisions/`, `adr/`) and any per-package ADR dirs.

ADRs are **append-only records** — never rewrite the decision content of an accepted ADR.

1. Read **every** ADR. Verify its Status field (Proposed / Accepted / Superseded / Deprecated).
2. Code contradicts an accepted ADR → ask the user: did the decision change (write a new ADR, mark the old one `Superseded by ADR-NNN`) or did the code drift (flag as a violation)? Never decide silently.
3. Proposed ADRs whose subject has since been implemented → confirm adoption, update Status.
4. Significant architecture decisions visible in code with no ADR (especially cross-package boundary decisions) → draft new ADRs (sequential number, Status: Accepted, current date).

If no ADR directory exists, skip this phase — do not introduce ADR practice unprompted.

---

## REFRESH — Phase R4: Audit Serena Memories (Namespaced)

`mcp__serena__list_memories`, then **read every memory**. No sampling. Classify each:

| Verdict | Signals | Action |
|---------|---------|--------|
| KEEP | Durable patterns, conventions, templates — still accurate | Nothing |
| UPDATE | Right topic, stale details | `mcp__serena__edit_memory` or rewrite via `write_memory` |
| MERGE | Two memories cover one domain | Merge into one, delete the other |
| RENAME | Wrong/missing package prefix | `mcp__serena__rename_memory` to `<package>_<topic>` |
| ORPHANED | Prefix of a package that no longer exists | Delete (or rename, if the package moved) |
| DELETE | Log-style content (below) | `mcp__serena__delete_memory` |

**Log-style memories — always delete.** They accumulate over time and are the main rot source:

- Date-stamped names: `*_2026_*`, `session_*`, `*_handoff`, `*_log`
- "What was done" history: completed-task logs, fix records, migration journals
- PRD/review/planning notes for features that have since shipped (the code is now the source of truth)
- Stale snapshots: "current state as of [date]" inventories
- Anything an agent never needs in order to **write new code correctly**

The test: *does this memory teach a pattern or convention an agent must follow?* No → delete.

After cleanup:

- Every kept memory is referenced from at least one doc's "On-Demand References" table (root or the matching package)
- No On-Demand References table points at a deleted or renamed memory

---

## REFRESH — Phase R5: Clean Up Obsolete Files

Scan root **and every package** for generated debris:

| Candidate | Typical locations |
|-----------|-------------------|
| Logs | `*.log`, `logs/`, `npm-debug.log*`, lint/build output dumps |
| Test artifacts | `test-results/`, `playwright-report/`, stale `coverage/`, `*.trace.zip` — root and per-package |
| Test screenshots/videos | screenshot dirs full of test-run output, `*.png`/`*.webm` from automation, `__diff_output__/` |
| Dead experiments | scratch files in the repo root or package roots, abandoned `dev-tools/` leftovers |

Safety rules, in order:

1. Run `git status --ignored` first. Gitignored **and** regenerable → delete directly.
2. Untracked but not ignored → list each to the user with a one-line reason; delete only after confirmation.
3. **Tracked** files → never delete without explicit user confirmation.
4. Anything referenced by name elsewhere (grep the repo and docs before deleting) → keep it, or fix the reference first.

---

## Phase 6: Verify (both modes)

### Root always-loaded doc checklist

- [ ] Each root doc under its budget (architecture: 300, testing: 250, styleguide: 100)
- [ ] Root CLAUDE.md has an accurate package map
- [ ] Root CLAUDE.md has no duplicated doc content (uses `@import` only)
- [ ] `AGENTS.md` is in sync with `CLAUDE.md`
- [ ] Imperative language throughout
- [ ] References Serena memories via "On-Demand References" tables

### Per-package checklist (for each package)

- [ ] `packages/<name>/CLAUDE.md` exists and is ≤80 lines
- [ ] Package CLAUDE.md does **not** restate any root rule
- [ ] Package CLAUDE.md has a "See Root For" section
- [ ] Package docs (if any) ≤ budget and contain only package-unique content
- [ ] Package memories are namespaced with the package prefix

### Cross-duplication checklist (monorepo-specific)

- [ ] No rule appears in both root and a package doc
- [ ] No rule appears in two different package docs (if it does, lift it to root)
- [ ] Root `architecture.md` does not repeat `testing.md` content
- [ ] `styleguide.md` does not repeat `architecture.md` content
- [ ] Serena memories do not duplicate doc content

### REFRESH-specific checklist

- [ ] Every doc (root + each package), every memory, every ADR was read and classified — list any skipped and why
- [ ] No doc references a deleted memory, file, package, or command
- [ ] No docs or memories remain for removed packages
- [ ] Deletion list for non-ignored files was shown to the user before removal

### Token budget verification

```
Always-loaded at root:
  CLAUDE.md:        60-120 lines
  architecture.md:  150-300 lines
  testing.md:       100-250 lines
  styleguide.md:    60-100 lines
  [+ optional]
  ─────────────────
  Subtotal:         < 1000 lines

When working in a package (additional):
  packages/<name>/CLAUDE.md:   30-80 lines
  packages/<name>/docs/*.md:   ≤200 lines each (if present)
  ─────────────────
  Subtotal:         < 400 lines added on top of root

Total when working in any single package: < 1400 lines
Total when reasoning cross-package: < 1000 lines (root only)
```

---

## Success Criteria

An LLM agent can:

1. From any cwd in the repo, read root `CLAUDE.md` and know the monorepo identity, package map, shared constraints, and root commands.
2. When entering a package directory, automatically pick up that package's `CLAUDE.md` and know its stack, local layout, and local commands without rereading the root.
3. Know which package owns a given concern by consulting the root package map and `docs/architecture.md`.
4. Load a Serena memory by its namespaced name to get detailed examples for the current package/domain.
5. Never have to read another package's docs when working in one package.
6. Read the root layer only when reasoning about cross-package work.

**Output summary (CREATE)**:

```
Created monorepo agent documentation:

Always-loaded at root:
- CLAUDE.md (X lines) — Monorepo identity, package map, shared constraints
- docs/architecture.md (X lines) — Cross-package layout, boundaries, decision trees
- docs/testing.md (X lines) — Shared test stack, repo-wide commands
- docs/meta/styleguide.md (X lines) — Immutable shared style rules
[+ any cross-cutting domain docs]

Per-package (auto-loaded when working inside that package):
- packages/<a>/CLAUDE.md (X lines) — <a> identity, local layout, local commands
- packages/<a>/docs/*.md — <a>-specific patterns (only if needed)
[+ repeated per package]

On-demand (Serena memories, namespaced):
- code_style_conventions, cross_package_boundaries (repo-wide)
- <package>_structure, <package>_patterns (per package)

Total always-loaded: ~X lines (root only)
Total when working in one package: ~X lines (root + that package)
Cross-duplication: verified zero (root↔package and package↔package)
```

**Output summary (REFRESH)**:

```
Refreshed monorepo agent documentation:

Root docs:    X updated, X sections removed, X created, X deleted (list)
Package docs: X packages audited — X updated, X created (new packages), X deleted (removed packages)
ADRs:         X status updates, X new, X flagged for user decision (list)
Memories:     X kept, X updated, X merged, X renamed, X deleted (list deleted with reason)
Artifacts:    X files deleted (gitignored), X removed after confirmation (list)
AGENTS.md:    regenerated from CLAUDE.md (root [+ packages])

Total always-loaded: ~X lines root, ~X lines max per package (was ~X / ~X)
Cross-duplication: verified zero (root↔package and package↔package)
Skipped: [none, or list with reasons]
```
