---
name: commit
description: Commit and push to remote without opening a PR.
allowed-tools:
  - Bash
  - Read
  - Grep
  - Glob
---

## Task
Commit all uncommitted changes in the working tree as atomic commits, with optional context for commit messages. Fix any issue found during validation.

## Constraint
Push to the remote without opening a PR. Do not open a PR.
