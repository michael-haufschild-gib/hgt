# Prompt Optimization Workflow

## Warning: Better Can Hurt

Generic prompt improvements have been measured degrading task-specific performance:
- Extraction pass rate: 100% → 90%
- RAG compliance: 93.3% → 80%

Never deploy an "improved" prompt without evaluating against the original on real task inputs.

---

## Audit Workflow

### Step 1: Read and Understand
Read the existing prompt completely. Identify its target model, output type, and intended task.

### Step 2: Classify Output Type
Map the prompt to an output type from the SKILL.md routing table. Load the relevant references for that type.

### Step 3: Check Anti-Patterns
Audit against the ANTI-PATTERNS table in SKILL.md. Mark every match for removal.

Common findings:
- Generic "think step by step" → remove. Structured decomposition for complex tasks → acceptable
- Anti-laziness directives ("be thorough") → remove
- Aggressive tool language ("CRITICAL: MUST") → soften
- Rationale without mechanism ("because consistency is important") → remove. Rationale naming a transferable mechanism → keep
- Schema far from output step → move adjacent
- Unbounded retry loops → cap at one

### Step 3b: Human Voice Purge (most common optimization finding)
Read every sentence and apply the deletion test: "If I remove this, does the agent produce different output?" Delete every sentence that fails this test.

Target these categories — they are the most frequent contamination in existing prompts:
- **Narration**: history of changes, "previously X now Y", version notes, deprecation context, problem descriptions when only the solution matters
- **Pedagogy**: background "for understanding" that restates training knowledge, definitions of known terms, edge cases inferable from the stated principle. **Keep** rationale that enables generalization to cases the rules don't enumerate — reasoning models use this as substrate for edge-case judgment
- **Rhetoric**: "you may want to consider", "note that", "keep in mind", transitional sentences, meta-commentary about sections
- **Redundancy**: same rule restated in different words, summaries of what was just said, introductory sentences that repeat the header

This step typically removes 20-40% of an existing prompt's content. That is expected and correct.

### Step 4: Check Structural Requirements
Against the loaded type-specific reference, verify:
- Correct structural pattern (e.g., CLAUDE.md under 200 lines with @imports)
- Required sections present (e.g., compaction guidance, session management)
- Attention anchoring (critical rules at start AND end)
- Short hop distance (schemas adjacent to output)

### Step 5: Check Signal Relevance
- Is anything loaded that isn't relevant to the agent's task?
- Are there redundant sections (ToC, summaries, "see also")?
- Could @imports or reference files improve organization?
- Is state tracked in files or accumulating in conversation?

### Step 6: Draft Improvements
Apply fixes. Preserve the original prompt's intent and task-specific tuning. Do not add features, complexity, or "improvements" the user did not ask for.

### Step 7: Adversarial Review
Use `mcp__sequential-thinking__sequentialthinking` to attack the revised prompt. Follow the ADVERSARIAL REVIEW section in SKILL.md. Do not skip this step. Do not accept the draft without finding at least one defect — if you found none, you reviewed too superficially.

### Step 8: Synthesize
Incorporate valid criticisms from the adversarial review. Do not defend the draft.

### Step 9: Before/After Comparison
Present the changes as a diff or side-by-side. State what was changed and the specific defect it fixes.

### Step 10: Quality Gate
Run the QUALITY GATE from SKILL.md on the revised prompt.

---

## Iteration Principles

- **Iterate on observed failures, not theoretical completeness.** Watch the model fail, then fix the specific failure pattern.
- **SCOPE framework**: corrective synthesis from failure traces + enhancement from successful patterns. Both streams feed prompt evolution.
- **Evaluate before and after.** If you cannot measure improvement, you cannot claim it.
- **Do not stack techniques.** Generic CoT + ReAct + Step-Back stacked together performs worse than zero-shot on frontier models. Apply one technique with clear justification.

---

## Quick Audit Checklist

- [ ] No anti-laziness directives
- [ ] No generic CoT for frontier models — structured decomposition for complex tasks acceptable
- [ ] Tool language softened
- [ ] Output schema adjacent to output step
- [ ] No redundant sections (ToC, summary, changelog)
- [ ] Critical rules at start AND end (attention anchoring)
- [ ] Under line/char limit for target format
- [ ] Model-specific formatting applied
- [ ] One retry max in any loop
- [ ] State persisted to files, not conversation
- [ ] Human voice purge applied — no narration, rhetoric, or redundancy remains. Rationale kept only where it enables generalization beyond enumerated rules
- [ ] Adversarial review performed via sequential thinking — findings incorporated
- [ ] Anti-sycophancy constraints present (if prompt targets decision/review/advisory agent)
