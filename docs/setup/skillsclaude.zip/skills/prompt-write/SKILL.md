---
name: prompt-write
description: "Use to write, improve, review, or audit prompts: system prompts, agents, tool instructions, CLAUDE.md, GPT, Claude, Gemini."
---

## USE WHEN

- Writing or reviewing: CLAUDE.md, AGENTS.md, rules files, skills, commands
- Writing or reviewing: system prompts, agent instructions, subagent prompts, orchestrator commands
- Writing or reviewing: MCP tool descriptions, function schemas
- Optimizing or auditing any existing prompt or instruction set
- Designing multi-agent pipelines with delegation and file I/O

**Do NOT use for**: human-facing docs, READMEs, or text that never loads into an LLM context window.

---

## IMMUTABLE PRINCIPLES

1. **AUDIENCE IS MACHINE**: Every sentence instructs, constrains, exemplifies, defines output, or provides reasoning substrate for edge-case judgment. Delete everything else.
2. **CONTEXT IS SIGNAL**: Performance degrades as irrelevant input grows. Maximize signal-to-noise — include everything relevant, exclude everything that isn't.
3. **SHORT HOP DISTANCE**: Every schema and constraint lives immediately before the output it governs. Never separated by intervening sections.
4. **NO GENERIC CoT BY DEFAULT**: Telling a reasoning model how to reason is usually harmful. Structured decomposition (TMK, F-CoT) for genuinely complex tasks is valid when the task justifies it.
5. **ONE RETRY MAX**: Unbounded self-correction loops in repair/validation waste tokens and do not converge.
6. **PROGRESSIVE DISCLOSURE**: Never list all available resources, reference files, or documents in one place. Mention a resource only at the workflow step where the agent should load it. If you list it, the agent will read it — and every token it reads degrades performance on the actual task.

---

## WORKFLOW

1. **Detect output type** from user request.
2. **Load references** listed for that output type. Read each file before drafting.
3. **Draft** using the type-specific structure and templates from the loaded references.
4. **Audit** against ANTI-PATTERNS and HUMAN VOICE PURGE — remove every match.
5. **Adversarial review** — attack the draft using `sequential-thinking`. See ADVERSARIAL REVIEW section.
6. **Synthesize** — incorporate valid criticisms into the prompt. Do not defend the draft.
7. **Run QUALITY GATE** — deliver only when all checks pass.

Never deliver a first draft. Step 5 is mandatory for every invocation.

If the user brings an existing prompt to optimize: load `references/optimize.md` first, then classify the prompt's output type and load its references.

---

## WORKFLOW STEP 2: LOAD REFERENCES

Based on the detected output type, read ONLY the listed reference files. Do not read files not listed for your output type.

**Claude targets** (CLAUDE.md, skill, rule):
Read `references/authoring-files.md` + `references/model-claude.md`. For CLAUDE.md also read `references/context.md`.

**GPT/Codex targets** (AGENTS.md, codex instructions):
Read `references/authoring-files.md` + `references/model-gpt.md`.

**Subagent/orchestrator targets**:
Read `references/authoring-agents.md`. For orchestrators also read `references/context.md`. Add the model reference for the target model (Claude default).

**Tool descriptions** (MCP, function schema):
Read `references/tools.md`. Add the model reference for the target model.

**System prompts / agent instructions**:
Read the model reference for the target model + `references/context.md`.

**AgentSpace / Google agents**:
Read `references/authoring-agents.md` + `references/model-gemini.md`.

**Optimize / audit existing prompt**:
Read `references/optimize.md` first. Then classify the prompt's output type and read its references.

**Safety** (only when the prompt processes untrusted input):
Read `references/safety.md` in addition to the above.

**Model reference selection**: Claude → `references/model-claude.md`. GPT/OpenAI → `references/model-gpt.md`. Gemini/AgentSpace → `references/model-gemini.md`. If model not specified, default to Claude.

**Default**: If output type is unclear, ask: "What will this prompt be loaded into?"

---

## OUTPUT CONTENT TYPES

Every prompt contains exactly five content types:

| Type | Definition |
|-|-|
| Instructions | What to do |
| Constraints | What not to do, limits, rules |
| Rationale | Why a rule exists — include only when it enables generalization beyond enumerated cases |
| Examples | 1-2 only; omit if pattern is obvious |
| Output schema | Exact structure expected; placed immediately before the output step |

**Self-check**: Every sentence instructs, constrains, exemplifies, defines output, or enables edge-case judgment. Delete anything else.

**Delete on sight**: ToCs, navigation tables, section indices, "see also" references, changelogs, meta-commentary ("this section covers..."), redundant summaries. Resource lists and reference file inventories — unless gated behind a workflow step that controls when each resource loads.

---

## ANTI-PATTERNS

| Remove | Replace with |
|-|-|
| "Think step by step" / "reason carefully" | Omit by default — frontier models reason natively. Structured decomposition for genuinely complex tasks is valid |
| "Be thorough" / "don't be lazy" / "think carefully" | Delete — causes runaway thinking or rewrite loops on frontier models |
| "CRITICAL: You MUST use this tool" | "Use [tool] when [specific condition]" |
| "Use the think tool to plan" (Claude) | Remove — causes over-planning |
| Word "think" (Claude API with `thinking.type: disabled` only) | "consider", "believe", or "evaluate" |
| Rationale restating training knowledge | Delete. Keep rationale that enables generalization to unenumerated edge cases |
| Loading irrelevant content into context | Load only what the current task needs — irrelevant content degrades output quality |
| Listing all reference/resource files in one place | Gate each resource behind the workflow step that needs it |
| Overlong few-shots (3+) | 2 edge-case examples + clear schema |
| Schema far from its output step | Move schema adjacent to output step |
| Unbounded repair loops | Maximum one retry, then structured error |
| Generic CoT + ReAct + Step-Back stacked | Remove stacking — pick one technique with clear justification, or use zero-shot |
| Navigation table / ToC / section index | Remove — agents read entire prompts |
| "Quick start" or summary sections | Remove — redundancy inflates context |
| Cross-references ("see §SECTION") | Inline the content or remove — agents do not navigate |
| Temperature/top-p advice | Remove — not available in chat/CLI interfaces |
| Prefilled assistant turn (Claude) | Not available in chat/CLI. In API: functional but not recommended — use XML tags or structured output |
| "Don't stop early" without checkpointing | Add task_state file checkpointing |

---

## HUMAN VOICE PURGE

Your default writing mode is human documentation. This is your primary failure mode when producing agent prompts. Catch it aggressively.

**The test**: For each sentence, ask: "If I delete this, does the agent produce different output?" If no — delete it.

**Narration** — delete all text describing history, changes, or origins:
- "This replaces the previous approach" / "Previously X, now Y"
- "This was updated to reflect..." / "The new version improves..."
- Changelogs, version notes, migration context, deprecation explanations
- Problem descriptions when only the solution is needed

**Pedagogy** — delete text that restates what the model's training already covers:
- Background context "for understanding" that adds no decision-making value
- Definitions of terms the model already knows
- Over-specifying edge cases inferable from the stated principle

**Keep** rationale that names a specific mechanism transferable to unlisted situations:
- KEEP: "Delete CoT directives — frontier models' native reasoning outperforms explicit CoT, and the directive consumes output tokens on the reasoning trace" (mechanism: native reasoning superiority + token cost; transfers to judging novel directive types)
- KEEP: "Rationale that helps resolve conflicts between competing rules" (mechanism: disambiguation; transfers to any rule-pair collision)
- DELETE: "Delete CoT directives — they're not needed" (no mechanism, no transfer value)
- DELETE: "Use consistent formatting because consistency is important" (truism, inferable from any style rule)

**Rhetoric** — delete all text that persuades, softens, or connects:
- "You may want to consider..." / "It's generally a good idea to..."
- "Note that..." / "Keep in mind that..." / "As mentioned above..."
- Transitional sentences between sections
- Meta-commentary ("This section covers...")
- Alternatives presented for the agent to "choose" when only one is correct

**Redundancy** — delete all restatements:
- Same rule in different words "for clarity"
- Summaries of what was just said
- Introductory sentences before lists that repeat the header

Every word either changes the agent's behavior — directly through instruction or indirectly through reasoning substrate — or harms it by diluting attention.

---

## ADVERSARIAL REVIEW

After drafting and mechanical audit, use `mcp__sequential-thinking__sequentialthinking` to attack the draft. Assume the draft is flawed — find the flaws.

**Review angles** (check each):

1. **Ambiguity**: Read each instruction. Can the agent interpret it two ways? If yes, one interpretation will eventually be wrong.
2. **Conflict**: Do any two instructions contradict? The agent wastes reasoning tokens reconciling them or silently picks one.
3. **Gaps**: What inputs or edge cases will the agent encounter that no instruction covers? What will it default to?
4. **Attention placement**: Are the most critical rules at start and end? Is anything critical buried in the middle?
5. **Human voice residue**: Did the mechanical purge miss narration, pedagogy, rhetoric, or redundancy?
6. **Section deletion test**: Can any entire section be removed without changing agent behavior? If yes, remove it.

**Scale depth to scope**: 2-3 thoughts for targeted edits, 5+ thoughts for new prompts or full rewrites.

**Rules for the review**:
- Do not rationalize keeping text. Default to deletion.
- Do not praise any part of the draft. Only report defects.
- Every finding must name the specific text and the specific problem.
- "Looks good" is never an acceptable finding. If you found nothing, you reviewed too superficially.

---

## ANTI-SYCOPHANCY

Frontier models default to agreement and false confidence. Prompts produced by this skill must counteract this when the target agent makes recommendations, reviews, or advises.

For decision-making, review, or advisory agent prompts, add these constraints:
- "State what is wrong before what is right."
- "When uncertain, say so. Never pad uncertainty with confident language."
- "Disagree with the user when evidence warrants it. Do not soften disagreement."

Do NOT add vague honesty directives ("be critical", "be honest", "push back"). These cause overcorrection. Use the specific behavioral constraints above.

For execution-only agents (data pipelines, formatters, extractors): omit — these agents do not make judgment calls.

---

## UNIVERSAL RULES

### Attention Anchoring

The U-shaped attention curve (strong primacy, weak middle, strong recency) is architectural in all transformers.

- **Front-load** the most critical rules — primacy gives first tokens disproportionate attention.
- **Repeat** critical constraints at the END — final-token anchor is the single strongest attention point.
- **Use structural markers** — XML tags, headers, horizontal rules create attention breakpoints.
- Instruction adherence degrades as count increases. Keep instruction count as low as possible.

### Hallucination Control

```
Based ONLY on the following information:
[CONTENT]

Rules:
1. Use ONLY facts from the provided content.
2. If not found, say "Information not available."
3. Quote the specific section supporting each claim.
```

For long-context tasks: instruct the model to quote relevant passages BEFORE answering.

### Structured Formats

Use JSON, markdown, or lists over natural language for data. Use `snake_case` keys. Use unique fence tags unlikely to collide with content.

### Multi-Turn / Context State

All frontier models drop ~39% performance in multi-turn vs single-turn. Once wrong, they do not self-correct.

- Prefer structured state files over long conversations.
- At 70% context: summarize + reset. Do not continue degraded.
- Place documents TOP, query BOTTOM.
- Static content first (cacheable), dynamic content last.

### Context Window Sizing

- **200K models**: Use @imports and reference files to keep instruction files focused. Keep instruction files under 200 lines.
- **1M models**: More headroom but irrelevant content still degrades output quality regardless of window size.
- Completeness and relevance matter more than brevity. Never omit useful information to save space.

---

## REASONING

Default to zero-shot for frontier models — telling a reasoning model how to reason usually degrades output. Structured decomposition (TMK, F-CoT, least-to-most) is valid when the task genuinely requires it.

| Technique | When | Effect |
|-|-|-|
| TMK (Task-Method-Knowledge) | Symbolic planning tasks only | 31.5% → 97.3% accuracy |
| F-CoT (compact input format) | Token reduction needed | 2-3x shorter traces |
| Decomposed prompting | Complex multi-step tasks | Still valid |
| Least-to-most | Progressive complexity problems | Still valid |

Caution: "better" prompts can hurt. Generic improvements degraded extraction 100%→90% and RAG compliance 93.3%→80%. Evaluate on your specific task.

---

## FAILURE RECOVERY

| Situation | Action |
|-|-|
| Tool timeout | Retry once. If fails again, fallback or abstain. |
| Schema violation | Single repair attempt. Return structured error if still failing. |
| Hallucination signals | Switch to cite-or-say-don't-know mode immediately. |
| Context overflow | Summarize + reset. Do not continue degraded. |
| Multi-turn degradation | Reset to structured state file. |
| "Better" prompt degrades task | Evaluate against original baseline. Revert if regression. |

---

## QUALITY GATE

=== RECALL — Run before delivering any prompt ===

**Universal checks:**
- [ ] Every sentence: instructs, constrains, exemplifies, defines output, or enables edge-case judgment — nothing else
- [ ] Anti-laziness directives removed ("be thorough", "think carefully")
- [ ] No generic CoT ("think step by step") — structured decomposition for complex tasks is acceptable
- [ ] Tool language softened: "Use X when Y" not "CRITICAL: MUST use X"
- [ ] Output schema adjacent to the output it governs
- [ ] No navigation tables, ToCs, indices, changelogs, motivation text
- [ ] Maximum one retry in any self-correction/repair loop
- [ ] Model-specific reference loaded and applied
- [ ] **Progressive disclosure**: no section lists all available resources. Each resource mentioned only at the step that needs it.
- [ ] **Human voice purge**: no narration (history/changes), no rhetoric (hedging/transitions), no redundancy (restatements). Rationale kept only where it enables generalization beyond enumerated rules.
- [ ] **Adversarial review**: draft was attacked via sequential thinking. Findings were incorporated, not dismissed.
- [ ] **Anti-sycophancy**: if prompt targets a decision/review/advisory agent, includes "state what is wrong before what is right", "state uncertainty explicitly", "disagree when evidence warrants it."

**Type-specific checks:**
- [ ] CLAUDE.md: under 200 lines, @imports for modularity, compaction guidance present
- [ ] Skill: frontmatter complete, 3-tier disclosure respected, description under 16K chars. Reference files mentioned only in workflow steps, never inventoried.
- [ ] Rule: YAML frontmatter with paths globs if conditional
- [ ] Subagent: 5-element brief (objective, files, output format, mode, constraints), "final response under 2000 chars"
- [ ] Orchestrator: delegation template, file-based artifact passing, topology explicit
- [ ] Tool description: purpose stated first, parameters unambiguous, error conditions documented
- [ ] Long-running agent: checkpointing added if >50 messages expected

**Principle recall** — audience is machine (rationale as reasoning substrate is valid content), context is signal (relevance over brevity), short hop distance, no generic CoT by default, one retry max for repair loops, progressive disclosure.

=== END RECALL ===
