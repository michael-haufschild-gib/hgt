---
name: write-news-article
description: >-
  Use when writing news articles, breaking news, standard news reports, investigative pieces, or journalistic explainers. Produces accurate, attributed, objective articles using Five Ws + H, inverted pyramid structure, AP-style conventions, source verification, and neutral attribution.
metadata:
  short-description: News article writing
---

# News Article Writing

## Workflow

1. Determine story type: breaking news, standard news, feature, investigation, or explainer.
2. Establish Five Ws + H: who, what, when, where, why, and how.
3. Verify newsworthy claims with at least two credible independent sources when possible. Browse for current or uncertain facts.
4. Identify source names, titles, affiliations, and why each source is in position to know.
5. Write the lead first. Put the most important verified fact up front.
6. Order body paragraphs by descending importance. Assume readers may stop anywhere.
7. Include background, competing perspectives, and context only after the core facts.

## Reporting Standards

- Do not fabricate facts, quotes, sources, locations, dates, or context.
- Attribute opinions and disputed claims.
- Use neutral attribution verbs, especially "said".
- Use anonymous sources only when the information is newsworthy, the source is credible, and anonymity has a legitimate reason.
- Avoid editorializing in straight news.
- Use reporter presence markers only when grounded: "According to documents reviewed...", "Reached by phone...", "In an interview...".

## Style Rules

- Lead target: 25-35 words, answering as many Five Ws + H as possible.
- One idea per paragraph.
- Paragraphs: 2-4 sentences.
- AP-style defaults: spell out one through nine, use numerals for 10+, lowercase titles after names, format time as `3 p.m.`, avoid serial comma unless needed for clarity.
- Use specific geographic and temporal details instead of vague "recently" or "local officials".

## Output

Return:

```markdown
# [Headline]

[article]

## Verification Notes
- Sources used: [list]
- Facts still unverified: [none/list]
```

Omit verification notes only if the user requests article-only output.

## Final Check

- Lead answers core facts.
- Article follows inverted pyramid.
- Every quote and opinion has attribution.
- No unsupported current claim remains.
