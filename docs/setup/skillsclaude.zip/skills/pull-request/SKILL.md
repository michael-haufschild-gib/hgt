---
name: pull-request
description: Commit all uncommitted changes as atomic logical commits and push. Open a PR.
allowed-tools:
  - Bash
  - Read
  - Grep
  - Glob
---

## Task
Commit all uncommitted changes in the working tree as atomic commits, with optional context for commit messages. Fix any issue found during validation.

Then push to the remote. Open a PR.
