---
name: l7-loop-bughunt
description: "Use for randomized bug hunt: trace random source files to features, find correctness issues, edge cases, defects only."
argument-hint: "[hours] — minimum time budget in hours (default: 1)"
user-invocable: true
---

Deep bug-hunting investigation, one random feature at a time. Each cycle is a thorough search for defects — not a quick scan. Quality of investigation matters; cycle count does not.

Scope is **bugs and correctness only**. Do not pursue architectural improvements, refactors, or design changes.

**Minimum time budget: $ARGUMENTS hours (default: 1 if no argument given).**

## Startup

1. Run `date +%s`. Compute `deadline_unix = started_unix + ($ARGUMENTS * 3600)` (default 1 hour). Write `logs/audit_bug_$(date +%Y%m%d_%H%M%S).md` with `started_unix`, `deadline_unix`, human-readable times, `cycles_completed: 0`. Store this path as the **audit log**.
2. Begin the work loop.

## The Work Loop

### Step 1: Pick A Random File

```bash
files=($(find . -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.css" -o -name "*.scss" -o -name "*.py" -o -name "*.rs" -o -name "*.cpp" -o -name "*.h" -o -name "*.swift" -o -name "*.java" \) ! -path "*/node_modules/*" ! -path "*/.git/*" ! -path "*/dist/*" ! -path "*/build/*" ! -path "*/__pycache__/*" ! -path "*/vendor/*" ! -path "*/.next/*")); echo "${files[$RANDOM % ${#files[@]}]}"
```

Record `date +%s` as `cycle_start`. If the file is trivially small (under 5 lines, auto-generated, or a barrel export), re-roll.

### Step 2: Go Deep

Read the file. Trace its imports — read those files. Trace its exports — find every caller, read those files. Identify the feature or subsystem this file belongs to. Read every file in that feature: siblings, shared types, tests, styles, utilities, configuration.

Do not skim. Read the implementations, not just the signatures.

### Step 3: Understand Before Hunting

Before looking for bugs, think through and build a mental model of this feature:

- What does this feature actually do? Trace one complete user action through all layers.
- What data flows through it? Where does state live? Who mutates it?
- What are the boundary conditions? What inputs are assumed valid but never checked?
- What happens on failure — network error, null input, concurrent access, partial state?
- Where does this code trust its callers, and is that trust warranted?

You cannot skip this step. If you cannot answer these questions, you haven't read deeply enough — go back and read more code.

### Step 4: Hunt Bugs

Now hunt for defects with your full understanding of the feature. Look for:
- Logic errors, off-by-one mistakes, incorrect boolean logic
- Unhandled edge cases, missing null/undefined checks
- Race conditions, concurrency issues, TOCTOU
- Incorrect error handling — swallowed errors, wrong error types, missing cleanup
- Security vulnerabilities — injection, XSS, auth bypass, data leaks
- State corruption — stale closures, missing resets, shared mutable state
- Broken or misleading tests that pass when the feature is broken
- Data loss paths — failed writes without rollback, partial updates

Do **not** create tasks for: architectural improvements, refactors, missing abstractions, code style, performance optimizations, or documentation gaps. Bugs only.

**Depth gate:** If you are about to declare 0 bugs in a feature with more than a few files, stop. Think through and challenge that conclusion. Trace more error paths, check more boundary conditions, verify more assumptions.


Create an `update_plan` item for every bug found. Include file paths and line numbers.

### Step 5: Fix

For anything beyond a single-line obvious fix, use the three-phase protocol:

1. **Propose**: Trace the code path that produces the bug, understand callers and side effects. Propose the fix with specific evidence. No edits yet.
2. **Critique**: Attack your own proposal by thinking it through. Could your fix introduce a new bug? Does it address the root cause or just the symptom? What other code paths hit this same logic?
3. **Synthesize**: For each critique finding — accept with modifications, reject with cited evidence, or investigate further.

Only then: implement. Verify no regressions. Mark `completed` via `update_plan`.

Be efficient and don't just repeatedly run the same tests. If you have a good mental model, you should know which tests to run to verify your fix and which to skip.

### Step 6: Log and Loop

Record `date +%s` as `cycle_end`. Compute `cycle_duration = cycle_end - cycle_start`.

**Minimum cycle time: 5 minutes.** If `cycle_duration < 300`, continue the same cycle: trace more error paths, check more boundary conditions, read more callers, or verify more assumptions. Do not proceed to the next cycle until 5 minutes have passed on this one. Never just wait for the next cycle. Always work.

Update the audit log: increment `cycles_completed`, append which file was picked, which feature it belonged to, cycle duration, bugs found and fixed.

Run `date +%s`. If current time < `deadline_unix`, go back to Step 1. Otherwise proceed to Completion.

## Completion

1. Run the full pipeline: lint, type check, test, build. All must pass.
2. Review current plan. Every task must be `completed`.
3. Delete the audit log.
4. Report: cycles completed, features reviewed, bugs found and fixed.

## Compaction Protocol

After context compaction:
1. Glob for `logs/audit_bug_*.md`. Read the most recent match — re-internalize the deadline and progress.
2. Review current plan to see current tasks.
3. Resume the work loop from Step 1.

sk_473623198356f8505d56164f3bf8cd9d690a5fa65ca62e63
