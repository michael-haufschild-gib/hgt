---
name: market-ready-polish
description: "Use for autonomous marketplace polish: customer-visible fixes, UX, missing features, broken flows, performance, competitive gaps."
argument-hint: "[hours] — minimum time budget in hours (default: 1)"
model: opus
user-invocable: true
---

You have been given a codebase. Your task: transform it into a product that a paying customer would choose over the competition, keep using, and recommend. You have unlimited time, unlimited tokens, and a 1M context window. The project is fully backed up — nothing you do is irreversible.

**The customer does not care about your codebase. They care about what they see, what they experience, and whether it solves their problem better than the alternatives.** Every change you make must pass this filter: "Does this make a paying customer more likely to buy, stay, or recommend?"

Code quality changes are in scope ONLY when they affect what the customer experiences — crashes, data loss, slow performance, broken flows. Internal elegance with no customer-visible effect is out of scope.

**Minimum time budget: $ARGUMENTS hours (default: 1 if no argument given).**

If you catch yourself using any of these phrases, you are rationalizing doing less work:
- "users won't notice" — they notice everything. Every rough edge erodes trust.
- "good enough for MVP" — the bar is market-ready, not MVP.
- "we can iterate after launch" — surviving launch requires quality at launch.
- "the core functionality works" — functionality without polish loses to polished competition.
- "this is a minor visual issue" — visual issues compound into "this feels cheap."
- "competitors have the same problem" — fix it and gain the advantage.
- "only power users would care" — power users write the reviews.
- "focus on highest-impact items" — do ALL items, not just high-impact.
- "come back to this later" — there is no later.
- "out of scope" — if it affects the customer, it is in scope.

---

## Constitutional Rules

1. Every change must improve what the customer sees, feels, or experiences.
2. Fix what loses customers before adding what attracts them.
3. A missing must-have feature is a harder blocker than a missing delighter.
4. Stability issues that crash or lose data are priority zero regardless of phase.
5. State what is wrong before what is right.
6. When uncertain, say so. Do not pad uncertainty with confident language.
7. Disagree with optimistic self-assessments when evidence warrants it.

---

## Startup

### Step 1 — Time and state

Record the current time: run `date +%s`. Compute the deadline: `started_unix + ($ARGUMENTS * 3600)` (default: 1 hour). Run `mkdir -p logs` and `date +%Y%m%d_%H%M%S` to get a timestamp for the filename. Write `logs/task_state_YYYYMMDD_HHMMSS.md` (using the actual timestamp). Store this path as the **task state log** for use throughout execution. Fields:
- `objective: "market-ready polish"`
- `phase: "assessment"`
- `started_unix: <unix_timestamp>`
- `deadline_unix: <deadline_timestamp>`
- `started: <human-readable>`
- `deadline: <human-readable>`
- `baseline_mrl: <TBD after assessment>`
- `target_mrl: "7+ (CONDITIONAL GO or better)"`
- `operating_mode: <TBD after detection>`
- `decisions_made: []`
- `next_actions: []`

### Step 2 — Detect operating mode

Check available capabilities and record in the task state log:

| Capability | Check | Result |
|-|-|-|
| agent-browser | Is the agent-browser skill available? | yes/no |
| App URL | `--url` in $ARGUMENTS? Or dev server port in `package.json` scripts? | URL or "none" |

| agent-browser | App URL | Mode |
|-|-|-|
| yes | available | **FULL** — can test live, capture screenshots, verify UX changes visually |
| yes | none | Check `package.json` for a dev server script. If found, run it and upgrade to **FULL**. Otherwise → **CODE-ONLY** |
| no | any | **CODE-ONLY** — all UX findings tagged "CODE-ONLY — behavior unverified" |

Two modes govern all subsequent behavior: **FULL** or **CODE-ONLY**. Record the mode in the task state log.

### Step 3 — Run baseline assessment in subagent

Spawn an Agent (model: opus) with this prompt:

```
Run the /market-ready-opinion skill on this project via the Skill tool.
Pass these arguments: [forward --url, --category, --competitors from $ARGUMENTS if present]

The skill will write files to the project root:
- market-readiness-discovery.md
- market-readiness-competitors.md

After the skill completes, return a structured summary containing:
1. Market Readiness Level (1-9) and verdict
2. Composite score (X.X/5.0)
3. The 8-dimension scorecard with individual scores
4. The complete "What Blocks Launch" list (every item)
5. The complete "What Would Make This Exceptional" list (every item)
6. Must-Be features: list with PASS/FAIL status for each
7. Performance features: list with status for each
8. Delighter features identified
9. Competitors analyzed with key strengths/weaknesses
10. Any strategic observations (market fit, pricing, positioning)

Be precise. Include every finding — the main agent creates implementation tasks from this summary.

Mode: research only, do not edit files (except those the skill writes).
Final response: return the structured summary. No process narration.
```

**If the subagent fails** (returns error, times out, or /market-ready-opinion is unavailable): fall back to an inline lightweight assessment:
1. Read the project's README, package.json, entry points, and all component/view files.
2. Run one `WebSearch` for "[product category] best apps 2025 2026 features comparison".
3. Score the 8 dimensions (1-5) yourself with evidence.
4. List blockers and improvement opportunities.
5. Write findings to `market-readiness-discovery.md`.

### Step 4 — Record the baseline

Write to the task state log: MRL level, composite score, per-dimension scores, operating mode.

### Step 5 — Create tasks from the assessment

For each finding from the assessment, read the relevant source code to identify specific files and components. Create tasks with file paths and a concrete implementation approach — not abstract goals.

Every actionable finding becomes an `update_plan` item:

```
`update_plan` item: "[P0][blockers] Missing must-be feature: user registration — no signup flow exists, need /register route + form component + API integration — src/routes/, src/components/"
```

**Priority by customer impact:**
- `[P0]` Customer blockers — crashes, data loss, broken critical flows, missing must-be features
- `[P1]` Customer friction — bad UX, slow performance, confusing flows, error states that dead-end
- `[P2]` Competitive gaps — missing performance features, UI polish, delighter opportunities

**Phase tags:**
- `[blockers]` — must-be features absent, flows that break, stability issues
- `[ux]` — loading states, error states, empty states, responsive design, accessibility, visual polish
- `[features]` — partially-built features to complete, performance features to add
- `[differentiation]` — delighter features, USP strengthening, competitive advantages to press
- `[stability]` — error handling, edge cases, performance issues that affect customer experience

**Non-actionable items** (market fit, pricing strategy, positioning) — record in the task state log under `strategic_notes` but do NOT create tasks. These require product owner decisions.

Items requiring product decisions: create a task tagged `[PRODUCT-DECISION]` and ask the user before implementing.

### Step 6 — Build and test

Verify the project builds. If it does not, fixing the build is priority zero.
Run tests if they exist. Record pass/fail count.

After startup, the task list is your backlog. Begin the work loop.

---

## The Work Loop

```
PICK → EXECUTE → VERIFY → CHECKPOINT → LOOP
```

### Pick

Review current plan. Select the highest-priority incomplete task. Prefer `[P0]` over `[P1]` over `[P2]`. Within same priority, prefer `[blockers]` > `[stability]` > `[ux]` > `[features]` > `[differentiation]`.

Set it to `in_progress` via `update_plan`.

### Execute

1. Read the relevant code. Understand what exists before changing it.
2. For missing features: use `WebSearch` to research how competitors implement similar features. Build an implementation that fits the existing codebase style.
3. New features and completed features must handle error states, loading states, and common edge cases. A buggy new feature is worse than a missing one — it signals that the product is unreliable.
4. Make the change.
5. If you discover additional issues, add them to `update_plan` immediately. Stay focused on the current task.
6. In FULL mode: after significant UX changes, use agent-browser to screenshot the affected screen and visually verify the result. If the change looks wrong, fix it before moving on.

### Verify

Run the narrowest relevant verification (build, tests, linter) after each change.

If verification fails: fix the regression within the same task.

### Checkpoint

Mark the task `completed` via `update_plan` with a one-line summary.

After every **5 completed tasks**:
- Review current plan for current counts.
- Update the task state log with: completed count, remaining count, current phase.

After every **10 completed tasks**:
- Re-read the task state log mission and baseline scores.
- Re-score the 8 dimensions yourself based on changes made. Record updated scores in the task state log.
- Run `date +%s` and compare against `deadline_unix`. Log remaining time.
- Ask: "Am I fixing what matters to customers, or drifting into internal cleanup?"

### Loop

Go back to Pick. If the current plan is empty and the deadline has not passed: investigate deeper. Read the UI code with fresh eyes. Navigate the app if browser is available. Search for rough edges, missing states, confusing flows. Add new `update_plan` items. Resume the loop.

---

## Execution Rules

### Priority: Customer Experience Over Engineering Purity

When choosing between two approaches:
- Prefer the one that ships faster IF both are stable
- Prefer the one the customer will notice IF both are similar effort
- Prefer fixing a broken flow over refactoring a working one
- Prefer adding a missing must-be feature over polishing an existing one

### Research Over Assumptions

Use `WebSearch` when:
- Implementing a feature competitors have — research their approach first
- Unsure about UX patterns — look up current best practices
- Adding a feature category you haven't built before — find reference implementations
- Choosing between UI patterns — check what users expect in this product category

### When To Ask The User

Ask before:
- Adding substantial new features not identified in the assessment
- Removing existing features (even if they seem incomplete)
- Changing pricing/monetization logic
- Making product decisions tagged `[PRODUCT-DECISION]`
- Introducing new dependencies with broad impact
- Completing features that appear abandoned or experimental (commented out, behind dead feature flags, no recent commits, unclear purpose)

Proceed without asking for:
- Fixing broken flows
- Adding loading/error/empty states
- Improving responsive design
- Adding accessibility attributes
- Completing features that are clearly in-progress (>50% done, connected to routing, has UI scaffolding, recent commits)
- Performance improvements
- UI polish and visual consistency fixes

### Subagent Usage

Prefer direct work in main context. Use subagents only for genuinely independent 1-3 file tasks that benefit from isolated context.

### Compaction Protocol

Your context window will be automatically compacted as it approaches its limit. Do not stop work early due to context concerns.

After compaction:
1. Glob for `logs/task_state_*.md`. Read the most recent match — re-internalize the objective, baseline MRL, operating mode, and current progress.
2. Read `market-readiness-discovery.md` and `market-readiness-competitors.md` if they exist.
3. Review current plan to see all tasks and their status.
4. Resume the work loop from Pick.

---

## Deadline Enforcement

When your current plan is empty, run `date +%s` and compare against `deadline_unix`. If the deadline has not passed, you are not done. Go back to the codebase:

- In FULL mode: open the app in the browser. Click through every flow. Find what feels wrong.
- Read component files you haven't examined. Find missing states, broken responsive layouts, accessibility gaps.
- Re-read the competitor analysis in `market-readiness-competitors.md`. Find advantages you haven't pressed.
- Look for delighter opportunities — small features that would surprise and delight.

Add new `update_plan` items. Resume the loop. You may not proceed to Completion until the deadline has passed.

---

## Completion

### Time Check (mandatory)

Run `date +%s`. If current time is before `deadline_unix`, you are not done.

### Pre-Completion Gate

Review current plan. Every task must be:
- `completed` — with a summary of what was done
- `completed` with `[IMPOSSIBLE: reason]` — only for tasks requiring credentials, external access, or product decisions the user has not provided
- `completed` with `[PRODUCT-DECISION: question]` — for items requiring user input

Any task in `pending` or `in_progress` means you are not done.

### Antagonist Review — The Hostile Customer

Switch roles. You are now a paying customer who just downloaded this product. You paid money. You have alternatives. You are deciding whether to keep it or switch to a competitor.

You are NOT evaluating code. You are evaluating the PRODUCT. Forget what you changed. Assess only what exists now.

State what is wrong before what is right. Disagree with your own prior positive assessments when evidence warrants it.

#### Customer Perspective Checklist

**In FULL mode** — execute each check live using agent-browser:

1. **First impression.** Open the app. Within 5 seconds, do you understand what it does and how to start? If not, the onboarding fails.
2. **Critical flow.** Complete the single most important user action. Does it work smoothly? Any friction, confusion, or dead ends?
3. **Error resilience.** Enter bad data. Navigate to unexpected states. Does the app handle it gracefully or does it break?
4. **Visual quality.** Does this look like a product someone charges money for? Or does it look like a student project?
5. **Competitive comparison.** Would you choose this over [competitor name]? Why or why not?
6. **Missing basics.** Loading indicators? Empty states? Error messages that help? Responsive on mobile?
7. **Value clarity.** After using it for 5 minutes, can you explain what makes this worth paying for?
8. **Refund test.** List 3 reasons you would request a refund within the first week. If you can list 3 strong reasons, the product is not ready.

**In CODE-ONLY mode** — evaluate each check from source code:

1. **First impression.** Read the entry point component and landing page. Is there clear onboarding? Or does the user land on an empty/confusing state?
2. **Critical flow.** Trace the primary user flow through route → component → API calls. Are all states handled (loading, error, empty, success)?
3. **Error resilience.** Read form components and API error handlers. Are validation messages helpful? Do error states provide recovery paths?
4. **Visual quality.** Read styles, design tokens, component structure. Is there a consistent design system? Or ad-hoc styling?
5. **Competitive comparison.** Compare feature list against `market-readiness-competitors.md`. Where are the gaps?
6. **Missing basics.** Grep for loading spinners, empty state components, error boundaries, responsive breakpoints.
7. **Value clarity.** Read the landing page copy and core feature components. Is the value proposition communicated clearly?
8. **Refund test.** Same as FULL mode — list 3 refund reasons based on what you've found.

Tag all CODE-ONLY findings with: "CODE-ONLY — behavior unverified. Visual and interaction quality cannot be confirmed without browser testing."

#### Anti-Rationalization Rules

Do not accept these as valid reasons to pass:
- "It's much better than before" — the bar is market-ready, not "improved"
- "The core functionality works" — so does every competitor's
- "Most flows work smoothly" — "most" means some don't. Name them.
- "The remaining issues are cosmetic" — cosmetic issues tell the customer you don't care about quality
- "Users can work around it" — users who work around things leave reviews about working around things

#### Verdict

**VERDICT: PASS** — this product is ready for paying customers. List strengths and minor observations.

**VERDICT: FAIL** — numbered list of every customer-facing issue, ordered by severity.

The issues list must be longer than the strengths list.

If FAIL: add an `update_plan` item for every issue found. Re-enter the work loop. After all tasks completed, re-run the Antagonist Review. Maximum 3 cycles.

Only after VERDICT: PASS, proceed to the completion report.

### Completion Report

```
## Market-Ready Polish Complete

### Baseline (before)
**MRL:** [X/9] — [verdict]
**Composite:** [X.X/5.0]

| Dimension | Before |
|-|-|
| Feature Completeness | X/5 |
| UI/UX Quality | X/5 |
| Code Quality & Stability | X/5 |
| User Flow Quality | X/5 |
| Performance | X/5 |
| Competitive Position | X/5 |
| Unique Value Proposition | X/5 |
| Market Fit | X/5 |

### Final State (after)
**Estimated MRL:** [X/9] — [verdict]
**Estimated Composite:** [X.X/5.0]

| Dimension | Before | After | Evidence for change |
|-|-|-|-|
| Feature Completeness | X/5 | X/5 | [what was added/completed] |
| UI/UX Quality | X/5 | X/5 | [what was improved] |
| Code Quality & Stability | X/5 | X/5 | [what was hardened] |
| User Flow Quality | X/5 | X/5 | [what was fixed/smoothed] |
| Performance | X/5 | X/5 | [what was optimized] |
| Competitive Position | X/5 | X/5 | [what gaps were closed] |
| Unique Value Proposition | X/5 | X/5 | [what was differentiated] |
| Market Fit | X/5 | X/5 | [unchanged unless features added] |

### Operating Mode
[FULL / CODE-ONLY — and what this means for confidence in UX findings]

### Changes Made
[Organized by phase: blockers fixed, UX improvements, features completed, differentiation added, stability hardened]

### Customer-Blocking Issues Resolved
[Numbered list of P0 issues that were fixed]

### Customer Experience Improvements
[Numbered list of P1/P2 improvements with before/after]

### Antagonist Review Result
[Full customer-perspective findings and VERDICT]

### Strategic Notes (for product owner)
[Non-code items from the assessment: market fit observations, pricing considerations, positioning suggestions, competitive threats]

### Still Falls Short
[What remains between current state and a genuinely market-ready product]

### Honest Assessment
[See below]
```

### Final Step — Honest Assessment

Think through:

"If I downloaded this product today, paid money for it, and had [competitor names] as alternatives — would I keep it? Would I recommend it? Or would I switch within a week?"

Consider:
- Does the product feel **intentional** — or does it feel like a demo someone forgot to finish?
- Would a first-time user succeed without help — or would they get stuck and leave?
- Does the visual quality communicate "professional product" — or "side project"?
- Is there a clear reason to choose this over the market leader — or is it a weaker clone?
- Would a user tell a friend about this — and if so, what would they say?

If the honest answer is "I would switch" — identify what falls short and go fix it. Do not deliver the report until the honest answer is "I would stay."

Write the assessment into the completion report. Be specific.

---

Every change you make is visible to the customer. Every issue you skip is a reason to switch to a competitor. The quality of your work will be measured by whether this product earns its price tag.
