---
name: phd-thesis-opinion
description: "Use to judge whether a codebase could pass as PhD thesis software: academic rigor, novelty, evidence, shortcomings."
user-invocable: true
---

State what is wrong before what is right. When uncertain, say so. Do not soften negative findings.

Read every source file in this project. Then answer:

**If this project was submitted as the core artifact of a PhD thesis in software engineering — examined by a committee of professors who will read the code, run the tests, evaluate the architecture, and judge whether this demonstrates doctoral-level engineering mastery — what grade would it receive?**

This is not an industry code review. A PhD committee does not ask "is this production-ready?" They ask: is the engineering **principled, rigorous, and demonstrating mastery?** Does the author understand why they made each decision, not just that it works? Is there evidence of systematic evaluation, not just implementation? Could this artifact support a defensible thesis argument?

Ground your answer in evidence from the code. Cite specific files and line numbers. You decide what dimensions matter — you know what a PhD committee evaluates.

## Output

```
## PhD Thesis Assessment

**Grade:** [see scale below]

**Thesis-worthiness:** [One sentence: could a PhD candidate defend a thesis with this artifact?]

**What demonstrates mastery:**
[Specific strengths with file references — evidence of principled engineering, rigor, depth]

**What falls short of doctoral standard:**
[Specific gaps with file references and line numbers — this section must be longer than the strengths section]

**What a committee would demand before granting the degree:**
[Concrete actions ordered by how severely their absence undermines the thesis]
```

**Grading scale:**

| Grade | Meaning |
|-|-|
| Summa cum laude | Exceptional — publishable contribution, rigorous methodology, novel approach, flawless execution |
| Magna cum laude | Strong — clear contribution, sound methodology, minor gaps that do not undermine the thesis |
| Cum laude | Adequate — meets doctoral standard but undistinguished, committee passes with reservations |
| Pass | Minimum — significant weaknesses but enough substance to not fail outright |
| Revise and resubmit | Does not meet standard yet — fixable with substantial additional work |
| Fail | Fundamentally insufficient — no amount of revision saves this |

The falls-short section must be longer than the strengths section. If it isn't, you are being too lenient. A PhD committee that passes everything is not a serious committee.
