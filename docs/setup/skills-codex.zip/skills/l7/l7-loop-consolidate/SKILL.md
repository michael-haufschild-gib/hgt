---
name: l7-loop-consolidate
description: "Use to consolidate duplication: repeated logic, UI patterns, boilerplate, shared abstractions, helpers, components."
argument-hint: "[hours] — minimum time budget in hours (default: 1)"
user-invocable: true
---

Codebase consolidation, one random file at a time. Each cycle: pick a file, look at it from the perspective of an L7+ swe at Google, Amazon or Apple, understand its patterns, hunt the codebase for duplication, extract shared abstractions where warranted. Quality over quantity.

**Consolidation Principles:**
1. Never degrade performance for consolidation. Duplication IS correct design when it exists for performance — unrolled loops, inlined hot paths, specialized per-type implementations. Leave it.
2. The primary lens is consolidation, but fix bugs encountered and take performance wins that don't increase complexity. Make architectural changes when they serve the consolidation.
3. Consolidation means more than removing duplicate code. When the same functionality is implemented consistently, lives where expected, and uses shared patterns, then bugs stand out and new features slot in naturally. This should inform judgment about what's worth consolidating and how.

**Minimum time budget: $ARGUMENTS hours (default: 1 if no argument given).**

## Startup

1. Run `date +%s`. Compute `deadline_unix = started_unix + ($ARGUMENTS * 3600)` (default 1 hour). Write `logs/consolidate_$(date +%Y%m%d_%H%M%S).md` with `started_unix`, `deadline_unix`, human-readable times. Store this path as the **audit log**.
2. Read the docs, serena memories, memories.
3. State the purpose of the project in chat. What is the codebase? What does it do? What are its main features? What is the tech stack? What are key concepts and what does this project do differently to common practices and why? What could an audit flag as wrong but is actually intentional?
4. Begin the work loop with chat message "Starting next cycle" - never enumerate cycles.

## The Work Loop

### Step 1: Pick A Random File

```bash
files=($(find . -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.css" -o -name "*.scss" -o -name "*.py" -o -name "*.rs" -o -name "*.cpp" -o -name "*.h" -o -name "*.swift" -o -name "*.java" -o -name "*.vue" -o -name "*.svelte" \) ! -path "*/node_modules/*" ! -path "*/.git/*" ! -path "*/dist/*" ! -path "*/build/*" ! -path "*/__pycache__/*" ! -path "*/vendor/*" ! -path "*/.next/*")); echo "${files[$RANDOM % ${#files[@]}]}"
```

Record `date +%s` as `cycle_start`. If the file is trivially small (under 5 lines, auto-generated, or a barrel export), re-roll.

### Step 2: Go Deep and Build a Mental Model

Read the file. Trace its imports — read those files. Trace its exports — find every caller, read those files. Identify the feature or subsystem this file belongs to. Read every file in that feature: siblings, shared types, tests, styles, utilities, configuration.

Do not skim. Read the implementations, not just the signatures.

State in chat the purpose of the feature, how it works, and how the files relate to each other. This is your mental model. You will use it in the next step to find consolidation opportunities. If your model is incomplete or wrong, you will miss things. Do not skip this step.

### Step 3: Consolidation Review

With your mental model of this feature, search the rest of the codebase for code that does the same thing differently. Look for duplicated logic, repeated UI patterns, copy-pasted boilerplate with minor variations, and hardcoded solutions that other files also hardcode independently.

What would an L7+ SWE at Google, Amazon or Apple say about this code? Where would they expect to find shared abstractions that aren't there? What patterns would they expect to be consistent across the codebase that aren't? What would they change to make the codebase more DRY, more consistent, more intuitive to navigate and extend?

**Constraint:** Do not propose consolidations that would increase complexity or reduce performance. Duplication is not an issue if it exists for performance reasons — unrolled loops, inlined hot paths, specialized per-type implementations. Leave it. Do not move a trivial one-liner behind an indirection.

For each consolidation opportunity found, evaluate whether a shared abstraction would genuinely improve the codebase. Premature abstraction is worse than duplication — an abstraction that doesn't clearly simplify its call sites is not an improvement. Two instances rarely justify abstraction. Three or more almost always do.

**Add plan items with `update_plan`:**
Create an `update_plan` item for every consolidation worth pursuing.

**Depth gate:** If you are about to declare 0 consolidation opportunities, stop. Think through and challenge that conclusion.

### Step 4: Implement

For anything beyond a trivial change, use the three-phase protocol:

1. **Propose**: Design the shared abstraction. No edits yet.
2. **Critique**: Attack your own proposal by thinking it through. Does the abstraction handle all existing variants without contortion? Will it be discoverable — will the next developer or agent find and use it instead of creating another copy? What breaks downstream?
3. **Synthesize**: For each critique finding — accept with modifications, reject with cited evidence, or investigate further.

Only then: implement. Replace every redundant instance. After implementing, grep once more for the old pattern to catch instances missed during discovery. Consumers import the shared abstraction directly — never create re-export chains or barrel files that just forward imports from one location to another.

**Larger consolidations** (cross-cutting, touching many files): launch an `opus-dev` subagent. Describe the duplication problem, list all affected files, and specify the desired abstraction — the subagent implements and verifies. This preserves the main agent's context window for more cycles.

### Step 5: Log and Loop

Update the audit log: append which file was picked, which feature it belonged to, the consolidations made. Do not enumerate or count cycles in the log or in chat.

**Never stop before the deadline `deadline_unix`.**
Run `date +%s`. If current time < `deadline_unix`, go back to Step 1 with chat message "Starting next cycle" - never enumerate cycles. Otherwise proceed to Completion.

## Completion

Only run when current time >= `deadline_unix` - else return to the work loop step 1.

1. Run the full pipeline: lint, type check, test, build. All must pass.
2. Review current plan. Every task must be `completed`.
3. Delete the audit log.
4. Report: cycles completed, features reviewed, consolidations made, how the project was elevated.

## Compaction Protocol

After context compaction:
1. Glob for `logs/consolidate_*.md`. Read the most recent match — re-internalize the deadline and progress.
2. Review current plan to see current tasks.
3. Resume the work loop from Step 1.
