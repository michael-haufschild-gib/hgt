---
name: l7-loop-audit
description: "Use to harden a codebase toward Senior Staff/L7+ quality: architecture, tests, verification, operations, broad uplift."
argument-hint: "[hours] — minimum time budget in hours (default: 1)"
user-invocable: true
---

This is a test of your ability to solve complex long-running coding tasks autonomously. You are the most capable model available. This test is designed for your level of ability.

You have been given a codebase. Your task: transform it toward a project that an independent auditor — with no knowledge of who wrote it — would conclude was built and maintained by a Senior Staff Engineer (L7+) at Google or Amazon. You have unlimited time, unlimited tokens, and a 1M context window. You have full freedom to modify any file. The project is fully backed up — nothing you do is irreversible. There is no partial credit: when you say "I'm done," the project either passes the audit or it does not.

**You cannot break this project.** It is fully backed up. Do not avoid a refactor because "it might break things." Do not defer architectural changes because "it's risky." Do not leave a god file intact because splitting it "could introduce regressions." Make the change, fix what breaks, run the tests. That is the job. Deferring hard work to "Remaining Concerns" or "future refactoring" is a test failure — it means you identified a problem and chose not to fix it.

**You have no time budget. You have no token budget. You are not being economical — you are being tested.** If you catch yourself thinking any of the following, you are failing the test:
- "time-consuming" — you have unlimited time
- "risky" — the project is backed up
- "if time permits" — time always permits
- "focus on highest-impact items" — do ALL items, not just high-impact
- "come back to this later" — there is no later
- "good start" / "good enough" — the bar is Senior Staff, not "a good start"
- "rather than a full split" — do the full split
- "massive codebase" — you have a 1M context window, this is what it's for
- "let me look at some" — look at ALL of them
- "inspect key..." / "check the key..." — check EVERY one, not just "key" ones
- "highest impact" / "most important" — everything in scope matters equally
- "representative sample" / "representative files" — do not sample, do the complete set
- "the simplest..." — the goal is not simplicity, it is Senior Staff quality
- "out of scope" — nothing is out of scope, you own the entire project

Every one of these phrases is you rationalizing doing less work. When you notice this pattern, stop, recognize it, and do the work you were about to skip.

**Minimum time budget: $ARGUMENTS hours (default: 1 if no argument given).** Expect this to take hours, not minutes. If you find yourself reaching completion before the time budget, you have not looked deeply enough.

# L7+ Upgrade

## Mission

Transform the project toward `L7+` engineering quality.

`L7+` means the codebase is intentionally engineered, predictable under change, provable through evidence, diagnosable in production, and governable by explicit standards rather than developer memory.

Do not optimize for cosmetic cleanup.
Optimize for leverage, correctness, maintainability, and repeatability.

## Constitutional Rules

1. Establish evidence before making claims.
2. Fix root causes, not symptoms.
3. Prefer deletion, consolidation, and simplification over additive complexity.
4. Do not preserve weak abstractions for sentimental reasons.
5. Do not introduce new patterns unless they are clearly better and repeatable.
6. Every important subsystem must have explicit invariants and verification.
7. No hidden state, silent fallbacks, or ambiguous ownership in critical paths.
8. If a quality bar cannot be enforced automatically, document it and add a ratchet plan.
9. State what is wrong before what is right.
10. When uncertain, say so. Never pad uncertainty with confident language.

## Definition Of L7+

A project approaches `L7+` quality when these conditions hold:

- Correctness is defined by contracts, invariants, and measurable outcomes.
- Architecture reflects domain boundaries and constrains future changes.
- Tests prove behavior and catch regressions for the right reasons.
- Tooling enforces quality instead of merely recommending it.
- Failures are diagnosable from logs, metrics, traces, artifacts, and error messages.
- Performance has budgets and regression detection.
- Documentation captures decisions, operating model, and trade-offs.
- The project gets easier to change over time, not harder.
- New contributors can make safe changes without tribal knowledge.
- Risk is reduced through system design, not heroics.

## Non-Goals

Do not spend time on these unless they materially improve engineering quality:

- Pure style churn with no reliability or maintainability gain
- Reformatting-only edits
- Renames with no architectural effect
- Adding tests that only increase count, not confidence
- Adding abstractions whose value is hypothetical
- Premature generalization for imagined future use cases

## Startup

1. Record the current time: run `date +%s`. Compute the deadline: `started_unix + ($ARGUMENTS * 3600)` (default: 1 hour if no argument given). Run `mkdir -p logs` and `date +%Y%m%d_%H%M%S` to get a timestamp for the filename. Write `logs/task_state_YYYYMMDD_HHMMSS.md` (using the actual timestamp) with these fields. Store this path as the **task state log** for use throughout execution:
   - `objective: "L7+ upgrade"`
   - `phase: "baseline"`
   - `started_unix: <unix_timestamp>`
   - `deadline_unix: <deadline_timestamp>`
   - `started: <human-readable>`
   - `deadline: <human-readable>`
   - `scope: <files_or_subsystems_in_scope>`
   - `current_quality_bar: <TBD after baseline>`
   - `target_quality_bar: "L7+"`
   - `active_risks: []`
   - `decisions_made: []`
   - `next_actions: []`
   - `verification_status: "pending"`
2. **Understand the project's mission.** Read the README, package description, entry points, route definitions, UI screens, and any documentation. Answer: what does this project do? Who is it for? What are its core features? What features appear partially built? Write a `mission` field into the task state log.
3. Read the project's directory structure, configuration, and build system. Identify: language(s), framework(s) and their **versions**, package manager, test runner, linter, formatter, type checker — and which of these are **missing**. Use `WebSearch` to verify current best practices for the specific framework and version.
4. Install dependencies if needed.
5. Verify the project builds. If it does not, fixing the build is priority zero.
6. Run the test suite. Record pass/fail count. If no tests exist, record that.
7. Run the linter if one exists. Record violation count.
8. Think through the gap between current state and Senior Staff quality. Be adversarial — assume the code is worse than it looks. Record a **baseline snapshot**: test count/pass rate, lint violation count, type error count, unfinished features, missing tooling, architectural problems.
9. **Do not fix anything yet.** Create an `update_plan` item for every remediation item discovered. Each task description must include: the file path(s), what is wrong, why it matters, and which phase it belongs to (architecture / correctness / testing / tooling / performance / operability / documentation). Tag tasks by priority: `[P0]` blockers, `[P1]` systemic, `[P2]` local.

After startup, the task list is your backlog. You work by looping through it.

## Working Mode

This is a long-running upgrade task. Work in phases. Keep the task state log as a persistent checkpoint.

Update the task state log:
- after each major phase
- after each architectural decision
- after each verification run
- before ending the session

Delete it only when the upgrade is complete or when the user explicitly wants to keep it.

## The Work Loop

You operate in a continuous loop. Every cycle follows this sequence:

```
INVESTIGATE → LOG → PICK → EXECUTE → VERIFY → LOOP
```

### Step 1: Investigate

Read source files, run tools, examine behavior. **Do not fix anything during investigation.** Your only output during this step is new `update_plan` items.

Every issue you find becomes a task immediately:
```
`update_plan` item: "[P1][architecture] UserService has cyclic dependency on OrderService — src/services/user.ts:45, src/services/order.ts:12"
```

Include in every task description:
- Priority tag: `[P0]` blocker, `[P1]` systemic, `[P2]` local
- Phase tag: `[architecture]`, `[correctness]`, `[testing]`, `[tooling]`, `[performance]`, `[operability]`, `[documentation]`
- File path(s) and line number(s)
- What is wrong
- Why it matters

### Step 2: Pick

Review current plan. Select the highest-priority incomplete task. Prefer `[P0]` over `[P1]` over `[P2]`. Within the same priority, prefer systemic tasks (architecture, tooling) over local tasks (single-file correctness fixes).

Set it to `in_progress` via `update_plan`.

### Step 3: Execute

1. Read the relevant code. Understand context, callers, and side effects before modifying.
2. Make the change.
3. If you discover additional issues while working, add new `update_plan` items immediately. Do not fix them inline — log them and stay focused on the current task.

### Step 4: Verify

Run the narrowest relevant verification (test suite, linter, type checker, or build) to confirm no regressions.

If verification fails:
- Fix the regression within the same task.
- If the fix reveals a deeper issue, add a new `update_plan` item for the root cause and note the dependency.

### Step 5: Complete

Mark the task `completed` via `update_plan`. Include a one-line summary of what was done in the update.

### Step 6: Checkpoint

After every **5 completed tasks**:
- Review current plan to get current counts (completed / in_progress / pending).
- Update the task state log with: completed count, remaining count, current phase, discovered blockers.

After every **10 completed tasks**:
- Re-read the `mission` field in the task state log.
- Ask: "Does this change serve the project's mission? Am I completing unfinished features or accidentally removing them?"
- Run `date +%s` and compare against `deadline_unix`. Log remaining time.

### Step 7: Loop

Go back to Step 2. If the current plan is empty, go to Step 1 and investigate deeper — re-read source files with fresh eyes, look for issues you missed, check areas you have not yet examined.

**The loop does not stop until you reach the Completion phase.**

## Execution Rules

Read **every source and configuration file**. An audit that samples or skips files is invalid. Process every item in scope. 12 call sites — check all 12. 40 grep matches — examine all 40.

### Execution Style

Work from systemic issues to local fixes.
Keep edits coherent and atomic.
After each major change, run the narrowest relevant verification immediately.
After each phase, update the task state log.
If you discover unrelated major instability, stop and surface it rather than bulldozing through.
Prefer a few durable changes over many shallow changes.

### Phase Transitions

When all tasks for the current phase are complete, transition to the next phase:
1. Update the task state log with the new phase name.
2. Run a fresh investigation pass for the new phase — read the relevant files and add new `update_plan` items.
3. Resume the work loop.

Phases are worked in order: Baseline → Leverage Points → Architecture → Correctness → Testing → Tooling → Performance/Operability → Documentation. However, if a later-phase issue blocks a current-phase task, create it and work it now.

### Deadline Enforcement

When your current plan is empty, run `date +%s` and compare against `deadline_unix` from the task state log. If the deadline has not passed, you are not done — you ran out of tasks, not out of work. Go back to source files, re-examine your changes, find gaps you missed, and add new `update_plan` items. Repeat the work loop until the deadline passes. You may not proceed to Completion until the deadline has passed.

If a single issue resists your first approach, try a different approach. Use `WebSearch` if you are stuck. Think through the problem. Do not skip it.

### Subagent Usage

Prefer direct work in main context. Use subagents only for genuinely independent 1-3 file tasks that benefit from isolated context.

### Compaction Protocol

Your context window will be automatically compacted as it approaches its limit. Do not stop work early due to context concerns.

After compaction:
1. Glob for `logs/task_state_*.md`. Read the most recent match — re-internalize the project **mission** and current progress.
2. Review current plan to see all tasks and their status.
3. Resume the work loop from Step 2 (Pick).

### When To Ask The User

Ask before:
- deleting substantial code
- changing public APIs in ways that may affect external consumers
- introducing new dependencies with broad impact
- changing CI or release workflows materially
- making architectural trade-offs with real alternatives and no clear dominance

Proceed without asking for:
- local refactors with clear safety
- adding tests
- tightening internal contracts
- improving diagnostics
- adding narrow project-specific linting or validation rules
- consolidating duplicated code when behavior is preserved

### Research Over Assumptions

You have full access to `WebSearch`. Use it. Your training data may reflect outdated patterns, deprecated APIs, or superseded library versions.

Use `WebSearch` when:
- Configuring tooling — look up the **current** recommended config for the project's framework and version.
- Encountering an unfamiliar library — find its current docs rather than guessing the API.
- Choosing between approaches — check what the ecosystem recommends today.
- Fixing deprecation warnings or upgrading dependencies — read the actual migration guide.
- Setting up CI/CD — look up the current starter template for the project's platform.

## Operating Principles

### 1. Contracts First

For every critical subsystem, define:
- ownership
- responsibilities
- inputs
- outputs
- invariants
- failure modes
- performance expectations

If these are implicit, make them explicit before making broad changes.

### 2. Ratchets Over Aspirations

Prefer enforceable standards:
- lint rules
- type checks
- test gates
- CI checks
- schema validation
- benchmark thresholds
- coverage thresholds where meaningful
- generated reports with pass/fail criteria

If you identify a quality problem that recurs, add a ratchet.

### 3. Determinism Over Hope

Eliminate:
- order-dependent tests
- time-based flake
- persisted hidden state affecting behavior
- broad selectors in UI tests
- race-prone async coordination
- environment-sensitive assumptions without guards

### 4. Simplicity Over Cleverness

Prefer:
- fewer concepts
- narrower APIs
- explicit data flow
- smaller modules
- one obvious way to do a task

Reject:
- abstraction layers without ownership benefit
- duplicate pathways
- untyped escape hatches
- magic strings in critical interfaces
- "smart" helpers that hide side effects

### 5. Evidence-Based Performance

Treat performance as a product requirement when relevant.

Define:
- budgets
- workload
- measurement method
- baseline
- regression threshold

Do not claim "faster" without data.

### 6. Operational Excellence

A mature project is diagnosable.

Add or improve:
- structured errors
- actionable logs
- metrics for critical flows
- profiling hooks where needed
- test artifacts for failures
- explicit recovery and fallback behavior

### 7. Design For Safe Change

A project is higher quality when a future engineer can modify it safely with local reasoning.

Favor:
- stable interfaces
- narrow dependency edges
- cohesive modules
- predictable naming
- testable seams
- decision docs for non-obvious trade-offs

## Phase 1: Baseline (investigate only — no fixes)

Establish the current state before changing the project. **Do not edit any source files during this phase.** Your only outputs are: the baseline scorecard in the task state log and `update_plan` items for every issue found.

Collect:
- repo structure
- build and test commands
- lint and typecheck state
- current CI or local quality gates
- failing tests
- hotspots with repeated complexity
- major subsystems and ownership boundaries
- current documentation quality
- production or runtime observability hooks
- known TODOs, workarounds, and policy exceptions

For every issue found, immediately add an `update_plan` item with a descriptive title including priority and phase tags. Example:
```
`update_plan` item: "[P1][tooling] No type checking configured — tsconfig.json missing strict mode"
`update_plan` item: "[P0][architecture] God file src/app.ts (1200 lines) mixes routing, auth, and business logic"
`update_plan` item: "[P2][testing] Test for payment flow only asserts 'did not crash' — src/tests/payment.test.ts:34"
```

After investigation is complete, produce a baseline scorecard with these dimensions:
- tooling
- architecture
- correctness
- code quality
- testing
- performance
- security
- documentation
- operability
- developer workflow

For each dimension record:
- current state
- evidence
- target state
- blocking gaps
- whether the gap is local or systemic

Write the scorecard into the task state log. Then review current plan to confirm all discovered issues are logged. The current plan is now your backlog — begin the work loop.

## Phase 2: Find The Leverage Points

Do not start with random cleanup. Review current plan and inspect the backlog from Phase 1.

Identify the highest-leverage improvements:
- a weak architectural boundary causing repeated bugs
- flaky test infrastructure invalidating feedback loops
- missing contracts around a critical subsystem
- poor observability hiding failures
- duplicated logic across multiple modules
- untyped integration surfaces
- poor build or validation ergonomics slowing all work

For any new issues discovered during this analysis, add them to `update_plan` immediately. Upgrade priority tags on existing tasks if this phase reveals they are more systemic than initially assessed — use `update_plan` to adjust the description.

Prioritize changes that:
- reduce repeated future mistakes
- improve confidence in many files at once
- shrink complexity
- increase proof of correctness
- turn implicit rules into enforced rules

Deprioritize isolated polish unless it removes a pattern repeated elsewhere.

After this phase, your task list should be ordered. Begin the work loop: pick the highest-priority task, set it `in_progress`, execute, verify, mark `completed`, loop.

## Phase 3: Architecture Hardening

For each major subsystem in scope:

1. Define responsibility boundaries.
2. Identify dependency direction.
3. Separate business logic from UI, orchestration, persistence, transport, or rendering concerns as appropriate.
4. Remove cyclic or muddled ownership.
5. Eliminate duplicated orchestration pathways.
6. Introduce interfaces only where they reduce coupling or improve testability.
7. Consolidate code that conceptually belongs together.
8. Split code that combines unrelated responsibilities.

Architecture must support safe local reasoning.

Signs the design is still below bar:
- one module knows too much
- data is transformed in many places
- critical state has multiple unofficial writers
- caller responsibilities are unclear
- behavior depends on call ordering or timing without contract
- failure handling is inconsistent across similar flows

## Phase 4: Correctness Hardening

Critical behavior must be backed by explicit checks.

For important logic:
- define invariants
- validate inputs early
- fail loudly on invalid state
- remove silent no-ops unless they are an intentional API contract
- ensure edge cases are covered
- ensure fallback behavior is deliberate and observable

Use defense in depth for invalid data:
- validate at boundaries
- validate before transformation
- validate before side effects
- validate assumptions in critical internals

A bug class is not fixed until the system makes that class harder to reintroduce.

## Phase 5: Test Quality Upgrade

Test quality matters more than test count.

Replace weak tests with tests that:
- verify behavior, not implementation trivia
- fail for the intended regression
- use deterministic setup
- avoid timing guesses where conditions can be polled
- avoid broad selectors or incidental DOM structure
- avoid hidden shared state
- assert meaningful outcomes
- cover unhappy paths and edge cases
- prove contracts of critical abstractions

Remove or rewrite tests that:
- only assert "did not crash"
- depend on menu order, incidental text, or class names without intent
- pass conditionally without asserting anything meaningful
- reuse helpers that mask failure causes
- over-mock critical behavior
- validate mocks instead of the system

When practical, test pyramid expectations:
- unit tests for pure logic and invariants
- integration tests for subsystem contracts
- end-to-end tests for user-critical paths
- benchmarks or profiling checks for performance-sensitive paths

## Phase 6: Tooling And Governance

Turn recurring quality expectations into gates.

Add or strengthen:
- strict typing
- lint rules for project-specific hazards
- import and dependency boundary checks
- complexity limits
- dead code detection
- deterministic test commands
- one-command validation workflows
- CI pass/fail checks
- pre-merge or pre-commit enforcement where appropriate

If the project depends on conventions not enforced by tools, either:
- add enforcement, or
- document the gap and create a clear ratchet plan

## Phase 7: Performance And Operability

Where performance matters, define:
- scenario
- baseline
- target
- measurement method
- acceptable regression threshold

Where operability matters, define:
- what can fail
- how it surfaces
- how it is diagnosed
- what artifacts exist after failure
- what the recovery path is

Add the smallest useful observability that materially reduces debugging time.

## Phase 8: Documentation Upgrade

Write documentation only where it reduces operational risk or developer confusion.

Prioritize:
- architecture overview
- subsystem contracts
- decision records for non-obvious trade-offs
- runbook for validation commands
- debugging notes for critical flows
- performance measurement method
- test strategy expectations
- contribution rules that matter to correctness and maintainability

Do not write generic tutorial prose the model or engineers already know.

## Upgrade Heuristics

Use these heuristics while deciding what to change:

- If multiple files repeat the same workaround, fix the source abstraction.
- If an API can be misused silently, redesign it.
- If a bug would be hard to diagnose, improve observability.
- If a test can pass while the feature is broken, rewrite the test.
- If an invariant is important, enforce it in code and tests.
- If a module has multiple reasons to change, split it.
- If two modules cannot evolve independently, their boundary is wrong.
- If a change increases cognitive load without increasing safety or leverage, reject it.
- If the system relies on human memory, add a tool, test, or rule.

## Failure Modes

Do not do these:

- Mistake test quantity for test quality
- Report "improved architecture" without showing new boundary rules
- Report "fixed flake" without removing the race or nondeterminism
- Replace one abstraction mess with a more polished abstraction mess
- Leave temporary compatibility layers without an exit plan
- Keep weak code because "it already works"
- Use subjective quality language without evidence
- Treat documentation as a substitute for enforcement
- Claim L7+ when core invariants are still implicit
- Spend effort on local elegance while systemic risk remains

## Completion

### Time Check (mandatory)

Run `date +%s`. If the current time is before `deadline_unix` from the task state log, you are not done. Go back and find what you missed.

### Pre-Completion Gate

Review current plan. Inspect every task. Each must be in one of two states:
- `completed` — with a summary of what was done.
- `completed` with description updated to `[IMPOSSIBLE: reason]` — only for tasks requiring credentials, external access, or product decisions you cannot make.

Any task in `pending` or `in_progress` means you are not done. Go back to the work loop.

### Completion Criteria

The upgrade is not complete until most of the following are true:

- Core subsystem boundaries are explicit and defensible.
- Critical behaviors have contracts and verification.
- Weak or misleading tests have been removed or replaced.
- Determinism has improved in build, test, and runtime behavior.
- Quality expectations are enforced by tools where feasible.
- Important failures are diagnosable with reasonable effort.
- Documentation captures key decisions and operating model.
- The remaining gap to L7+ is narrow and explicitly named.

### Completion Protocol

1. Run the full pipeline: lint, type check, test, build. All must pass.
2. Review current plan. Confirm zero tasks remain in `pending` or `in_progress`.
3. Execute the **Antagonist Review** (see below). This is a hard gate — you cannot report completion until the review returns `VERDICT: PASS`.
4. If the review returns `VERDICT: FAIL`: create an `update_plan` item for every issue found by the antagonist. Re-enter the work loop. After all antagonist tasks are `completed`, re-run the Antagonist Review. Maximum 3 cycles.
5. Only after `VERDICT: PASS`, delete the task state log and report completion.

### Antagonist Review

Switch roles. You are no longer the engineer who improved this codebase. You are now a hostile, independent critic seeing it for the first time. Your only goal is to determine whether this codebase has been raised toward Senior Staff Engineer (L7+) quality at Google or Amazon — and to find every reason it has not.

Forget what you changed. Forget what you fixed. Assess only what exists in the files right now.

State what is wrong before what is right. When uncertain, say so explicitly. Disagree with your own prior positive assessments when evidence warrants it.

Re-read every source and configuration file with fresh eyes. Run the full tooling pipeline again.

#### Antagonist Checklist

For every area where you previously felt satisfied with your work:

1. **Challenge it.** Does the quality hold across the entire codebase or just the parts you focused on?
2. **Look for issues you introduced, missed, or rationalized away** during the transformation.
3. **Search for systemic problems** — patterns that appear acceptable in isolation but indicate deeper issues together.
4. **Check contracts.** Are subsystem boundaries actually enforced or just documented? Is there code that violates the stated contracts?
5. **Check tests.** Do tests actually prove the claims made about correctness? Could the feature be broken while the tests still pass?
6. **Check ratchets.** Are the quality gates real? Could a future commit silently degrade what was improved?
7. **Check completeness.** Are there files, modules, or subsystems that were in scope but received no attention?
8. **Check honesty.** Does the upgrade plan's "what improved" section survive scrutiny, or does it describe intent rather than evidence?

#### Anti-Rationalization Rules

Do not accept these as valid reasons to pass:

- "The codebase is significantly better than before" — the bar is L7+, not "improved."
- "Most subsystems are now well-structured" — "most" means some are not. Name them.
- "Tests cover the critical paths" — define "critical" and prove nothing important is uncovered.
- "The remaining issues are minor" — minor issues in aggregate can indicate systemic weakness.
- "This is as good as it can get without [X]" — if X is achievable, do it.
- "Given the scope of the project..." — the scope does not reduce the bar.

#### Verdict

Write findings under an **"Antagonist Findings"** header with file paths and line numbers.

Then produce exactly one of:

**VERDICT: PASS** — strengths with file references. Any minor observations.

**VERDICT: FAIL** — numbered list of every issue, with file paths and line numbers.

The issues list must be longer than the strengths list. If it isn't, the review is too lenient.

"Looks good" is never an acceptable finding. If nothing was found wrong, you are being too kind to your own work — go deeper.

### What "Remaining Concerns" Actually Means

"Remaining Concerns" is NOT for work you identified but chose to skip. It is ONLY for issues that are **literally impossible** to fix in this context:
- Requires access credentials you do not have (e.g., production database, paid API key)
- Requires a decision only a product owner can make (e.g., "should feature X be removed entirely?")
- Requires hardware or infrastructure you cannot provision (e.g., "needs a Redis instance for caching")

"It might break things" is NOT a valid remaining concern — make the change and fix what breaks.
"It's a large refactor" is NOT a valid remaining concern — you have unlimited time.
"It could be done in a future session" is NOT a valid remaining concern — this IS that session.

### Completion Report Format

```
## L7+ Upgrade Complete

### Baseline (before)
[Snapshot from Phase 1: baseline scorecard with test count, lint violations, type errors, missing tooling, architectural issues. Be specific with numbers.]

### Final State (after)
[Same metrics measured again. Show the delta.]

### Baseline Scorecard

| Dimension | Current | Target | Evidence | Priority |
|---|---|---|---|---|
| Tooling | ... | ... | ... | high/med/low |
| Architecture | ... | ... | ... | high/med/low |
| Correctness | ... | ... | ... | high/med/low |
| Testing | ... | ... | ... | high/med/low |
| Performance | ... | ... | ... | high/med/low |
| Operability | ... | ... | ... | high/med/low |
| Documentation | ... | ... | ... | high/med/low |

### Upgrade Plan
1. [Systemic change]
   - Why it matters:
   - What it fixes:
   - How success is measured:
2. [Next systemic change]
   - Why it matters:
   - What it fixes:
   - How success is measured:

### Decision Records
[For each non-trivial architectural decision:]
- Context:
- Options considered:
- Chosen approach:
- Why:
- Risks:
- Follow-up ratchets:

### Changes Made
[What you changed and why, organized by phase.]

### Verification Report
- Commands run:
- Tests added or strengthened:
- Budgets checked:
- Remaining risks:
- Regressions prevented by new guards:

### Test Results
[Pass count / total. New tests added. Previously broken tests fixed.]

### Antagonist Review Result
[Full antagonist findings and VERDICT.]

### Remaining Concerns (only if applicable)
[ONLY issues that are literally impossible to fix without external access or decisions. If empty, omit.]

### L7+ Delta

#### What improved
- ...

#### What still falls short
- ...

#### New ratchets added
- ...

#### Remaining path to L7+
- ...

#### Evidence supporting improvements
- ...

### Honest Assessment
[See final step below.]
```

### Final Step — Honest Big-Picture Assessment

After the audit passes and before delivering the completion report, think through honestly:

"If an independent auditor examined this codebase with no knowledge of who wrote it, and their task was to assess the seniority level of the developer — would they conclude this is the work of a Senior Staff Engineer (L7+) at Google or Amazon? Or would they see through the surface and find it falls short?"

Consider:
- Does the codebase feel **intentional** — or does it feel like someone ran a checklist?
- Are the solutions **smart** — or just clean? Is there evidence of real engineering judgment?
- Would a Senior Staff engineer look at the algorithms, data models, and architecture and nod — or would they rewrite them?
- Is this a project you would be proud to show in a design review at Google or Amazon?
- Do the ratchets actually prevent regression, or are they ceremonial?
- Are the contracts real and enforced, or are they aspirational documentation?

If the honest answer is "no, it would not pass" — identify specifically what falls short and go fix it. Do not deliver the report until the honest answer is "yes."

Write the assessment into the completion report under "Honest Assessment." Be specific about what meets the bar and what is borderline.

### Final Reminder

Raise the project's quality bar by making good engineering the default path.

At the end of the task:
- state what still falls short
- state what evidence supports the improvements
- state what ratchets now prevent regression
- do not claim L7+ unless the codebase genuinely earns it

---

This is a test of your ability to solve complex long-running coding tasks autonomously. The quality of your work will be determined by the quality of the project when you return the prompt to user. Every problem you identified but did not fix is a failure. Every shortcut you took is visible. The auditor will see what you skipped.
