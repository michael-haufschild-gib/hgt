---
name: l7-honest-opinion
description: "Use for blunt Senior Staff/L7+ codebase assessment: architecture, quality, risks, gaps, no-sugar-coating verdict."
user-invocable: true
---

State what is wrong before what is right. When uncertain, say so. Do not soften negative findings.

Read every source file in this project — not a sample, not "key files", not "representative files." Every file. An audit that skips files is invalid. If you catch yourself reading "a few more" or "some additional" files, you have not read all of them yet. Then answer:

**If an external auditor examined this codebase in depth — with no knowledge of who built it — to estimate the seniority level of its developer, would the returned score be at least what a Senior Staff Engineer (L7+) at Google or Amazon would achieve?**

Ground your answer in evidence from the code. For each dimension, check every file in scope — not a sample. Cite specific files and line numbers:

1. **Tooling** — Is there a linter with complexity rules, a formatter, strict type checking, single-command workflows? Or is this duct-taped together?
2. **Architecture** — Are there clear module boundaries, unidirectional dependencies, separated concerns? Or is it a tangle?
3. **Solutions** — Are the algorithms, data models, and API designs appropriate for the problems they solve? Or are there naive/wrong approaches that a senior engineer would immediately flag?
4. **Code quality** — Error handling, type safety, naming consistency, no dead code? Or are there empty catch blocks, any-types, and console.logs?
5. **Testing** — Do tests catch real bugs with meaningful assertions? Or are they existence checks and happy-path-only?
6. **Security** — Input validation, no hardcoded secrets, dependencies audited? Or are there obvious vulnerabilities?
7. **Documentation** — Can a new developer go from clone to productive by reading the README? Or is it missing/stale?
8. **Overall impression** — Does this codebase feel *intentionally engineered* by someone who made deliberate choices? Or does it feel like it was built by someone who got it working and stopped?

## Output Constraints

List every finding and every needed change — not a curated selection. The count reflects the actual state of the codebase. 5 findings means the code is strong. 40 findings means the code needs work. Do not truncate to a target count.

```
## Honest Seniority Assessment

**Verdict:** [YES — this passes L7+ / NO — this falls short]

**Estimated level:** [Junior / Mid / Senior / Staff / Senior Staff+]

**What meets the bar:**
[Specific strengths with file references]

**What falls short:**
[Every gap found, with file references and line numbers — this section should be longer than the strengths section]

**What would need to change:**
[Every concrete action to close the gap, with file path — do not cap at a fixed number]
```

The falls-short section should be longer than the strengths section. If it isn't, you are being too lenient.
