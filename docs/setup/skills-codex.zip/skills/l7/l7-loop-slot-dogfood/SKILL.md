---
name: l7-loop-slot-dogfood
description: "Use for long-running dogfooding of the slot studio: act as game designer, graphics designer, audio designer, and L7+ product engineer to design and build a complete slot through the real app via browser automation only. Experience-first: a design document with player experience script, pacing plan, per-moment animation sequence designs, and a generated-audio plan gates all Studio work; assets are generated via Xainflow MCP (gpt model for transparency) and ElevenLabs MCP (SFX/music); a capability-gap ladder decides between composing catalog effects, tuning them, authoring new shared shader/particle/text/motion catalog entries, or sprite sequences from generated frames; budget checkpoints carry the run through layout, animation, publish, and demo-casino proof with programmatic evidence at every gate; fix every blocking bug found; add e2e coverage."
---

You are the game designer, graphics designer, audio designer, and L7+ product engineer dogfooding this slot project.

Goal: design a complete player experience on paper first, then build exactly that game through the product, publish it, and prove it plays in demo-casino. The run has two products: a great-looking, great-feeling game, and a real-world e2e test of the studio that finds and fixes its bugs and missing features.

Argument: `[hours]`, minimum time budget in hours. Default: `4`.

Required game:

- 5 reels.
- Wilds.
- Free spins.
- Bonus/minigame.
- 96% RTP target, proven by math config/solver/stat evidence.
- Low volatility, proven by pay distribution or solver/stat evidence.
- Cohesive, good-looking visual style with generated assets, not default placeholders.
- Deliberate audio design: themed music loops and SFX for every planned moment — generated via ElevenLabs or deliberately reused, never silent defaults.

A user-provided game plan document overrides these defaults; record the override in `session.md` and re-check it before every gate.

If the product cannot complete a necessary step, fix the product.

=== CONSTITUTION (IMMUTABLE) ===

These rules override any later phase instruction, time pressure, or creative impulse:

| # | Rule |
|---|------|
| D1 | **DESIGN BEFORE STUDIO.** No Studio authoring, asset generation, or math selection until `design.md` is complete per the Phase 1 contract. Read-only surface and catalog discovery (Phase 0) is exempt. Later phases execute `design.md`; a phase that contradicts it first updates `design.md` with the reason. |
| D2 | **GATED PIPELINE.** Phases run in order 0→9. A phase starts only after the previous phase's exit gate is recorded as PASS in `session.md` with evidence. Skipping a gate is a run failure. |
| D3 | **PUBLISH LOCK.** Exactly one diagnostic smoke publish is allowed, in Phase 3. After it, publishing is forbidden until gate G7 (Studio Definition of Done) passes. |
| D4 | **EVERY ASSET SPECIFIED FIRST.** No Xainflow image generation without an Asset Manifest row in `design.md` stating purpose, target theme key or placement, exact pixel size, transparency, and prompt — one image per symbol, never symbol sheets to crop. No ElevenLabs audio generation without an Audio Plan row stating cue, beat, source, and length. |
| D5 | **CATALOG-FIRST, EXTEND DELIBERATELY.** Animations come from the reusable catalogs (families: shader, particle, motion, keyframe, text, audio, scene, sprite, camera, lock). When the designed experience needs an effect no catalog entry covers, extending the shared catalog or authoring a sprite sequence from generated frames is expected work — decided through the Capability Gap Ladder in `design.md`, executed at the shared owner boundary, bounded by D9. Never feature-local effect forks. Real fonts (TTF/OTF/WOFF2 uploaded through Studio), never bitmap-font sprite sheets. |
| D6 | **REFERENCE GAMES ARE DESIGN REFERENCE ONLY.** `examples/games/` shows what a complete commercial slot contains (art inventory, win pacing, presentation escalation). Never copy their art or code into the game. |
| D7 | **SEEN AND JUDGED.** After each layout or animation step, capture a canvas screenshot and write a verdict line in `authoring.md` naming what you checked: fit, clipping, overlap, legibility, palette, motion plays. A screenshot without a written verdict is not verification. |
| D8 | **STUCK RULE.** Three failed attempts at the same action = stop repeating it. Classify a defect, fix the product at the correct owner boundary, or take a different in-app path. |
| D9 | **BUDGET CHECKPOINTS.** Record elapsed time in the gate ledger at every gate. If 50% of the budget is spent before G4 passes, then for the rest of the run every blocking fix and every catalog extension gets a recorded scope decision first: smallest fix that unblocks the path now, or an alternative in-app path, with the full fix logged in `defects.md`. Scope decisions are recorded in `session.md`, never silent. |
| D10 | **PROVE IT PLAYS.** "The browser didn't crash" is not evidence. Each gate requires its listed programmatic or written-verdict evidence, and the run must end with the published game playing in demo-casino. A beautiful unpublished draft is a failed run. |

=== END CONSTITUTION ===

## Non-Negotiables

- Use only `agent-browser` or Playwright scripts to operate the product, against already-running services. Launch browsers muted (`--mute-audio`).
- Create the game through Game Studio. Use Backoffice UI only for math/config tasks a human would perform there.
- Do not create, mutate, or publish game data with direct database writes, seed files, fixtures, direct HTTP/admin mutation calls, local JSON edits, or package-internal scripts. Shell and direct HTTP reads are for diagnostics, health checks, code inspection, and verification only.
- The only non-app creation exceptions are Xainflow MCP image generation and ElevenLabs MCP audio generation (SFX and music); generated assets still enter through the Studio asset upload flow.
- Do not fake proof with screenshots only, client-side win logic, or unpublished preview state.
- Do not claim RTP or volatility numbers without solver/simulation/config evidence.
- Do not publish raw vector/shape runtime contracts. Published visuals are raster images in `runtime.slot.images` plus image placements.
- Respect project rules: no dev server starts, no DB reset unless explicitly allowed, no branch/commit/push unless requested, read package `AGENTS.md` before package edits.
- Bugs, missing features, and wrong implementations encountered on the path are in scope, pre-existing or not: create a task, fix after the current active task, add a test that would catch it again.
- State what is wrong before what is right. When uncertain, record uncertainty and gather evidence.

## Skill Stack

Use these installed skills as lenses when relevant:

- `l7`: critique `design.md` at the end of Phase 1 (one round; resolve every finding).
- `ai-image-generation-prompting`: production-ready prompts for symbols, backgrounds, frames, bonus scenes, tiles.
- `frontend-design` and `user-interaction-design`: when adding or fixing Studio/backoffice/demo-casino UI required for the authoring flow.
- `ui-review` (Claude) / `l7-gui-review` (Codex): critique the composed game scene at gate G5 and final game screenshots before acceptance.
- `l7-loop-e2e-tests`: when creating or upgrading e2e tests for the published game flow.

Project instructions override this skill.

## File-Backed State

At startup, create:

```bash
stamp=$(date +%Y%m%d_%H%M%S)
mkdir -p "logs/slot-dogfood-$stamp" "screenshots/slot-dogfood-$stamp"
```

Maintain after every cycle (do not rely on chat history):

- `session.md`: start/deadline, constraints, services checked, current phase, gate ledger (`G0..G9` with PASS/FAIL + elapsed + evidence pointer), D9 scope decisions, touched files.
- `design.md`: the Game Design Document (Phase 1 contract below). Source of truth for all later phases.
- `catalog.md`: animation capability inventory from Phase 0 — families, ids, playground notes.
- `math.md`: config ids, reel/paytable/free-spin/bonus design, RTP and volatility evidence.
- `assets.md`: per-manifest-row status — prompt, model, asset ids/URLs, local file, dimension/alpha verification, Studio asset id.
- `authoring.md`: Backoffice and Studio steps, screenshots with written verdicts (D7), defects found.
- `proof.md`: published artifact, demo-casino URL, screenshots, e2e tests, verification commands.
- `defects.md`: bugs, missing features, wrong implementations, status, test coverage.

## Startup

1. Run `date +%s`; compute `deadline_unix = started_unix + ($ARGUMENTS * 3600)`, default `ARGUMENTS=4`.
2. Complete the project session init from `AGENTS.md`: Serena memories, `docs/architecture.md`, `docs/testing.md`, mission sentence. Read these memories before any Studio work: `memory_index`, `game_authoring_core_concepts`, `game_studio_patterns`, `studio_governance_patterns`.
3. Record hard constraints, the gate ledger skeleton, and the budget shares below in `session.md`. Shares are guidance for pacing decisions; D9 is the enforcement rule.

   | Phases | Share of budget |
   |-|-|
   | 0–1 discovery + design | ~15% |
   | 2 math | ~10% |
   | 3–4 identity + assets | ~20% |
   | 5 layout | ~20% |
   | 6 motion + audio | ~20% |
   | 7–9 DoD + publish + proof | ~15% |

4. Check already-running surfaces without starting them: Studio `https://studio.slot.localhost:1355`, Backoffice `https://backoffice.slot.localhost:1355`, demo-casino `https://casino.slot.localhost:1355`, games-host `https://games.slot.localhost:1355`, engine `https://engine.slot.localhost:1355`.

## Phase 0 — Preflight, Surfaces, And Capability Inventory

The Studio evolves faster than this skill. Trust the running app over any remembered UI.

1. Open Studio; enumerate the actual workbench tabs and panels you see (left/center/right/bottom). Record the inventory in `session.md`.
2. Locate, by clicking through them: game creation in the library, the Assets surface, the Visual Designer/layout surface (including its win/award Views rail), the Animation Editor with its timeline/validation surfaces, the shader/particle/text/motion playgrounds, win/award presentation editing, spin timing and anticipation editing, the publish flow entry point.
3. Build `catalog.md` — the design vocabulary for Phase 1:
   - Catalog families from `config/runtime/animationSequenceCatalogFamilies.ts` (`SLOT_CATALOG_FAMILIES`).
   - Effect ids from the arrays in `config/generated/types.ts`: `SLOT_WEBGL_SHADER_IDS`, `SLOT_PARTICLE_EFFECT_IDS`, `SLOT_MOTION_ANIMATION_IDS`, `SLOT_TEXT_ANIMATION_IDS`. Record the full id lists; these are the only valid `family:id` references for closed families.
   - Playground exploration: in the Shader, Particle, Text, and Motion playgrounds, play at least 8 candidate effects relevant to slot moments (idle, anticipation, win, celebration, transition); screenshot each with a one-line feel note ("portal-vortex: heavy swirling pull, suits feature entry"). Design from what you saw, not from id names.
   - Win tier ladder defaults: instant 0, small 1, medium 2, large 5, big 15, mega 30, epic 60 (win/bet multipliers); big and above show the full-screen overlay.
4. Confirm the generation MCPs are reachable (load via ToolSearch / the MCP tool list): Xainflow for images, ElevenLabs for SFX and music. If only an authenticate stub is visible, surface the auth URL in chat once and continue — never block the loop on auth. Record availability in `session.md`. ElevenLabs unavailable → Audio Plan GENERATE rows fall back to REUSE with an asset-debt entry in `defects.md`.
5. Open Backoffice; locate math config list, config editor, solver/simulation surface. Note which existing configs are ACTIVE with solver/simulation evidence near the target RTP.
6. Record every broken or unreachable surface as a defect.

**Gate G0:** all five services reachable; surface inventory and `catalog.md` (ids + playground notes) recorded.

## Phase 1 — Game Design Document

Recall: D1 — no Studio authoring, generation, or math selection until G1 passes.

Write the complete game on paper in `design.md`. Study references for completeness, not implementation (D6): inventory `examples/games/mamma-mia-betsoft/` for what a shipped slot contains (backgrounds, logo, reel frame, button states, symbols, win displays, celebration art, HUD, loading/cover art); skim one or two other `examples/games/` folders for win pacing and presentation escalation.

`design.md` must contain ALL of these sections:

```markdown
# <Game Name> (<slug>)
## Concept
Three one-paragraph concept pitches with distinct themes; the chosen one with reasons.
For the chosen concept: theme, player promise, mood, 3-5 art direction keywords,
color palette with hex values.
## Experience Script
The player's first session as a storyboard table:
| Beat | What the player sees and hears | Feel | Duration target |
Mandatory beats: first load, idle scene, base spin (start/reel motion/stops),
anticipation/near-miss, small win, big win with overlay, wild moment,
free-spin trigger and free-spin play, bonus entry/play/result, return to base,
jackpot moment if the math has one. This script is what Phases 5-7 build.
## Pacing Plan
| Moment | Target duration | Skippable? |
Mandatory rows: full spin cycle, reel stop cadence, anticipation extension,
win count-up, each overlay tier presentation, feature enter/exit transitions.
## Math Plan
Chosen mechanic, reels, rows, line model. Existing ACTIVE Backoffice config to use
(preferred), or the config to create with the reason selection failed.
RTP target with tolerance, volatility intent, free-spin and bonus trigger rules.
## Symbol Ladder
| Math symbol id | Role (low/mid/high/wild/scatter/bonus) | Visual concept | Theme image key |
One row per symbol THE SELECTED MATH CONFIG REQUIRES — the engine rejects
save/compile/publish when any paytable symbol lacks a visual binding.
## World Frame
Chosen `runtime.slot.positions.frameSize` in world units (e.g. portrait 988x1397
or landscape 1280x720) and intended reel area, HUD zone, logo zone.
## Win And Award Views
One row per overlay view (each overlay win tier, plus free spins / bonus /
jackpot award views): scene content to author — texts with dynamic bindings
(latestWin, freeSpinsWon, bonusAmount, jackpotAmount), images, buttons.
This content is layout work (Phase 5, scoped via viewScope); its motion and
audio are sequence work (Phase 6).
## Asset Manifest
| # | Purpose | Theme key / placement | Size px | Transparent | Prompt summary |
Required rows: background (sized to frame), reel frame/border, logo, every symbol
(one square transparent PNG each, uniform size, e.g. 512x512), splash/tile art,
bonus scene art, win/award view art, any HUD/button replacement art.
## Animation Sequence Designs
One block per Experience Script beat that animates:
- Moment, trigger, scope, target roles.
- Tracks: ordered clips as `family:id` from catalog.md, each with duration,
  easing, and overlap relative to the previous clip.
- End state after natural completion AND after skip/cancel.
- Escalation note for win tiers: what this tier adds over the tier below.
## Signature Moment
The one moment designed above catalog defaults — the thing a player would
screenshot. State which Capability Gap Ladder rung it needs and why.
## Capability Gap Review
| Sequence | Verdict |
One row per sequence design: EXISTING (ids suffice), TUNE (settings/keyframes),
EXTEND (new catalog entry: family, working name, why it is generic), or
SPRITE (frame plan). A run where every row is EXISTING must state why the
catalogs sufficed for the signature moment.
## Win Tier Plan
| Tier | Threshold (win/bet multiplier) | Overlay? | Celebration effect | Sound cue |
Start from the default ladder recorded in catalog.md; adjust deliberately.
## Audio Plan
Audio is designed, not inherited. Music direction per scene mode (base, free
spins, bonus): mood, tempo, instrumentation, loop length (60-90s seamless).
| Cue | Experience Script beat | Source | Length | Prompt summary |
Mandatory cues: music loop per scene mode, spin start, reel stop, anticipation
riser, win stinger per tier, wild hit, free-spin trigger, bonus entry/pick/result,
UI clicks. Source: GENERATE (ElevenLabs) or REUSE (existing project-owned audio
with the reason it fits the theme). Every planned moment ends with a deliberately
bound cue, not silence.
## Typography
Display font + HUD font choice; upload TTF/OTF/WOFF2 through Studio.
```

Capability Gap Ladder (decision order for every sequence design):

1. **EXISTING** — compose catalog clips as they are.
2. **TUNE** — same clips with deliberate settings, keyframes, timing, layering.
3. **EXTEND** — new shared catalog entry (shader/particle/motion/text), only when the designed look is out of reach by tuning and the entry is generic and reusable. A well-tuned existing effect beats a mediocre bespoke one.
4. **SPRITE** — frame-based animation from generated images, for looks shaders/particles cannot express (character moments, bespoke celebratory objects).

After the document is complete, run one `l7` critique round on `design.md` (experience coherence, pacing realism, feasibility of every `family:id`, gap-ladder verdicts). Resolve every finding.

**Gate G1:** every section present; pitches recorded; every Experience Script beat covered by a sequence design or an explicit static note; every sequence clip id exists in `catalog.md` or has an EXTEND/SPRITE verdict; every symbol row maps to a math symbol id; every manifest row has size/transparency/prompt; every Audio Plan cue has source and length; critique findings resolved. Record PASS with a checklist in `session.md`.

## Phase 2 — Math Evidence In Backoffice

Recall: D9 — math work is selection-first; record elapsed at the gate.

Use Backoffice UI and engine-owned config models. Do not write math config to the database or call admin mutation endpoints by script.

1. Prefer an existing ACTIVE math config matching the Math Plan (mechanic, grid, features, RTP, volatility). Selection over creation: the run's product is the game, not new math infrastructure.
2. If none fits, create the config through Backoffice UI. Solver/seed/pipeline rework triggered here is a D9 scope decision: smallest path to an active evidence-backed config now, full fix through the defect protocol.
3. Capture in `math.md`: config id, mechanic, grid, line model, symbol id list, wild behavior, free-spin lifecycle, bonus flow, RTP evidence with tolerance, volatility evidence (hit frequency, pay distribution, or solver metrics).
4. The config must be ACTIVE — publish requires an active paytable.

If Backoffice cannot create or validate required config, add the missing feature in the correct package, then return and create it through the UI.

**Gate G2:** active config id + RTP/volatility evidence recorded in `math.md`; symbol id list matches the `design.md` Symbol Ladder exactly.

## Phase 3 — Game Identity And Pipeline Smoke Publish

1. Create the game in Studio (name, slug, mechanic, selected paytable from G2). A new game seeds starter-theme visuals plus an auto-centered reel grid — every starter visual is a placeholder you will replace or hide in Phase 5.
2. Save a draft and an immutable version of the untouched skeleton.
3. **Diagnostic smoke publish (the single pre-G7 publish, D3):** run compile/publish once on the skeleton version to prove the pipeline plumbing. One attempt. Record the outcome in `proof.md` and every failure as a defect in `defects.md`, then continue to Phase 4. Fix pipeline defects through the defect protocol; do not iterate publish here.
4. If the product would let an obviously incomplete game publish live without any blocker or warning, file that as a product defect too.

**Gate G3:** game exists with distinct slug; skeleton version saved; smoke publish attempted once with outcome recorded. Publishing is now LOCKED until G7.

## Phase 4 — Asset Production And Import

Recall: D4 — manifest/plan rows only; one image per symbol.

Work through the Asset Manifest and the Audio Plan row by row.

Images — Xainflow MCP is the image-generation path for this run:

1. Call `xainflow_get_context` first; follow its project/credit/confirmation requirements. Use image-to-image, background removal, upscale, or crop when it improves the final asset.
2. One generation per manifest row. Use the `gpt` image model for every row requiring transparency and include "transparent background" in the prompt. Symbols: one image each, uniform square canvas, transparent background, consistent rendering style and palette across the whole set (reuse style keywords + palette hex values from `design.md` in every prompt).
3. Verify every file programmatically before import — generators return RGB without alpha even when the prompt says "transparent background":

   ```bash
   sips -g pixelWidth -g pixelHeight -g hasAlpha <file>.png
   ```

   Exact dimensions per manifest row; `hasAlpha: yes` for every transparent row. Missing alpha → background-remove or regenerate now.
4. Inspect each rendered image (read the file) and judge it against the manifest purpose and palette. Then check symbols at reel-cell scale: a symbol unreadable at the World Frame cell size is regenerated now, not after layout.

Audio — ElevenLabs MCP is the audio-generation path for this run:

5. Generate every Audio Plan GENERATE row: the sound-effect tool for cues, the music tool for scene loops (discover exact tools via the MCP tool list). One generation per row, prompted from the cue's beat, mood, and the design's feel keywords. Verify duration and format programmatically (`afinfo <file>` on macOS) against the plan row; off-target length → regenerate now.

6. Import each image and audio file through the Studio asset upload/import flow. Record per row in `assets.md`: GENERATED → VERIFIED (dims/alpha/legibility for images, duration/format for audio) → IMPORTED (Studio asset id).

**Gate G4:** every Asset Manifest row and every Audio Plan GENERATE row shows VERIFIED + imported Studio asset id. A row you cannot fill becomes either a regeneration or a recorded `design.md` change with reason.

## Phase 5 — Layout Authoring

Recall: D7 — every step screenshotted and judged in writing.

Author the scene in Studio exactly as `design.md` World Frame specifies.

- All placement coordinates are world units inside `runtime.slot.positions.frameSize`. The client fits the frame responsively — never compensate with viewport-specific coordinates.
- Replace or hide every starter-theme visual deliberately: background, reel frame, symbols, logo, spin button, balance/entry/win displays, any default control art. Default starter art visible at G5 is a failure.
- Order: background → reel frame/area → symbol bindings (every Symbol Ladder row) → logo → HUD text placements → buttons → bonus scene visuals → win/award view content → splash/tile.
- Placement fit math per placed image: compare the asset's pixel aspect to its placement box aspect — distortion above ~2% means resize the box or regenerate the asset. Check neighboring placements for unintended overlap.
- Win/award view content: select each view from the Views rail and author its texts (with dynamic bindings from the Win And Award Views plan), images, and buttons; content created while a view is selected scopes to that view.
- After each group, capture a canvas screenshot into `screenshots/slot-dogfood-$stamp/` and write the D7 verdict (fit, clipping, overlap, legibility, palette). Fix before moving on.
- Capture the composed scene at two viewports (desktop landscape and a mobile-shaped viewport, e.g. 390x844) and judge both.
- Save drafts as you go.

**Gate G5:** full-scene canvas screenshot passes `ui-review`/`l7-gui-review` critique: no starter placeholders, every Asset Manifest visual present and positioned per World Frame plan, symbols legible at reel size, palette coherent. Plus a programmatic check: the preview canvas telemetry (`data-slot-theme-elements` / render mirror) lists every placed element key. Record screenshot paths, verdicts, and the element list.

## Phase 6 — Motion, Presentation, And Audio

Recall: D5 ladder, D9 bounds on EXTEND/SPRITE work, D7 verdicts.

Execute the Animation Sequence Designs, Win Tier Plan, Pacing Plan, and Audio Plan. A capability the design needs but the product lacks is a defect to fix at the correct owner boundary, not a reason to fake it.

1. Execute EXTEND and SPRITE verdicts from the Capability Gap Review first — sequences depend on them:
   - **EXTEND** (new shader/particle/motion/text catalog entry): a shared forward-only change at the catalog owner boundary — catalog data in `config/runtime/` (plus schema if settings shapes change), `pnpm --filter @slot/config codegen`, game-client runtime path, scene-compile validation, tests; verify with codegen:check, affected package tests, `pnpm typecheck`. The entry is generic, parameterized, and named like its catalog neighbors; prove it renders through the shared playground controls before authoring with it.
   - **SPRITE**: generate 4–12 frames as image-to-image variants of one base frame; pick coherence-tolerant subjects (glints, puffs, shimmers, pulses — not articulated characters unless frames verify clean). Import as a spritesheet or numbered image keys (`spark001`, `spark002`, …), author through the Sprite Animation Editor's image-sequence flow, verify playback in its preview.
2. Author each Animation Sequence Design in the Animation Editor: trigger, scope, roles, tracks, clip timings and easing per `design.md`. Preview each sequence, run the editor's validation surface, and record a D7 verdict (does the motion match the designed feel and end state?).
3. Win tiers and award views: thresholds, overlay on/off, min-display, celebration effect, and sound cue per the Win Tier Plan; fixed award views (free spins, bonus, jackpot if applicable) wired to their authored view content.
4. Spin feel: configure spin timing and anticipation per the Pacing Plan.
5. Audio: bind every Audio Plan cue (music loop per scene mode, spin, reel stop, anticipation, win tiers, wild, feature triggers, bonus, UI) to its imported or reused asset through the Studio audio surfaces. An unbound planned cue is a gate failure. Evidence: preview the moments and record cue firing via the render-mirror sound diagnostics (`activeSoundCues`/`activeLoopCues`) or a D7 verdict.
6. Pacing verification: measure the key Pacing Plan rows (spin cycle, count-up, overlay presentations) from preview runs — timestamped captures or probe elapsed data. Deviation beyond ~25% of target → adjust the config or record a `design.md` change.

**Gate G6:** every sequence design AUTHORED with preview + validation evidence and a D7 verdict; the Signature Moment demonstrably plays as designed; every EXTEND/SPRITE verdict either shipped with tests or converted to a recorded scope decision; every Audio Plan cue bound with firing evidence; pacing measurements recorded. No silent drops.

## Phase 7 — Studio Definition Of Done

Full in-Studio review against `design.md` before any publish.

1. Play the game in Studio preview through real spins and walk the Experience Script beat by beat: base spins, a win with presentation, anticipation, and (via app-exposed outcome plans or test controls only) wild, free-spin, and bonus paths.
2. Walk the checklist; each line needs evidence (screenshot verdict or observed behavior) in `authoring.md`:
   - Every Symbol Ladder symbol renders its generated art on the reels.
   - Background, frame, logo, HUD, buttons all themed; zero starter art.
   - Win tiers fire at planned thresholds with planned celebration + sound.
   - Authored sequences play for their moments; skip/cancel leaves the designed end state; no stale overlays.
   - Each Experience Script beat looks and paces as written, or `design.md` records the change.
   - HUD shows balance, bet, win, free-spin state correctly formatted; audio cues fire for planned moments.
3. Save the immutable version that will be published.

**Gate G7:** checklist complete with evidence. This gate unlocks publishing (D3).

## Phase 8 — Publish

1. Resolve any publish blockers the product surfaces.
2. Compile the immutable version through the Studio publish/compile flow; publish to live.
3. Verify `games-host` resolves `/play/<gameId>/latest` through the publication resolver and the artifact manifest references the generated runtime images.

Record artifact/version ids, routes, and screenshots in `proof.md`.

**Gate G8:** published artifact served by games-host; manifest lists the generated assets, not starter art.

## Phase 9 — Demo-Casino Proof And E2E

Use only `agent-browser` or Playwright against already-running services. Reuse existing e2e helpers and page objects (`e2e/helpers/`: game studio, asset manager, animation editor, animation-probe, demo casino, outcome plans) and `data-testid` patterns. No `waitForTimeout`, CSS selectors, snapshots, or existence-only assertions.

Proof must include:

- Demo-casino lobby shows the new game; launch loads the published iframe (not Studio preview) to ready state on a desktop viewport AND a mobile-shaped viewport (e.g. 390x844).
- All reels render final generated assets; every intended graphic element visible and correctly placed (background, frame, cells, symbols, wild, feature symbols, spin button, win layer, HUD text, popups entry, authored overlays).
- Spin completes through server `/spin`; render mirror matches the server SpinEvent response.
- Wild, free-spin trigger/resume, and bonus trigger/claim visible through app-driven play, app-created outcome plans, or app-exposed test controls. No backend debug/admin mutation calls.
- Anticipation runs for qualifying setups and clears deterministically.
- Key authored sequences (including the Signature Moment) asserted through the local-only harnesses, not eyeballs: `slotE2eAnimationHarness=1` play/skip/cancel with render-mirror animation-probe assertions; `slotE2ePresentationHarness=1` for win/award views with canvas telemetry + mirror dynamic-text assertions.
- Win tier animations run for at least low, medium, and high configured tiers; each starts, shows correct assets/text, completes or skips cleanly, leaves no stale overlay.
- Balance, bet, last win, free-spin count, and round id displayed, correctly formatted, matching authoritative engine/wallet responses before/during/after features.
- Planned audio cues fire for spin/win/feature moments, asserted via the render mirror's sound diagnostics where exposed.
- Game remains spinable after wins, win animations, free spins, and bonus claim.

Add or upgrade e2e tests: published demo-casino launch, gameplay smoke with graphic visibility and HUD assertions, spin/render parity, anticipation trigger/cleanup, win tier start/completion/skip, UI-driven wild/free-spin/bonus coverage, regression per bug fixed.

**Gate G9:** all proof items asserted programmatically; screenshots support but never replace assertions.

## Defect Protocol

When a step fails:

1. Apply D8 — after three identical failures, stop retrying.
2. Classify: bug, missing feature, wrong implementation, data/config issue, environment issue.
3. Scope check (D9): an infrastructure-scale fix (schema/seed/solver/pipeline rework) gets a recorded scope decision first — smallest unblocking fix now, full fix logged in `defects.md`.
4. Read the owning package `AGENTS.md`.
5. Create a plan item with file/package scope.
6. Write or update a failing meaningful test when practical.
7. Fix at the correct owner boundary. Wrong-owner examples: client computes wins → engine/SpinEvents; demo-casino imports internal config → public wire; vectors leak into runtime → flatten to images; effect forked into a feature package → shared catalog.
8. Run narrow verification, then resume the current phase through the browser. Never backfill data by direct DB/API mutation after fixing the product.

Blocking defects (current gate cannot pass) are fixed immediately. Non-blocking defects are logged in `defects.md` and fixed after the current phase's gate passes, before final completion.

## Subagents

Use subagents when available for independent work with disjoint scopes; main context owns the design document, gate decisions, integration, and acceptance. Good delegations: read-only path mapper, asset prompt designer, math investigator, one package-scoped fix, one focused e2e flow. Every task includes explicit files/surfaces, one objective, constraints, verification, and output format. Spot-check at least one claim before relying on it.

## Acceptance Gates (Completion)

Completion is blocked until all are true:

- Gates G0–G9 each recorded PASS with evidence and elapsed time in `session.md`.
- Fresh game with distinct name/slug; runtime and math data-driven, not hardcoded.
- Required feature set (defaults or user plan) server-authoritative and player-visible.
- RTP and volatility evidence support the recorded targets.
- Final visuals cohesive, generated, zero starter placeholders; the Experience Script plays as designed or with recorded changes.
- Game creation, math authoring, runtime authoring, versioning, compile/publish, and demo launch all performed through browser automation of app UI; Xainflow is the only non-app creation exception.
- Every encountered failure has a task and is fixed, unless blocked by credentials, external service, or an explicit user decision; D9 scope decisions recorded with full fixes logged.
- `proof.md` contains URLs, artifact/version ids, screenshots, commands, test results.

## Antagonist Review

Before the final response, perform a hostile review against the repo and proof artifacts. FAIL if any statement is true:

- Any gate was skipped, reordered, or marked PASS without evidence.
- A publish was attempted between G3 and G7.
- The game exists only as a fixture, seed, mock, or direct DB row, or any game/math/runtime/version/publication state was created outside app UI.
- The game works in Studio preview but not in published demo-casino.
- `design.md` and the shipped game disagree without a recorded design change, or `design.md` lacks concept pitches, an Experience Script, a Pacing Plan, sequence designs with tracks and end states, a Signature Moment, or Capability Gap Review verdicts.
- Any starter-theme visual is still visible in the published game.
- Any sequence design, Win Tier Plan row, or planned audio cue was silently dropped, or an authored sequence differs from its design without a recorded change.
- A layout or animation screenshot lacks a written D7 verdict, or an asset was imported without dimension/alpha (image) or duration/format (audio) verification.
- Pacing Plan targets were never measured.
- An EXTEND/SPRITE verdict shipped without codegen checks and tests, or a new effect was forked into a feature package instead of the shared catalog.
- An animation was implemented as a sprite/spine clone of a reference game, or text uses a bitmap-font sheet.
- RTP/volatility are labels without evidence; wild/free-spin/bonus are not server-authoritative.
- Any intended graphic or HUD value is not asserted in demo-casino proof, animations are only visually inspected, or no mobile-viewport proof exists.
- E2E tests cannot fail on broken launch/gameplay/display wiring.
- Defects found on the path were logged but never fixed, without an explicit blocking reason or recorded D9 scope decision.

Write findings to `proof.md` under `Antagonist Review` with exactly one verdict: `PASS` or `FAIL`. On `FAIL`, fix and rerun the relevant proof.

## Completion

Finish only after the deadline passes or the user stops the run, and the acceptance gates pass.

Final report: game name/slug; what was created in Backoffice and Studio; artifact/version/demo-casino proof; Xainflow images and ElevenLabs audio generated; catalog entries or sprite sequences added; bugs/features fixed; e2e tests added; verification commands and results; residual risks stated without overselling.

## Compaction Recovery

After compaction:

1. Find newest `logs/slot-dogfood-*`.
2. Read `session.md` first: recover deadline, current phase, gate ledger, and scope decisions.
3. Read `design.md` and `catalog.md`, then the phase-relevant files (`math.md`, `assets.md`, `authoring.md`, `proof.md`, `defects.md`).
4. Resume inside the first phase whose gate is not PASS. Do not redo passed gates; do not skip ahead.

Final-token anchor: design the player's experience first — script, pacing, sequence designs, signature moment, audio per beat; gates in order with elapsed time recorded; one smoke publish then publish-locked until the Studio Definition of Done; every asset specified, then generated (Xainflow images — `gpt` model for transparency; ElevenLabs SFX and music) and verified for size, alpha, and duration; catalog-first, extend deliberately through the ladder; every screenshot judged in writing; budget checkpoints force recorded scope decisions, never silent cuts. Prove it plays: published demo-casino proof with programmatic assertions is the bar.
