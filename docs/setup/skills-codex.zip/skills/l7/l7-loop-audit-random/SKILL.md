---
name:  l7-loop-audit-random
description: "Use for randomized L7+ feature audit: pick random source files, trace feature, review behavior, architecture, tests."
argument-hint: "[hours] — minimum time budget in hours (default: 1)"
user-invocable: true
---

Deep investigation of a codebase from the perspective of a Senior Staff Engineer (Google L7+), one random feature at a time. Each cycle is a rabbit hole — follow it wherever it leads. Quality of insight matters; cycle count does not.

**Minimum time budget: $ARGUMENTS hours (default: 1 if no argument given).**


## Startup

1. Run `date +%s`. Compute `deadline_unix = started_unix + ($ARGUMENTS * 3600)` (default 1 hour). Write `logs/audit_rnd_$(date +%Y%m%d_%H%M%S).md` with `started_unix`, `deadline_unix`, human-readable times. Store this path as the **audit log**.
2. Read the docs, serena memories, memories.
3. State the purpose of the project in chat. What is the codebase? What does it do? What are its main features? What is the tech stack? What are key concepts and what does this project do differently to common practices and why? What could an audit flag as wrong but is actually intentional?
4. Begin the work loop with chat message "Starting next cycle" - never enumerate cycles.

## The Work Loop

### Step 1: Pick A Random File

```bash
files=($(find . -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.css" -o -name "*.scss" -o -name "*.py" -o -name "*.rs" -o -name "*.cpp" -o -name "*.h" -o -name "*.swift" -o -name "*.java" \) ! -path "*/node_modules/*" ! -path "*/.git/*" ! -path "*/dist/*" ! -path "*/build/*" ! -path "*/__pycache__/*" ! -path "*/vendor/*" ! -path "*/.next/*")); echo "${files[$RANDOM % ${#files[@]}]}"
```

Record `date +%s` as `cycle_start`. If the file is trivially small (under 5 lines, auto-generated, or a barrel export), re-roll.

### Step 2: Go Deep and Build a Mental Model

Read the file. Trace its imports — read those files. Trace its exports — find every caller, read those files. Identify the feature or subsystem this file belongs to. Read every file in that feature: siblings, shared types, tests, styles, utilities, configuration.

Do not skim. Read the implementations, not just the signatures.

State in chat the purpose of the feature, how it works, and how the files relate to each other. This is your mental model. You will use it in the next step to find issues. If your model is incomplete or wrong, you will miss things. Do not skip this step.


### Step 3: L7+ Review

What would an L7+ SWE at Google say about this feature?
What questions would an L7+ SWE at Google ask?
What would they criticize? What would they praise?
What would they change?
What would they do to make this exceptional?

Everything is in scope. Do not limit yourself!

Create an `update_plan` item for every finding.

**Depth gate:** If you are about to declare 0 changes, stop. Think through and challenge that conclusion.

### Step 5: Inplement

For anything beyond a trivial change, use the three-phase protocol:

1. **Propose**: Investigate the code. Propose a solution with specific evidence. No edits yet.
2. **Critique**: Attack your own proposal by thinking it through. What did you assume without checking? What did you miss? What breaks downstream?
3. **Synthesize**: For each critique finding — accept with modifications, reject with cited evidence, or investigate further.

Only then: implement.

**Larger changes or cross-cutting architectural redesigns**: launch a subagent with `model: "opus"` and invoke `/l7`. Describe the problem and quality bar — not the solution.

### Step 6: Log and Loop

Update the audit log: append which file was picked, which feature it belonged to,  the improvements made. Do not enumerate or count cycles in the log or in chat.

**Never stop before the deadline `deadline_unix`.**
Run `date +%s`. If current time < `deadline_unix`, go back to Step 1 with chat message "Starting next cycle" - never enumerate cycles. Otherwise proceed to Completion.

## Completion

Only run when current time < `deadline_unix` - else return to the work loop step 1.

1. Run the full pipeline: lint, type check, test, build. All must pass.
2. Review current plan. Every task must be `completed`.
3. Delete the audit log.
4. Report: cycles completed, features reviewed, changes made, how the project was elevated.

## Compaction Protocol

After context compaction:
1. Glob for `logs/audit_rnd_*.md`. Read the most recent match — re-internalize the deadline and progress.
2. Review current plan to see current tasks.
3. Resume the work loop from Step 1.
