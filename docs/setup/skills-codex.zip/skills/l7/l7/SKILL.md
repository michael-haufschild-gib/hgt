---
name: l7
description: "Use for rigorous engineering judgment on bugs, features, architecture, code changes, testing, tradeoffs, or reviews."
argument-hint: "<task description or question>"
user-invocable: true
---

Every response follows three mandatory phases. No phase may be skipped. Deliver all three before making any code changes.

**No file edits, no code writes, no implementation during Phases 1-3.** The three phases are a reasoning protocol. Read, investigate, and analyze — but do not modify any files until Phase 4 (Implementation). Tool use during Phases 1-3 is limited to: Serena mcp, `Read`, `Grep`, `Glob`, `WebSearch`, `Bash` (read-only commands only), and private reasoning.

$ARGUMENTS

## Phase 1: Investigate and Propose

Read the relevant code before answering. Trace call chains, understand callers and side effects. Use Serena mcp, `Grep`, `Glob`, `Read`, and `WebSearch` as needed — do not answer from memory when the codebase or current documentation can be checked.

Propose a solution, approach, or analysis. Describe what you would change and where, with specific file paths and line numbers. Do not make the changes yet.

For every claim, cite evidence: file path and line number, command output, or verified external source. Claims without evidence are unverified — mark them as such or remove them.

Behavioral constraints for this phase:
- Trace root causes, not symptoms. If the user reports a bug, find the code path that produces it.
- Evaluate downstream impact. Every change affects callers, consumers, and tests.
- When choosing between approaches, state the trade-off explicitly: what each option costs, what each gains, which failure modes each introduces.
- Check for the same problem class elsewhere. A bug in one handler likely exists in sibling handlers. A pattern violation in one file likely recurs.
- Consider failure modes and edge cases before proposing.
- Prefer the harder correct solution over the easier approximate one when the difference affects correctness or maintainability at the project's actual scale.
- Check CLAUDE.md for scale context. If absent, default to midsize enterprise: millions of users, reasonable team, standard infrastructure. Propose the simplest correct solution at that scale. If a more complex approach would be needed at FAANG scale (billions of requests, multi-region, custom infrastructure), mention it as a footnote — do not implement it.

Deliver under an `## Initial Analysis` header.

## Phase 2: Adversarial Critique

Think through this phase privately. Increase reasoning depth for complex tasks.

Switch perspective. You are now a hostile, independent critic who did not write the Phase 1 proposal. Your goal is to find every reason the proposal is wrong, incomplete, risky, or naive.

Forget what you proposed. Assess only whether it is correct and complete.

For each claim in your initial analysis:
- State the supporting evidence. If there is none, mark the claim `[UNVERIFIED]`.
- State what would make this claim wrong. If you cannot articulate a failure mode, the analysis is shallow.

Attack vectors — check each:
1. **Correctness**: Does the proposed change actually fix the root cause? Could it introduce new bugs? Are there code paths where it fails?
2. **Completeness**: What did the initial analysis miss? Files not checked, call sites not traced, edge cases not considered?
3. **Assumptions**: What is the proposal assuming about state, ordering, concurrency, or input that is not guaranteed? Are the assumption backed by evidence?
4. **Downstream impact**: What breaks? What tests need updating? What consumers are affected?
5. **Alternatives**: Is there a simpler, more correct, or more maintainable approach that was not considered?
6. **Evidence quality**: Which claims rest on evidence and which rest on plausible-sounding reasoning?
7. **Overengineering**: Is the proposed solution more complex than the actual scale and team require? Is this FAANG-scale infrastructure for a midsize problem? Could a managed service, a synchronous API call, or a simpler pattern handle the real-world load? Would the operational overhead (infrastructure, monitoring, debugging surface) exceed the problem it solves?

Constraints for this phase:
- State what is wrong before what is right.
- When uncertain, say so explicitly. Do not pad uncertainty with confident language.
- Disagree with your own Phase 1 assessment when evidence warrants it.
- Do not soften findings. "The proposal handles the common case but silently drops edge case X" is a finding. "The proposal is a good start" is not.
- If you found fewer than 2 issues, re-examine — you are being too lenient on your own work. Go deeper: re-read the files, check more call sites, trace more paths.

Deliver your critique under an `## Adversarial Critique` header. List every finding with file paths and line numbers where applicable.

## Phase 3: Synthesis

Review your initial analysis and adversarial critique together. This phase produces the final answer.

For each critique finding, do one of:
- **Accept**: the critique is valid. Modify the proposal. State what changed and why.
- **Reject**: the critique is wrong. Cite specific evidence (file:line, test output, documentation) proving it wrong. "I believe the original is correct" without evidence is not a rejection.
- **Investigate**: the evidence basis is thin for either side. Run additional investigation now — `Read` the relevant files, `Grep` for usage patterns, `WebSearch` for current best practices. Then accept or reject based on what you find.

Every `[UNVERIFIED]` claim from Phase 2 must be resolved in this phase. Either verify it with evidence or remove it from the final answer.

Constraints for this phase:
- The final answer must differ from the initial analysis wherever the critique was validly accepted. If the adversarial phase found real issues, the synthesis must address them — not restate the original.
- State remaining uncertainty explicitly. "I was unable to verify X" is acceptable. Silent uncertainty is not.
- Where the initial analysis and critique conflict and evidence is ambiguous, present both positions and state which you favor and why.

Deliver the final answer under an `## Final Answer` header. This is the plan that will be implemented.

## Phase 4: Implementation

This phase runs only after Phases 1-3 are complete. The Final Answer from Phase 3 is the specification — implement exactly what it describes.

Now make the code changes, write the tests, update the configuration, or perform whatever work the Final Answer prescribes. Use `Edit`, `Write`, `Bash`, and any other tools needed.

After implementation, run the relevant verification (tests, linter, type checker, build) to confirm the changes work.

If verification reveals issues not anticipated by the Final Answer, fix them and note the discrepancy — do not re-enter the three-phase cycle for minor implementation details.

## Output Structure

```
## Initial Analysis
[Phase 1 — proposed approach with evidence, no code changes]

## Adversarial Critique
[Phase 2 — findings attacking the proposal]

## Final Answer
[Phase 3 — synthesized plan incorporating valid critiques]

[Phase 4 — implementation of the Final Answer, with verification results]
```

Scale depth to task scope. A variable rename gets concise phases. An architecture change gets thorough phases. Match the effort to the complexity, but never skip a phase.

---

No code changes until Phase 3 completes. Phases 1-3 use read-only tools only. Phase 2 requires private reasoning. Phase 3 addresses each critique finding with accept, reject (with evidence), or investigate (with additional tool use). The Final Answer is the implementation spec — Phase 4 executes it.
