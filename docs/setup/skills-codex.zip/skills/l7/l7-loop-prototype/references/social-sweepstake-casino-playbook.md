# Social Sweepstakes Casino Playbook

For product designers, UX writers, live-ops managers, CRM owners, campaign operators, support leads, VIP teams, and anyone approving player-facing offers.

This is not a law memo, finance model, or engineering spec. It is a practical guide to the screens, campaigns, messages, and daily decisions that shape player trust and business performance in a social sweepstakes casino.

Everything here comes back to one test: **trust before pressure.**

In this category, trust is not soft brand language. It is the product. Players need to understand what they are buying, what they receive for free, what can be redeemed, what cannot be redeemed, why a redemption is blocked, how eligibility works, and how to get help. When those things are unclear, every later campaign becomes more expensive, riskier, and less credible.

Use this as a working playbook. Start with the non-negotiables. Use the journey chapters when designing screens, the offer chapters when launching promotions, the CRM chapters when deciding who sees what, and the checklists when reviewing work before launch.

## How To Use This Playbook

Use the section that matches the work in front of you. This is not meant to be read cover to cover every time.

If you are designing a screen, start with **The Mobile Player Journey**, then use **Screen Field Notes**, **Copy Bank**, and **Design Review**. Focus on the current player task and make failure states explainable.

If you are launching a campaign, start with **Non-Negotiables**, then use **Offers And Shop Governance**, **Live-Ops Calendar Rules**, **Campaign Playbooks**, and **Measurement And Stop Rules**. Know who sees the campaign, who does not, what it costs, what stops it, and what support will say.

If you are running CRM, start with **CRM And Segmentation**, **Player-State Playbooks**, and **Commercial Suppression Gate**. Make sure safety, consent, support, redemption, and fatigue override commercial pressure.

If you are in support, start with **Redemption Runbook**, **Support**, **Copy Bank**, and **Operating Scenarios**. Keep product state, player explanation, and internal reason codes aligned.

If you manage VIP, start with **VIP As Service**, **Player In Risk State**, **VIP Service Recovery**, and **Trust Standards By Moment**. Use personal attention for service and recognition, not pressure.

If you are a leader reviewing product quality, start with **Manager Read-Through**, **Final Pre-Launch Walkthrough**, and **Do Not Build Or Say**. Look for operating drift: more pressure, more clutter, weaker suppression, unclear redemption, and campaigns that cannot be explained.

Use this guide in three rhythms.

Before design work, use it to frame the problem. A brief should say the player state, screen job, currency exposure, suppression needs, support state, and measurement plan. Without that, the design team ends up making product decisions inside pixels.

During review, use it to find missing states. Do not review only the ideal path. Review decline, close, expired, ineligible, suppressed, payment failure, verification needed, support distress, and blocked redemption. If those states are missing, the work is not done.

After launch, use it to decide what stays. A campaign that looked good in preview can still create confusion. A flow that passed design review can still create support tickets. A CRM journey can still over-contact. Post-launch review should update components, copy rules, campaign defaults, support macros, and suppression rules.

The playbook is strict around money, redemption, risk, and automation. It leaves room around theme, art direction, event creativity, content, and brand voice. Use that distinction. Be creative where creativity helps entertainment. Be boring where clarity protects trust.

When teams disagree, return to the player moment. A designer may want a calmer screen, live ops may want another campaign slot, CRM may want a sharper segment, finance may want lower exposure, and support may want fewer edge cases. The right answer is usually visible when everyone states what the player is trying to do and what could go wrong if the product gets louder, vaguer, or harder to exit.

That habit protects both player trust and operator judgment when campaign pressure rises quickly.

## Start Here

### What We Are Building

A social sweepstakes casino usually serves two player motivations at once.

Some players are here for entertainment: game discovery, progress, status, collections, daily rewards, events, and social activity. They care about fun, clarity, and momentum.

Some players are prize-aware: they watch Sweepstake Coin balances, eligibility, redemption rules, verification, payment methods, and support responses. They care about trust, fairness, and whether the product behaves as promised.

The product has to serve both groups without confusing either one.

Gold Coins and Sweepstake Coins need to stay visibly separate everywhere. Gold Coins are the paid entertainment currency. Sweepstake Coins are promotional and may become redeemable only when the player meets the rules. Players will often judge a package by the Sweepstake Coins it includes; that is a basic commercial reality of the category. The screen still has to make the structure clear: GC is the purchased item, SC is the promotional value, and free-entry access exists. Do not write copy that says players buy Sweepstake Coins directly. Do not make Sweepstake Coins look like a standalone priced product. Do not hide the free-entry route. Keep internal terms like liability, ratio, risk score, and high-value pressure out of player-facing copy, support macros, push messages, emails, affiliate briefs, and creator talking points.

Redemption is not a back-office feature. It is one of the main trust surfaces in the product. A player should be able to see redeemable balance, eligibility progress, verification status, expected timing, blocker reason, and support path without guessing. If redemption is blocked, the screen should explain what happened, what the player can do next, whether funds are safe, and when support will respond. Keep purchase offers, upsells, urgency, and retention popups out of the redemption flow.

Live ops should create rhythm, not clutter. A good calendar gives players a clear reason to return, a clear next action, and a clear reward path. A bad calendar floods the lobby, shop, inbox, and popups until nothing feels important. Use defined campaign slots. Avoid stacking major pushes. Pause commercial messages when a player shows risk signals: cooldown activity, self-exclusion, high spend velocity, repeated failed payments, unusually long sessions, redemption distress, support complaints, opt-outs, or message fatigue.

Offers need math before art. Before any starter pack, chain offer, VIP bonus, winback reward, draw ticket bundle, or Free Sweepstake Coin grant goes live, the owner must know who is eligible, where the offer is allowed, how much Gold Coin value is sold, how much Free Sweepstake Coin exposure is created, what support or fraud cost is expected, how success will be measured, and which guardrails stop the campaign. Raw purchase conversion is not enough. A campaign that raises purchases while increasing complaints, opt-outs, support load, redemption failures, or responsible-play signals is not a win.

Personalization should help players navigate, not help the business find vulnerable timing. It is acceptable to personalize game recommendations, campaign relevance, shop complexity, notification timing, and content based on behavior and stated preferences. It is not acceptable to individualize price or pressure from inferred income, home area, device price, employment, education, age proxies, financial stress, loss velocity, failed payments, or late-night escalation. When in doubt, suppress the commercial action and show neutral support, account tools, free claims, preference controls, or responsible-play controls.

AI can help the team work faster. It cannot replace accountable human judgment. AI may draft copy, summarize campaign results, flag anomalies, create first-pass art, suggest segments, or triage moderation. Humans approve anything that affects money, eligibility, sanctions, compliance, payout, redemption, support escalation, or player protection.

### Plain Terms

**Gold Coins (GC)** are paid entertainment currency. They are used for play, progress, and entertainment value. They are not redeemable.

**Sweepstake Coins (SC)** are promotional sweepstakes entries or credits. They may become redeemable only under approved rules. Players often treat them as the main value cue in an offer, but player-facing copy still needs to preserve the approved purchase structure.

**Free Sweepstake Coins** are promotional SC. Player-facing copy should make the free or promotional nature clear and avoid dollar-like pricing.

**AMOE** means alternate method of entry. It is the no-purchase path. Players should be able to find it from relevant product, promotion, rules, and help surfaces.

**Redemption** is the player process for requesting eligible value after the rules are met. It includes eligibility, verification, method selection, review, approval, payment or prize delivery, and support.

**KYC / verification** means identity or account checks required by legal, compliance, fraud, payment, or redemption policy. Timing is not a design choice alone. It must be approved.

**Suppression** means replacing or stopping commercial prompts because the player, channel, account, jurisdiction, risk state, or consent state makes a commercial action inappropriate.

**Holdout** means a group of eligible players who do not receive a campaign so the team can see whether the campaign truly changed behavior.

## Non-Negotiables

These rules block launch. They are not growth ideas; they are operating controls.

### The Launch Gate

Before any player-facing release, campaign, shop change, redemption change, VIP program, CRM journey, affiliate claim, creator promotion, or AI-assisted decision flow goes live, the owner needs answers to these questions.

| Gate | What Must Be True |
|---|---|
| Legal and compliance | Current jurisdiction, sweepstakes, AMOE, age, verification, tax, terms, and responsible-play review is complete for the intended launch scope. |
| Platform and channel | Native app, web, ad network, payment, wallet, push, email, SMS, affiliate, and creator claims are approved for the exact use case. |
| Currency clarity | GC and SC are separate in copy, layout, balances, receipts, ledgers, analytics, support, and campaign briefs. |
| AMOE readiness | The no-purchase path is discoverable, operational, supportable, and consistent with approved rules. |
| Redemption trust | The product shows redeemable balance, eligibility, verification state, expected timing, blockers, and support path. |
| Suppression | Commercial prompts stop for self-exclusion, cooldown, risk, consent, fraud, support, redemption distress, and fatigue signals. |
| Finance and liability | Free SC exposure, redemption cost, fees, fraud, chargebacks, support load, and campaign budget have an owner and stop rule. |
| Measurement | The campaign or feature has a hypothesis, eligible audience, holdout or comparison plan, guardrails, rollback owner, and post-launch review. |
| Support | Support macros, escalation paths, blocker reasons, refund or chargeback handling, and player explanations are ready. |

If a team cannot answer a gate, softer copy will not fix the gap. Stop and route it to the right owner.

### Internal Policy Versus External Rules

Use precise review language.

"We require" means an internal operating policy. Example: we require no purchase offers inside redemption.

"Legal must review" means the team does not decide alone. Example: legal must review any playthrough requirement, state availability, AMOE flow, redemption threshold, expiry, or prize mechanic.

"Platform owner must review" means the team must check current app-store, ad-network, payment, or messaging rules before use.

"Test default" means a starting point. It is not a universal best practice. Package count, message cadence, timers, holdout size, chain depth, season length, and campaign spacing all belong in this category.

### Decision Priority

When rules conflict, use this order:

1. Legal, compliance, responsible-play, jurisdiction, consent, and account integrity.
2. Redemption clarity, support clarity, and player trust.
3. Finance, SC exposure, fraud, payment, and operational risk.
4. Player experience quality: clarity, accessibility, performance, fatigue.
5. Retention and engagement.
6. Revenue, conversion, and campaign lift.

This order matters. A VIP offer does not override a cooldown. A churn score does not override a complaint. A model recommendation does not override suppression. A high-value account does not override redemption clarity.

## Currency And Redemption Basics

### Separate The Currencies Everywhere

GC and SC separation has to survive the full journey:

| Surface | Required Treatment |
|---|---|
| Header and wallet | Show separate balances with short plain labels. Do not combine into one account value. |
| Shop card | Show the GC package and make the Free SC value easy to compare, while labeling it as promotional. |
| Checkout | Confirm the player is buying GC. Show Free SC clearly as free or promotional value, if included. |
| Receipt | Repeat what was bought, what was granted free, payment method, timestamp, and support path. |
| Account history | Keep purchase history, promotional grants, SC eligibility, and redemption history understandable. |
| Support macros | Preserve the same wording support sees and players see. |
| Analytics | Track GC sale and SC exposure separately. |
| Finance | Model SC as potential redemption exposure, not as decorative bonus text. |

Bad currency design creates disputes. It is expected that players compare offers by Free SC, especially prize-aware players. The screen fails when it makes SC look like a standalone purchased product, hides the GC purchase framing, or obscures the no-purchase route.

### Player-Facing Copy Rules

Use direct words.

Good:

- "Buy Gold Coins."
- "Includes Free Sweepstake Coins as a promotional bonus."
- "Sweepstake Coins may be redeemable when eligibility requirements are met."
- "No purchase necessary. See official rules."
- "Redeemable balance."
- "Verification may be required before redemption."
- "Your redemption is under review. Your balance remains visible while we review it."

Avoid:

- "Buy Sweepstake Coins."
- "Deposit."
- "Cash balance."
- "Guaranteed winnings."
- "Risk-free."
- "Boost your odds."
- "Only paying players can win."
- "One more purchase to unlock redemption."
- "This offer improves your chance to redeem."
- "Everyone at your tier is buying now."

The shop may be energetic. It cannot be ambiguous.

### Free Entry Must Be Findable

The no-purchase path should not be a scavenger hunt. Players should be able to find it from:

- Sweepstakes rules.
- Footer or account help.
- Shop or promotion terms.
- Customer support.
- Relevant campaign details.
- Redemption education.

Do not make AMOE visually compete with the purchase CTA inside every payment step, but do not bury it so deeply that only legal experts can find it. Treat it as trust information.

### Redemption Is A Product Surface

A redemption screen should answer:

- What amount is redeemable now?
- What amount is locked, pending, ineligible, or still in progress?
- What threshold or eligibility condition remains?
- Is verification required now, later, or already complete?
- Which redemption methods are available for this player?
- What timing should the player expect?
- What fees or method constraints apply, if any?
- Why is a request blocked?
- What can the player do next?
- How does support help?

Every blocked state needs three pieces:

| Piece | Example |
|---|---|
| Player explanation | "We need to verify your identity before this redemption can continue." |
| Next action | "Upload the requested document" or "Contact support." |
| Internal reason code | Used by support, fraud, compliance, and reporting. |

No redemption screen should contain a purchase offer, countdown sale, chain offer, winback offer, or VIP pressure. Redemption is where the product proves it can be trusted.

### Verification Timing

Do not promise that verification is never needed. Do not surprise players with verification only after they have invested effort and cannot understand why the request appeared.

Good design sets expectations early:

"Verification may be required before redemption."

"We will show any required steps before your redemption is submitted."

"If review is needed, we will show the reason and next step."

The exact timing of verification is a legal, payment, fraud, and compliance decision. Designers decide how clearly it is explained, not whether it exists.

## The Mobile Player Journey

Most players will experience the product on a phone. Mobile design is not a responsive afterthought; it is the primary product.

Each screen needs a clear job. A screen that tries to sell, teach, redeem, entertain, and cross-promote at the same time will do all of those poorly.

### Landing And Promo Pages

Treat the landing page as a trust-clearance surface before treating it as a conversion surface.

The first view should make three things clear: what the player gets, what action comes next, and why the product is credible enough to continue. The offer shown in an ad, email, push, affiliate page, creator video, or social post should match the landing page. If a creative promises a welcome reward, the landing page should not make the player search for it.

Use one clear primary action. Do not place multiple competing offer cards above the first CTA. Decorative art should not push the value, eligibility, or trust copy below the point where mobile users will miss it.

Put trust near the decision: no-purchase language where relevant, official rules access, eligibility notes, secure account language, support path, and responsible-play access. Trust copy should be readable. It should not feel like legal dust sprinkled at the bottom.

Avoid:

- Fake countdowns.
- Vague "limited" claims.
- Creator or testimonial claims that cannot be substantiated.
- Winner stories without approved disclosures.
- Ad copy that says or implies purchase improves odds.
- Landing pages that hide state, eligibility, or rules until after registration.

### Signup And Login

Signup should reduce uncertainty, not collect everything at once.

Ask for the minimum required to create the account, then collect more information when the player reaches a moment where it makes sense and policy requires it. Use persistent labels, clear error messages, password help, verification-code autofill where possible, and visible progress for multi-step flows.

Do not stack permission prompts at cold launch. Ask for notification permission after the player understands what notifications are for: reward reminders, account status, event updates, redemption status, or chosen alerts. Never imply that notification permission improves odds or eligibility.

Make login, account recovery, and support easy to find. A player who cannot access an account with pending balance or redemption interest becomes a support and trust problem.

### First Session

The first session should build comprehension and confidence.

Do:

- Show the welcome reward or free starting value.
- Explain GC and SC through action, not a long lecture.
- Let the player try a game quickly.
- Show where balances live.
- Introduce daily claim or mission progress after the player sees value.
- Let the player enter the shop if they choose to.
- Keep account and responsible-play controls findable.

Do not:

- Interrupt the first session with purchase popups.
- Trigger offers from confusion, losses, near-misses, or failed actions.
- Force KYC unless policy requires it.
- Show multiple live events before the player understands the core loop.
- Use a tutorial overlay that blocks play and asks the player to memorize the product.

User-initiated shop browsing is allowed. Interruptive first-session purchase pressure is not.

### Lobby

The lobby decides whether the product feels alive or chaotic.

Good lobby design gives the player a next action without hiding choice. Use a clear primary event or featured game, recent games, recommended games, favorites, search, filters, and a small number of live-ops surfaces. The lobby should not become a wall of banners.

The main hero slot should carry one decision at a time: a major event, featured game, collection, tournament, or welcome path. Avoid carousel dependence for anything important. Many players will never see later slides.

Game cards should show what a player needs to choose: title, thumbnail, provider or category where useful, and one or two meaningful cues such as new, event, jackpot, mission, or favorite. Do not cover every tile in badges. If every game is hot, nothing is hot.

The lobby should feel responsive even when art is still loading. Live-ops teams need asset budgets and review. Oversized campaign art should not be able to slow the core lobby.

### Game Page

Above the fold, the player should know what the game is, why it is credible, and what action is available.

Show title, provider, game preview or art, relevant stats or rules access, and a clear play CTA. Keep related games, promotions, and event tie-ins below the main play decision.

During active gameplay, suppress shop and promo popups. Balance, help, exit, responsible-play tools, and relevant game controls should remain consistent. Offers belong at natural pauses, not in the middle of play.

### Shop

The shop is decision architecture. It should not feel like a spreadsheet, a slot machine, or a negotiation.

A good shop starts with a simple structure:

- Featured approved offer, if any.
- Daily free claim or free reward, clearly separate from paid choices.
- Core GC packages.
- Bundles or personalized offers behind clear sections.
- Terms, AMOE, support, and purchase history access.

New players need fewer, clearer choices. Experienced players can see more depth after they understand the economy. VIP or personalized offers should not pollute the core grid for new users.

Every package card should make comparison easy:

| Element | Rule |
|---|---|
| GC amount | Primary package headline. |
| Free SC | Prominent value cue, clearly labeled as free or promotional. |
| Extras | Optional chips or short labels. |
| Price | Clear, final, and consistent. |
| Badge | Only if true: best value, popular, limited, or personal. |
| CTA | Buy GC, not buy SC. |

Do not pretend SC is incidental. For many players, Free SC is the value signal they care about most. The job of the shop is to let them compare that value without turning SC into a priced product or hiding the legal/free-entry structure.

Avoid bundle confusion. Do not intentionally make packages impossible to compare. Do not stack discount, timer, badge, bonus, VIP points, and receipt upsell all on the same package unless the team has explicitly approved the cognitive load and measured downstream trust.

### Checkout

Checkout should be calm, explicit, and hard to misunderstand.

Show:

- Package selected.
- GC purchased.
- Free SC promotional value, if included.
- Extras, if any.
- Final amount charged.
- Payment method.
- Terms and support path.
- Purchase confirmation.

Use approved payment methods and wallets only where platform, processor, geography, and risk review allow them. Do not design around a payment rail before the owner confirms availability.

The final button should describe the action. Use placeholders in design specs until pricing is approved: "Pay {price}" or "Buy {gc_amount} Gold Coins." Never hide a charge behind vague button text like "Continue."

### Receipt And Purchase Confirmation

The receipt is not decorative. It is a trust artifact.

It should show the completed transaction, transaction ID or support reference, GC purchased, Free SC granted, payment method, timestamp, updated balances, support link, and next action. If a post-purchase offer is allowed, it must be secondary, easy to decline, and never obscure the receipt.

Receipt copy should repeat the currency distinction. If the receipt is clearer than the shop card, the shop card needs work.

### Popups And Bottom Sheets

Use popups as part of a lifecycle system, not as one-off sales interruptions.

Good popup rules:

- Trigger from a meaningful event or natural pause.
- Make the value and next action clear.
- Provide a clear close path.
- Respect channel consent and fatigue.
- Suppress during risk, redemption, support distress, or active gameplay.
- Measure downstream behavior, not just taps.

Mobile overlays should be reachable and easy to dismiss. Bottom sheets often fit mobile tasks well because they preserve context and start near the thumb zone, but they are still interruptions. Use them with restraint.

Never use hidden close buttons, confirmshaming, disabled back behavior, fake scarcity, or repeated nagging after a decline.

### Profile, Wallet, And Settings

Profile is where identity, account control, and trust meet.

A good profile includes:

- Avatar and display name.
- GC and SC wallet access.
- Purchase history.
- Promotional grants and claim history.
- Redemption history and status.
- Tier or loyalty progress.
- Achievements or collections.
- Preferences.
- Notification controls.
- Privacy and personalization controls.
- Responsible-play tools.
- Support.

Do not bury account work under a hard-to-find menu. Players should be able to find receipts, rules, redemption status, limits, support, and notification settings without guessing.

### Search And Filters

Search is a retention feature. It helps players return to what they like and discover what fits their mood.

Make search discoverable from the lobby. Keep the query visible on results. Use chips for common filters and a full sheet for complex filters. Show applied filters as removable chips or a clear count. Empty states should help the player recover: clear filters, show popular categories, or suggest recent games.

Do not turn empty search into a purchase offer unless the offer directly solves the player need. Most of the time, better discovery is the right answer.

### Accessibility, Performance, And Motion

Meet platform accessibility standards for touch targets, contrast, focus, screen-reader behavior, text scaling, reduced motion, and input support. Accessibility is not a final QA pass. It affects conversion, trust, and support load.

Design for stable layouts. Buttons, badges, timers, translated strings, dynamic values, and loading states should not shift the screen or overlap content.

Motion should explain state, confirm action, preserve navigation context, or celebrate a meaningful moment. Do not run multiple competing animations in headers, nav, shop cards, and popups at the same time. Casino UI already carries high stimulation; hierarchy matters.

Live-ops uploads must respect performance budgets. A campaign should not be able to degrade the lobby, shop, or checkout by shipping heavy art, unreadable text, or untested animation.

## Offers And Shop Governance

### Offers Need Math Before Art

No offer should reach design review without an owner and basic economics.

The owner needs to define:

| Field | Question |
|---|---|
| Player audience | Who is eligible, and who is excluded? |
| Jurisdictions | Where can it run? |
| Channel | Where will the player see it? |
| Package | What GC is sold? |
| Free SC | What promotional SC is granted? |
| Other value | Extras, VIP points, entries, cosmetics, boosts, or access. |
| Cost | Payment fees, platform fees, support, fraud, chargebacks, tax/accounting, and expected redemption exposure. |
| Budget | What is the spend or liability cap? |
| Holdout | Who does not receive it for comparison? |
| Guardrails | Complaints, opt-outs, support load, redemption queue, risk signals, fraud, and profitability. |
| Stop rule | What pauses or kills the campaign? |
| Copy owner | Who approves player-facing wording? |
| Support owner | What macro and escalation path are ready? |
| Rollback owner | Who can turn it off quickly? |

If the answer is "we will see after launch," the offer is not ready.

### Starter Offers

A starter offer is not there to maximize first purchase at any cost. It should help a new player understand the paid entertainment economy without creating immediate regret, confusion, or unrealistic reference value.

Good starter offers:

- Are simple.
- Make GC primary.
- Make Free SC easy to compare as the promotional value cue.
- Avoid excessive complexity.
- Appear at a natural moment.
- Are easy to decline.
- Do not trigger during confusion, frustration, or losses.
- Are measured by repeat purchase, retention, complaints, support, redemption exposure, and responsible-play signals.

Do not make the first offer so generous that the normal shop feels punitive later. Do not immediately follow a decline with pressure. Do not train players that the product is a sequence of ever-louder offers.

### Second Purchase And Repeat Offers

The second purchase is a trust test. The player has already paid once. The next offer should feel consistent with the first experience, not like a trapdoor into pressure.

Use calm contexts:

- Receipt or thank-you screen, where allowed and not obscuring purchase details.
- Lobby return after a positive session.
- Milestone or achievement completion.
- Shop visit after a free claim.
- Loyalty progress view.

Avoid:

- Immediate post-loss pressure.
- Rage-quit or frustration triggers.
- Repeated prompts after decline.
- High anchors that ignore recent purchase behavior.
- Pressure during long sessions or unusual spend patterns.

Measure more than purchase rate. Look at repeat behavior, trust signals, support tickets, refunds, chargebacks, opt-outs, and suppression events.

### Chain Offers

Chain offers can work because they create visible progress. They can also turn into pressure machines if they are too long, too urgent, too opaque, or too hard to exit.

A chain offer should have:

- A clear sequence.
- Clear step states.
- One understandable timer or duration rule, if time-limited.
- Visible Free SC exposure and economy approval.
- A clear exit.
- Suppression after decline or risk signals.
- No hidden escalation.
- No impossible completion path.
- Holdout and stop rules.

For new or cautious players, chain offers should be short, transparent, and generous enough to teach the mechanic without requiring repeated purchases. For experienced players, deeper chains may be tested only when finance, support, legal, and responsible-play gates are satisfied.

Do not use ultra-short timers to degrade judgment. Do not place chain offers in redemption. Do not use chain progress to imply better odds, guaranteed redemption, or special prize treatment.

### Daily Free Claims

Daily free claims are habit builders. They should feel genuinely free and quick to understand.

The free claim can live in or near the shop because it teaches players where value lives. It must not become an unavoidable upsell gate. If a player taps to claim free value, the product should not force a purchase decision before the claim is granted.

Good pattern:

1. Player sees free claim available.
2. Player claims it.
3. Product confirms what was granted.
4. Product suggests a next action: play, mission, event, or shop browsing.

Bad pattern:

1. Player sees free claim.
2. Tap opens a purchase modal.
3. Close path is hidden.
4. Claim is delayed behind offer pressure.

### Bundles And Extras

Bundles can increase perceived value without inflating currency too aggressively, but only if players can understand them.

Good extras:

- Event entries.
- VIP points.
- Collection packs.
- Boosters.
- Badges or cosmetics.
- Convenience perks.
- Tournament entries where approved.

Bad extras:

- Unclear "mystery value."
- Hidden odds.
- Prize-like value without rules.
- Expiring value with poor disclosure.
- Add-ons checked by default.
- Extras that imply better chance outcomes.

If a bundle cannot be explained in one card and one details sheet, simplify it.

### Offer Copy Review

Every offer should pass a copy review before launch.

Approved direction:

- "Buy Gold Coins."
- "Includes Free Sweepstake Coins as a promotional bonus."
- "Limited-time offer ends {approved_time}, no purchase required to enter."
- "You are eligible for this offer because {non-sensitive_reason}."
- "No thanks" or "Maybe later" is visible.

Rejected direction:

- "Deposit now."
- "Buy SC."
- "Cash out faster with this package."
- "You are close. One more purchase."
- "Do not lose your chance."
- "Only players like you get this."
- "Everyone is buying."
- "Your balance is low. Recover now."

Copy should sound like a trustworthy entertainment product, not a pressure script.

## Live-Ops Calendar Rules

### Rhythm, Not Noise

Live ops gives the product life. It also creates clutter faster than any other function.

A campaign calendar needs to answer:

- What is the main player reason to return?
- What is the main business goal?
- What player segment is served?
- What screen owns the message?
- What else is running for the same player?
- What should be suppressed?
- What does support need to know?
- What stops the campaign?

If every surface advertises everything, the product has no hierarchy.

### Campaign Slots

Use defined slots so campaigns do not spread everywhere.

| Surface | Good Use | Avoid |
|---|---|---|
| Landing first view | One acquisition offer tied to source creative. | Multiple competing offers. |
| Lobby hero | Main event, featured game, collection, or welcome path. | Auto-rotating critical information. |
| Lobby rows | Secondary event or mission modules between game sections. | Banner after every row. |
| Game tile badge | Compact tags such as new, event, jackpot, or mission. | Badge stacks that cover art. |
| Header | Balances, level, streak, claim indicator. | Long campaign copy. |
| Bottom nav | Navigation and small actionable badges. | Campaign CTAs disguised as tabs. |
| Shop featured area | Main approved shop offer. | Multiple primary offers above packages. |
| Free claim slot | Habit claim. | Forced upsell before claim. |
| Checkout | Payment clarity. | Cross-sell before confirmation. |
| Receipt | Confirmation and optional next step. | Upsell that hides receipt. |
| Profile | Status, achievements, account controls. | Generic sale banners. |
| Redemption | Status and support only. | Any purchase or winback offer. |

### Calendar Collision

Campaigns collide when they target the same attention, budget, player state, liability pool, or support queue.

Before launch, check:

- Is another major event already running for this player?
- Is the same surface already occupied?
- Does this offer increase Free SC exposure beyond approved limits?
- Will this create support questions the team is not staffed to answer?
- Does the player have an unresolved redemption, complaint, failed payment, cooldown, or risk signal?
- Will this train players to wait for discounts?
- Does this campaign conflict with a VIP, lifecycle, or reactivation journey?

If two campaigns compete, choose the one with the stronger trust and lifecycle reason. Revenue forecast is not the first tiebreaker.

### Fatigue

Fatigue is not just "too many messages." It is too many demands on attention.

Watch:

- Popup dismissals.
- Push opt-outs.
- Email unsubscribes.
- SMS opt-outs.
- Support complaints.
- Shorter sessions after campaign exposure.
- Claims left unclaimed.
- Players ignoring event badges.
- Increased redemption or payment distress.
- Cooldown, limits, or self-exclusion after campaign contact.

When fatigue rises, reduce commercial pressure before increasing offer value. More value can still feel like more pressure.

### Campaign Launch Process

Use a simple launch process:

1. Define the player problem and business goal.
2. Confirm legal, platform, payment, channel, and jurisdiction scope.
3. Confirm currency framing and Free SC exposure.
4. Confirm suppression and eligibility.
5. Confirm design, copy, and support.
6. Confirm measurement and holdout.
7. Run internal QA.
8. Launch to limited scope where appropriate.
9. Monitor guardrails.
10. Scale, revise, or stop.

The team needs to know who can pause the campaign at any hour it is live.

## Retention Modules

Do not add every retention mechanic at once. Each module adds cognitive load, support load, fraud surface, economy complexity, and compliance review.

Use a maturity model.

| Stage | Goal | Good Work | Blocked Until Gated |
|---|---|---|---|
| Launch foundation | Clear core journey. | Currency clarity, shop, receipt, redemption, support, free claims, basic missions. | Complex prize mechanics and social value transfer. |
| Core retention | Give players a reason to return. | Daily claim, recent games, missions, loyalty progress, seasonal art. | High-liability events without finance controls. |
| Measured progression | Build longer-term goals. | Collections, badges, tier progress, event calendar, tournaments with clear rules. | Trading, SC prize pools, skill contests without review. |
| Gated experiments | Add differentiated systems. | Draws, social teams, VIP host programs, AI-assisted recommendations, random mini-games. | Dynamic payouts, emotion-reactive monetization, autonomous campaigns. |

### Daily Claims And Missions

Daily claims should provide a guaranteed positive action. Missions should make play legible.

Good daily loop:

- Player opens app.
- Player claims or advances something.
- Product confirms progress.
- Player sees a next target.
- Player can exit without punishment.

Good missions:

- Teach the product.
- Fit normal play.
- Show progress clearly.
- Avoid spend requirements unless explicitly approved.
- Reward completion without hiding conditions.
- Use game tags so players know what advances the mission.

Avoid:

- Streak repair pressure.
- Punishing missed days.
- Missions that require spend to complete.
- Opaque progress.
- Leaderboards based only on raw spend or volume.

### Loyalty And Tiers

Loyalty should make progress visible and service better.

A good loyalty screen shows current tier, next tier, benefits, progress, expiration or maintenance rules where relevant, and support path. It should not make the player feel that status is held hostage by one more purchase.

Benefits should be safe and explainable:

- Faster support.
- Host access where appropriate.
- Event access.
- Cosmetic status.
- GC bonus rates where approved.
- Capped promotional boosts.
- Clearer redemption support.

Avoid:

- Better odds language.
- Hidden prize advantage.
- Loss-based status pressure.
- Public spend comparison.
- "Keep status by buying now" during risk signals.

### Collections

Collections are best used as a retention layer. They turn individual sessions into longer-term progress.

Good collection design:

- Clear album or set structure.
- Visible missing items.
- Duplicate value.
- Earned through normal play and events.
- Catch-up paths.
- Optional social gifting where approved.
- A permanent museum or history so past progress is not erased.

Collections should not feel impossible without paying. Randomness can create excitement, but there must be deterministic or forgiving paths that prevent terminal frustration.

Trading, gifting, and marketplace-like behavior require extra review. They can create fraud, secondary-market behavior, pressure, and support complexity.

### Tournaments And Leaderboards

Competition can create energy, but raw leaderboards can pressure unsafe play.

Use:

- Matched cohorts.
- Divisions or tiers.
- Clear rules.
- Fairness notes.
- Anti-cheat checks.
- Reward tables.
- Opt-in entry.
- Privacy controls.

Avoid:

- Spend-only ranking.
- Public shaming.
- Exact public spend comparisons.
- Unclear prize eligibility.
- SC prize pools without legal, finance, fraud, and support review.
- Skill-based contests without dedicated legal review.

### Draws And Random Rewards

Draws, wheels, scratch cards, pick-a-prize, mystery chests, and ticket systems are high-attention mechanics. They are also high-risk if rules, odds, eligibility, audit, and support are unclear.

Use them only when:

- Rules are approved.
- Eligibility is clear.
- Reward tables or odds are disclosed where required.
- Ticket earning is transparent.
- Fraud controls exist.
- Winner or grant review is defined.
- Support can explain outcomes.
- Notification frequency is controlled by player preference and fatigue rules.
- Free and paid paths are not misleading.

Do not use random rewards to obscure cost, hide conditions, imply better odds from purchase, or manufacture urgency.

### Social Features

Social mechanics should create optional identity, belonging, and reciprocity. They should not create coercion.

Good social features:

- Friend gifting with limits.
- Clubs or groups with moderation.
- Cooperative missions.
- Profile showcases with privacy controls.
- Achievement sharing.
- Lightweight activity feeds.
- Friendly challenges.

Avoid:

- Spend leaderboards.
- Guild pressure to purchase.
- Public loss or balance exposure.
- Social shame.
- Creator or host pressure.
- Player-to-player transfer of redeemable value without deep review.

### Seasonal Progression

Seasonal systems refresh goals. They should not erase identity.

Good seasonal design:

- A clear theme.
- A visible path.
- Free participation.
- Optional premium or VIP layer only where approved.
- Catch-up mechanics.
- End-of-season summary.
- Preserved badges, collections, or history.

Avoid:

- Too many simultaneous passes, albums, events, and tournaments.
- Rewards that expire without clear disclosure.
- Seasons that require unhealthy session volume.
- Resetting meaningful progress in a way that feels punitive.

## CRM And Segmentation

### The Decision Ladder

Segmentation starts with safety and eligibility, not value.

Use this order:

1. Legal, jurisdiction, age, consent, account integrity, and responsible-play state.
2. Suppression and service needs.
3. Lifecycle: new, active, first purchase, repeat, at risk, lapsed, reactivated.
4. Behavior: games played, missions, collections, shop visits, claims, redemptions, support, channel engagement.
5. Value: purchase history, engagement depth, loyalty tier, redemption behavior.
6. Motivation: collector, competitor, social player, casual player, learner, prize-aware player, VIP service seeker.
7. Offer or content selection.

Do not start with predicted revenue. Do not let a model choose pressure before the rules have excluded risk.

### Commercial Suppression Gate

The suppression gate stops or replaces commercial action.

Suppress purchase offers, VIP pressure, winback offers, chain offers, and aggressive CRM when there is:

- Self-exclusion.
- Cooldown.
- Limit-setting activity.
- Responsible-play page visits indicating concern.
- High spend velocity.
- Repeated failed payments.
- Chargeback or refund friction.
- Fraud or account-integrity review.
- Long or unusual sessions.
- Loss-chasing patterns.
- Redemption distress.
- Failed or blocked redemption.
- Support complaint.
- Message fatigue.
- Opt-out or missing consent.
- Underage or jurisdiction uncertainty.
- KYC, AML, sanctions, or tax review.

Replacement content can be:

- Account tools.
- Support.
- Free claim.
- Preference center.
- Game discovery.
- Responsible-play controls.
- Redemption status.
- Educational content.

For CRM, this is the hard line: suppression beats lifecycle, VIP, predicted churn, and revenue.

### Allowed Personalization

Allowed by default, subject to normal privacy and consent review:

- Recent games.
- Favorite categories.
- Stated preferences.
- Device or viewport layout needs.
- Channel preference.
- Notification time preferences.
- Mission progress.
- Collection progress.
- Loyalty progress.
- Language and accessibility settings.
- Jurisdiction eligibility.
- Broad lifecycle state.
- Offer fatigue.

Use personalization to reduce effort and improve relevance.

### Forbidden Targeting

Do not use individual or inferred socioeconomic pressure in offers or pricing.

Forbidden for offer pressure:

- Income prediction.
- Home value.
- Employment.
- Education.
- Household composition.
- Device price as wealth proxy.
- Payment method as wealth proxy.
- ZIP-based affordability scoring.
- Debt, credit, or financial distress.
- Age proxies beyond legal and accessibility needs.
- Gender, race, health, disability, or protected-class proxies.
- Late-night desperation timing.
- Failed payment pressure.
- Loss velocity.
- Support distress.

Aggregate geography can help with market planning, localization, accessibility planning, legal eligibility, and fairness monitoring. It should not become a per-player price or pressure score.

### Reactivation

Reactivation starts by diagnosing why the player left, not by choosing an incentive.

Common lapse reasons:

- No clear first value.
- Currency confusion.
- Content fatigue.
- Progression blocked.
- Lost account access.
- Redemption frustration.
- Payment friction.
- Support issue.
- Bonus fatigue.
- Competitor pull.
- Life interruption.

Use the least pressuring path that fits the diagnosis.

For a missed habit, a saved-progress reminder or free claim may be enough. For an early lapse, show new content, mission progress, or a clearer reason to return. For a longer lapse, use product news, preference reset, survey, or service recovery before escalating value. For former high-value players, start with service and issue resolution, not bigger pressure.

Stop reactivation when the player ignores repeated contact, opts out, complains, shows risk signals, or fails to show incremental behavior versus holdout.

### Channel Rules

In-app is best for contextual prompts when the player is already active.

Push is best for short-lived, opted-in reminders the player asked for or reasonably expects.

Email is best for explanations, receipts, product news, policy updates, re-permission, and richer offers.

SMS is intrusive. Reserve it for opt-in service, high-intent, time-sensitive, or VIP contexts with strict approval.

Every channel has to respect consent, opt-out, fatigue, jurisdiction, and suppression. Do not move a player to a more intrusive channel because they ignored a safer one.

## VIP As Service

VIP should mean service, recognition, convenience, and clarity. It should not mean better odds, hidden prize advantage, pressure from a host, or exemption from safety rules.

### Good VIP Benefits

- Faster support.
- Named host or support path.
- Clear tier progress.
- Event invitations.
- Cosmetic status.
- Priority issue resolution.
- Clear redemption support.
- Special GC packages where approved.
- Capped promotional SC where approved.
- Birthday or milestone recognition.

### VIP Rules

VIP offers must still pass the same gates:

- Currency framing.
- Legal and jurisdiction review.
- Free SC exposure.
- Suppression.
- Support readiness.
- Measurement.
- Stop rules.

VIP messaging should be calm and service-oriented.

Good:

"Your host can help explain your current benefits."

"You are close to the next tier. View benefits and requirements."

"Your redemption question has been escalated to VIP support."

Avoid:

"One more purchase keeps your status."

"Players at your level are buying this."

"Do not lose VIP access."

"Your host saved this only for you" when the offer is not genuinely unique.

### High Value And High Risk Can Overlap

Do not assume high-value players are safe to pressure. High spend, long sessions, repeated payment failures, redemption distress, and support complaints should reduce pressure, not increase it.

VIP reviews should include both commercial health and player protection health. Reward the VIP team for retention, satisfaction, issue resolution, and responsible handling, not only purchases.

## Redemption Runbook

### What The Player Should See

The redemption area should be boring in the best way: clear, stable, and predictable.

Show:

- Redeemable balance.
- Non-redeemable or locked balance.
- Eligibility progress.
- Verification state.
- Available methods.
- Timing by method.
- Fees or method constraints where applicable.
- Current requests.
- Status tracker.
- Blocker reason.
- Support path.
- Rules link.

If the player is not eligible, explain why without sounding punitive. If a document is required, explain what is needed and what happens after submission. If a method fails, explain whether the player can choose another method.

### Status Language

Use plain status names:

| Status | Player Meaning |
|---|---|
| Not eligible yet | More requirements must be met before redemption. |
| Ready to redeem | Player can start a request. |
| Verification needed | Identity or account checks are required. |
| Submitted | Request was received. |
| Under review | Team or system is reviewing. |
| Action needed | Player must complete a step. |
| Approved | Request passed review. |
| Processing | Payment or prize delivery is in progress. |
| Completed | Redemption finished. |
| Blocked | Request cannot continue; explain why and next step. |
| Cancelled | Request was cancelled; explain by whom and what happens to balance. |

Do not use internal reason codes as player copy. "AML_REVIEW_PENDING" is not a message. It is an internal code that needs a human explanation.

### Blocker Taxonomy

Common blockers:

- Verification needed.
- Verification failed or expired.
- Method unavailable.
- Payment rejection.
- Duplicate account review.
- Jurisdiction issue.
- Fraud or abuse review.
- Terms or eligibility issue.
- Tax documentation.
- Chargeback or payment-risk review.
- Support escalation.

Every blocker needs:

- Player copy.
- Support macro.
- Internal owner.
- Escalation path.
- Expected update pattern.
- Balance handling.
- Audit trail.

### No-Offer Rule

No purchase offer, winback offer, VIP upsell, chain offer, countdown, or shop promo belongs inside redemption.

When a player is in redemption, the product should reduce uncertainty. A purchase prompt during redemption looks like the product is trying to distract, delay, or recover value. Do not do it.

### Support Scripts

Support should use the same currency and redemption language the product uses.

Good support tone:

"Your request is under review. Your balance is still visible in your account. We need {next_step} before we can continue. We will update you through {channel}."

Bad support tone:

"The system rejected you."

"Try buying another package."

"This is just how it works."

"Check the terms" without explaining the relevant term.

Support should never improvise legal explanations, promise approval, promise timing outside the approved range, or suggest purchase as a solution to redemption friction.

## AI And Automation

### Good AI Uses

AI is useful when it speeds up internal work and preserves human control.

Good uses:

- Summarize campaign results.
- Flag anomalies.
- Draft copy variants.
- Resize or adapt approved promo assets.
- Generate first-pass design directions inside brand constraints.
- Check text overflow, contrast, layout issues, and mobile screenshots.
- Triage support or moderation queues.
- Recommend audience or channel with reason codes.
- Draft compliance or campaign review packets.
- Detect likely fraud patterns for human review.
- Summarize player feedback themes.

### Human Approval Required

Humans approve:

- Campaign launch.
- Bonus budget or threshold changes.
- Eligibility rules.
- Account suspension or ban.
- Fraud case disposition.
- Redemption denial or release.
- Responsible-play intervention.
- Legal or compliance filing.
- Payment or prize policy.
- Production design asset release.
- Model objective changes.
- Any player-facing copy in sensitive flows.

AI can propose. Humans decide.

### AI Guardrails

Any player-affecting AI workflow needs:

- Minimized data inputs.
- Consent and privacy review.
- Reason codes.
- Audit logs.
- Monitoring.
- Human override.
- Fallback behavior.
- Appeal or review path where punitive or eligibility-affecting.
- Suppression rules outside model control.

Do not feed responsible-play or distress signals into monetization optimization. Those signals should suppress pressure or trigger support, not increase offers.

### Avoid

Do not build:

- Autonomous campaign execution.
- AI-driven dynamic payout or prize changes.
- Emotion-reactive monetization.
- Voice, camera, posture, or biometric pressure loops.
- AI companions that comfort losses or celebrate purchases.
- Black-box fraud or compliance decisions.
- Personal luck agents.
- Real-time outcome manipulation.
- AI systems that make it harder for operators to explain why a player saw, received, lost, or was blocked from something.

## Measurement And Stop Rules

### Measure Outcomes, Not Clicks

A casino campaign can look successful on clicks and still damage the business.

For every major campaign, track:

| Area | Signals |
|---|---|
| Commercial | Purchases, repeat purchases, revenue, margin, cannibalization. |
| Economy | Free SC issued, eligible SC, redemption requests, redemption cost, abuse. |
| Retention | Return behavior, mission completion, event participation, churn, reactivation. |
| Trust | Complaints, support tickets, refund requests, chargebacks, redemption confusion. |
| Fatigue | Dismissals, opt-outs, unsubscribes, ignored messages, reduced engagement. |
| Safety | Cooldowns, limits, self-exclusion, long sessions, unusual spend, support distress. |
| Operations | Support load, fraud queue, payment failures, redemption queue, QA issues. |

Do not scale a campaign until guardrails are clean. A purchase lift with worse trust indicators is not a clean win.

### Experiment Template

Use this template before launch:

| Field | Answer |
|---|---|
| Hypothesis | What player behavior should change? |
| Player benefit | Why is this good for the player? |
| Business benefit | What business result should improve? |
| Audience | Who is eligible? |
| Suppression | Who is excluded? |
| Channels | Where will it appear? |
| Creative | Which copy and design versions? |
| Currency impact | GC sold, Free SC granted, expected exposure. |
| Comparison | Holdout or other comparison group. |
| Guardrails | Complaints, opt-outs, support, redemption, safety, fraud. |
| Stop rule | What pauses or kills it? |
| Owner | Who monitors and decides? |
| Review date | When will the team decide scale, revise, or stop? |

### Stop Rules

Stop or pause when:

- Players complain that the offer is misleading.
- Free SC exposure exceeds approved limits.
- Redemption queue or support load spikes.
- Opt-outs or unsubscribes rise.
- Suppression fails.
- Fraud or abuse increases.
- Payment failures or chargebacks rise.
- Responsible-play signals increase.
- Holdout shows no meaningful benefit.
- Campaign cannibalizes standard shop behavior.
- Copy, terms, jurisdiction, platform, or payment status changes.
- A material bug appears.

Name the rollback owner before launch.

### Weekly Operating Rhythm

A practical weekly review covers:

- Campaigns launched.
- Campaigns stopped.
- Guardrail changes.
- Redemption queue.
- Support themes.
- Payment failures.
- Fraud or abuse patterns.
- Free SC exposure.
- Top complaints.
- Opt-outs and fatigue.
- VIP service issues.
- Upcoming calendar collisions.
- Experiments ready to scale.
- Experiments that should die.

Keep this meeting decision-oriented. The output should be an action: continue, change, pause, stop, escalate, or investigate.

## Copy Bank

Use these as direction, not final legal copy.

### Shop

Use:

- "Buy Gold Coins."
- "Includes Free Sweepstake Coins as a promotional bonus."
- "Offer available to eligible players."
- "No purchase necessary. See rules."
- "View details."
- "No thanks."

Avoid:

- "Buy Sweepstake Coins."
- "Deposit now."
- "Cash out with this package."
- "Guaranteed value."
- "Your odds improve."
- "Only today" unless the deadline is real and approved.

### Checkout

Use:

- "You are buying {gc_amount} Gold Coins."
- "You will receive {free_sc_bonus} Free Sweepstake Coins as a promotional bonus."
- "Total charged: {price}."
- "Payment method: {method}."
- "Need help? Contact support."

Avoid:

- "Continue" when the tap charges the player.
- Hidden fees.
- Prechecked add-ons.
- Unclear recurring language.
- Post-purchase offer before receipt details.

### Redemption

Use:

- "Redeemable balance: {amount}."
- "Verification needed before this request can continue."
- "Your request is under review."
- "Action needed: {next_step}."
- "Your balance remains visible while we review this request."
- "Contact support."

Avoid:

- "Rejected" without reason.
- "Try buying more."
- "Check terms" without context.
- "You are not allowed" when the issue is incomplete verification or method failure.

### Push And Email

Use:

- "Your daily reward is ready."
- "Your event progress changed."
- "Your redemption status was updated."
- "A game you played has a new event."
- "Choose what reminders you receive."

Avoid:

- "Do not miss out" as default tone.
- Repeated urgent sales language.
- Loss recovery pressure.
- VIP shame.
- Financial stress triggers.
- Any message after opt-out or missing consent.

### VIP

Use:

- "Your VIP benefits are available here."
- "Your host can help with account questions."
- "You are close to the next tier. View requirements."
- "We paused promotional messages while your account issue is under review."

Avoid:

- "One more purchase keeps your status."
- "Players like you are buying."
- "Your host saved this because you need it now."
- "Do not lose your place."

## Review Checklists

### Design Review

Ask:

- Is there one clear primary action for this screen state?
- Are GC and SC separate and correctly labeled?
- Is Free SC visibly promotional, not priced?
- Is AMOE or rules access discoverable where relevant?
- Is the close path clear for overlays?
- Are material terms visible before commitment?
- Does the screen work on small mobile viewports?
- Does text fit in all expected languages?
- Are touch targets and contrast accessible?
- Are loading, empty, error, success, and blocked states designed?
- Does motion explain state or merely decorate?
- Is redemption free of purchase pressure?

### Offer Review

Ask:

- Who owns the offer?
- Who is eligible?
- Who is suppressed?
- Where can it run?
- What GC is sold?
- What Free SC is granted?
- What is the expected redemption exposure?
- What support questions will it create?
- What fraud or abuse risk exists?
- What comparison group exists?
- What guardrails are monitored?
- What stops it?
- Is copy approved?
- Is support ready?

### CRM Review

Ask:

- Does suppression run before value targeting?
- Is channel consent present?
- Is the player in redemption, support distress, cooldown, or risk state?
- Is personalization based on behavior or stated preference?
- Are forbidden socioeconomic proxies excluded?
- Is the contact cadence reasonable?
- Is there a player benefit?
- Is there a holdout or comparison?
- What happens after decline?
- When does the journey stop?

### Live-Ops Review

Ask:

- What is the main player reason to return?
- What surface owns the message?
- What else is running for the same player?
- Does this collide with another event or offer?
- Is Free SC exposure capped?
- Is support staffed?
- Are rules and reward tables clear?
- Are fraud and abuse controls ready?
- Is there a rollback owner?
- What are the stop rules?

### Redemption Review

Ask:

- Can the player see redeemable and non-redeemable amounts separately?
- Can the player understand eligibility?
- Are verification expectations clear?
- Are methods, timing, and constraints clear?
- Are blocked states explained?
- Is support ready?
- Are internal reason codes mapped to player copy?
- Are purchase offers suppressed?
- Are status notifications appropriate and consented?
- Are audit logs complete?

### AI Review

Ask:

- Is AI only assisting, or is it deciding?
- What data does the model see?
- Is sensitive data minimized?
- Are reason codes available?
- Is there human approval for player-affecting actions?
- Are suppression rules outside model control?
- Is there monitoring?
- Is there fallback behavior?
- Is there an appeal or review path?
- Could the objective optimize pressure, distress, or short-term revenue at the expense of trust?

## Do Not Build Or Say

These patterns are rejected.

| Pattern | Why It Fails |
|---|---|
| Buy SC wording | Turns promotional SC into the apparent purchased product instead of the value cue inside a GC package. |
| Purchase offers in redemption | Damages trust at the most sensitive moment. |
| Fake scarcity | Creates deception and long-term distrust. |
| Hidden close buttons | Coerces action and increases complaints. |
| Forced add-ons | Weak consent and poor checkout trust. |
| Loss-recovery offers | Targets vulnerable timing. |
| Failed-payment pressure | Turns payment friction into pressure. |
| Long-session escalation | Exploits fatigue. |
| Income or ZIP pressure | Creates privacy, fairness, and reputational risk. |
| Dynamic individualized pricing from wealth proxies | Hard to justify and easy to abuse. |
| Spend leaderboards | Social pressure around money. |
| Better odds for VIP copy | Misleading and dangerous. |
| AI autonomous campaigns | No accountable judgment. |
| Dynamic payout or prize changes | Trust and regulatory risk. |
| Emotion-reactive monetization | Predatory optics and privacy burden. |
| Unrestricted trading of value | Fraud and secondary-market risk. |
| Skill contests without legal review | Jurisdiction and prize-risk complexity. |
| Obstructed opt-out | Consent failure. |
| Support scripts that say "check terms" only | Creates frustration and escalation. |

## Practical Maturity Path

### Foundation

Build this before complex live ops:

- Clear landing and signup.
- Separate GC and SC wallet.
- Clear shop and checkout.
- Correct receipt.
- Free claim.
- Basic missions.
- Redemption status.
- Support macros.
- Suppression gate.
- Measurement and rollback.

### Growth With Control

Add:

- Lifecycle CRM.
- Shop personalization by behavior.
- Loyalty tiers.
- Better lobby recommendations.
- Event calendar.
- Collections pilot.
- VIP service program.
- Support and redemption dashboards.

### Advanced Experiments

Gate carefully:

- Draws.
- Random reward mini-games.
- Tournaments.
- Social groups.
- Trading or gifting.
- AI campaign recommendations.
- AI moderation triage.
- AI design production support.

### Avoid As Strategy

Do not build the product around:

- More popups.
- More timers.
- More segmentation without suppression.
- More offers without liability math.
- More AI without clean data and human approval.
- More mechanics before redemption and support are trustworthy.

## Role Playbooks

The same principle looks different for each team. Designers, live ops, CRM, support, VIP, and data should not all read this guide the same way. Each role owns a smaller set of decisions.

### Product Design

Design owns clarity under pressure.

The product will always have more to say than a mobile screen can hold. Offers, balances, terms, missions, jackpots, social signals, VIP progress, free claims, redemption status, and support all compete for attention. Design decides what matters in the current state and what can wait.

A strong designer in this category does not start with, "Can we fit it?" The better question is, "What should the player understand now?" If the player is choosing a game, the screen should help them choose a game. If the player is paying, the screen should make the purchase unambiguous. If the player is redeeming, the screen should reduce anxiety. If the player is in a risk or support state, the screen should stop selling and help.

Design also protects consistency across web and native apps. The same balance should mean the same thing. The same blocked redemption should have the same reason. The same offer should preserve the same GC and Free SC language. Players should not need to relearn trust rules because they moved from mobile web to native app.

Design review should focus on these questions:

- What is the screen's job?
- What is the player's emotional state?
- What could be misunderstood?
- Where is the primary action?
- What happens if the player declines?
- What happens if something fails?
- Is commercial pressure suppressed when it should be?
- Can support explain the state from the screen alone?

Do not let visual excitement outrun comprehension. Casino art can be rich, animated, celebratory, and energetic. The hierarchy around it has to stay calm.

### UX Writing

UX writing owns the difference between confidence and confusion.

The most important copy work in a social sweepstakes casino is not clever headlines. It is exact language around currency, eligibility, purchase, redemption, verification, limits, and support. A small wording mistake can make a paid entertainment purchase look like a redeemable purchase. A vague redemption status can create support escalation. A careless VIP message can sound like pressure.

Good UX writing in this category is plain, consistent, and player-centered. Use the same words in the shop, checkout, receipt, wallet, help center, support macros, and CRM messages. If the shop says "Free Sweepstake Coins," the receipt should not say "bonus cash." If the redemption screen says "under review," the support macro should not say "rejected" unless the request is actually rejected.

Writers should maintain an approved vocabulary:

| Concept | Use | Avoid |
|---|---|---|
| Paid currency | Gold Coins | Deposit, cash, redeemable coins |
| Promotional currency | Free Sweepstake Coins | Purchased SC, cash bonus |
| Purchase action | Buy Gold Coins | Deposit, fund account |
| Redemption | Redeem eligible balance | Withdraw winnings, cash out instantly |
| Delay | Under review, action needed | Stuck, rejected, system issue |
| Decline path | No thanks, maybe later | I hate rewards, lose my bonus |
| Responsible tools | Limits, cooldown, account controls | Punishment, restriction, lockout |

Copy should never hide a material condition because the condition hurts conversion. If the condition matters to the player decision, it belongs near the decision.

### Live Ops

Live ops owns rhythm.

The job is not to keep every surface filled. It is to give the product a believable pulse. Players should feel that something useful, fun, or timely is happening without feeling hunted by campaigns.

A live-ops manager should know the main event for each player state. New players should see onboarding value and learning. Active players should see progress, fresh goals, and relevant offers. Prize-aware players should see eligibility and redemption clarity. Lapsed players should see a reason to return, not a punishment for leaving. Players in risk or support states should see service and tools.

Good live ops uses fewer stronger moments:

- A clear welcome path.
- A meaningful daily claim.
- A visible weekly or seasonal goal.
- A shop offer that is easy to understand.
- A lobby event with one main action.
- A support-aware redemption experience.

Bad live ops stacks:

- Sale banner.
- Popup.
- Inbox message.
- Push.
- Badge.
- Chain offer.
- VIP host message.
- Event tile.
- Receipt upsell.

When all of those point at the same player in the same period, the product stops feeling live and starts feeling noisy.

Review the calendar from the player's point of view. Do not ask only, "What campaigns are scheduled?" Ask, "What does one player actually see today?"

### CRM And Lifecycle Marketing

CRM owns who receives which message, through which channel, and why.

CRM should not be a louder version of live ops. It should be the control system that decides when a message is relevant, when it is redundant, and when it is inappropriate.

The safest CRM pattern is:

- Start with eligibility and suppression.
- Choose the player lifecycle state.
- Choose the player need.
- Choose the channel.
- Choose the message.
- Measure incrementality and guardrails.
- Stop when the player declines, ignores, opts out, or shows risk.

CRM should be able to explain every commercial message in plain language:

"This player saw the free daily claim reminder because they opted into reward reminders and had not claimed today."

"This player saw a collection event because they have been collecting and are missing items."

"This player did not see a purchase offer because they had repeated payment failures and an unresolved support issue."

If the explanation sounds uncomfortable, the targeting rule is probably wrong.

### Support

Support owns the player's reality when the product fails, confuses, or disappoints.

Support needs clear macros before campaigns and features launch. Do not wait until complaints arrive. Every offer, redemption status, payment failure, verification step, bonus grant, and eligibility rule should have support language ready.

Support should have:

- The player-facing explanation.
- The internal reason code.
- What support can fix.
- What support cannot promise.
- When to escalate.
- Which team owns the blocker.
- How to protect the player from repeated commercial pressure during the issue.

Support also feeds product quality. If players repeatedly ask the same question, the screen is probably unclear. If players believe SC was sold as a standalone redeemable product, the shop and receipt are wrong. If players compare packages by Free SC, that is expected behavior and the shop should support it clearly. If players do not understand redemption status, the tracker is weak. If support macros need long explanations, the product is carrying hidden complexity.

### VIP And Hosts

VIP owns service quality for important relationships.

VIP should never be a shadow pressure channel. A host has more social influence than a generic push or banner, so that influence must be used carefully.

Good host work:

- Explain benefits.
- Help resolve account or redemption issues.
- Invite eligible players to events.
- Answer questions.
- Recognize milestones.
- Route risk signals to the right team.

Bad host work:

- Pressure status maintenance.
- Push offers during long sessions.
- React to failed payments with bigger offers.
- Encourage chasing.
- Imply special prize access.
- Use personal relationship to drive purchases.

VIP needs suppression rules as strict as automated CRM. A human message can be more powerful, so it needs more judgment, not less.

### Data And Analytics

Data owns whether the team can tell the difference between movement and progress.

A campaign can raise sales among exposed users and still fail if those users would have purchased anyway. A popup can raise taps and lower trust. A VIP offer can increase short-term revenue and increase redemption stress. A winback campaign can recover purchases while training players to wait for incentives.

Analytics should make the whole outcome visible:

- Incremental behavior versus comparison.
- Repeat behavior after the campaign.
- Free SC exposure.
- Redemption cost and timing.
- Support load.
- Complaints.
- Opt-outs.
- Fraud.
- Responsible-play signals.
- Cannibalization.
- Long-term player quality.

Data also protects against oversegmentation. If every small segment gets a different offer, the team loses the ability to know what worked. Practical segmentation is only useful when the team can measure it.

### Legal, Compliance, Trust, And Safety

These teams own review boundaries and escalation paths.

They should be involved before creative polish, not after. The worst time to find a problem is when a campaign has already been designed, loaded, translated, scheduled, and forecast.

For each sensitive area, the playbook needs an owner:

- Currency wording.
- AMOE path.
- State and jurisdiction eligibility.
- Verification and identity checks.
- AML, sanctions, and tax handling.
- Payment and redemption methods.
- Responsible-play tools.
- Affiliate and creator claims.
- Push, email, and SMS consent.
- VIP host conduct.
- AI decisioning.
- Data use and privacy.
- Variable rewards and prize mechanics.

The point is not to slow every idea. The point is to make approval predictable.

## Campaign Playbooks

The following playbooks describe common campaign types in plain operational terms. Treat them as patterns, not templates. Each still needs approval, measurement, and suppression.

### Welcome Campaign

A welcome campaign should help the player understand the product, receive value, and complete a first meaningful action.

The first screen should make the value obvious. The first session should show the player where balances live, what GC does, what SC means, where free value appears, and how to start playing. Do not over-explain through text. Teach through sequence: claim, play, progress, receipt, wallet, help.

A good welcome path feels generous without sounding desperate. It may include a free claim, starter mission, clear game recommendation, or simple welcome package. It should not begin with a hard sale popup or introduce complex chain offers before the player understands the basic economy.

Live ops should watch where new players stall:

- They register but do not play.
- They play but do not understand balances.
- They visit shop and abandon.
- They receive Free SC but do not understand eligibility.
- They try redemption too early and become confused.
- They disable notifications immediately.
- They contact support during onboarding.

Each stall needs a product answer before a promotion answer. If players do not understand SC, do not send a bigger SC offer. Fix the explanation.

### Daily Claim Campaign

The daily claim is a trust-building habit. It should be easy to find, quick to claim, and clear about what was granted.

Paid pressure should not surround the daily claim. It can sit near the shop, but it should preserve the feeling of a free value moment. After claim, the product can suggest a next action: play a recent game, advance a mission, check an event, or view the shop. The suggestion should not block the claim.

Design should make the claim state obvious:

- Available.
- Claimed.
- Next claim not ready.
- Missed.
- Streak or progress, if used.
- Error or support state.

Avoid punitive streak copy. A missed claim should not feel like failure. If streaks exist, use them as encouragement, not as anxiety.

### Shop Sale Campaign

A shop sale should have one commercial idea.

Examples:

- Starter value.
- Event bundle.
- Loyalty boost.
- Collection support.
- Seasonal package.
- VIP service offer.

Do not combine every lever in one card. If the same card has a timer, a Free SC boost, bonus GC, VIP points, a limited badge, a chain unlock, and a receipt upsell, the player cannot tell what matters.

Before launch, the owner should answer:

- Is this sale incremental or just discounting purchases that would happen anyway?
- Does it preserve standard shop credibility?
- Does it create Free SC exposure we can support?
- Does it create refund, chargeback, or support risk?
- Is the timer real?
- Is the badge true?
- Is the audience appropriate?
- Who is suppressed?

If a sale becomes the only way players feel good about buying, the standard shop has a reference-value problem.

### Collection Event

A collection event should give players a reason to return and complete progress over time.

The player should understand:

- What set or album exists.
- How to earn items.
- What duplicates do.
- What rewards exist.
- What happens when the event ends.
- Whether progress is preserved.
- Whether trading or gifting is allowed.
- What catch-up paths exist.

Live ops should prevent collection fatigue. Do not start new collections faster than players can understand the current one. Do not make the last missing item feel impossible. Do not use opaque randomness as the only completion path.

Support needs macros for missing items, duplicate conversion, reward grants, event end, and any trade or gift issue.

### Tournament Campaign

Tournament campaigns need fairness more than noise.

A good tournament tells players:

- Who can enter.
- How scoring works.
- How divisions or cohorts are formed.
- What rewards exist.
- When results finalize.
- What anti-cheat review may occur.
- What happens if there is a tie, error, or review.

Avoid leaderboards that reward only spend or volume. Use divisions, caps, or comparable cohorts so the event feels competitive rather than predetermined by the largest spender.

If the tournament includes SC or prize-like value, route it through deeper review. Rules, audit logs, fraud monitoring, support scripts, and reward tables must be ready before creative work scales.

### Reactivation Campaign

Reactivation starts with diagnosis.

Do not treat all lapsed players as the same. A player who left after a support issue needs service recovery. A player who left after confusion needs education. A player who returns only for incentives needs lower-pressure economics. A former high-value player with risk signals needs care, not a bigger offer.

Good reactivation messages:

- Reference a real product update.
- Offer a clear low-pressure reason to return.
- Respect preferences.
- Avoid guilt.
- Avoid urgency unless real.
- Stop after non-response.

Bad reactivation messages:

- "We miss you" repeated without value.
- Bigger and bigger bonuses after silence.
- Purchase pressure after redemption frustration.
- SMS escalation without strong consent and reason.
- Host pressure based only on past value.

The best winback may be no offer. A new feature, fixed issue, preference reset, free claim, or support resolution can be more trustworthy than another discount.

### VIP Service Recovery

When a VIP has a problem, the first message should be service, not sales.

A service recovery flow should:

- Acknowledge the issue.
- Confirm ownership.
- Explain the next step.
- Give a realistic update path.
- Pause commercial pressure until the issue is resolved.
- Avoid promising outcomes before review.
- Document the resolution.

After recovery, a goodwill gesture may be appropriate if approved. It should not look like a purchase hook. The gesture should close the issue, not open a pressure path.

### Redemption Status Campaign

Redemption updates are service messages.

They should be short, factual, and tied to status:

- Request received.
- Verification needed.
- Review in progress.
- Action needed.
- Approved.
- Processing.
- Completed.
- Unable to continue, with reason and next step.

Do not mix redemption updates with offers. Do not use marketing language in redemption updates. The player is not looking for excitement; they are looking for certainty.

### Educational Content Campaign

Educational content should reduce support burden and increase trust.

Useful topics:

- GC and SC basics.
- How free entry works.
- How redemption works.
- How verification works.
- Game rules.
- Volatility and entertainment framing.
- Responsible-play tools.
- Notification preferences.
- Privacy and personalization controls.
- How tournaments or collections work.

Education should route to safer next actions: play, learn, set preferences, view rules, contact support, or manage account. Do not use education about psychology, odds, or mechanics to build pressure triggers.

## Screen Field Notes

This section gives practical notes for common screen reviews.

### Wallet

The wallet is where players verify product honesty.

A good wallet separates:

- GC balance.
- SC balance.
- Redeemable SC.
- Pending or locked SC.
- Promotional grants.
- Purchase history.
- Redemption history.
- Rules and help.

Do not make players infer redeemable value from a total balance. Do not hide locked or pending status behind support. Do not show internal accounting language.

The wallet should also help support. If support cannot see or explain the same state the player sees, disputes will drag.

### Offer Card

An offer card should answer the purchase question without requiring mental math.

It should show:

- What is being bought.
- What Free SC or other promotional value is included.
- Price.
- Eligibility.
- Expiration if real.
- Main condition.
- CTA.
- Details link.

Free SC can be one of the most prominent value cues on the card. The problem is not prominence; the problem is ambiguity. The card should make the SC amount easy to compare while still making clear that GC is purchased and SC is granted as promotional value.

If the card needs dense footnotes to be truthful, the offer is too complicated or the card hierarchy is wrong.

### Checkout Error

Payment errors are sensitive. The player may be embarrassed, frustrated, or worried about duplicate charges.

A good error state:

- Says the payment did not complete or needs action.
- Explains whether the player was charged.
- Suggests safe next steps.
- Provides support path.
- Does not immediately present a new offer.
- Does not shame the player.
- Does not retry silently in a way that creates duplicate concern.

Do not use failed payments as an offer trigger.

### Redemption Blocked

A blocked redemption is one of the highest-risk moments in the product.

The screen should lead with reassurance where true: balance visibility, request state, and next step. The blocker should be specific enough to be useful but not expose fraud-sensitive details.

Good:

"We need to review your account before this redemption can continue. Your balance remains visible. Support can help if you believe this is incorrect."

Bad:

"Redemption failed."

"Not eligible."

"Try again later."

"Buy more Gold Coins."

Design should give support a direct path from the blocked state. Players should not need to search a help center while anxious about redeemable value.

### Notification Preferences

Notification preferences are not just compliance hygiene. They are a live-ops quality control.

Players should be able to choose:

- Reward reminders.
- Event reminders.
- Redemption updates.
- Account and security notices.
- VIP or host messages where available.
- Email categories.
- Push categories.
- SMS where approved.

Do not combine all messages under one vague "marketing" switch if the product has materially different message types. Give players control so the team does not have to guess tolerance through opt-outs.

### Support Entry

Support should be reachable from:

- Wallet.
- Redemption.
- Checkout.
- Receipt.
- Account settings.
- Verification.
- Promotion details.
- Help center.

Support should know the context. If the player taps support from a failed redemption, the ticket should carry the redemption state. If they tap from a receipt, it should carry transaction reference. If they tap from an offer, it should carry campaign and creative version.

Players should not have to rebuild context in a message box.

## Operating Scenarios

These scenarios show how to apply the rules when the product is messy.

### Scenario: Shop Conversion Is Low

Weak shop conversion does not automatically mean the offer value is too low.

Check:

- Do players understand GC and Free SC?
- Are packages comparable?
- Is the primary CTA clear?
- Is the shop too dense for new players?
- Is payment availability confirmed and working?
- Are errors or loading states causing abandonment?
- Are players reaching the shop before they understand value?
- Is Free SC exposure making finance restrict value?
- Are players trained to wait for sales?
- Are support complaints rising after purchase?

Try fixes in order:

- Clarify currency and receipt language.
- Simplify visible choices.
- Improve trust copy at payment anxiety points.
- Move offers to natural pauses.
- Segment shop complexity by experience.
- Remove confusing bundles.
- Test value only after clarity is sound.

Do not jump straight to bigger Free SC.

### Scenario: A Campaign Lifts Purchases But Complaints Rise

Treat this as a warning, not a win.

Look for:

- Misleading copy.
- Timer misunderstanding.
- SC presented as bought.
- Hidden eligibility.
- Bad decline path.
- Offer shown during risk state.
- Support not ready.
- Redemption confusion after campaign.
- Affiliate or creator mismatch.

Response:

- Pause scaling.
- Read complaints verbatim.
- Check exposed players against holdout.
- Review support tickets.
- Inspect screenshots across mobile states.
- Fix copy and eligibility.
- Relaunch only with guardrails.

If the campaign works only when players misunderstand it, it does not work.

### Scenario: Redemption Queue Spikes After A Promotion

Do not celebrate until the queue is understood.

Ask:

- Did Free SC exposure exceed forecast?
- Did players understand eligibility?
- Are verification steps creating surprise?
- Are payment methods failing?
- Is fraud review overloaded?
- Is support prepared?
- Did the promotion attract abuse?
- Did the offer create player expectation of instant redemption?

Immediate actions:

- Stop or cap the promotion if exposure is high.
- Add clear status copy.
- Staff support.
- Segment queue reasons.
- Notify affected players with service language.
- Review future offer math.

Never put purchase offers into the redemption flow as a response to redemption pressure.

### Scenario: VIP Revenue Falls

Do not assume the answer is more pressure.

Check:

- Are VIPs seeing service issues?
- Are redemptions delayed?
- Are hosts over-contacting?
- Are benefits unclear?
- Are risk signals increasing?
- Are standard offers eroding VIP value?
- Are players fatigued by status maintenance?
- Are support issues unresolved?

Response:

- Review host contact quality.
- Improve benefit clarity.
- Resolve service issues.
- Suppress pressure for risk states.
- Use personal contact for help, not only offers.
- Rebuild VIP around recognition and reliability.

VIP should feel better served, not more targeted.

### Scenario: New Players Do Not Return

Low return is often a first-session problem.

Check:

- Did they receive value?
- Did they play quickly?
- Did they understand balances?
- Did they find a game they liked?
- Did they encounter a signup or login problem?
- Did they see too much monetization too early?
- Did notifications ask before value?
- Did the lobby overwhelm them?

Fix:

- Make the first action clearer.
- Reduce first-session offer pressure.
- Add a simple mission.
- Improve recent-game return path.
- Explain currency through action.
- Use low-pressure reminder only after consent.

Do not solve weak onboarding with a larger winback offer.

### Scenario: Players Ignore Live Events

An ignored event may be invisible, unclear, irrelevant, too complex, or too frequent.

Check:

- Is the event visible in the right surface?
- Is the reward understandable?
- Is eligibility clear?
- Is the action simple?
- Does the event compete with another campaign?
- Are players already fatigued?
- Does the event require too much work?
- Is it relevant to the player's preferred games?

Fix:

- Improve placement.
- Simplify the goal.
- Reduce concurrent events.
- Tie event progress to games players already play.
- Add clear progress feedback.
- Use education before incentives.

If players need a long explainer, the event is not ready for broad launch.

### Scenario: AI Recommends A High-Value Segment Offer

Before approving, ask:

- Why did AI recommend this segment?
- Are any sensitive proxies involved?
- Are risk signals excluded?
- Does the offer comply with currency rules?
- Is Free SC exposure approved?
- Is there a holdout?
- Can an operator explain the decision?
- Can the campaign be stopped quickly?
- Does human review happen before send?

If the recommendation is a black box, treat it as a draft, not a decision.

## Multi-Brand, Web, And Native App Operations

Running multiple brands and platforms changes the operating problem. A single mistake can be copied many times.

### Shared Rules, Local Expression

Each brand can have different tone, art direction, character, event themes, and pacing. The trust rules should be shared.

Shared:

- GC and SC separation.
- Free SC promotional framing.
- AMOE access.
- Redemption status patterns.
- Suppression rules.
- Support escalation.
- Measurement.
- AI approval boundaries.
- Do-not-build list.

Brand-specific:

- Visual style.
- Promo art.
- Event themes.
- Character voice.
- Game catalog emphasis.
- Loyalty naming.
- Seasonal calendar.
- VIP tone within approved boundaries.

Do not let brand personality rewrite currency, redemption, or responsible-play language into something cute but unclear.

### Native App Versus Mobile Web

Native app and mobile web should preserve the same trust model, but they have different constraints.

Native apps may have platform review, payment, permission, rating, and distribution constraints. Mobile web may have different payment, attribution, cookie, consent, and browser constraints. Do not assume a campaign or payment method can move unchanged across platforms.

Design should keep core states consistent:

- Account.
- Wallet.
- Shop.
- Checkout.
- Receipt.
- Redemption.
- Support.
- Preferences.
- Notification controls.

Operations should keep eligibility consistent. A player should not see an offer on web that support cannot explain in app. A redemption status should not differ across platforms. A player should not receive a push that leads to an unavailable native route.

### Multi-Brand Asset Discipline

Live-ops assets need constraints.

Every campaign asset should have:

- Approved placement.
- Safe text area.
- Mobile crop preview.
- File size or performance budget.
- Brand token usage.
- Legal or terms placement if needed.
- Alt text or accessibility equivalent where relevant.
- Expiration and takedown date.
- Owner.

Do not let generated art, affiliate creative, or last-minute banners bypass design constraints. A beautiful campaign that slows the lobby, hides terms, or overlaps text is not launch-ready.

### Shared Component Library

A shared component library reduces risk when it encodes the right rules.

Useful shared components:

- Currency balance.
- Offer card.
- Free claim.
- Checkout summary.
- Receipt.
- Redemption tracker.
- Blocked-state panel.
- Support link.
- Terms drawer.
- Notification preference row.
- Campaign badge.
- Mission card.
- Collection progress.
- VIP benefit row.

Each component should include allowed copy patterns, forbidden copy, states, accessibility behavior, and analytics events. A component library that only stores visuals misses the operating point.

## Review Meetings

### Design Review Meeting

Design review should not be an art critique first. It should start with the player task.

Suggested flow:

- State the player state.
- State the screen job.
- Walk the happy path.
- Walk decline path.
- Walk error path.
- Walk suppressed-risk path.
- Check mobile viewport.
- Check copy.
- Check accessibility.
- Check support handoff.

Do not approve a screen only from the happy path. Most trust damage happens in blocked, failed, declined, expired, or confused states.

### Campaign Approval Meeting

Campaign approval should be short because the work was done before the meeting.

The owner should bring:

- Campaign goal.
- Player benefit.
- Eligible audience.
- Suppressed audience.
- Surfaces and channels.
- Creative.
- Currency impact.
- Support plan.
- Measurement plan.
- Stop rules.
- Rollback owner.

The meeting decision should be one of:

- Approved.
- Approved with changes.
- Needs legal or platform review.
- Needs finance or liability review.
- Needs support readiness.
- Needs design simplification.
- Rejected.

Do not leave approval meetings with vague "looks good" decisions.

### Weekly Live-Ops Review

The weekly review should force tradeoffs.

Cover:

- What is currently live?
- What is launching next?
- What should stop?
- What player groups are over-contacted?
- What surfaces are crowded?
- What support issues are rising?
- What redemption issues are rising?
- What fatigue signals are rising?
- What experiments are inconclusive?
- What should become standard?

The best live-ops teams delete as much as they add.

### Postmortem

Run a postmortem when a campaign creates material complaints, incorrect grants, redemption confusion, payment issues, support overload, platform risk, or trust damage.

Useful questions:

- What did players see?
- What did they believe?
- What did we intend?
- Which screen or message created the gap?
- Which approval gate missed it?
- Did suppression fail?
- Did support have the right language?
- Did measurement catch it early?
- Was rollback fast enough?
- What component, copy rule, or checklist changes prevent repeat?

Postmortems should change the operating system, not only blame a campaign.

## Player Education

A social sweepstakes casino needs product education because misunderstanding creates risk.

### What Players Need To Learn

Players should be able to understand:

- What GC is.
- What SC is.
- How Free SC can be obtained.
- Where no-purchase entry information lives.
- What makes SC redeemable.
- How redemption works.
- Why verification may be needed.
- Where receipts live.
- How to manage notifications.
- How to use limits and cooldowns.
- How game rules and fairness work.
- How to contact support.

Education should be available in short surfaces, not only long legal pages.

### Where To Teach

Teach at the moment of relevance:

- Wallet teaches currency.
- Shop teaches purchase and promotional bonus.
- Checkout teaches what is charged.
- Receipt teaches what was bought and granted.
- Redemption teaches eligibility and verification.
- Missions teach progress.
- Event page teaches rules and rewards.
- Notification preferences teach message types.
- Support teaches resolution.

Do not put all education in onboarding. Players will not remember it. Repeat short explanations in the right places.

### Tone

Educational copy should sound calm and adult.

Avoid childish simplification for serious topics. It is fine to make games playful; it is not fine to make redemption or verification sound cute when the player is concerned about value.

Good:

"Gold Coins are used for play. Sweepstake Coins are promotional and may be redeemable when requirements are met."

Bad:

"These shiny coins are your ticket to big wins."

Trust copy should not sound like marketing copy.

## Responsible Growth

Growth is responsible when the team can explain why the player saw the message, why it was appropriate, what was measured, and what would stop it.

### Entertainment First

The product should be worth using even when the player does not buy.

That means:

- Good game discovery.
- Free claims that feel real.
- Missions that create progress.
- Collections or achievements that do not require spending.
- Social features that are optional.
- Clear account controls.
- Education and support.

If the product only feels alive when it sells, live ops will keep increasing pressure to compensate for weak entertainment design.

### Pressure Has A Cost

Pressure can create short-term action. It also creates distrust, fatigue, support load, opt-outs, complaints, and regulatory attention.

Common pressure costs:

- Players learn to close popups without reading.
- Players wait for bigger offers.
- Standard shop loses credibility.
- Redemption feels adversarial.
- VIP feels manipulative.
- Support becomes defensive.
- Brand becomes harder to advertise and partner.

Every pressure lever should have a counterweight:

- Timer needs real deadline and clear decline.
- Personalization needs explanation and opt-out.
- VIP needs service and suppression.
- Push needs preference control.
- Random reward needs rules and audit.
- Chain offer needs exit and cap.
- Winback needs stop rule.

### Trust Compounds

Trust also compounds.

Small trust wins:

- The receipt matches the shop.
- The balance updates instantly.
- The redemption tracker is clear.
- Support uses the same words as the product.
- The player can close an offer.
- A timer is real.
- A free claim is actually free.
- A blocked state explains next step.
- Preferences are respected.

These moments rarely show up as dramatic campaign lifts. They lower friction across every future campaign.

## Player-State Playbooks

Player state is more useful than a generic persona. A persona says who a player might be. State says what the player needs now.

Use these playbooks to decide which surfaces, messages, and campaigns fit a player moment.

### New Visitor

The new visitor has not earned the product's trust yet. They may arrive from an ad, affiliate, creator, organic search, app store listing, referral, or direct brand search. Their first questions are basic:

- Is this real?
- What do I get?
- Is there a catch?
- Can I play on my phone?
- What happens after signup?
- Is this available to me?
- What are GC and SC?

The best screen for this state is direct. Do not ask the new visitor to decode a casino economy, a loyalty system, a tournament, and a sale at the same time. Show a clear offer if approved, a simple reason to start, short trust cues, and a primary action.

Good operator behavior:

- Match inbound creative exactly.
- Show no-purchase and rules access where relevant.
- Use one primary CTA.
- Keep the first screen fast and legible.
- Avoid multiple competing welcome offers.
- Avoid unsupported winner or payout claims.
- Avoid affiliate language that exaggerates redemption.

Good design tone: confident, simple, not frantic.

### Registered But Not Yet Engaged

This player created an account but has not experienced enough value to understand why they should return.

Do not treat them as a failed payer. Treat them as an incomplete onboarding. The right next action is usually game discovery, free claim, tutorial, mission, or preference setting.

Useful prompts:

- "Your starter reward is ready."
- "Pick a game style to start."
- "Complete your first mission."
- "See how Gold Coins and Sweepstake Coins work."
- "Set reward reminders."

Avoid:

- Immediate purchase pressure.
- Complex shop offers.
- VIP language.
- Large event calendars.
- Push escalation before consent or value.

The product should help them finish a first satisfying session. Revenue can come later.

### Active Non-Purchaser

Active non-purchasers are not useless. They create liquidity, community, habit, game discovery, and future conversion opportunities. Some may use free-entry routes. Some may become purchasers after trust builds. Some may remain entertainment-only players.

Give them value:

- Daily claims.
- Missions.
- Free events.
- Collections.
- Social gifting.
- Beginner content.
- Game recommendations.
- Clear wallet education.

Do not punish them with constant purchase popups. If they are active and not purchasing, the product should learn what they enjoy and where they stall. A player who repeatedly opens the shop and leaves may need clearer packages. A player who never opens the shop may need more entertainment value first.

Commercial prompts can appear when behavior shows intent, but they should stay calm and easy to decline.

### First-Time Purchaser

The first purchase is a fragile trust moment.

The player should feel:

- The shop was clear.
- The charge was expected.
- The receipt matches the offer.
- Balances updated.
- Support is reachable.
- The product did not immediately pressure them again.

Do not rush into a second offer before the first purchase is fully confirmed. If a next offer appears, it should be secondary and dismissible. The player should be able to return to play immediately.

Watch for:

- Purchase confusion.
- Receipt mismatch.
- Payment failure.
- Currency misunderstanding.
- Buyer regret.
- Support contact.
- Quick uninstall or inactivity.

A first-time purchaser needs reassurance more than a sales ladder.

### Active Purchaser

Active purchasers have proven willingness to buy GC, but that does not mean every session should become a sales moment.

Good treatment:

- Keep standard shop credible.
- Recommend packages near familiar behavior, not sudden extreme anchors.
- Use loyalty progress and event relevance.
- Place offers at natural pauses.
- Suppress during unusual spend, failed payments, long sessions, or support distress.
- Preserve clear receipts and account history.

Avoid:

- Escalating every purchase into a larger next ask.
- Hiding normal value behind constant limited offers.
- Using losses or frustration as triggers.
- Treating value as permission to pressure.

Active purchasers are retained through consistency, service, and relevant entertainment, not only offers.

### Prize-Aware Player

Prize-aware players pay close attention to SC, eligibility, redemption, verification, and rules. They may be highly engaged even if they do not purchase often.

They need:

- Clear SC balance.
- Redeemable and non-redeemable separation.
- Eligibility progress.
- No-purchase path clarity.
- Redemption rules.
- Verification expectations.
- Support path.
- Consistent terms.

Do not hide redemption education because it might distract from shop conversion. Prize-aware confusion becomes support pressure and trust damage.

For this state, the best personalization may be clarity rather than promotion. Show wallet education, redemption status, rules access, and relevant reminders. Avoid pressure that looks like the product is trying to monetize the player's redemption intent.

### Bonus-Seeking Player

Some players engage mostly when incentives appear. Do not label this as bad behavior in player-facing language. Internally, it is an economy and campaign design state.

Good treatment:

- Lower-pressure reward design.
- Clear economics.
- Strong Free SC caps.
- Abuse monitoring.
- Fewer escalating incentives.
- More entertainment and content paths.
- Holdout measurement.

Avoid:

- Chasing them with bigger and bigger rewards.
- Teaching them that leaving is the best way to get value.
- Treating every return as recovered value.
- Ignoring redemption and abuse cost.

The goal is not to punish bonus-seeking. The goal is to stop the campaign calendar from training it.

### Lapsed Player

A lapsed player may have left for many reasons. Treat lapse as a diagnostic state.

Possible causes:

- Lost interest.
- Too much friction.
- Weak game discovery.
- Bad support experience.
- Redemption frustration.
- Payment issue.
- Fatigue.
- Better competitor offer.
- Life interruption.
- Product confusion.

The right message depends on the cause. A service recovery message is better after a support issue. Product news is better after content fatigue. A free claim is better after a light casual lapse. A purchase offer is only one option, not the default.

Do not keep contacting a lapsed player who ignores messages. Silence is a signal.

### Player In Support Distress

Support distress should suppress commercial pressure.

This includes:

- Open support ticket about payment.
- Open support ticket about redemption.
- Complaint about misleading offer.
- Account access problem.
- Verification frustration.
- Missing grant.
- Confusing balance.
- Refund or chargeback discussion.

The product should show status, help, and resolution paths. Do not show shop pressure, winback offers, chain offers, VIP purchase nudges, or celebratory sales language while the issue is unresolved.

After resolution, consider whether a goodwill action is appropriate. Do not use goodwill as a disguised upsell.

### Player In Risk State

Risk state is broader than formal self-exclusion.

Signals can include cooldown activity, limit-setting, repeated failed payments, unusual spend velocity, unusually long sessions, loss-chasing patterns, late-session escalation, support distress, redemption distress, or explicit concern.

The response should be:

- Stop commercial pressure.
- Show neutral account tools.
- Offer support or responsible-play controls.
- Preserve access to necessary service messages.
- Avoid VIP host pressure.
- Avoid AI or CRM monetization decisions.

Risk state should be treated with dignity. Do not use shame or alarmist copy unless policy requires a specific intervention. Calm, direct controls are better.

## Economy And Finance For Non-Finance Operators

Designers and live-ops teams do not need to own the full financial model. They do need to understand why some offers are risky even when they convert.

### GC Revenue Is Not The Whole Story

Paid packages create GC revenue. They may also create Free SC exposure, payment fees, support cost, fraud risk, chargebacks, platform cost, and redemption cost.

A campaign that sells a lot of GC can still be weak if it creates too much downstream cost or support pressure. A campaign that looks modest in purchase volume can still be strong if it improves retention, clarity, and long-term trust without heavy liability.

Operators should avoid saying "this campaign made money" until finance has seen the full picture.

### Free SC Is Not Free To The Business

Free SC may be promotional to the player, but it is not meaningless to the operator.

It can create:

- Redemption exposure.
- Fraud attempts.
- Support questions.
- Terms and eligibility questions.
- Abuse through repeated accounts or scripted claims.
- Payment and KYC review load.
- Disputes if framing is unclear.

Every Free SC grant should have an approved purpose. Do not add Free SC because the card "needs more value" at the end of design. Economy approval comes before art.

### Margin Can Be Destroyed By Confusion

Confusion has a cost:

- Support tickets.
- Refund requests.
- Chargebacks.
- Bad reviews.
- Complaints.
- Slower redemption processing.
- Compliance review.
- Reduced ad or platform confidence.
- Lower trust in future campaigns.

Clear wording and clean receipts are financial controls. They reduce disputes.

### Discount Addiction

If players learn that every weekend, every decline, every lapse, or every return creates a better offer, the standard shop loses credibility.

Live ops should protect the base shop:

- Keep normal packages understandable.
- Avoid constant sale language.
- Rotate event types, not just discounts.
- Use free value for habit, not permanent price destruction.
- Watch whether players delay purchases until campaigns.
- Use holdouts to see whether offers are incremental.

Discounts are easy to launch and hard to unwind.

### Cannibalization

Cannibalization happens when a campaign takes purchases that would have happened anyway and gives away extra value to get them.

Signs:

- Revenue rises during campaign but falls after.
- Standard package purchases drop.
- Existing purchasers shift to discounted offers.
- Holdout behaves similarly without offer.
- Players wait for predictable sales.
- Support asks why normal value is worse.

If cannibalization is high, improve targeting, reduce frequency, change value type, or stop the campaign.

### Support Cost Belongs In Offer Review

Some offers are support-heavy:

- Complex chains.
- Expiring bonuses.
- Eligibility-limited offers.
- VIP-only campaigns.
- Redemption-adjacent promotions.
- Collection events with duplicates.
- Tournaments and prize rules.
- Payment-method promotions.

If support cannot explain it quickly, the offer is not operationally cheap. Add support cost to campaign judgment.

### Fraud And Abuse Are Design Inputs

Fraud is not only a backend issue. Design can make abuse easier or harder.

Risky design patterns:

- Free claims with weak account controls.
- Hidden eligibility that creates disputes.
- Trade or gift flows without limits.
- Prize mechanics without audit history.
- Offer URLs that can be shared outside intended audience.
- Campaigns that do not check jurisdiction or account state.
- Receipt states that do not confirm grant details.

Designers should ask fraud and support what they need visible, logged, and constrained before launch.

## Backoffice And Configuration Principles

Live ops needs tools that prevent mistakes. A beautiful player experience can still fail if the operator console makes unsafe configuration easy.

### Configuration Should Have Guardrails

Backoffice tools should not let an operator accidentally launch:

- Offer without approved currency framing.
- Campaign without suppression.
- Promotion in excluded jurisdiction.
- Push without consent checks.
- Free SC grant without budget or cap.
- Event without support macro.
- Prize mechanic without rules.
- Redemption message with marketing copy.
- VIP offer to risk-suppressed players.
- AI recommendation directly to production.

If the tool can create a dangerous state, it should warn, block, or require approval.

### Preview The Player Reality

Operators should preview the exact player experience:

- Mobile web.
- Native app.
- Small viewport.
- Returning player.
- New player.
- Suppressed player.
- Ineligible player.
- Player with pending redemption.
- Player with failed payment.
- Player with notification opt-out.

A campaign can look fine in a desktop admin preview and fail on a phone. Preview states should include real copy length, translated strings, badges, timers, balances, and error states.

### Campaign Priority Should Be Explicit

When several campaigns could apply, the system should not choose randomly or by last edited.

Priority should reflect:

- Legal and service messages.
- Account and redemption status.
- Player-requested reminders.
- Risk suppression.
- Lifecycle importance.
- Event relevance.
- Commercial value.

Operators should see why one campaign beat another. Hidden priority creates confusing player experiences and impossible debugging.

### Every Campaign Needs An Audit Trail

The team should know:

- Who created it.
- Who approved it.
- What changed.
- When it changed.
- Which audience was eligible.
- Which rules suppressed it.
- Which creative version showed.
- Which channels delivered.
- Which players were held out.
- Why it stopped.

Audit trails are not bureaucracy. They are how the team answers complaints, platform questions, payment questions, and internal disputes.

### Kill Switches

Every material campaign or feature needs a kill switch.

The kill switch should be understandable by the operator on duty. It should stop the player-facing exposure without corrupting ledgers, balances, redemptions, or support state.

After using a kill switch, the team needs a communication plan:

- What players saw.
- Whether anything was granted.
- Whether balances changed.
- Whether support expects tickets.
- Whether a correction or apology is needed.
- Whether the campaign can return.

### Translation And Localization

Localization is not a final string export. It can change risk.

Some phrases that seem harmless in English may imply purchase, cash value, guaranteed outcome, or urgency in another language. Currency names, free bonus wording, redemption wording, and legal terms need extra review.

Design should allow longer strings. Do not put legal or currency copy inside tiny badges that break when translated.

### Affiliate And Creator Controls

Affiliate and creator campaigns are extensions of the product. They can create fast acquisition and fast risk.

Operators need:

- Approved claims.
- Approved screenshots.
- Approved currency wording.
- No-purchase language where required.
- Redemption claim rules.
- Testimonial and disclosure review.
- Takedown process.
- Tracking by source.
- Quality gates by cohort.
- Complaint review.

Do not let creators invent sweepstakes explanations. Give them approved plain-language scripts.

## Quality Assurance Scenarios

QA should test what players actually experience, not only whether buttons work.

### Currency QA

Test:

- Shop card.
- Checkout summary.
- Receipt.
- Wallet.
- Offer popup.
- Email.
- Push landing.
- Support macro.
- Account history.

The wording should preserve GC purchase and Free SC promotional grant everywhere. If one surface breaks the language, fix all linked surfaces before launch.

### Redemption QA

Test:

- Eligible player.
- Not eligible player.
- Verification needed.
- Verification failed.
- Pending review.
- Method unavailable.
- Payment rejected.
- Completed.
- Cancelled.
- Support contact.
- Return from notification.

Check that no purchase offer appears in any redemption state.

### Suppression QA

Create test accounts for:

- Cooldown.
- Self-exclusion.
- Limit activity.
- Failed payments.
- Open support ticket.
- Pending redemption.
- Opt-out.
- Jurisdiction ineligible.
- Fraud review.
- VIP with risk signal.

Confirm commercial surfaces stop or change. Do not assume the decision engine works because normal players see campaigns correctly.

### Campaign QA

Test:

- Eligible player sees correct campaign.
- Ineligible player does not.
- Suppressed player sees safe replacement.
- Decline path works.
- Close path works.
- Timer or deadline behaves as approved.
- Terms link works.
- AMOE or rules link works where relevant.
- Receipt and grant match offer.
- Analytics event fires.
- Support context is attached.

QA should inspect screenshots, not only event logs.

### Mobile QA

Test on real device classes, not only large desktop browser windows.

Look for:

- Text overflow.
- CTA hidden by keyboard.
- Badge overlap.
- Sticky footer covering terms.
- Bottom sheet too tall.
- Low contrast over art.
- Tiny close controls.
- Slow asset load.
- Motion overload.
- Scroll traps.
- Tap targets too close.
- Payment form autofill issues.

Live-ops assets should be checked in the actual placement before launch.

### Messaging QA

Test message journeys:

- Push opens correct screen.
- Email deep link preserves eligibility.
- SMS does not send without approved consent.
- In-app message respects suppression.
- Opt-out updates quickly.
- Redemption status message uses service tone.
- Expired campaign link shows useful fallback.

No player should tap a live message into a dead or contradictory state.

## Governance And Ownership

A playbook only matters if ownership is clear.

### Decision Owners

Each sensitive decision needs a named owner:

| Area | Owner Type |
|---|---|
| Currency wording | Product, legal, compliance, UX writing |
| Offer economics | Finance, live ops, product |
| Free SC exposure | Finance, compliance, fraud |
| Redemption | Product, compliance, support, payments |
| Verification | Compliance, fraud, payments, support |
| Suppression | Trust and safety, compliance, CRM, product |
| Campaign calendar | Live ops, CRM, product |
| VIP | VIP leadership, trust and safety, compliance |
| AI workflows | Product, data, legal, privacy, compliance |
| Messaging consent | CRM, legal, privacy |
| Affiliate claims | Marketing, legal, compliance |
| Support macros | Support, product, legal where sensitive |

Do not approve sensitive work with "everyone looked at it." Approval should name the accountable owner.

### Review Expiry

Some approvals expire.

Current law, platform policy, payment policy, ad policy, messaging rules, jurisdiction availability, and terms language should be reviewed on a cadence and when material changes happen. A screen approved last season may not be approved today if the channel, jurisdiction, product mechanic, or policy changed.

Designs should record the approval date and scope. Approval for web does not automatically mean approval for native app. Approval for one brand does not automatically mean approval for every brand. Approval for one jurisdiction does not automatically mean approval everywhere.

### Change Management

Small copy changes can be material.

Route changes when they affect:

- GC or SC meaning.
- Free bonus wording.
- AMOE language.
- Redemption eligibility.
- Verification requirements.
- Fees or timing.
- Expiry.
- VIP status.
- Responsible-play tools.
- Affiliate or creator claims.
- AI decisioning.
- Payment method.

Do not treat "just copy" as low risk.

## Trust Standards By Moment

Players judge the product at different moments for different reasons. A design that feels exciting in the lobby can feel predatory in redemption. A message that feels helpful after a claim can feel invasive after a failed payment. Use the moment to decide the tone.

### Before Registration

The player is deciding whether the brand deserves attention.

Trust standard:

- Be clear about the value.
- Be clear that rules exist.
- Avoid claims the product cannot prove.
- Do not overload the first view.
- Make the next step obvious.
- Keep no-purchase and eligibility access findable.

The player does not need the full legal architecture before registration, but they should not feel tricked after registration. If a condition would materially change their decision, do not hide it.

### During Registration

The player is giving the product identity and contact information.

Trust standard:

- Ask for what is needed now.
- Explain why sensitive information is requested.
- Keep labels persistent.
- Let players recover from errors.
- Avoid stacking permissions.
- Keep marketing consent separate from account essentials where required.

Do not use registration as a place to sneak in broad consent. Consent collected under confusion creates later distrust and may weaken channel quality.

### Before First Play

The player wants momentum.

Trust standard:

- Show starting value.
- Let the player act quickly.
- Explain currency through use.
- Keep choices simple.
- Do not interrupt with purchase pressure.
- Make help and account controls visible enough.

First play should answer "what can I do?" not "how many systems does this product have?"

### During Play

The player is focused on entertainment.

Trust standard:

- Keep play controls consistent.
- Keep balances visible where appropriate.
- Avoid intrusive offers.
- Avoid pressure tied to losses or frustration.
- Give feedback for meaningful progress.
- Keep exits and responsible controls findable.

Play is not the place to create panic. Offers belong at pauses, not in the middle of attention.

### After A Win Or Reward

The player is receptive and positive.

Trust standard:

- Celebrate proportionally.
- Confirm what was granted.
- Show updated progress.
- Suggest a relevant next action.
- Avoid making the reward feel smaller by immediately selling.

Celebration should not hide terms, eligibility, or balance state. A player should understand whether a reward is GC, Free SC, collection progress, ticket, badge, entry, or cosmetic.

### After A Loss Or Failed Action

The player may be frustrated.

Trust standard:

- Do not monetize frustration.
- Offer neutral navigation.
- Offer help where appropriate.
- Let the player recover calmly.
- Avoid "comeback" pressure tied to the failed moment.

This is a major difference between responsible entertainment design and exploitative design. A loss or failed action can be a moment for support, free recovery, or exit, but it should not be a high-pressure sales trigger.

### During Purchase

The player is making a money decision.

Trust standard:

- State what is being bought.
- State what is free or promotional.
- Show final amount.
- Show payment method.
- Show material conditions.
- Keep add-ons optional and unselected unless explicitly approved otherwise.
- Make cancellation or back navigation clear before charge.

Checkout should not be clever. It should be exact.

### After Purchase

The player wants confirmation.

Trust standard:

- Confirm success or failure clearly.
- Show what was charged.
- Show what was granted.
- Update balances.
- Provide receipt access.
- Provide support path.
- Keep any next offer secondary.

If the purchase fails, be especially careful. Do not shame. Do not imply the player was charged if they were not. Do not present a higher offer as the next step.

### During Redemption

The player wants certainty.

Trust standard:

- Show status.
- Explain blockers.
- Preserve balance visibility.
- Provide next step.
- Provide support.
- Avoid marketing.
- Avoid celebratory sales tone.

Redemption is a service flow. Treat it more like banking support than casino promotion.

### After A Complaint

The player wants to know whether the product listens.

Trust standard:

- Acknowledge the issue.
- Use specific context.
- Explain what can happen next.
- Stop unrelated commercial pressure.
- Do not argue with the player through generic macros.
- Feed repeated issues back to product.

Complaints are not only support events. They are product telemetry. If complaints cluster around the same screen, the screen is part of the problem.

### During VIP Contact

The player is receiving personal attention.

Trust standard:

- Use personal attention for service.
- Explain benefits.
- Keep offers optional.
- Avoid status anxiety.
- Pause pressure during risk or support issues.
- Document contact.

Host messages carry more weight than automated messages. The standard should be higher.

## Manager Read-Through

This section is for a leader who needs to know whether the team is operating well without reading every design file.

### What A Healthy Product Feels Like

A healthy social sweepstakes casino feels busy but not frantic. The player can always find games, wallet, shop, support, redemption, and account controls. Offers are present but not everywhere. The lobby has a main event, not a pile of banners. The shop is structured. The receipt is clear. Redemption has a status tracker. Support answers match the product. VIP feels like better service, not pressure. CRM messages arrive for understandable reasons.

Internally, teams can explain their decisions. Live ops knows why a campaign is running. CRM knows who is suppressed. Finance knows Free SC exposure. Support knows the macro. Design knows the screen job. Data knows how incrementality will be measured. Legal and compliance know which rules were reviewed. The rollback owner can stop the campaign.

### What An Unhealthy Product Feels Like

An unhealthy product feels like every team is fighting for the same player moment.

Symptoms:

- Popup on entry.
- Banner in lobby.
- Badge in nav.
- Push notification.
- Inbox message.
- Shop sale.
- Chain offer.
- Receipt upsell.
- VIP host note.
- Redemption frustration.
- Support macro that does not match screen.

No single tactic may look catastrophic alone. Together, they teach the player that the product is always selling.

Other symptoms:

- Players ask whether they bought SC.
- Players cannot find no-purchase information.
- Support cannot explain redemption blockers.
- Offers change faster than support macros.
- VIP messages continue during risk states.
- Campaigns launch without holdouts.
- Shop packages are redesigned for each sale.
- Timers recur so often they stop feeling real.
- AI recommendations are approved because they look sophisticated.
- Legal review happens after creative approval.

These are not only UX problems. They are operating problems.

### The Manager's Weekly Questions

Ask the same questions every week:

- Which player-facing trust issue increased?
- Which campaign should stop?
- Which surface is overcrowded?
- Which offer created support load?
- Which redemption blocker is most common?
- Which player group is over-contacted?
- Which suppression rule failed or needs improvement?
- Which campaign showed real incrementality?
- Which campaign only moved purchases around?
- Which AI suggestion was rejected and why?
- Which copy phrase caused confusion?
- Which approval expired or needs re-check?

The goal is to make the operating system smarter each week. If the same issue returns, the team is treating symptoms.

### What To Reward

Reward teams for:

- Simplifying a confusing flow.
- Killing a noisy campaign.
- Preventing a risky launch.
- Reducing support tickets.
- Improving redemption clarity.
- Finding a suppression bug.
- Improving receipt accuracy.
- Proving a campaign is not incremental.
- Replacing pressure with service.
- Building reusable components.
- Making AI outputs reviewable.

If teams are rewarded only for launch volume and revenue spikes, the product will drift toward pressure.

### What To Escalate

Escalate immediately when:

- SC is presented as purchased.
- A redemption flow contains a purchase offer.
- A campaign runs in an excluded jurisdiction.
- A payment or wallet claim is unapproved.
- A support macro contradicts product state.
- A VIP host pressures during risk or support distress.
- A campaign creates misleading urgency.
- A player cannot opt out.
- A creator or affiliate makes unapproved claims.
- AI changes eligibility, payout, sanction, or campaign action without human approval.
- A Free SC grant exceeds approved exposure.
- A fraud or responsible-play signal is used for monetization.

Escalation should be normal. The category is sensitive enough that silence is more dangerous than friction.

## Final Pre-Launch Walkthrough

Before a material release, walk through the product as if you are a skeptical player.

Start from an ad or app listing. Ask whether the promise matches the landing page. Register. Claim the first reward. Play. Open wallet. Open shop. Buy a small package in test mode. Read the receipt. Check balances. Trigger a failed payment state. Trigger a support path. Open notification settings. Try a redemption-eligible account. Try a non-eligible account. Trigger verification. Trigger a blocked redemption. Try a suppressed account. Try a VIP account with a support issue. Try the campaign after it expires.

During the walkthrough, note every moment where the product asks the player to trust it.

Those moments include:

- "What am I buying?"
- "What did I get for free?"
- "Can I close this?"
- "Was I charged?"
- "Where did my balance go?"
- "Can this be redeemed?"
- "Why am I blocked?"
- "What happens next?"
- "Who can help?"
- "Why did I receive this message?"
- "How do I stop messages?"
- "Is this deadline real?"

If the team cannot answer from the screen, support macro, or approved rules, do not launch broadly.

## Final Operating Principle

A social sweepstakes casino does not win by being the loudest product in the category. It wins by being clear enough that players understand it, disciplined enough that live ops does not drown it, safe enough that risk signals stop pressure, and reliable enough that redemption feels like a product promise, not a support gamble.

When a design or campaign is hard to judge, ask:

- Does this make GC and SC clearer?
- Does this make redemption more trustworthy?
- Does this help the player choose without pressure?
- Does this stop when risk appears?
- Does this have a real measurement plan?
- Would support be able to explain it calmly?
- Would we still be comfortable with this screen if a regulator, platform reviewer, payment partner, or angry player saw it?

If the answer is no, change the design before launch.
