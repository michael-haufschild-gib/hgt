# Monetization Strategy Catalog — 119 Strategies

Source: `monetization-psychology.md`. This is the raw material for ideation — cross-reference against the capability inventory each run (`strategy-crossref.md`: have / partial / absent). Open the source for the full "how it works / why it works" text before writing a concept doc.

Tags: **[A]** = tagged AGGRESSIVE in the source. Tier 2: can do. **[CR]** = COMPLIANCE RISK in the source — jurisdiction-dependent in production; usable in a prototype, note legal review in the concept doc.

Platform boundary: all strategies operate on platform-controlled elements only — purchase flows, bonuses, VIP, tournaments, social, onboarding, retention, redemption, lobby organization. None touch game math.

## 1. Core Platform Systems

| # | Strategy | Mechanic | Psychology | Note |
|---|---|---|---|---|
| 1 | Variable Promotional Wheel | Daily wheel, varying GC + Free SC, unpredictable ratios | Variable ratio reinforcement | |
| 2 | Mystery Purchase Multipliers | Hidden chance any GC purchase multiplies its promo SC 2x-10x | Anticipation per purchase | Multiplier must be standard promo grant variance, not purchasable odds |
| 3 | Progressive Package Unlock | Cumulative GC purchases unlock package tiers | Sunk cost | Tiers unlock packages/cosmetics only, never SC advantage |
| 4 | Multi-Wallet System | Visually distinct GC vs promo-SC wallets | Mental accounting | Required baseline anyway |
| 5 | VIP Journey System | Tiers from purchase volume; better promo ratios, faster redemption | Status loss aversion | "Faster redemption" = service speed, never eligibility |
| 6 | Achievement Journey Maps | Visual progression path with upcoming unlockables | Goal gradient | |
| 7 | Daily Quest Chains | GC game challenges unlock further quests, dual-currency rewards | Daily routine | Progress through play only |
| 8 | Entertainment XP | XP for all GC gameplay; thresholds unlock games/features | Outcome-independent progression | |
| 9 | GC Accumulation Achievements | Achievements on total GC earned/purchased/played | Win/lose-independent progress | |
| 10 | Milestone Celebration Ceremonies | Scaled celebrations at any milestone | Positive reinforcement | |

## 2. Collection & Retention Systems

| # | Strategy | Mechanic | Psychology | Note |
|---|---|---|---|---|
| 11 | Trading Card Collection | Card sets via play + purchases; complete sets give permanent GC multipliers | Zeigarnik, persistent value | |
| 12 | Avatar Customization Economy | Permanent avatar items, GC-bought or earned, event-limited rares | Endowment, identity | |
| 13 | Seasonal Collection Albums | Time-limited sticker albums; completion grants permanent rewards | FOMO + Zeigarnik | |
| 14 | Slot Machine Collection Gallery | Unlock slots as permanent collection via play milestones | Collecting as investment | |
| 15 | Badge Crafting | Combine duplicate badges with GC cost into higher tiers | Duplicate purpose, IKEA effect | |
| 16 | Login Streak Multipliers | Consecutive logins scale daily free GC/SC | Loss aversion for streaks | No punitive streak copy |
| 17 | GC Game Mastery Trees | Per-game progression unlocking features/rewards | Game-level investment | |
| 18 | Account Age Benefits | Permanent earning advantages by account age | Switching costs | |
| 19 | Streak Protection | Spend GC to protect login streaks | Loss aversion | GC spend protects GC-side streaks; SC-bearing streaks must stay free-protectable |
| 20 | Dual-Reward Collections | Collect items granting both GC and promo SC ("47/50 treasures") | Zeigarnik | SC payout earnable identically without purchase |

## 3. Shop & Pricing Architecture

| # | Strategy | Mechanic | Psychology | Note |
|---|---|---|---|---|
| 21 | Anchor Package Positioning | Expensive whale package makes mid-tier feel reasonable | Anchoring | |
| 22 | Goldilocks Layout | Groups of three, middle = best value | Compromise effect | |
| 23 | Three-Tier with Decoy | Middle option deliberately weak | Decoy effect | |
| 24 | Shop Heat Zones | High-margin packages in upper-left | Visual hierarchy | |
| 25 | Bundle Confusion | Overlapping bundles hard to compare | Analysis paralysis | Tier 2 |
| 26 | Multi-Select Offer Stacking | Add-ons on a base package, total-value display | IKEA effect | Add-ons never prechecked |
| 27 | Forced Binary Flash Sales **[A]** | Two timed offers, "choose now" framing | Eliminates no-purchase option | Tier 2 |
| 28 | Build-Your-Bundle Stacking | Sequential add-ons, each acceptance unlocks better next | Commitment/consistency | |
| 29 | Stack Visualization Multiplier | "Stack Power: 4.7x VALUE!" visual amplification | Perceived value | Displayed math must be true |
| 30 | Rotating Daily Shop Offers | Different configurations per weekday | Habitual checking, FOMO | |
| 31 | Flash Shop Takeovers | Whole shop replaced by themed event packages | Scarcity, novelty | |
| 32 | Time-Delayed Gift Reveals | Post-purchase surprise gifts over 24h | Extended gratification | |
| 33 | Progressive Upsell Ladder | Post-purchase one-time next-tier discount, chains | Yes-momentum | Tier 2 |
| 34 | Double-Up Hour Timer | 1h after first daily purchase: 50%-off double offer | Timed deal framing | Timer must be real |
| 35 | Behavioral Price Discrimination **[CR]** | Different prices by player history | Willingness-to-pay matching | Uniform-pricing laws in some jurisdictions; production needs legal review |
| 36 | Cart Abandonment Recovery | Escalating offers 1h/6h/24h after abandoned checkout | Purchase-intent pursuit | Tier 2 |
| 37 | Session-End Exclusive Offers **[A]** | "Before you go" 60s package at logout | Transition capture | Tier 2 |
| 38 | Social Proof Price Display | Live purchase counts on packages | Bandwagon | Real numbers only |
| 39 | Personalized Price Narratives | Same package framed by identity ("Smart Saver") | Identity alignment | |
| 40 | Commitment Cascade | $1 → $5 → $20 → $50 across first week | Foot-in-the-door | |
| 41 | Bundle Breaking | Declined big bundle re-offered in pieces | Contrast effect | Tier 2 |
| 42 | Limited Unlock Windows | Premium packages after triggers (10th purchase, anniversary) | Achievement + scarcity | |
| 43 | The False Ceiling | Bigger hidden "VIP exclusive" revealed after largest purchase | Escalation | |
| 44 | Bundle Value Display | Cumulative value shown across multiple purchases | Visual accumulation | |
| 45 | Tiered Shop System | Shop tiers (Basic→Platinum) by purchase history, preview-locked | Endowment, identity | Better GC ratios fine; never SC advantage |
| 46 | Comfort Zone Expansion | Detect price comfort zone, stretch 20-30% | Malleable reference prices | |
| 47 | Comfort Zone Ladder | $20 → $24 → $22 sequencing; new baseline | Weber-Fechner | |
| 48 | Dual-Zone Activation | Separate "everyday" vs "special occasion" spend mindsets | Mental accounting | |
| 49 | Sandwich Pricing | Target price between comfort and stretch options | Compromise effect | |

## 4. Promotional Campaigns & Communication

| # | Strategy | Mechanic | Psychology | Note |
|---|---|---|---|---|
| 50 | Flash GC Package Sales | 30s-2min sales with enhanced promo SC | Time pressure | Tier 2 |
| 51 | Cascade Email Rewards | Free GC/SC at unpredictable intervals | Variable ratio | |
| 52 | Reload Promotions | "Running low? Reload +25%" | Scarcity mindset | True low balance only |
| 53 | Limited Capacity Events | Tournaments with visibly filling spots | Scarcity + social proof | Real capacity only |
| 54 | Account Celebration Packages | Birthday/anniversary special rates | Reciprocity | |
| 55 | Community GC Challenges | "If 10,000 players buy today, everyone gets free GC" | Social pressure + community | |
| 56 | Happy Hour Windows | Scheduled enhanced-value times | Classical conditioning | |
| 57 | Behavioral History Messaging | "You played 47 games last week — 3 new matches" | Personalized consistency | |
| 58 | Peer Comparison Messaging | "Players at your VIP level average $X" | Conformity | Tier 2 |
| 59 | Package Value Framing | "Complete your package library" | Completionism | |
| 60 | GC Milestone Celebrations | "10 millionth GC purchased!" + offer | Milestone association | |
| 61 | Incomplete GC Collections | "87% complete — finish before month end" | Zeigarnik | |
| 62 | VIP Host Communications | Personalized host messages about packages | Authority, attention | VIP = service, not pressure (essentials); suppression applies |
| 63 | Package Availability Alerts | "Your favorite package enhanced today only" | Scarcity on familiar | Real deadline only |
| 64 | Status Maintenance Alerts | "One more purchase keeps Gold VIP" | Status loss aversion | Tier 2 |
| 65 | Loss Recovery Offers **[A]** | Post-loss "recovery packages" in 5-10min | Emotional vulnerability | Tier 2 |
| 66 | Win Momentum Upsells **[A]** | Post-big-win "victory packages" | Hot hand fallacy | Tier 2 |

## 5. UX & Psychology Flows

| # | Strategy | Mechanic | Psychology | Note |
|---|---|---|---|---|
| 67 | Progressive Value Revelation | Features revealed gradually | Repeated discovery dopamine | |
| 68 | Frictionless Purchase Flow | One-click, saved payment, biometric | Friction removal | |
| 69 | Multi-Step Exit Friction | Exit flow emphasizes losing progress | Compounded loss aversion | Tier 2 |
| 70 | Progressive Package Introduction | Small packages first, larger unlock by engagement | Escalating commitment | |
| 71 | Active Reward Claiming | Manual claim instead of auto-credit | IKEA effect, ownership | |
| 72 | Return Player Package Offers | Value scales with absence duration | Inertia override | Watch bonus-seeking training (essentials) |
| 73 | VIP Tier Trial via GC | Temporary VIP from any purchase | Endowment | |
| 74 | Social Gifting Mechanics | Gift packages to friends with celebrations | Reciprocity | Needs social graph |
| 75 | Progress Bars That Accelerate | Faster movement near 100% | Goal gradient illusion | Display must not misstate actual progress |
| 76 | Pulsing Urgency Indicators | Timers pulse faster near deadline | Attentional bias | Real deadlines only |
| 77 | Visual Hierarchy Design | Primary currency 3x larger, animated | Pre-attentive processing | |
| 78 | Near-Miss Highlighting | "You finished 11th — top 10 win!" | Near-miss effect | Tournament/leaderboard/collection ONLY — never game-level |
| 79 | Engagement Profile System | Display player's most active patterns | Personalization | Never imply "lucky" times/games |
| 80 | Re-engagement Recovery Path | Increasing free gifts by absence length | Guilt-free return | |

## 6. Social & Community

| # | Strategy | Mechanic | Psychology | Note |
|---|---|---|---|---|
| 81 | Real-Time Winner Showcase | Live win feed with player details | Vicarious reinforcement | Real data + consent only; needs identity/feed infra |
| 82 | Team Competition | Teams where purchases give team advantages | Diffused responsibility | Needs social graph; purchase→team-advantage forbidden if prizes involved |
| 83 | Gift Economy | Share purchase portions with friends | Reciprocity networks | Needs social graph; P2P redeemable transfer needs deep review |
| 84 | Spectator Mode | Watch others play | Vicarious reinforcement | Platform can't see inside iframe games — infeasible as stated |
| 85 | Exclusive Club Systems | Purchase-level clubs with exclusive offers | In-group identity | |
| 86 | Package Referral Programs | GC/SC for referral first purchases | Acquisition incentive | Needs referral infra |
| 87 | Tournament Investment Tracking | Cumulative GC investment across rounds | Sunk cost | |
| 88 | Social Proof Badges | "Most popular" + player counts | Bandwagon | True data only |
| 89 | Guild/Club Systems | Permanent groups, shared goals, chat | Belonging | Needs social graph + moderation |
| 90 | Gift-Giving Ceremonies | Elaborate gift celebrations | Reciprocity amplification | Needs gifting infra |

## 7. Visual & Sensory Design

| # | Strategy | Mechanic | Note |
|---|---|---|---|
| 91 | Audio Distinction | Distinct sounds per outcome type | |
| 92 | Color Psychology Systems | Consistent value/bonus/urgency color coding | Use brand tokens |
| 93 | Purchase Celebration Animations | Elaborate post-purchase celebration | |
| 94 | Haptic Feedback Patterns | Distinct vibrations per event | Limited in web mock |
| 95 | Staged Reveal Mechanics | Multi-stage package content reveals | |
| 96 | Particle Effect Celebrations | Coins/fireworks/sparkles on wins | See docs/meta/animations-particles.md |
| 97 | Animation Speed Ramping | Slow-start accelerating reveals | |
| 98 | Signature Sound Branding | Brand-identity outcome sounds | |
| 99 | Ambient Casino Atmosphere | Background activity/excitement sound | |
| 100 | Victory Light Shows | Lighting intensity scales with win size | |

## 8. Advanced Pricing Mechanics

| # | Strategy | Mechanic | Psychology | Note |
|---|---|---|---|---|
| 101 | Sacrifice Choice Offers | Trade tomorrow's gift vs pay more today | Loss aversion both ways | SC amounts must respect grant caps |
| 102 | Either/Or Gift Selection | Mandatory free-gift choice per package | Ownership before completion | |
| 103 | Time-Pressure Choice Cascades **[A]** | Forced choices, 60s→5s timers | Degraded decisions | Tier 2 |
| 104 | Complementary Stack Discoveries | Hidden combos unlock surprise gifts | Discovery | |
| 105 | Package Momentum Pricing | Each package within 24h slightly cheaper | Bulk urgency | |
| 106 | Round-Up Suggestions | "Add $5 to reach $50 and unlock extras" | Trivial-addition framing | |
| 107 | First Package Super-Value | Exceptional first-purchase rate | Anchoring | Don't make normal shop feel punitive (essentials) |
| 108 | Subscription Psychology | Monthly daily-currency delivery | Payment depreciation | |
| 109 | Seasonal Event Psychology | Holiday-tied modes and offers | Cultural anchoring | |
| 110 | Dormant Player Offers | Escalating deals by purchase dormancy | Inertia override | |
| 111 | Package Preference Learning | Learned size/timing personalization | Targeting | |
| 112 | Play Style Package Matching | Packages matched to play patterns | Shortage prevention | |
| 113 | Dynamic Package Sizing | Options adjusted to history | Decision-paralysis reduction | |
| 114 | Cross-Session Momentum Timing | Offers timed to primed sessions | Predictive timing | Tier 2 |

## 9. Responsible Gaming Integration

Source section; strategies 115-119 are valid prototype material like any other:

| # | Strategy | Mechanic |
|---|---|---|
| 115 | Self-Set Purchase Limits | Player-set daily/weekly/monthly caps, no override during cooling-off |
| 116 | Session Duration Displays | Always-visible session timer, optional break reminders |
| 117 | Spending Summary Notifications | Weekly spend/time/outcome summary |
| 118 | Cool-Off Periods | Optional 24h pause after large purchases; no upsells during |
| 119 | Reality Check Pop-ups | Interval session-stats display |

## Key Psychological Levers (shorthand for concept docs)

Variable ratio reinforcement, loss aversion (~2x gains), Zeigarnik effect (incomplete tasks), goal gradient (acceleration near goal), sunk cost, endowment, anchoring/decoy/compromise, mental accounting, reciprocity, social proof/bandwagon, FOMO/scarcity, IKEA effect, commitment/consistency, near-miss (platform-level only), peak-end rule, hyperbolic discounting, mere exposure, variable reward anticipation (dopamine).

