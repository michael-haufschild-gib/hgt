# Playbook Essentials — Operating Rules for Feature Prototyping

 Tier 1/Tier 2 rules live in `hard-constraints.md` — this file is the playbook's internal operating guidance: quality input for design decisions, not law.

Two player motivations coexist — entertainment players (fun, progress, status, collections, events) and prize-aware players (SC balances, eligibility, redemption, rules). Every feature must serve at least one without confusing the other.

## Surface Rules

| Surface | Job | Build | Avoid |
|---|---|---|---|
| Lobby | One next action without hiding choice | One hero decision, recent games, recommendations, favorites, few live-ops modules | Banner walls; badge on every tile ("if every game is hot, nothing is hot"); carousel-dependence for important info |
| Game page | Credible play decision | Title, provider, play CTA above fold; related content below | Promos mid-play; offers during active gameplay |
| Shop | Decision architecture | Featured offer → free claim (clearly separate) → core GC packages → bundles behind sections → terms/AMOE/support access | Spreadsheet feel, negotiation feel, bundle confusion, stacking timer+badge+discount+bonus on one card |
| Shop card | Comparison without mental math | GC headline, Free SC prominent as labeled promo, clear final price, true badges only | SC looking priced; untrue "best value"/"limited" badges |
| Checkout | Calm and exact | Package, GC, Free SC, final amount, method, support; button names the action ("Buy 50,000 Gold Coins") | "Continue" that charges; prechecked add-ons; cross-sell before confirmation |
| Receipt | Trust artifact | Transaction, GC bought, SC granted, balances updated, support path, next action | Upsell that hides receipt details |
| Popups/sheets | Lifecycle moments | Trigger on meaningful event or pause; clear value; clear close; respect fatigue | Entry popups, nagging after decline, hidden close |
| Profile/wallet | Honesty check | Separate GC/SC, redeemable vs pending SC, purchase + grant + redemption history | Inferring redeemable value from a total; internal jargon |
| Search | Retention feature | Recovery in empty states: clear filters, popular categories, recent games | Turning empty search into a sales pitch |

## Offers

- **Math before art**: every offer idea needs audience, eligibility, GC sold, Free SC exposure, suppression, measurement, stop rule. "We'll see after launch" = not ready.
- **Starter offers**: simple, GC primary, easy to decline, at a natural moment, never triggered by confusion/losses. Don't make the first offer so generous the normal shop feels punitive after.
- **Second purchase is a trust test**: calm contexts only (receipt secondary slot, lobby return, milestone, post-claim shop visit). Never post-loss, never repeated after decline.
- **Chain offers**: visible sequence and step states, one understandable timer, clear exit, suppression after decline, no hidden escalation, no impossible completion. Short and generous for new players.
- **Daily claims**: genuinely free, quick, never gated behind a purchase modal. Claim → confirm → suggest next action (play/mission/event), suggestion never blocks the claim.
- **Bundles**: explainable in one card + one details sheet, or simplify. Good extras: event entries, VIP points, collection packs, cosmetics, boosters. Bad: mystery value without rules, hidden odds, default-checked add-ons.

## Live-Ops Rhythm

Rhythm, not noise. Defined campaign slots; one main player reason to return at a time. Fatigue = too many demands on attention — when fatigue rises, reduce pressure before raising offer value (more value can still feel like more pressure). Review from the player's view: "what does one player actually see today?" The best live-ops teams delete as much as they add.

## Retention Modules (the proven catalog)

Maturity order matters — don't add every mechanic at once; each adds cognitive load, support load, and review surface.

- **Daily claims + missions**: guaranteed positive daily action; missions teach the product, fit normal play, show progress, never require spend. No punitive streak copy — a missed day is not failure; streaks encourage, never threaten.
- **Loyalty/tiers**: visible progress, better *service* (support, event access, cosmetic status, approved GC bonus rates). Never "better odds", never "keep status by buying now".
- **Collections**: albums with visible missing items, duplicate value, earned through normal play, catch-up paths, permanent museum/history. Never impossible without paying; never pure-random-only completion.
- **Tournaments/leaderboards**: matched cohorts/divisions, clear rules, opt-in, reward tables. Never spend-only ranking, never public spend exposure.
- **Draws/wheels/random rewards**: high attention, high risk — need clear rules, eligibility, disclosed reward tables, transparent ticket earning. Never used to obscure cost or manufacture urgency.
- **Social**: optional identity, belonging, reciprocity — gifting with limits, clubs, cooperative missions, achievement sharing. Never coercion, spend leaderboards, guild purchase pressure, or P2P transfer of redeemable value.
- **Seasonal progression**: clear theme, visible path, free participation, catch-up mechanics, end-of-season summary, preserved history. Never erase meaningful progress punitively; never stack too many simultaneous passes/albums/events.

## Player States (design for the state, not a persona)

| State | Needs | Never |
|---|---|---|
| New visitor / first session | Value fast, currency explained through action, one clear next step | Interruptive purchase popups, event overload, KYC without policy need |
| Active non-purchaser | Daily claims, missions, free events, collections, discovery — they create liquidity and habit | Punishing with constant purchase popups |
| First-time purchaser | Clear receipt, updated balances, reassurance | Immediate second-offer pressure |
| Active purchaser | Consistent shop, offers at natural pauses, loyalty relevance | Escalating every purchase into a bigger ask |
| Prize-aware player | SC clarity, eligibility progress, redemption rules, verification expectations | Monetizing their redemption intent |
| Lapsed | Diagnosis first: service recovery / education / content news before incentives | Bigger and bigger bonuses; the best winback may be no offer |
| Risk/support distress | Suppression: account tools, support, free claim, neutral content | Any commercial pressure |

## Trust Standards by Moment

- **After a win/reward**: celebrate proportionally, confirm exactly what was granted (GC? Free SC? badge? entry?), show progress, suggest next action — don't shrink the reward by instantly selling.
- **During purchase/after purchase**: exact, boring, confirmed.
- **Payment errors**: say whether the player was charged; safe next steps; no new offer.
- **Blocked redemption**: lead with reassurance (balance visible, next step, support path); specific but not fraud-revealing.

## Design Review Questions (apply in Phase 2 critique)

- What is this screen's one job, and the player's emotional state?
- Are GC and SC separate and labeled? Is Free SC promotional, not priced?
- Are decline, close, expired, ineligible, suppressed, error, loading, and empty states designed? (Most trust damage lives in non-happy paths.)
- Is the close path obvious? Are material terms near the decision?
- Does motion explain state or merely decorate? Casino UI is already high-stimulation; hierarchy must stay calm.
- Could support explain this screen's state from the screen alone?
- Would we be comfortable if a regulator, platform reviewer, or angry player saw it?

## Multi-Brand Rule
Brands share backoffice. Brands share most core features reskin them. Brands have special implementations with changed business logic or functionality for some features or brand-specific features. Expression is brand-specific (art, themes, character voice, event naming, pacing).

