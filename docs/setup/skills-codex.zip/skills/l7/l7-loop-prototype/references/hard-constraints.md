# Hard Constraints — Read Before Every Ideation Round

Two tiers. **Tier 1 (HC-1 to HC-11): cannot do** — illegal under the sweepstakes model, impossible on this platform, or economy-breaking. No exceptions, no "it's just a mock". **Tier 2: can do.** Constraint-gate verdicts cite the HC ids checked.

## Tier 1 — Cannot Build

### HC-1 — Games are a black box behind an iframe (platform fact)

The platform launches third-party casino games in an iframe. It controls NOTHING inside them: not RTP, not volatility, not symbols, paylines, reels, bonus-trigger frequency, near-misses, win pacing, or any game math. The platform only sees its own side: session start/end, bet placed, spin settled, balance changes, game metadata (title, provider, category, thumbnail).

- **Never** prototype a feature that alters, tunes, or claims to influence game outcomes, odds, or behavior ("boosted reels", "lucky hours on this slot", "your win chance rises").
- **Never** show "hot/cold" game indicators implying games have memory or patterns.
- **Allowed**: features that react to platform-visible events (a settled spin, a balance threshold, session length) or organize the catalog (lobby rotation, featured games, recommendations).

### HC-2 — SC is never sold (legal core)

Gold Coins (GC) are the purchased entertainment currency. Sweepstake Coins (SC) are promotional and free; they may become redeemable when eligibility rules are met. Every purchase buys GC; Free SC may be included as a promotional bonus.

- **Never** sell SC, price SC, or frame any purchase as buying SC, entries, or chances.
- **Never** make SC look like a standalone priced product on a card, in checkout, or on a receipt.
- **Allowed**: making Free SC a prominent, clearly-labeled promotional value cue on a GC package — players compare offers by Free SC and the shop should support that comparison honestly.

### HC-3 — No purchased advantage toward prizes (legal core)

A paying player must never reach redeemable value more easily than a non-paying player. This is the legal heart of the dual-currency sweepstakes model.

- **Never** sell progress: no purchase-gated steps in any SC-bearing or prize-bearing mechanic, no paid skips, no purchases that advance a sweepstakes-relevant meter.
- **Never** give buyers better odds, better drop rates, extra entries per dollar beyond the standard promotional grant, or privileged eligibility for redeemable value.
- **Never** write or imply "purchase improves your chances" anywhere.
- **Allowed**: purchases granting entertainment-side value (GC, cosmetics, GC-only boosts, collection items with GC rewards) and standard promotional Free SC at consistent ratios. If a mechanic pays out SC, its progress must be earnable identically without purchase.

Test: "Could a player who never pays complete this mechanic and reach its rewards on the same terms as a payer?" If no, reject.

### HC-4 — SC is a cash liability; the economy has hard rules

Free SC functions as real money: ~1:1 USD redemption. Every SC grant is potential cash out the door, not decorative bonus text.

- **No showering**: every SC-granting mechanic needs a stated purpose, a per-player cap, and a budget. A feature that mints uncapped SC is broken by design. Keep grant ratios consistent with the shop's promotional baseline.
- **Playthrough is always 1x**: an SC bonus can require at most one playthrough before redeemability. Classical casino bonus wagering (10x-40x) is not available in this model — never design a mechanic that depends on it.
- **Consequence — abuse prevention is first-class**: because SC converts to cash after minimal play, every SC-granting feature must state its abuse surface and controls in the design doc: eligibility rules, frequency/velocity caps, per-account limits, multi-account/dedup considerations, audit trail. Fraud is a design input, not a backend afterthought.
- **Prefer GC-side generosity**: GC is cheap entertainment value and can be generous; SC is liability. When a mechanic needs a satisfying reward and SC exposure is unjustified, reward GC, cosmetics, collection progress, or access.

### HC-5 — GC/SC separation everywhere (legal framing)

Separate balances, separate labels, separate copy in header, wallet, shop card, checkout, receipt, history, and every new feature surface. Never a combined "account value". Receipts repeat the distinction: what was bought (GC), what was granted free (SC).

### HC-6 — Free entry stays findable (legal requirement)

The no-purchase route (AMOE) is trust information. Never hide it, bury it, or design a surface that undermines it. New offer/shop surfaces include rules access ("No purchase necessary. See official rules.").

### HC-7 — Approved vocabulary (legal-risk copy)

| Concept | Use | Never |
|---|---|---|
| Paid currency | Gold Coins | Deposit, cash, redeemable coins |
| Promotional currency | Free Sweepstake Coins | Purchased SC, cash bonus, Sweeps Coins |
| Purchase action | Buy Gold Coins | Deposit now, fund account, buy SC |
| Redemption | Redeem eligible balance | Withdraw winnings, cash out instantly |
| Odds/outcomes | — (say nothing) | Boost your odds, guaranteed winnings, risk-free |
| Prize-progress framing | — (say nothing) | One more purchase to unlock, this offer improves your chance to redeem |

### HC-8 — Everything displayed must be honest (deception is illegal)

No fake scarcity, fake countdowns, timers that reset, fabricated player counts, manufactured purchase numbers, fake "limited" claims, or invented winner feeds. A mechanic whose appeal depends on fabricated data is rejected at design time — mock data may be invented, but the mechanic must work with real data in production.

### HC-9 — No deceptive interaction patterns

No hidden or delayed close buttons, charges behind vague buttons ("Continue" that charges), prechecked add-ons, disabled back navigation, or obstructed opt-out/decline. Every overlay has a clear close; every offer has a visible decline.

### HC-10 — No forbidden targeting

Nothing aimed at minors. No socioeconomic or protected-class proxies for offer pressure or pricing: income prediction, home value, employment, device price, payment method as wealth proxy, ZIP affordability, debt/financial distress, gender/race/health/disability proxies.

### HC-11 — Redemption is sales-free

No purchase offer, chain offer, countdown, winback, VIP upsell, or shop promo on any redemption surface or in any redemption status message. Redemption copy is service copy.

## Tier 2 — Can Do

Everything not caught by Tier 1 is available, including:

- **Behavioral-timing offers**: post-loss recovery offers, post-win momentum upsells, session-end offers, long-session or late-night timing, failed-payment follow-ups, escalating cart-abandonment sequences.
- **Pressure mechanics**: forced binary choices, short or cascading timers (deadlines must be real), exit friction, re-offers after decline.
- **Social comparison**: peer-spend comparison messaging, status-maintenance alerts, purchase-visible leaderboards.
- **Individual price architecture**: comfort-zone expansion, personalized package sizing/timing. Behavioral price discrimination is `[CR]`: jurisdiction-dependent in production.
- **Offer placement**: during play, at pauses, at session boundaries.

## Auto-Reject Checklist (Tier 1 only — cite in every constraint-gate verdict)

1. Touches or implies influence over in-game math/odds → HC-1
2. Sells SC or frames purchase as buying entries/odds → HC-2
3. Paid path to redeemable value easier than free path → HC-3
4. Uncapped/unbudgeted SC grants, >1x playthrough design, or SC-granting mechanic with no abuse controls → HC-4
5. GC/SC blending in copy, balance, or receipt → HC-5
6. Fake scarcity / fabricated social proof / fake timers → HC-8
7. Hidden close, prechecked add-ons, vague charging button, obstructed decline → HC-9
8. Targets minors or uses socioeconomic/protected-class proxies → HC-10
9. Offer inside redemption → HC-11
