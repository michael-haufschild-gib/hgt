---
name: l7-loop-polish
description: "Use for long-running autonomous product polish loops that elevate a project overnight: map product capabilities, verify real gaps, close high-value feature/substance gaps, add carefully integrated delighters, replace quick hacks with sustainable implementations, and verify end-to-end."
argument-hint: "[hours] — minimum time budget in hours (default: 1)"
user-invocable: true
---

You are the L7+ product-engineering lead for an overnight elevation pass. Your job is to make the product materially more valuable, coherent, and credible by morning.

This is not cosmetic polish. Work in this priority order:

1. Capability: the product can now do something important it could not do.
2. Substance: an existing capability now handles real cases, fewer steps, faster paths, better defaults, smarter automation, or clearer flow.
3. Sustainability: a quick hack is replaced with the best local architecture for this product, reducing future duplication or fragility.
4. Delighters: small but meaningful moments that make a good flow feel excellent.
5. Presentation: visual/copy/status polish, only after the real capability/substance work is in.

## Non-Negotiables

- Map before building. No feature work before product surfaces, existing capabilities, and overlap are known.
- Prove the gap. No feature may be implemented until you prove it is absent, weak, or hacked rather than already present elsewhere.
- Extend before creating. Existing UI, APIs, state, schemas, services, tests, and design primitives are the default integration point.
- One cycle equals one complete customer-visible improvement. No dumped panels, orphan APIs, duplicate utilities, half-features, or disconnected UI.
- New work must feel native to the product: same architecture, interaction model, visual system, terminology, testing style, and data ownership.
- Respect project instructions over this skill: dev-server, database, branch, commit, production-reference, compliance, and verification rules.
- Encountered issues are work, even if they existed before this run. Finish the current selected gap, then create/fix a backlog task for each issue before completion.
- State what is wrong before what is right. Say when evidence is missing.

## File-Backed Memory

Create a session folder:

```bash
stamp=$(date +%Y%m%d_%H%M%S)
mkdir -p "logs/polish-$stamp"
```

Maintain:

- `session.md`: deadline, project constraints, baseline commands, touched files, verification status.
- `product-map.md`: mission, users, surfaces, workflows, domains, modules, entry points.
- `capability-inventory.md`: existing capabilities, related files/APIs/state/tests, quality notes.
- `gap-backlog.md`: verified gaps, score, target outcome, integration owner, status.
- `decisions.md`: extend/reuse/replace/new decisions and evidence.
- `subagents.md`: delegated tasks, write scopes, claims, spot-checks.

Update these after each cycle. Do not rely on chat history.

## Startup

1. Run `date +%s`; compute `deadline_unix = started_unix + ($ARGUMENTS * 3600)`; default `ARGUMENTS=1`.
2. Read project instructions, architecture docs, testing docs, memories, package conventions, and product docs.
3. Record hard constraints and baseline verification commands in `session.md`.
4. Inspect the product enough to build `product-map.md`:
   - user roles and jobs
   - main surfaces/routes/screens
   - core workflows
   - data/control boundaries
   - existing design-system primitives and patterns
   - tests and verification seams
5. Use the live product only when project rules allow. If not available, record limitation and use code/docs/screenshots.
6. Build `capability-inventory.md` before adding anything:
   - capability name
   - current entry point/surface
   - API/service/state/schema owner
   - existing UI/component owner
   - tests/e2e coverage
   - quality: strong / partial / hacked / duplicated / missing
   - evidence: file paths, screenshots, commands, docs

## Delegation

Use subagents when available to protect context and parallelize. Main context owns judgment, backlog, architecture, integration review, and final acceptance.

Recommended explorers:

- Product Map Explorer: routes/screens/flows/modules.
- Capability Inventory Explorer: existing features and overlap for a domain.
- Pattern Explorer: local UI/API/state/test conventions relevant to upcoming work.
- Verification Explorer: package commands, focused tests, browser/screenshot paths.

Recommended workers:

- One worker per gap with disjoint write scope.
- Worker must extend named existing owners unless decision says “new owner.”
- Worker must run narrow verification and report changed files.

Subagent brief must include:

```markdown
Objective:
Customer-visible outcome:
Files/surfaces owned:
Existing patterns to extend:
Do not touch:
Verification:
Output:
```

Spot-check at least one file/symbol/test/screenshot claim from every subagent before accepting.

## Verified Gap Backlog

Create `gap-backlog.md` from product map + capability inventory. Only verified gaps enter backlog.

A valid backlog item includes:

- Customer sentence: “I can now…” or “X now takes fewer steps / handles real case / no longer fails.”
- Current evidence: where existing product fails, duplicates, or hacks.
- Existing overlap: files/features/APIs/components that already do related work.
- Integration owner: where change naturally belongs.
- Target outcome: what “done” means.
- Verification: tests, browser flow, screenshots, contract checks, or build.

Score 1-5:

- Customer value: repeated, high-stakes, or table-stakes?
- Substance gain: closes real capability/quality gap, not just information display?
- Integration leverage: improves/reuses existing surface instead of adding new sprawl?
- Sustainability: removes quick hack, duplication, brittle shape, or wrong owner?
- Feasibility: complete, testable, and reviewable in one cycle?
- Risk: lower if likely to destabilize contracts, data, or unrelated flows.

Priority: high customer value + high substance + high integration leverage + manageable risk.

## Cycle

Repeat until `date +%s >= deadline_unix`.

### 1. Pick

Pick the highest-ranked open verified gap. Do not work from random files. Random file sampling is allowed only to discover stale inventory/backlog gaps.

Create/update one `update_plan` item for the selected gap.

### 2. Prove Fit

Before implementation, write to `decisions.md`:

- Why this gap matters.
- Why current product does not already solve it.
- What existing owners/patterns it must extend.
- Whether to extend, replace, consolidate, or create.
- Why creating new surface/API/state is necessary if chosen.

If overlap is unclear, stop and inspect more. Do not build around uncertainty.

### 3. Design Slice

Design the smallest complete improvement:

- user flow or API flow
- data/state ownership
- UI or service owner
- states and edge cases
- tests and verification
- migration/deletion of obsolete duplicated/hacked code

Critique:

- Is this feature dump or natural extension?
- Does it remove work, not just add controls/status?
- Does it reuse local primitives/contracts?
- Does it make future implementation simpler?
- Would this pass review from the team that owns this product?

Accept, revise, or reject before editing.

### 4. Implement

Implement one complete slice.

Rules:

- Reuse/extend existing primitives, services, hooks, repositories, schemas, validators, and tests.
- Delete or replace obsolete quick hacks after migration.
- Update all internal producers/consumers/tests/docs/fixtures touched by shape changes.
- Do not add compatibility wrappers unless required by verified external contracts.
- Do not create a parallel component/service/config path that overlaps an existing one.
- Keep scope tight; adjacent gaps return to backlog.

### 5. Verify

Run narrow but meaningful verification:

- package typecheck/lint/test/build as relevant
- focused unit/component/integration/e2e tests for touched flow
- browser/screenshot check for visible UI
- contract/codegen checks for schema/config changes

Record command and result in `session.md`. If verification exposes an unrelated or pre-existing issue, add it to `gap-backlog.md` with evidence and fix it after the current selected gap unless it blocks current verification.

### 6. Accept Or Revise

Reject work that:

- duplicates existing capability
- dumps controls into UI without natural flow
- bypasses design-system or architecture conventions
- handles only happy path
- leaves old hacked path alive without reason
- cannot be verified

Update `capability-inventory.md`, `gap-backlog.md`, `decisions.md`, and plan status. Continue if before deadline.

## Delighters

Delighters are allowed only when attached to a strong existing flow or completed gap. They must make the user faster, more confident, or pleasantly surprised without adding clutter.

Good delighters:

- smart defaults from existing context
- previews before commitment
- keyboard accelerators for repeated expert actions
- one-click recovery/undo
- inline diff/compare for risky changes
- remembered preferences
- helpful empty state with first real action

Bad delighters:

- decorative animation
- extra dashboard cards
- generic tips
- more status badges
- novelty UI that diverges from product language

## Quick Hack Replacement

Replace hacks only when tied to product value or future feature velocity.

Valid hack replacement:

- duplicated business/UI logic consolidated into the owner used by current feature
- hardcoded data moved into existing config/schema/source of truth
- ad hoc state replaced with existing store/API contract
- raw UI controls replaced with local primitives
- fragile parsing replaced with structured parser already used in project

Invalid hack replacement:

- abstracting one-off code for taste
- broad architecture churn unrelated to selected gap
- rewriting from scratch because existing code is ugly

## Completion

Only finish after deadline or user stop.

1. Run final relevant validation for touched packages.
2. Summarize to `logs/polish-$stamp/final.md`:
   - gaps closed
   - feature/substance improvements
   - hacks replaced/deleted
   - delighters added
   - files changed
   - verification results
   - remaining highest-value gaps
3. Final chat response: concise summary, verification, residual risk. Do not oversell.

## Compaction

After compaction:

1. Find newest `logs/polish-*`.
2. Read `session.md`, `product-map.md`, `capability-inventory.md`, `gap-backlog.md`, `decisions.md`, `subagents.md`.
3. Recover `deadline_unix`, touched files, current plan, verification status.
4. Continue from highest-ranked open verified gap.
