---
name: market-ready-opinion
description: "Use to assess marketplace readiness, product quality, UI/UX, competitors, feature gaps, pricing value, GO/NO-GO."
argument-hint: "[--url http://localhost:PORT] [--category 'product category'] [--competitors 'App1, App2, App3']"
user-invocable: true
---

State what is wrong before what is right. When uncertain, say so. Disagree with optimistic assumptions when evidence warrants it.

Answer this question about the project in the current working directory:

**If this product were listed on a marketplace tomorrow — with a price tag — would a paying customer find it worth their money? Would they choose it over the alternatives? Would they stay, or churn within a week?**

This is not a code review. This is a market readiness assessment. Code quality matters only insofar as it affects what the customer experiences. A beautiful codebase that ships a broken product fails. An ugly codebase that ships a polished, stable, differentiated product passes.

Parse `$ARGUMENTS` for overrides:
- `--url`: App URL for live testing (skip browser testing if absent and no dev server found)
- `--category`: Product category override (skip auto-detection)
- `--competitors`: Comma-separated competitor names (skip competitor discovery)

---

## Phase 1: Discovery

Read every source file. Determine:

1. **What is this product?** One sentence.
2. **Who is it for?** Target user.
3. **What market category?** (e.g., "social casino app", "project management SaaS", "e-commerce storefront")
4. **Tech stack** — framework, UI library, backend, database.
5. **All user-facing features** — list every feature visible to the end user. Include features that are partially implemented.
6. **App URL** — check `$ARGUMENTS` for `--url`. If absent, check `package.json` scripts for dev server port. If found, record it.

Write discovery results to `market-readiness-discovery.md` in the project root. This survives context compaction.

---

## Phase 2: Market Intelligence

Use WebSearch to research the competitive landscape. Every claim must cite a verified source URL.

**Step 2.1 — Competitor identification:**
If `--competitors` provided, use those. Otherwise: search "[market category] best apps 2025 2026" and "[market category] alternatives comparison". Identify the top 3-5 competitors by market presence.

**Step 2.2 — Competitor feature inventory:**
For each competitor, search "[competitor name] features" and "[competitor name] review". Record:
- Core feature set
- Pricing model
- User sentiment (from reviews, ratings)
- Strengths mentioned in reviews
- Weaknesses mentioned in reviews

**Step 2.3 — Market expectations baseline:**
From the union of all competitor features, classify using Kano-informed categories:
- **Must-Be**: features present in ALL competitors (absence = rejection)
- **Performance**: features present in 2+ competitors with varying quality
- **Delighter**: features present in 0-1 competitors

Write results to `market-readiness-competitors.md`.

---

## Phase 3: Code Quality Assessment

Invoke the `/senior-honest-opinion` skill via the Skill tool. Wait for its output.

Extract from the output:
- Overall verdict and estimated level
- Specific stability risks (error handling gaps, missing tests, security issues)
- Architecture quality assessment

If `/senior-honest-opinion` is unavailable: assess code quality directly using the same 8 dimensions from that skill. Read every source file. Cite file paths and line numbers.

Record the code quality verdict and key findings. Do not re-read source files already read in Phase 1.

---

## Phase 4: UI/UX Assessment

Select mode based on available capabilities:

**Mode A — Live testing** (app URL available + agent-browser):
1. Use agent-browser to open the app URL.
2. Navigate each critical user flow (registration, core action, settings).
3. Capture a screenshot of each key screen.
4. For each screenshot: invoke `/ui-review` via the Skill tool with the screenshot path.
5. Record findings from each review.

**Mode B — Code analysis** (no app URL or no agent-browser):
1. Invoke `/ui-review-code` via the Skill tool.
2. Record its findings.

**Mode C — Minimal** (neither skill available):
1. Read all component/view files.
2. Assess: responsive design support, loading states, error states, empty states, accessibility attributes, visual consistency.
3. Tag all findings as "CODE-ONLY — behavior unverified."

Record the UI/UX assessment and mode used.

---

## Phase 5: Scoring

Load [references/scoring-methodology.md](references/scoring-methodology.md). Apply all three frameworks.

**Step 5.1 — Feature Completeness Matrix (Kano-informed):**

| Feature | Our Product | Market Category | Classification | Status |
|-|-|-|-|-|
| [feature] | Present/Absent/Partial | Must-Be/Performance/Delighter | PASS/FAIL/PARTIAL | [notes] |

Count: Must-Be present/total, Performance present/total, Delighters count.

**Step 5.2 — Competitor Comparison Matrix (Pugh-style):**

Select the market leader as baseline. Score our product and each competitor on 8-12 criteria using the -2 to +2 scale from the methodology. Compute weighted composites.

**Step 5.3 — Weighted Readiness Scorecard:**

Score each of the 8 dimensions (1-5) with evidence:

| Dimension | Weight | Score | Evidence summary |
|-|-|-|-|
| Feature Completeness | 20% | [1-5] | [must-be coverage, performance features] |
| UI/UX Quality | 20% | [1-5] | [from Phase 4 assessment] |
| Code Quality & Stability | 15% | [1-5] | [from Phase 3 assessment] |
| User Flow Quality | 10% | [1-5] | [critical path analysis] |
| Performance | 10% | [1-5] | [load times, responsiveness] |
| Competitive Position | 10% | [1-5] | [Pugh matrix composite] |
| Unique Value Proposition | 10% | [1-5] | [what makes this worth choosing?] |
| Market Fit | 5% | [1-5] | [does it solve a problem people pay for?] |

Compute the weighted composite score. Apply hard ceiling rules from the methodology.

**Step 5.4 — Map composite to Market Readiness Level and verdict** using the MRL table in the methodology.

---

## Phase 6: Adversarial Verdict

Before finalizing, attack your own assessment:

1. **Challenge each score.** For each dimension scored 3+, ask: "Would a paying customer agree with this score?" If the evidence is thin, lower it.
2. **Challenge the verdict.** If GO or CONDITIONAL GO: list the top 3 reasons a customer would request a refund within the first week. If you can list 3 strong reasons, downgrade.
3. **Challenge the USP.** State the unique value proposition. Then ask: "Would a customer explain this to a friend in one sentence?" If not, the USP is unclear.
4. **Challenge the competitive position.** For each competitor scored lower than our product: verify with evidence. Optimism without evidence is hallucination.

Adjust scores based on this challenge. Document adjustments.

---

## Output

```
## Market Readiness Assessment

**Product:** [name — one sentence description]
**Category:** [market category]
**Date:** [ISO date]

**Verdict:** [SHIP IT / GO / CONDITIONAL GO / NOT YET / MAJOR WORK / FAR FROM READY / PROOF OF CONCEPT / EARLY DEV]

**Market Readiness Level:** [1-9] — [meaning from MRL table]

**Composite Score:** [X.X / 5.0]

**One-sentence summary:** [Would a paying customer find this worth their money?]

---

### Readiness Scorecard

| Dimension | Weight | Score | Evidence |
|-|-|-|-|
| Feature Completeness | 20% | X/5 | [summary] |
| UI/UX Quality | 20% | X/5 | [summary] |
| Code Quality & Stability | 15% | X/5 | [summary] |
| User Flow Quality | 10% | X/5 | [summary] |
| Performance | 10% | X/5 | [summary] |
| Competitive Position | 10% | X/5 | [summary] |
| Unique Value Proposition | 10% | X/5 | [summary] |
| Market Fit | 5% | X/5 | [summary] |

Hard ceiling rules applied: [list any that triggered, or "none"]

---

### Feature Completeness (Kano-Informed)

**Must-Be features:** [X/Y present]
[table of must-be features with PASS/FAIL]

**Performance features:** [X/Y present]
[table of performance features with status]

**Delighters:** [count]
[list of delighter features, if any]

**Blockers:** [list must-be features that are missing — these must be built before launch]

---

### Competitor Landscape

**Competitors analyzed:** [list with source URLs]

[Pugh comparison matrix]

**Where we win:** [specific advantages with evidence]
**Where we lose:** [specific disadvantages with evidence]
**Unique selling proposition:** [one sentence — or "UNCLEAR" if none found]

---

### What Blocks Launch (ordered by impact)

[Numbered list: specific, actionable items that must be resolved before charging customers. Each item references a dimension, a score, and the evidence.]

### What Would Make This Exceptional

[Numbered list: delighter opportunities, competitive advantages to press, quick wins for differentiation.]

### Adversarial Notes

[Document the Phase 6 challenges and any score adjustments made.]
```

The "What Blocks Launch" section must be longer than "What Would Make This Exceptional." If it isn't, the assessment is too lenient. A product that has more opportunities than blockers is rare — verify you haven't overlooked gaps.
