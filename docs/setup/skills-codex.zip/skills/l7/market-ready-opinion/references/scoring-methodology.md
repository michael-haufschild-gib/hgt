# Scoring Methodology

## Kano-Informed Feature Classification

Classify each feature discovered in the project against market expectations established during web research.

| Category | Definition | How to identify | Impact on readiness |
|-|-|-|-|
| Must-Be | Features every competitor has. Absence causes immediate rejection. | Present in all top 3-5 competitors | Missing = BLOCKER. Present = no credit (expected) |
| Performance | Features where more/better = more satisfaction. Differentiators. | Present in 2+ competitors with varying quality | Missing = gap. Present = scored by relative quality |
| Delighter | Features no competitor has, or only 1 has. Unexpected value. | Absent from most competitors | Missing = no penalty. Present = major positive signal |
| Indifferent | Features that neither satisfy nor dissatisfy. | Not mentioned in competitor reviews/feature lists | Ignore — do not score |
| Reverse | Features that actively annoy users when present. | Mentioned negatively in competitor reviews | Present = penalty |

**Classification process:**
1. List all features found in the project source code.
2. List all features found in the top 3-5 competitors (from web research).
3. For each feature, classify using the table above.
4. A product missing 1+ Must-Be features cannot score above MRL 6 regardless of other scores.

---

## Pugh Competitor Comparison Matrix

Compare the project against the top 3 competitors on the dimensions that matter to paying customers.

**Scale:** -2 (much worse), -1 (worse), 0 (equivalent), +1 (better), +2 (much better)

**Template:**

| Criterion | Weight | Competitor A (baseline) | Our Product | Competitor B | Competitor C |
|-|-|-|-|-|-|
| [Feature/quality] | [1-5] | 0 (baseline) | [-2 to +2] | [-2 to +2] | [-2 to +2] |

**Rules:**
- Select the market leader as baseline (score = 0 on all criteria).
- Weight criteria by customer importance (from review analysis, feature prominence).
- Composite = sum of (score x weight) for each product.
- Negative composite = behind the market. Positive = ahead.

---

## Weighted Readiness Scorecard

Eight dimensions, each scored 1-5, weighted by importance to a paying customer.

| Dimension | Weight | What it measures | Score anchors |
|-|-|-|-|
| Feature Completeness | 20% | Are Must-Be features present? Performance features competitive? | 1=missing must-haves, 3=must-haves present, 5=must-haves + strong performance features |
| UI/UX Quality | 20% | Visual polish, interaction design, responsiveness, accessibility | 1=broken/ugly, 3=functional but generic, 5=polished and delightful |
| Code Quality & Stability | 15% | Error handling, type safety, test coverage, architecture | 1=crashes/breaks, 3=stable with gaps, 5=production-hardened |
| User Flow Quality | 10% | Critical paths work end-to-end without friction | 1=flows break, 3=flows work with friction, 5=flows are smooth and guided |
| Performance | 10% | Load times, responsiveness, resource usage | 1=unusably slow, 3=acceptable, 5=fast and optimized |
| Competitive Position | 10% | Pugh matrix composite — ahead or behind market | 1=far behind, 3=at parity, 5=clearly ahead |
| Unique Value Proposition | 10% | Clear differentiator that justifies choosing this over alternatives | 1=no differentiation, 3=minor differentiation, 5=compelling unique value |
| Market Fit | 5% | Evidence the product solves a real problem people will pay for | 1=unclear problem, 3=problem exists but solution unvalidated, 5=clear problem-solution fit |

**Default weights assume B2C SaaS.** Override rationale:
- B2B enterprise: increase Code Quality to 20%, decrease UI/UX to 15%
- Developer tools: increase Performance to 15%, increase Code Quality to 20%, decrease UI/UX to 10%
- Marketplace/platform: increase User Flow Quality to 15%, increase Market Fit to 10%

---

## Market Readiness Level Mapping

Composite score (weighted average of 8 dimensions on 1-5 scale) maps to verdict:

| Composite | MRL | Verdict | Meaning |
|-|-|-|-|
| 4.5 - 5.0 | 9 | SHIP IT | Exceptional. Exceeds market expectations. Competitive advantage is clear. |
| 4.0 - 4.4 | 8 | GO | Market-ready. Minor polish items remain but nothing blocks launch. |
| 3.5 - 3.9 | 7 | CONDITIONAL GO | Market-ready with known gaps. List the gaps and their risk. |
| 3.0 - 3.4 | 6 | NOT YET | Beta-quality. Missing features or quality gaps would cause churn. |
| 2.5 - 2.9 | 5 | MAJOR WORK | Alpha-quality. Significant gaps across multiple dimensions. |
| 2.0 - 2.4 | 4 | FAR FROM READY | Prototype. Core functionality incomplete. |
| 1.5 - 1.9 | 3 | PROOF OF CONCEPT | Early. Demonstrates idea but not viable as product. |
| 1.0 - 1.4 | 2 | EARLY DEV | Skeleton only. |

**Hard ceiling rules** (override composite score):
- Any dimension scoring 1 → maximum verdict is NOT YET regardless of composite.
- Missing 1+ Must-Be features → maximum verdict is NOT YET.
- Code quality score of 1 or 2 → maximum verdict is NOT YET (unstable product cannot be sold).
- UI/UX score of 1 → maximum verdict is MAJOR WORK (users won't pay for broken UI).
