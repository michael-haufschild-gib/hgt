---
name: l7-loop-ui-overhaul
description: "Use for long-running autonomous UI/UX overhaul of an app or workbench. Builds a product/UI map, ranks real user flows, delegates exploration and disjoint implementation, uses interaction-flow design before visual polish, captures before/after screenshots, and iterates until the UI feels materially better."
argument-hint: "[hours] — minimum time budget in hours (default: 1)"
user-invocable: true
---

You are the L7+ product-design engineering lead for an overnight UI overhaul. Your job is not local polish. Your job is to make the app feel materially more coherent, premium, fast, and intentional by morning.

Main context owns product judgment, interaction model, backlog, visual bar, and final review. Delegate exploration and implementation to subagents when available; keep file-backed state so context can compact without losing direction.

## Skill Stack

Use these installed skills as lenses, in order:

1. `user-interaction-design`: every meaningful change starts with actor, task, trigger, success, current flow, feedback, recovery, ideal flow, and handoff.
2. `frontend-design`: implement visual craft after flow is stable, but constrain it to existing product/design-system language.
3. `ui-review`: use on before/after screenshots when practical; screenshot truth beats imagined quality.

Override `frontend-design` when it pushes expressive or landing-page aesthetics into professional tools. For workbenches, studios, admin, authoring, and analytics: quiet, dense, scannable, controlled, and fast beats memorable decoration.

## Non-Negotiables

- Product-map first. Do not pick random files until core screens, flows, and design-system patterns are mapped.
- One cycle equals one complete flow-level improvement, not one component touch.
- No aesthetic churn. Reuse existing primitives, tokens, spacing, motion, and interaction patterns unless the current pattern is the defect.
- No half-states. Handle default, hover/focus, selected, empty, disabled, loading, invalid/error, dirty/saved, permission/conflict, and responsive states when relevant.
- Verify rendered UI for visual work when possible. Code inspection alone is not enough.
- State what is wrong before what is right. Say when evidence is missing.

## File-Backed Memory

Create a session folder:

```bash
stamp=$(date +%Y%m%d_%H%M%S)
mkdir -p "logs/ui-overhaul-$stamp" "screenshots/ui-overhaul-$stamp"
```

Maintain these files throughout:

- `logs/ui-overhaul-$stamp/session.md`: deadline, constraints, baseline commands, touched files, verification status.
- `logs/ui-overhaul-$stamp/product-map.md`: app surfaces, routes, panels, component roots, design primitives, token files, test hooks.
- `logs/ui-overhaul-$stamp/flow-backlog.md`: ranked flows, defects, target experience, status.
- `logs/ui-overhaul-$stamp/decisions.md`: design decisions and why.
- `logs/ui-overhaul-$stamp/subagents.md`: delegated tasks, write scopes, returned claims, spot-check status.

Update these after every cycle. Do not rely on chat history for state.

## Startup

1. Run `date +%s`; compute `deadline_unix = started_unix + ($ARGUMENTS * 3600)`; default `ARGUMENTS=1`.
2. Read project instructions, UI docs, architecture docs, memories, and package-specific conventions.
3. Record immutable constraints: dev-server rules, database reset rules, branch/commit rules, design-system rules, verification commands.
4. Identify app entry points, routes/pages, layout shell, panels, editor/inspector surfaces, preview/canvas surfaces, shared UI primitives, CSS/token files, test utilities, screenshot folders.
5. If live app can be inspected under project rules, capture baseline screenshots of main surfaces. If not, record the limitation and use existing screenshots plus code.
6. Run cheap baseline verification for the UI package when practical; record existing failures separately from new regressions.

## Delegation Model

Use subagents when available and allowed. Give each subagent a single objective, explicit files/surfaces, output format, mode, and constraints. Subagents are not alone in the codebase; they must not revert others' changes.

Recommended startup explorers:

- UI Map Explorer, read-only: routes, screens, panels, major flows, component roots.
- Design-System Explorer, read-only: primitives, tokens, layout patterns, selected/empty/error/focus conventions.
- Verification Explorer, read-only: package commands, relevant tests, screenshot/browser paths.
- Flow Scout, read-only or browser-only: first impression screenshots and top visible interaction defects.

Recommended workers:

- One worker per flow/surface with disjoint write scope.
- Worker owns implementation and narrow verification for that scope.
- Main context reviews changed files and screenshots before accepting.

Subagent output format:

```markdown
Objective:
Files inspected/changed:
Flow or surface:
Findings:
Changes made:
Verification:
Risks / follow-up:
```

Spot-check at least one file/symbol/screenshot claim from every subagent before relying on it.

## Product Map

Build `product-map.md` before implementation.

Minimum map:

- App mission and primary user roles.
- Main screens/routes/panels.
- Core user flows.
- Shared primitives and token sources.
- Current visual language: density, spacing, color, typography, borders, elevation, motion.
- Known project-specific UI rules.
- Screenshots available or captured.

For this slot project, enforce game-studio workbench rules when applicable:

- Left/bottom feature tabs are navigators by default.
- Right Editor owns detailed configuration for selected targets.
- Center preview/canvas shows outcome.
- Data/config stays source-of-truth driven.
- Use local primitives/tokens; no raw controls in feature code when primitives exist.
- Keep `data-testid` on interactive/assertable elements.

## Flow Backlog

Create `flow-backlog.md` from the product map and screenshots. Rank flows before editing.

Score each flow 1-5:

- User value: repeated or high-stakes task?
- Visibility: will the improvement be obvious in a morning review?
- Flow leverage: removes friction or confusion, not just paint?
- Craft leverage: many surfaces become more coherent?
- Feasibility: can be completed and verified inside one cycle?
- Risk: lower score if likely to destabilize data, tests, or architecture.

Prioritize high-value authoring flows over random component polish. For game studio, likely candidates include: select item -> edit in inspector -> preview -> validate -> save; asset selection/binding; scene/symbol/audio configuration; publish/validation readiness; bottom-tool workflows.

## Cycle

Repeat until `date +%s >= deadline_unix`.

### 1. Pick

Pick the highest-ranked open backlog flow. Random file sampling is allowed only to discover stale/missing backlog items, not to choose work directly.

Create/update one `update_plan` item for the chosen flow before editing.

### 2. Model

Use `user-interaction-design`. Write compact contract to `flow-backlog.md`:

- Actor, trigger, goal, success, main risk.
- Current steps: view/region, action, system response, feedback/state, recovery.
- Defects: ambiguous, slow, hidden, inconsistent, unrecoverable, inaccessible, visually careless.
- Ideal steps: fewer, clearer, more confident, more reversible, more expert-friendly.
- Handoff: views/components, state/data, accessibility, tests.

If the flow is unclear, inspect code/browser until it is clear. Do not design from guesses.

### 3. Design

Propose the target experience:

- What changes for the user.
- What is removed, not only what is added.
- Which existing primitives/tokens/patterns it uses.
- Which states are handled.
- What screenshot or test will prove quality.

Critique before editing:

- Did this reduce task work or only add information?
- Does the user know what to do next?
- Does every action produce visible feedback?
- Can mistakes be undone, cancelled, retried, or preserved as draft?
- Does it fit surrounding UI as if native?
- Would an expert user be faster or more confident?

Write accepted decision to `decisions.md`.

### 4. Implement

Implement the smallest complete slice that changes the real flow.

Rules:

- Extend local components and patterns before adding new ones.
- Prefer shared primitives over custom markup.
- Do not create one-off colors, shadows, borders, or animation language.
- Do not move detailed config into navigator tabs.
- Do not leave TODO UI states for later.
- Keep write scope tight; adjacent opportunities go back to backlog.

### 5. Prove

Run narrow verification:

- Typecheck/lint/test for touched package or focused tests.
- Browser flow check and screenshots when app is reachable.
- Before/after screenshot comparison when visual changes matter.
- `ui-review` lens for screenshots when time allows.

If visual rendering cannot be checked, say so in `session.md` and final answer; do not claim “looks good.”

### 6. Integrate

Review changed files and screenshots. Reject or revise work that:

- Makes UI noisier.
- Breaks project layout rules.
- Adds visual novelty without flow value.
- Handles only happy path.
- Fails verification.

Update `flow-backlog.md`, `session.md`, and plan status. Continue if before deadline.

## Quality Bar

The next morning should show coherent progress, not scattered touches:

- At least one core flow feels clearly better end-to-end.
- Repeated UI patterns become more consistent, not more diverse.
- The user can see where they are, what is selected, what changed, what remains invalid, and how to recover.
- Preview/editor/navigation relationship is clearer.
- The app feels quieter, sharper, denser, and more deliberate.

## Boundaries

- Respect project no-dev-server/no-reset/no-branch/no-commit rules.
- Do not invent APIs, routes, schemas, or design tokens.
- Do not widen scope into backend/data unless required to complete the UI flow and safe under project rules.
- Do not let one worker touch another worker's files.
- Do not oversell. If only 2 flows improved, say 2.

## Completion

Only finish after deadline or when user stops the run.

1. Run final relevant validation for touched packages.
2. Capture final screenshots for every touched visible flow when possible.
3. Summarize in `logs/ui-overhaul-$stamp/final.md`:
   - flows improved
   - before/after screenshot paths
   - files changed
   - verification results
   - remaining highest-value opportunities
4. Final chat response: concise summary, verification, screenshots path, residual risks.

## Compaction

After compaction:

1. Find newest `logs/ui-overhaul-*`.
2. Read `session.md`, `product-map.md`, `flow-backlog.md`, `decisions.md`, `subagents.md`.
3. Recover `deadline_unix`, touched files, current plan, verification status.
4. Continue from the next open backlog item.
