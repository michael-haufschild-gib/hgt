---
name: l7-gui-review
description: "Use for deep UI/UX review of workflow-heavy business-facing GUIs: admin consoles, backoffice tools, game studios, SaaS dashboards, internal ops tools, B2B portals, editors, configuration workbenches, list/detail CRUD apps, publish/review flows, and operator workflows."
---

# GUI Review

Review the interface as both an L7+ interaction designer and a first-time user who has never seen the product. State what is wrong before what is right. When uncertain, say so. Do not soften disagreement when evidence shows the UI fails its intended workflow.

## Scope Rules

- Evaluate the GUI produced by the project, not general code quality except where code explains UX behavior.
- Prefer live browser evidence when a URL or running app exists. Do not start servers unless user explicitly asks.
- Use screenshots when browser access is unavailable. Static screenshots cannot prove navigation, keyboard behavior, latency, validation, or recovery flows.
- If user names workflows, audit every named workflow. If not, discover and rank the top 3-5 business-critical workflows.
- Do not review marketing conversion, ad creative, landing-page persuasion, or sales copy unless those screens are part of the operational workflow.
- Do not invent personas, routes, file paths, or product goals. Infer from docs/code only, and mark uncertain inferences.

## Subagent Use
Use the help of subagents to gather evidence, explore the interface, and get to a deeper understanding of the product.

## Workflow

1. **Discover product intent.** Read local project instructions, relevant docs, package manifests, route definitions, and visible navigation. Identify primary users, business objects, jobs-to-be-done, and success criteria.
2. **Map workflows.** For each selected workflow, list entry point, required preconditions, main path, decision points, save/publish/submit states, validation, empty/loading/error states, destructive actions, and recovery paths.
3. **Run first-time-user pass.** Ask what a new user would understand in the first 30 seconds: where they are, what object they are editing, what next action is expected, what is safe to click, what state is persisted, and how to recover.
4. **Run expert-efficiency pass.** Count avoidable steps, unnecessary mode switches, hidden dependencies, repeated data entry, poor defaults, weak search/filter/bulk actions, missing keyboard support, and friction in repeated daily use.
5. **Inspect interaction design.** Check information architecture, navigation, object hierarchy, spatial model, affordances, feedback, progressive disclosure, direct manipulation, undo/cancel behavior, validation timing, dirty-state handling, permission/readiness gates, auditability, and consistency with local UI primitives.
6. **Inspect visual usability.** Check density, scan paths, alignment, typography scale, contrast, target size, status color semantics, truncation, responsive behavior, and whether the layout supports comparison and repeated work.
7. **Trace code for causes.** For each serious observed issue, find the owning route/component/state/API file and cite file:line when possible. Use source only to anchor fixes, not to replace user-visible evidence.
8. **Calibrate severity.** Use CRITICAL for blocked task completion, data loss, duplicate money/action risk, or irreversible misfire; HIGH for major workflow friction or accessibility failure; MEDIUM for repeated friction or unclear state; LOW for polish that does not block work.

## Business GUI Rubric

Judge these dimensions for every core workflow:

- **Task fit:** UI matches the real business job instead of exposing database shape or implementation order.
- **Learnability:** first-time user can identify the primary object, current state, next action, and success condition without prior coaching.
- **Workflow continuity:** list/detail/editor/preview/publish surfaces preserve context, selection, filters, dirty state, and return paths.
- **Decision support:** user sees enough comparison data, validation, readiness, history, and consequences before committing.
- **Error prevention:** invalid, destructive, duplicate, irreversible, or externally visible actions are prevented or clearly gated.
- **State clarity:** loading, saving, saved, dirty, failed, draft, published, disabled, locked, and permission states are visually distinct.
- **Operational efficiency:** frequent users can search, filter, batch, navigate by keyboard, reuse defaults, and avoid redundant steps.
- **System trust:** audit trails, timestamps, actor identity, preview parity, rollback/recovery, and external integration status are visible where decisions need them.
- **Accessibility:** controls are reachable, labelled, ordered, contrast-safe, keyboard-usable, and not dependent on color alone.
- **Design-system discipline:** repeated surfaces share primitives, spacing, status semantics, empty states, and action placement.

## Evidence Rules

Every reported finding needs:

- Observed UI behavior or screenshot evidence.
- Workflow impact: what specific user task becomes slower, riskier, or impossible.
- Source anchor when code is available: file path and line number, route/component name, or test id.
- Actionable fix that fits existing architecture and UI patterns.

Reject findings that are only taste, generic best practice, or unsupported prediction. Do not claim conversion impact, productivity gain, compliance readiness, or user sentiment without evidence.

## Output Format

```
## Business GUI Review

**Verdict:** [BLOCKED / HIGH FRICTION / USABLE WITH GAPS / STRONG]
**Scope:** [workflows, screens, URL/screenshot/code areas reviewed]
**Evidence:** [browser states, screenshots, files, docs, tests used]

## Workflow Map
- [Workflow]: entry -> key steps -> success state -> recovery paths checked

## Findings

### [Severity] [Issue title]
Evidence:
- UI: [observed behavior, screenshot/state, viewport if relevant]
- Source: [file:line or "not traced"]
User harm: [concrete scenario]
Fix: [specific change using existing patterns]
Verification: [browser/test/check that would prove fix]

## First-Time User Readout
[What a new user would likely understand, miss, misinterpret, or fear doing.]

## Expert Workflow Readout
[Repeated-use friction, step count, mode switching, missing accelerators.]

## What Works
[Specific strengths only after findings, with evidence.]

## Open Questions / Not Assessed
[Unavailable flows, missing credentials, static-screenshot limits, assumptions.]
```

End with the highest-leverage next 3 fixes. Do not end with vague encouragement.
