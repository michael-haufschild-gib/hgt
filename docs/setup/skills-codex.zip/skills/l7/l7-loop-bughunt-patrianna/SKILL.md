---
name: l7-loop-bughunt-patrianna
description: "Use for read-only randomized bug hunt: trace random source files to features, find correctness defects, validate each finding, log bug reports. No code edits."
argument-hint: "[hours] — minimum time budget in hours (default: 1)"
model: opus
user-invocable: true
---

Deep bug-hunting investigation, one random feature at a time. Each cycle is a thorough search for defects — not a quick scan. Quality of investigation matters; cycle count does not.

This is a **read-only** variant: do not modify any source file. Instead, log every validated bug to the audit log.

Scope is **bugs and correctness only**. Do not pursue architectural improvements, refactors, or design changes.

**Minimum time budget: $ARGUMENTS hours (default: 1 if no argument given).**

## Startup

1. Run `date +%s`. Compute `deadline_unix = started_unix + ($ARGUMENTS * 3600)` (default 1 hour). Write `logs/audit_bug_$(date +%Y%m%d_%H%M%S).md` with `started_unix`, `deadline_unix`, human-readable times, `cycles_completed: 0`. Store this path as the **audit log**. This file is also the bug report deliverable — append every validated bug to it.
2. Begin the work loop.

## The Work Loop

### Step 1: Pick A Random File

```bash
files=($(find . -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.css" -o -name "*.scss" -o -name "*.py" -o -name "*.rs" -o -name "*.cpp" -o -name "*.h" -o -name "*.swift" -o -name "*.java" \) ! -path "*/node_modules/*" ! -path "*/.git/*" ! -path "*/dist/*" ! -path "*/build/*" ! -path "*/__pycache__/*" ! -path "*/vendor/*" ! -path "*/.next/*")); echo "${files[$RANDOM % ${#files[@]}]}"
```

Record `date +%s` as `cycle_start`. If the file is trivially small (under 5 lines, auto-generated, or a barrel export), re-roll.

### Step 2: Go Deep

Read the file. Trace its imports — read those files. Trace its exports — find every caller, read those files. Identify the feature or subsystem this file belongs to. Read every file in that feature: siblings, shared types, tests, styles, utilities, configuration.

Do not skim. Read the implementations, not just the signatures.

### Step 3: Understand Before Hunting

Before looking for bugs, think about the big picture and build a mental model of this feature:

- What does this feature actually do? Trace one complete user action through all layers.
- What data flows through it? Where does state live? Who mutates it?
- What are the boundary conditions? What inputs are assumed valid but never checked?
- What happens on failure — network error, null input, concurrent access, partial state?
- Where does this code trust its callers, and is that trust warranted?

You cannot skip this step. If you cannot answer these questions, you haven't read deeply enough — go back and read more code.

### Step 4: Hunt Bugs

Now hunt for defects with your full understanding of the feature. Look for:
- Logic errors, off-by-one mistakes, incorrect boolean logic
- Unhandled edge cases, missing null/undefined checks
- Race conditions, concurrency issues, TOCTOU
- Incorrect error handling — swallowed errors, wrong error types, missing cleanup
- Security vulnerabilities — injection, XSS, auth bypass, data leaks
- State corruption — stale closures, missing resets, shared mutable state
- Broken or misleading tests that pass when the feature is broken
- Data loss paths — failed writes without rollback, partial updates

Do **not** report: architectural improvements, refactors, missing abstractions, code style, performance optimizations, or documentation gaps. Bugs only.

**Depth gate:** If you are about to declare 0 bugs in a feature with more than a few files, stop. Challenge that conclusion. Trace one more error path, check one more boundary condition, verify one more assumption. If you genuinely find nothing after deep analysis, state specifically what code paths you traced and why each is correct.

For each candidate bug, draft a finding internally. Do not append to the audit log yet — Step 5 validates first.

### Step 5: Validate, Then Log

For every candidate bug from Step 4, run a fresh validation round before logging.

1. **Re-read the relevant code with fresh eyes.** Do not rely on notes — re-open the file(s) at the exact lines you flagged.
2. **Disprove yourself.** Argue the *opposite*: assume the code is correct and explain why. Look for a caller that pre-validates the input, a type/runtime guarantee elsewhere, a wrapping try/catch, a passing test that covers the scenario, or language semantics you may have gotten wrong.
3. **Construct a concrete trigger.** Write out specific inputs or a sequence of events that reach the defective code path. If you cannot describe a concrete trigger, the bug is not validated — drop it.

If the bug survives validation, append an entry to the audit log:

```markdown
## Bug <N>: <short title>

- **File:** `<path>:<line>` (and other locations as needed)
- **Description:** <what is wrong, the exact mechanism>
- **Likely impact:** <what goes wrong from a user/system perspective, who is affected, how often>
- **How to surface it:**
  - *Automated test:* <framework, where it would live, exact inputs, expected vs actual>
  - *Manual repro:* <numbered steps with concrete values; final observable defect>
- **Validation:** <what you re-read and what counter-argument you considered and rejected>
```

If the bug fails validation, drop it. Do not implement any fix — this skill does not modify source code.

### Step 6: Log and Loop

Record `date +%s` as `cycle_end`. Compute `cycle_duration = cycle_end - cycle_start`.

**Minimum cycle time: 15 minutes.** If `cycle_duration < 900`, you went too shallow. Go back to Step 2 and trace one more error path you skipped, check one more boundary condition, read one more caller you glossed over. Do not proceed to the next cycle until 15 minutes have passed on this one.

Update the audit log: increment `cycles_completed`, append which file was picked, which feature it belonged to, cycle duration, bugs logged this cycle.

Run `date +%s`. If current time < `deadline_unix`, go back to Step 1. Otherwise proceed to Completion.

## Completion

1. **Time gate (mandatory).** Run `date +%s`. If the current time is before `deadline_unix`, STOP — you are not done. Return to the work loop step 1. Do not proceed to step 2.
2. Report: cycles completed, features reviewed, bugs logged, and the path to the audit log.

**Do not delete the audit log.** It is the deliverable.

## Compaction Protocol

After context compaction:
1. Glob for `logs/audit_bug_*.md`. Read the most recent match — re-internalize the deadline and progress.
2. Resume the work loop from Step 1.
