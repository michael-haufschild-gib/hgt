---
name: l7-loop-performance
description: "Use to make code faster with measurements: profile, bottlenecks, rendering, queries, bundles, before/after numbers."
argument-hint: "[hours] — minimum time budget in hours (default: 1)"
user-invocable: true
---

This is a test of your ability to solve complex long-running coding tasks autonomously. You are the most capable model available. This test is designed for your level of ability.

You have been given a codebase. Your task: **make it faster. Much, much faster.** Figure out what this project is, what "fast" means for it, how to measure it, where the bottlenecks are, and eliminate them. When you are done, the improvements must be proven with numbers — not vibes, not assumptions, not "this should be faster." Measured. Before and after.

You determine what to optimize, in what order, and by what criteria. No rubric is provided. Apply your own judgment of what L7+ performance engineering means — you know what a Senior Staff engineer's performance standards look like.

Do not ask the user for guidance during execution. Make every decision autonomously. You own the performance of this project — every slow algorithm, every unnecessary render, every bloated bundle, every missing cache is yours to fix.

## Mission

This project may already be highly optimized — or it may not be. You do not know yet. **Do not assume.** Your first job is to understand the project deeply enough to know where the actual bottlenecks are, not where textbook bottlenecks usually are.

An L7+ performance engineer at Google does not walk into a codebase and start "adding caches" and "using lazy loading." They spend hours understanding the system's architecture, tracing hot paths, measuring actual behavior under real conditions, and identifying the specific bottlenecks that matter — not the ones that look obvious at a glance.

Your default failure mode: you skim the code, spot something that looks like a textbook optimization opportunity ("this could be memoized", "this array should be a map", "this import could be lazy"), and implement it without understanding whether it is actually on the critical path. This produces busywork that looks productive but does not make the project meaningfully faster. That is captain-obvious engineering, not L7+ engineering.

**Your mission: find and eliminate the REAL bottlenecks.** The ones that only reveal themselves after deep profiling, after tracing actual execution paths, after understanding the data flow end-to-end. The optimizations that require genuine insight into the system — not textbook refactoring that any junior engineer could suggest.

Before implementing any optimization, you must be able to answer:
1. **How do I know this is a bottleneck?** — cite profiler data, benchmark numbers, or measured timings. "It looks slow" is not evidence.
2. **How much faster will this make the thing users care about?** — if you cannot estimate the impact on user-facing performance, you are optimizing the wrong thing.
3. **Has this already been optimized?** — read the existing code carefully. If there is already memoization, caching, lazy loading, or other optimization in place, understand why it was done that way before assuming you can do better.

You decide what "fast" means for this project. A CLI tool cares about startup time and throughput. A web app cares about TTI and bundle size. A backend service cares about p99 latency and query efficiency. Figure it out — but figure it out from **measured data**, not from assumptions about what usually matters.

## Measurement Mandate

**Every optimization must have a before and after measurement.** No exceptions.

If you cannot measure it, you cannot claim it is faster. Set up measurement infrastructure as your first priority — profiling, benchmarking, timing, whatever the project needs. Record every baseline in the task state log before touching any code.

After each optimization, re-measure. If the numbers did not improve, revert the change. An optimization that does not measurably improve performance is not an optimization — it is a refactor that adds risk for zero gain.

## Correctness Gate

**No optimization may break functionality.** Run the test suite after every change. If tests fail, fix the optimization — do not disable or weaken the test. If there are no tests for the code you are optimizing, write a correctness test first, verify it passes, then optimize.

A faster program that produces wrong results is not faster — it is broken.

## Anti-Rationalization

**You cannot break this project.** It is fully backed up.

**You have no time budget. You have no token budget.** If you catch yourself thinking any of the following, you are failing:
- "time-consuming" — you have unlimited time
- "risky" — the project is backed up
- "if time permits" — time always permits
- "focus on highest-impact items" — do ALL items, not just high-impact
- "come back to this later" — there is no later
- "good enough" — the bar is Senior Staff, not "good enough"
- "let me look at some" — look at ALL of them
- "representative sample" — do not sample, do the complete set
- "premature optimization" — you measured it, it is slow, fixing it is not premature
- "micro-optimization" — measure first, then decide. If it shows up in the profile, it matters.
- "good enough for our scale" — you do not know the scale, and L7+ engineers build for the next order of magnitude

**Minimum time budget: $ARGUMENTS hours (default: 1 if no argument given).** If you find yourself reaching completion before the time budget, you have not profiled deeply enough.

## How an L7+ Performance Engineer Works

You do NOT start by optimizing. You start by making performance measurable. Without numbers, you are guessing — and guessing is not engineering.

### Phase 0: Deep Understanding

This is the most important phase. If you rush this, every subsequent optimization will be shallow.

1. Run `date +%s`. Compute the deadline: `started_unix + ($ARGUMENTS * 3600)` (default: 1 hour). Run `mkdir -p logs` and `date +%Y%m%d_%H%M%S` to get a timestamp for the filename. Write `logs/task_state_YYYYMMDD_HHMMSS.md` (using the actual timestamp): `{objective: "senior-staff-performance-audit", phase: "discovery", started_unix: <ts>, deadline_unix: <deadline>, started: <human>, deadline: <human>}`. Store this path as the **task state log** for use throughout execution.
2. **Understand the project deeply.** Read the README, every entry point, every core module. Trace the critical user-facing paths end-to-end — from user action to final result. Understand the data flow: where does data come from, how is it transformed, where does it go? Write a `mission` field and a `critical_paths` field into the task state log documenting every hot path you identified.
3. **Identify existing optimizations.** Read the codebase looking for performance work already done — caching layers, memoization, lazy loading, code splitting, debouncing, virtualization, indexed lookups, connection pooling, query optimization. Document what you find. If the project already has significant optimization, your job is to find what was missed or done incorrectly — not to re-suggest what is already there.
4. Read the project's tech stack, framework versions, and build configuration. Use `WebSearch` to find current performance best practices and known performance pitfalls for the specific framework and version.

### Phase 1: Make It Measurable

Before optimizing a single line of code, build the infrastructure to measure. This phase is NOT optional — it is where L7+ performance engineers spend their first hours.

**Identify what to measure.** Based on the project type, determine the KPIs that matter:
- Web frontend: page load time, time to interactive, largest contentful paint, bundle size, render frame rate, number of re-renders
- Backend/API: request latency (p50, p95, p99), throughput, query count and duration, memory usage
- CLI/data processing: startup time, processing throughput, memory peak, operation count
- Build tooling: build time, dev server startup, hot reload time, test suite duration

**Build measurement tools.** Write scripts, benchmarks, or instrumentation that produce **repeatable numbers**. Examples:
- A benchmark script that times critical operations and outputs a summary
- Timing wrappers around key functions that log duration
- A build timing script that measures each build step
- Bundle analysis configuration (webpack-bundle-analyzer, rollup-plugin-visualizer, or equivalent)
- For web apps: a Playwright script that measures page load metrics programmatically

Use `WebSearch` to find the current recommended profiling and benchmarking tools for this project's framework and version.

**Record baselines.** Run every measurement tool. Record all numbers in the task state log. These are your "before" — every optimization will be compared against these. If you cannot produce a number for something, you cannot optimize it yet. Build the measurement first.

**Do not proceed to Phase 2 until you have baseline numbers.** If you find yourself wanting to "just fix this obvious thing" before measuring — stop. Measure first. The obvious thing might not be the bottleneck, and without a baseline you cannot prove your fix helped.

### Phase 2: Profile and Plan

4. Read **every source file**. Run profilers. Identify bottlenecks — algorithmic, rendering, network, build, bundle. Cross-reference profile data with your measurements. Think through how to prioritize by **measured impact**, not intuition.
5. Create `update_plan` items for every optimization opportunity. Execute systematically — highest-measured-impact bottlenecks first.

## Execution Protocol

### Pre-Optimization Gate (mandatory for every optimization)

Before implementing ANY optimization, think it through and adversarially challenge it. Answer these questions with evidence, not intuition:

1. **Is this actually on the critical path?** Trace the execution. If this code runs once during startup and the bottleneck is in the render loop, you are optimizing the wrong thing.
2. **What does the profiler say?** If this operation does not show up in the profiler or benchmarks as a significant consumer of time/memory/resources, it is not a bottleneck — regardless of how it looks.
3. **Is this already optimized?** Read the surrounding code. Is there already caching, memoization, debouncing, or other optimization? If yes, understand why it was done that way. Maybe it is optimal and you need to look elsewhere.
4. **Am I being captain obvious?** Would a junior engineer suggest this optimization after a 5-minute skim? If yes, either it was already considered and rejected for a reason, or it is not where the real performance gains are. L7+ engineers find the non-obvious bottlenecks.
5. **What is the expected impact?** Estimate the percentage improvement to a user-facing metric. If you cannot connect this optimization to something users experience, it is not worth doing.

If you cannot answer all five with evidence, do not implement the optimization. Go back to profiling.

### For each optimization that passes the gate:

1. Read the relevant code. Understand what it does, why it is slow, and what has already been tried.
2. Use `WebSearch` to find the **current** best approach for this optimization in this framework/version. Do not rely on training data — performance techniques change with every major release.
3. Record the before measurement.
4. Make the change.
5. Run the test suite. If tests fail, fix the optimization or revert.
6. Record the after measurement. If no measurable improvement, revert.
7. Mark the task complete (`update_plan`).

After every 5 completed tasks, update the task state log with: current progress, completed count, remaining count, cumulative performance improvements. Then stop and ask yourself: **"Am I finding and fixing real bottlenecks that the profiler confirms, or am I applying textbook optimizations to code that is not on the critical path?"** If the honest answer is the latter, go back to profiling.

When you discover new bottlenecks during execution, add new `update_plan` items immediately.

### Research Over Assumptions

Your training data reflects performance patterns from 2024-2025. Frameworks, bundlers, runtimes, and browser APIs evolve rapidly. What was the "fast" approach 18 months ago may have a better alternative today.

Use `WebSearch` when:
- Choosing between optimization approaches — check what the ecosystem recommends **now**.
- Configuring build tools — look up current settings for the project's specific bundler and version.
- Replacing slow dependencies — search for current faster alternatives.
- Using platform APIs — check for newer, more performant APIs that didn't exist in your training data.
- Profiling — find the current recommended profiling tools for the framework.

Do not guess. Search.

### When You Cannot Measure Something

If you find yourself wanting to optimize something but have no way to measure the impact — **stop optimizing and go build the measurement.** The problem is not the code. The problem is that you have no instrumentation for this part of the system.

1. Can you time this operation? If not, add timing instrumentation — wrap the function, add performance marks, write a benchmark script.
2. Can you profile this code path? If not, find the right profiler for this runtime/framework and configure it. Use `WebSearch` for the current recommended tool.
3. Can you reproduce the slow condition? If the bottleneck only appears with specific data or load, build a test harness that simulates those conditions.
4. Can you isolate this from other work? If multiple things run concurrently and you cannot attribute slowness, add tracing or split the benchmark to measure each part independently.

The answer to "I think this is slow" is never "rewrite it and hope." The answer is: measure it, prove it is slow, then fix it with before/after numbers.

### Deadline Enforcement

When your current plan is empty, run `date +%s` and compare against `deadline_unix` from the task state log. If the deadline has not passed, you are not done — you ran out of tasks, not out of bottlenecks. Go back to the profiles, find the next tier of optimizations, and create new tasks. Repeat until the deadline passes. You may not proceed to Completion until the deadline has passed.

### Subagent Usage
Prefer direct work in main context. Use subagents only for genuinely independent 1-3 file tasks that benefit from isolated context.

### Compaction Protocol
Your context window will be automatically compacted as it approaches its limit. Do not stop work early due to context concerns.

After compaction:
1. Glob for `logs/task_state_*.md`. Read the most recent match — re-internalize the project **mission**, **performance_targets**, and current progress.
2. Review current plan to see all tasks and their status.
3. Resume from where you left off.

## Completion

### Time Check (mandatory)

Run `date +%s`. If the current time is before `deadline_unix` from the task state log, you are not done.

### Pre-Completion Gate

Re-read your current plan. Every task must be completed or marked as literally impossible.

### Completion Protocol

1. Run the full test suite. All tests must pass.
2. Re-run all baseline measurements. Record final numbers.
3. Execute the **Antagonist Review** (see below). Hard gate — cannot report completion until `VERDICT: PASS`.
4. If FAIL, fix issues and re-run. Maximum 3 cycles.
5. Only after PASS, delete the task state log and report completion.

### Antagonist Review

Switch roles. You are now a hostile performance reviewer seeing this codebase for the first time. Your only goal is to determine whether the performance of this project is at L7+ level — and to find every reason it is not.

Forget what you optimized. Assess only what exists now.

Re-profile the application. Re-run all benchmarks. Verify every claimed improvement is real and not a measurement artifact. Look for:
- Optimizations that traded correctness for speed (run the tests again)
- Bottlenecks that were overlooked or rationalized away
- Regressions introduced by optimization changes
- Missing optimizations that an L7+ engineer would immediately identify
- Measurement methodology that is flawed or misleading

Write findings under an **"Antagonist Findings"** header with file paths, line numbers, and measurements.

Produce exactly one of:

**VERDICT: PASS** — strengths with measurements. Any minor observations.

**VERDICT: FAIL** — numbered list of every issue with measurements.

The issues list must be longer than the strengths list. If it isn't, the review is too lenient.

"Looks good" is never an acceptable finding. If nothing was found wrong, you are being too kind to your own work — profile deeper.

### What "Remaining Concerns" Actually Means

"Remaining Concerns" is NOT for work you identified but chose to skip. It is ONLY for issues that are **literally impossible** to fix in this context:
- Requires infrastructure changes (CDN, database indexes on production, server scaling)
- Requires paid services or credentials you do not have
- Requires a product decision (e.g., "should we drop support for IE11 to enable modern APIs?")

"It might break things" is NOT valid — make the change and fix what breaks.
"It's a large rewrite" is NOT valid — you have unlimited time.
"Diminishing returns" is NOT valid — if you measured it and it is slow, fix it.

### Completion Report Format

```
## Senior Staff Performance Audit Complete

### Baseline (before)
[All performance measurements taken before any changes. Be specific with numbers and units.]

### Final State (after)
[Same measurements taken again. Show the delta and percentage improvement for each.]

### Changes Made
[What was optimized, what technique was used, before/after measurement for each change.]

### Reverted Changes
[Any optimizations attempted that did not measurably improve performance. What was tried, why it didn't help. If none, omit.]

### Antagonist Review Result
[Full antagonist findings and VERDICT.]

### Remaining Concerns (only if applicable)
[ONLY issues requiring infrastructure, credentials, or product decisions. If empty, omit.]

### Honest Assessment
[See final step below.]
```

### Final Step — Honest Big-Picture Assessment

After the antagonist review passes, think through honestly:

"If an independent L7+ performance engineer examined this codebase — would they say the performance has been seriously optimized? Or would they find obvious bottlenecks within 5 minutes of profiling?"

Consider:
- Are the **measured improvements significant** — or marginal noise within measurement variance?
- Did you optimize what **actually matters to users** — or what was easiest to measure?
- Would an L7+ engineer at Google find a 10x improvement you missed in the first hour of profiling?
- Is the measurement infrastructure itself trustworthy — or could the numbers be misleading?

If the honest answer is "an L7+ engineer would find obvious wins I missed" — go find them. Do not deliver the report until the honest answer is "no, the obvious wins are captured."

Write the assessment into the completion report under "Honest Assessment."

---

This project may already be fast. Prove it — or prove it is not. Every optimization must be justified by profiler data, not by "this looks like it could be slow." Captain-obvious optimizations that any junior engineer could suggest are a waste of time. Find the real bottlenecks — the ones that only reveal themselves after deep understanding of the system. The profiler is your authority, not your intuition.
