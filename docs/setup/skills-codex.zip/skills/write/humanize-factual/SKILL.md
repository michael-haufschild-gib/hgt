---
name: humanize-factual
description: >-
  Use when transforming AI-written factual English text such as news, reports, analysis, technical guides, professional articles, or factual explainers into natural, credible human prose while preserving all facts, attributions, numbers, and cause-effect relationships.
metadata:
  short-description: Factual text humanizer
---

# Factual Text Humanizer

## Mission

Rewrite AI-sounding factual text into natural professional prose without changing meaning. This skill humanizes style, rhythm, and structure. It does not add facts.

## Workflow

1. Identify text type, audience, formality level, and domain.
2. Detect AI patterns: formalistic verbs, generic transitions, uniform sentence length, contrast templates, rule-of-three lists, overbalanced phrasing, abstract verdicts, and unsupported certainty.
3. Define a professional editorial stance appropriate to the text: reporter, analyst, technical writer, policy expert, or domain specialist.
4. Rewrite for natural rhythm while preserving every fact, number, name, date, quote, attribution, and causal relationship.
5. Verify no new examples, sources, statistics, locations, claims, or implications were added.

## Preserve

- Numbers, dates, names, titles, organizations, quotes, attributions.
- Legal, technical, scientific, and financial meaning.
- Causal logic and uncertainty.
- Core order of ideas unless reordering improves readability without changing argument.

## Rewrite Rules

- Replace corporate/formal filler with direct verbs.
- Remove "however", "furthermore", "therefore", "it is important to note", and similar lecture markers where possible.
- Avoid "not X but Y", "many people think X", and symmetrical pro/con templates.
- Vary sentence length naturally. Do not make factual prose artificially chaotic.
- Keep a credible professional voice. No personal anecdotes unless the source text already contains them.
- Attribute evidence with context when present.

## Output

If the user asks only for a rewrite, output only:

```markdown
Text humanized successfully.

---

[rewritten text]
```

If user asks for explanation, include a concise note listing major pattern changes.

## Final Check

- No facts changed.
- No facts added.
- No attribution weakened.
- Text reads like professional human prose rather than marketing copy.
