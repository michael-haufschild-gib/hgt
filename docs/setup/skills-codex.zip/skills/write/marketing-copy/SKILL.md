---
name: marketing-copy
description: >-
  Use when writing conversion-focused marketing copy: landing pages, email campaigns, product descriptions, ads, sales letters, CTAs, launch copy, or persuasion-framework drafts. Produces truthful, brand-specific, high-converting copy using AIDA, PAS, BAB, or FAB, ethical persuasion, specific benefits, and human-sounding phrasing.
metadata:
  short-description: Marketing copy
---

# Marketing Copy

## Workflow

1. Identify content type, audience, awareness stage, conversion goal, offer, brand voice, benefits, and proof.
2. Ask only for missing information that blocks accuracy or conversion intent. If safe, state realistic assumptions and proceed.
3. Select one primary framework:
   - AIDA: ads, landing pages, email campaigns.
   - PAS: sales letters, VSLs, problem-aware audiences.
   - BAB: transformation stories, testimonials, case studies.
   - FAB: product descriptions and B2B collateral.
4. Draft benefits-first copy with one clear primary CTA.
5. Add ethical persuasion: customer-focused "you" framing, cause-effect reasoning, specific proof, and one suitable Cialdini principle.
6. Verify unstable facts such as prices, availability, product specs, statistics, claims, and current offers before using them.

## Style Rules

- Use brand-specific phrasing instead of generic corporate language.
- Prefer concrete outcomes: "save 3 hours per week" beats "improve productivity".
- Repeat the core value phrase 2-3 times across headline, body, and CTA.
- Use natural sentence rhythm: short punch, longer explanation, short close.
- Use hyphen or en dash style only if already suitable for the requested voice; avoid em dash-heavy AI rhythm.
- Avoid "not only X but also Y", "this is not just X", "in today's fast-paced world", "transform your X", and fake urgency.
- Do not fabricate ROI, testimonials, awards, case studies, user counts, scarcity, or guarantees.

## Output

Return the finished copy in the user's requested format. If no format is given, include:

```markdown
## Copy
[final copy]

## Notes
- Framework: [AIDA/PAS/BAB/FAB]
- Audience: [audience + awareness stage]
- Primary CTA: [CTA]
- Assumptions: [only if any]
```

## Final Check

- Formula is visible and coherent.
- CTA is specific and action-oriented.
- Claims are substantiated or clearly framed as assumptions.
- Reading level fits audience: B2C simpler, B2B more analytical.
- No Claude-only command mechanics or legacy tool requirements.
