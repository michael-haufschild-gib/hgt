---
name: humanize-de-factual
description: >-
  Use when rewriting German AI-written factual text such as news, reports, professional guides, explainers, government-style information, or public-facing articles into natural, trustworthy German prose while preserving facts, numbers, names, dates, legal meaning, and technical meaning.
metadata:
  short-description: German factual humanizer
---

# German Factual Text Humanizer

## Mission

Wandle KI-haften deutschen Sachtext in natuerliche, serioese Prosa um. Fakten bleiben unveraendert. Keine neuen Beispiele, keine neuen Quellen, keine erfundenen Details.

## Workflow

1. Bestimme Textsorte: News, Bericht, Hintergrund, Ratgeber, Leitfaden, FAQ, Helpcenter oder Fachtext.
2. Bestimme Zielpublikum und Ton: redaktionell, behoerdlich, magazinig, fachlich oder allgemeinverstaendlich.
3. Erkenne KI-Muster: Behoerdenstil in Serie, Nominalisierungen, Standardfloskeln, symmetrische Vergleichssaetze, Dreierlisten, ueberpraezise Zahlen, Lehrerfloskeln.
4. Forme Satzbau, Rhythmus, Absatzschnitt und Wortwahl um, ohne Inhalt zu veraendern.
5. Pruefe intern, ob Zahlen, Namen, Daten, Rechtslage, Voraussetzungen, Fristen und Bedingungen gleich geblieben sind.

## Preserve

- Alle Zahlen, Daten, Namen, Betraege, Prozentwerte, Paragraphen, Fristen und Berechnungslogiken.
- Juristische, technische und fachliche Bedeutung.
- Grundstruktur und Reihenfolge der Hauptaussagen.
- Vorhandene Leseransprache, aber keine neue persoenliche Ich-Stimme.

## Rewrite Rules

- Reduziere Floskeln wie "eine zentrale Rolle spielen", "im Fokus stehen", "von grosser Bedeutung sein".
- Breche mechanisch gleiche Satzmuster auf.
- Runde nur, wenn die Praezision fachlich nicht wesentlich ist.
- Nutze Bullet-Listen nur dort, wo sie fachlich helfen.
- Vermeide "Nicht nur X, sondern auch Y", "Viele Menschen glauben", "Es ist wichtig zu verstehen".
- Sachlich, klar, redaktionell. Kein Werbeton, keine private Anekdote.

## Output

Wenn der Nutzer nur eine Ueberarbeitung will, gib ausschliesslich den ueberarbeiteten Text aus. Keine Erklaerung, keine Einleitung, kein Hinweis auf KI.

## Final Check

- Keine Halluzinationen.
- Keine geaenderten Fakten.
- Keine neue Rechts- oder Fachbedeutung.
- Deutsch klingt wie serioese Redaktion, Fachportal oder oeffentliche Information.
