---
name: internal-memo
description: >-
  Use when writing internal company communication: executive memos, internal presentations, status reports, proposals, business cases, decision docs, project updates, or cross-functional alignment notes. Produces BLUF-first communication with quantified impact, ownership, risks, and tradeoffs.
metadata:
  short-description: Internal memos
---

# Internal Business Communication

## Workflow

1. Identify document type: executive memo, presentation, status report, proposal, business case, or decision note.
2. Identify audience, decision required, deadline, stakeholders, business impact, options, risks, constraints, and next steps.
3. Ask for missing names, dates, metrics, or decision asks when guessing would damage usefulness.
4. Put bottom line up front. Executives may read only the first paragraph.
5. Quantify impact with numbers, ranges, and context.
6. Assign owners by name or role and attach dates.
7. State tradeoffs before benefits when a recommendation has meaningful risk.

## Structures

- Memo: TO, FROM, DATE, RE, executive summary, background, recommendation, data, next steps.
- Presentation: title, agenda, executive summary, evidence slides, recommendation, next steps.
- Status report: project, period, status, accomplishments, metrics, milestones, blockers, next update.
- Proposal: executive summary, problem, solution, business case, alternatives, implementation, recommendation.

## Style Rules

- Use BLUF: recommendation or conclusion first.
- Use active voice: "Sarah approves budget by May 10" beats "budget approval is needed".
- Use exact dates instead of "soon".
- Include political and organizational context when supplied.
- Do not fabricate metrics, stakeholder names, OKRs, decisions, or institutional history.
- Use ranges for uncertain estimates.
- Keep paragraphs short and scannable.

## Output

Return the requested document in markdown. For memos, include headers unless user says not to. For presentations, provide slide-by-slide content with one message per slide.

## Final Check

- Decision ask is clear.
- Impact is quantified.
- Risks and alternatives are stated.
- Owners and deadlines are assigned.
- No vague "leadership", "soon", "significant", or "various stakeholders" unless source input is vague and labeled as such.
