#!/usr/bin/env python3
"""UI Review preprocessing pipeline.

Generates LLM-optimized image variants and color analysis from a UI screenshot.

Outputs:
    original.png   - Resized to Claude-optimal dimensions
    grid.png       - Numbered cell overlay for spatial reference
    blur.png       - Gaussian blur (squint test for processing fluency)
    grayscale.png  - Luminance-only (hierarchy without color test)
    analysis.txt   - Color palette, contrast ratios, image metadata
    sections/      - Vertical crops if aspect ratio > 2:1
"""

import argparse
import math
import os
import sys
import time
from collections import Counter
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageFilter, ImageFont
except ImportError:
    print("ERROR: Pillow is required. Install with: pip install Pillow", file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MAX_LONGEST_EDGE = 1568
MIN_EDGE = 200
MAX_MEGAPIXELS = 1.15 * 1_000_000  # 1.15 MP
BLUR_RADIUS = 7
GRID_LINE_COLOR = (128, 128, 128, 100)  # semi-transparent gray
GRID_LABEL_BG = (0, 0, 0, 140)
GRID_LABEL_FG = (255, 255, 255, 230)
TALL_ASPECT_THRESHOLD = 2.0  # trigger section crops
SECTION_OVERLAP_FRAC = 0.15
PALETTE_K = 8  # number of dominant colors to extract


# ---------------------------------------------------------------------------
# Image optimization
# ---------------------------------------------------------------------------

def optimize_image(img: Image.Image) -> Image.Image:
    """Resize image to Claude-optimal dimensions."""
    img = img.convert("RGB")
    w, h = img.size

    # Scale down if longest edge > 1568
    longest = max(w, h)
    if longest > MAX_LONGEST_EDGE:
        scale = MAX_LONGEST_EDGE / longest
        w, h = int(w * scale), int(h * scale)
        img = img.resize((w, h), Image.LANCZOS)

    # Scale down if exceeds 1.15 MP
    pixels = w * h
    if pixels > MAX_MEGAPIXELS:
        scale = math.sqrt(MAX_MEGAPIXELS / pixels)
        w, h = int(w * scale), int(h * scale)
        img = img.resize((w, h), Image.LANCZOS)

    # Ensure minimum edge
    if min(w, h) < MIN_EDGE:
        scale = MIN_EDGE / min(w, h)
        w, h = int(w * scale), int(h * scale)
        img = img.resize((w, h), Image.LANCZOS)

    return img


# ---------------------------------------------------------------------------
# Grid overlay
# ---------------------------------------------------------------------------

def _pick_grid_dims(w: int, h: int) -> tuple[int, int]:
    """Return (cols, rows) for the grid overlay."""
    large = max(w, h) > 1200
    if w >= h:  # landscape or square
        return (6, 4) if large else (4, 3)
    else:  # portrait
        return (4, 6) if large else (3, 4)


def generate_grid(img: Image.Image) -> Image.Image:
    """Overlay a labeled grid on the image."""
    base = img.copy().convert("RGBA")
    overlay = Image.new("RGBA", base.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    w, h = base.size
    cols, rows = _pick_grid_dims(w, h)

    col_w = w / cols
    row_h = h / rows

    # Draw grid lines
    for c in range(1, cols):
        x = int(c * col_w)
        draw.line([(x, 0), (x, h)], fill=GRID_LINE_COLOR, width=1)
    for r in range(1, rows):
        y = int(r * row_h)
        draw.line([(0, y), (w, y)], fill=GRID_LINE_COLOR, width=1)

    # Draw border
    draw.rectangle([(0, 0), (w - 1, h - 1)], outline=GRID_LINE_COLOR, width=1)

    # Try to load a small font; fall back to default
    font_size = max(10, min(14, int(min(col_w, row_h) / 6)))
    try:
        font = ImageFont.truetype("/System/Library/Fonts/Menlo.ttc", font_size)
    except (OSError, AttributeError):
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", font_size)
        except (OSError, AttributeError):
            font = ImageFont.load_default()

    col_labels = [chr(ord("A") + i) for i in range(cols)]
    row_labels = [str(i + 1) for i in range(rows)]

    for r_idx, r_label in enumerate(row_labels):
        for c_idx, c_label in enumerate(col_labels):
            label = f"{c_label}{r_label}"
            x = int(c_idx * col_w) + 3
            y = int(r_idx * row_h) + 2

            bbox = font.getbbox(label)
            tw = bbox[2] - bbox[0]
            th = bbox[3] - bbox[1]

            # Background rectangle behind label
            pad = 2
            draw.rectangle(
                [(x - pad, y - pad), (x + tw + pad + 2, y + th + pad + 2)],
                fill=GRID_LABEL_BG,
            )
            draw.text((x + 1, y), label, fill=GRID_LABEL_FG, font=font)

    result = Image.alpha_composite(base, overlay)
    return result.convert("RGB")


# ---------------------------------------------------------------------------
# Blur variant (squint test)
# ---------------------------------------------------------------------------

def generate_blur(img: Image.Image) -> Image.Image:
    """Apply Gaussian blur to simulate the squint test."""
    return img.filter(ImageFilter.GaussianBlur(radius=BLUR_RADIUS))


# ---------------------------------------------------------------------------
# Grayscale variant (hierarchy test)
# ---------------------------------------------------------------------------

def generate_grayscale(img: Image.Image) -> Image.Image:
    """Convert to luminance-preserving grayscale."""
    return img.convert("L").convert("RGB")


# ---------------------------------------------------------------------------
# Color palette extraction and contrast analysis
# ---------------------------------------------------------------------------

def _srgb_to_linear(c: float) -> float:
    """Convert sRGB channel (0-1) to linear."""
    if c <= 0.04045:
        return c / 12.92
    return ((c + 0.055) / 1.055) ** 2.4


def _relative_luminance(r: int, g: int, b: int) -> float:
    """WCAG 2.1 relative luminance from RGB 0-255."""
    rl = _srgb_to_linear(r / 255.0)
    gl = _srgb_to_linear(g / 255.0)
    bl = _srgb_to_linear(b / 255.0)
    return 0.2126 * rl + 0.7152 * gl + 0.0722 * bl


def _contrast_ratio(l1: float, l2: float) -> float:
    """WCAG contrast ratio from two relative luminances."""
    lighter = max(l1, l2)
    darker = min(l1, l2)
    return (lighter + 0.05) / (darker + 0.05)


def _wcag_verdict(ratio: float) -> str:
    """Return WCAG pass/fail string."""
    parts = []
    if ratio >= 7.0:
        parts.append("AAA normal")
    if ratio >= 4.5:
        parts.append("AA normal" if ratio < 7.0 else "AA normal")
        if ratio >= 4.5:
            parts.append("AAA large")
    elif ratio >= 3.0:
        parts.append("AA large only")
    else:
        parts.append("FAIL all levels")
    # Simplify
    if ratio >= 7.0:
        return "PASS AAA (normal+large)"
    elif ratio >= 4.5:
        return "PASS AA normal, AAA large"
    elif ratio >= 3.0:
        return "PASS AA large text only"
    else:
        return "FAIL all WCAG levels"


def extract_color_analysis(img: Image.Image) -> str:
    """Extract dominant colors and compute contrast ratios."""
    # Quantize to K colors
    small = img.copy()
    small.thumbnail((200, 200), Image.LANCZOS)
    quantized = small.quantize(colors=PALETTE_K, method=Image.Quantize.MEDIANCUT)
    palette_data = quantized.getpalette()
    get_data = getattr(quantized, "get_flattened_data", quantized.getdata)
    counts = Counter(get_data())

    total_pixels = sum(counts.values())
    colors = []
    for idx, count in counts.most_common(PALETTE_K):
        r = palette_data[idx * 3]
        g = palette_data[idx * 3 + 1]
        b = palette_data[idx * 3 + 2]
        pct = (count / total_pixels) * 100
        colors.append((r, g, b, pct))

    # Sort by percentage descending
    colors.sort(key=lambda c: c[3], reverse=True)

    # Classify colors
    lines = ["# Color Analysis", ""]
    lines.append("## Dominant Colors (sorted by area)")
    lines.append("")
    lines.append("| Rank | Hex | RGB | Area % | Role (estimated) |")
    lines.append("|-|-|-|-|-|")

    for i, (r, g, b, pct) in enumerate(colors):
        hex_val = f"#{r:02X}{g:02X}{b:02X}"
        lum = _relative_luminance(r, g, b)
        if pct > 20:
            role = "Background (dominant)"
        elif lum < 0.15:
            role = "Text-likely (dark)"
        elif lum > 0.85:
            role = "Background-likely (light)"
        else:
            role = "Accent / UI element"
        lines.append(f"| {i+1} | {hex_val} | ({r}, {g}, {b}) | {pct:.1f}% | {role} |")

    # Compute contrast ratios for likely text-background pairs
    lines.append("")
    lines.append("## Contrast Ratios (text-likely vs background-likely pairs)")
    lines.append("")

    bg_colors = [(r, g, b, pct) for r, g, b, pct in colors if pct > 15 or _relative_luminance(r, g, b) > 0.7]
    text_colors = [(r, g, b, pct) for r, g, b, pct in colors if _relative_luminance(r, g, b) < 0.25]

    if bg_colors and text_colors:
        lines.append("| Text Color | Background | Ratio | WCAG Verdict |")
        lines.append("|-|-|-|-|")
        for tr, tg, tb, _ in text_colors:
            t_lum = _relative_luminance(tr, tg, tb)
            for br, bg_c, bb, _ in bg_colors:
                b_lum = _relative_luminance(br, bg_c, bb)
                ratio = _contrast_ratio(t_lum, b_lum)
                t_hex = f"#{tr:02X}{tg:02X}{tb:02X}"
                b_hex = f"#{br:02X}{bg_c:02X}{bb:02X}"
                verdict = _wcag_verdict(ratio)
                lines.append(f"| {t_hex} | {b_hex} | {ratio:.2f}:1 | {verdict} |")
    else:
        lines.append("No clear text-background pairs detected. Manual inspection recommended.")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Section crops for tall images
# ---------------------------------------------------------------------------

def generate_sections(img: Image.Image, out_dir: Path) -> list[str]:
    """Split tall images into overlapping vertical sections."""
    w, h = img.size
    aspect = h / w
    if aspect <= TALL_ASPECT_THRESHOLD:
        return []

    section_dir = out_dir / "sections"
    section_dir.mkdir(exist_ok=True)

    # Each section height = width * 1.2 (roughly landscape-ish)
    section_h = int(w * 1.2)
    overlap = int(section_h * SECTION_OVERLAP_FRAC)
    stride = section_h - overlap

    sections = []
    y = 0
    idx = 1
    while y < h:
        y_end = min(y + section_h, h)
        # Ensure minimum height
        if y_end - y < MIN_EDGE:
            y = max(0, y_end - MIN_EDGE)
        crop = img.crop((0, y, w, y_end))
        name = f"section_{idx:02d}.png"
        crop.save(section_dir / name, "PNG")
        sections.append(name)
        idx += 1
        y += stride
        if y_end >= h:
            break

    return sections


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="UI Review image preprocessor")
    parser.add_argument("image", help="Path to UI screenshot")
    parser.add_argument("--output-dir", "-o", help="Output directory (default: auto-generated)")
    args = parser.parse_args()

    image_path = Path(args.image).resolve()
    if not image_path.exists():
        print(f"ERROR: File not found: {image_path}", file=sys.stderr)
        sys.exit(1)

    # Output directory
    if args.output_dir:
        out_dir = Path(args.output_dir).resolve()
    else:
        ts = time.strftime("%Y%m%d-%H%M%S")
        out_dir = image_path.parent / f"ui_review_{ts}"
    out_dir.mkdir(parents=True, exist_ok=True)

    # Load
    try:
        raw = Image.open(image_path)
    except Exception as e:
        print(f"ERROR: Cannot open image: {e}", file=sys.stderr)
        sys.exit(1)

    orig_w, orig_h = raw.size
    orientation = "landscape" if orig_w >= orig_h else "portrait"

    # Step 1: Optimize
    optimized = optimize_image(raw)
    opt_w, opt_h = optimized.size
    optimized.save(out_dir / "original.png", "PNG")

    # Step 2: Grid overlay
    grid = generate_grid(optimized)
    grid.save(out_dir / "grid.png", "PNG")

    # Step 3: Blur
    blur = generate_blur(optimized)
    blur.save(out_dir / "blur.png", "PNG")

    # Step 4: Grayscale
    gray = generate_grayscale(optimized)
    gray.save(out_dir / "grayscale.png", "PNG")

    # Step 5: Color analysis
    color_report = extract_color_analysis(optimized)

    # Step 6: Section crops
    sections = generate_sections(optimized, out_dir)

    # Append metadata to analysis
    meta_lines = [
        "",
        "## Image Metadata",
        "",
        f"- Original dimensions: {orig_w}x{orig_h}",
        f"- Optimized dimensions: {opt_w}x{opt_h}",
        f"- Orientation: {orientation}",
        f"- Aspect ratio: {orig_w/orig_h:.2f}:1" if orig_w >= orig_h else f"- Aspect ratio: 1:{orig_h/orig_w:.2f}",
        f"- Section crops generated: {len(sections)}",
    ]
    if sections:
        meta_lines.append(f"- Sections: {', '.join(sections)}")

    full_report = color_report + "\n" + "\n".join(meta_lines) + "\n"
    (out_dir / "analysis.txt").write_text(full_report)

    # Summary
    files = ["original.png", "grid.png", "blur.png", "grayscale.png", "analysis.txt"]
    if sections:
        files.extend([f"sections/{s}" for s in sections])

    print(f"Output directory: {out_dir}")
    print(f"Generated files:")
    for f in files:
        print(f"  {out_dir / f}")
    print(f"\nImage: {orig_w}x{orig_h} → {opt_w}x{opt_h} ({orientation})")
    if sections:
        print(f"Section crops: {len(sections)} (tall image detected)")


if __name__ == "__main__":
    main()
