# Flow Testing Playbook

Browser automation instructions per flow type. Each section specifies: how to identify the flow in code, exact browser steps, when to capture screenshots, what invalid data to inject, and which viewports to test.

=== BROWSER TESTING PROTOCOL (IMMUTABLE) ===

1. Before testing any flow: confirm the app URL is accessible. If no URL provided or server unreachable, skip browser testing and note "BROWSER TESTING SKIPPED — no accessible URL."
2. Use agent-browser for navigation, interaction, and screenshots. Use Chrome DevTools MCP for performance metrics and DOM inspection when available.
3. Capture screenshots at EVERY state transition: initial load, after interaction, error state, success state, loading state.
4. Save screenshots to `/tmp/ui_audit_<timestamp>/` with descriptive names: `checkout_step1_initial.png`, `checkout_step2_invalid_email.png`.
5. Test at THREE viewports minimum: mobile (375x812), tablet (768x1024), desktop (1440x900).
6. For each viewport, only re-test checks affected by layout (responsive behavior, touch targets, sticky elements). Do not repeat all interaction tests at every viewport.

**DOM Discovery — before every interaction step:**
Agent-browser cannot "see" the DOM directly. Before clicking or typing on any element:
1. Screenshot the current page state.
2. Identify the target element by its visible text label (button text, link text, input placeholder/label).
3. Locate the element using agent-browser by: visible text first, then `aria-label`, then `placeholder`, then `data-testid`.
4. If element not found: scroll down once, re-screenshot, try again. If still not found: record "ELEMENT NOT FOUND: [description]" and skip that step.
5. After interaction: screenshot the result state before proceeding to the next step.

=== END PROTOCOL ===

---

## Table of Contents

- [Flow Identification Strategy](#flow-identification-strategy)
- [Login / Registration Flow](#login--registration-flow)
- [Checkout / Purchase Flow](#checkout--purchase-flow)
- [Onboarding / FTUE Flow](#onboarding--ftue-flow)
- [Data Entry / Forms Flow](#data-entry--forms-flow)
- [Navigation / Browse Flow](#navigation--browse-flow)
- [Settings / Profile Flow](#settings--profile-flow)

---

## Flow Identification Strategy

Before testing, identify which flows exist in the project by reading the routing configuration.

### Framework-Specific Route Discovery

| Framework | Where to look | Command |
|-|-|-|
| Next.js (App Router) | `app/` directory — each folder with `page.tsx` is a route | `Glob: app/**/page.{tsx,jsx,ts,js}` |
| Next.js (Pages Router) | `pages/` directory | `Glob: pages/**/*.{tsx,jsx,ts,js}` |
| React + React Router | Router config file — search for `<Route`, `createBrowserRouter` | `Grep: createBrowserRouter\|<Route` |
| Vue + Vue Router | `router/index.ts` or `router.ts` | `Grep: routes.*=` in router files |
| Nuxt | `pages/` directory — file-based routing | `Glob: pages/**/*.vue` |
| Svelte + SvelteKit | `src/routes/` directory | `Glob: src/routes/**/+page.svelte` |
| Angular | `app-routing.module.ts` or `app.routes.ts` | `Grep: Routes\|RouterModule` |

### Flow Ranking

After discovering routes, rank flows by business impact:

| Priority | Flow type | Identify by |
|-|-|-|
| 1 | Checkout / Purchase | Routes containing: `checkout`, `cart`, `payment`, `order` |
| 2 | Registration / Login | Routes containing: `signup`, `register`, `login`, `auth`, `signin` |
| 3 | Core Feature | The route with the most components and state — usually the main dashboard, feed, or product listing |
| 4 | Onboarding | Routes containing: `onboarding`, `welcome`, `setup`, `tutorial` |
| 5 | Settings / Profile | Routes containing: `settings`, `profile`, `account`, `preferences` |

Select top 3-5 flows based on what exists. If the user specifies `--flow`, test only that flow.

---

## Login / Registration Flow

### Code Identification

Search for: `Grep: signup\|register\|login\|signin\|auth` in route and component files.

Components to read:
- Registration form component
- Login form component
- Auth provider/context (social login configuration)
- Validation logic (client-side validation rules)
- API call for registration/login endpoint

### Browser Test Sequence — Registration

```
STEP 1: Navigate to registration page
  → Screenshot: reg_initial_desktop.png
  → Record: field count, social login options present, label alignment

STEP 2: Test empty form submission
  → Click submit with all fields empty
  → Screenshot: reg_empty_submit.png
  → Record: which errors appear, error message quality, when errors appear (immediately or after submit)

STEP 3: Test invalid email
  → Enter "notanemail" in email field
  → Tab to next field (blur trigger test)
  → Screenshot: reg_invalid_email_blur.png
  → Record: does error appear on blur? What does it say?

STEP 4: Test weak password
  → Enter "123" in password field
  → Tab away
  → Screenshot: reg_weak_password.png
  → Record: error message specificity (does it say WHAT is required?)

STEP 5: Test valid submission
  → Fill all fields with valid test data
  → Submit the form
  → Screenshot: reg_submitting.png (capture loading state)
  → Screenshot: reg_success.png (or reg_error.png if test account creation blocked)
  → Record: loading indicator presence, button disabled during submission, success/error feedback

STEP 6: Check confirm-password field (mobile)
  → At 375px viewport, note if confirm-password field exists
  → Record: present or absent

STEP 7: Test social login buttons
  → Record: which social login options are present
  → Click one — does it redirect to OAuth provider? (Don't complete OAuth, just verify redirect works)
```

**Environment fallbacks — Registration/Login:**

| Blocked step | Action |
|-|-|
| OAuth redirect | Click the social login button. If redirect initiates, screenshot the redirect URL and record "OAuth redirect to [provider] verified." Do NOT complete the OAuth flow. |
| Email verification required | Record "EMAIL VERIFICATION SKIPPED." If post-verification pages are accessible via direct URL, test those separately. |
| CAPTCHA on registration | Record "CAPTCHA BLOCKED." Screenshot the CAPTCHA state. Test remaining form validation that occurs before CAPTCHA. |
| Rate limiting | If the app blocks repeated login attempts, record "RATE LIMITED after N attempts." Continue with other flow testing. |

### Browser Test Sequence — Login

```
STEP 1: Navigate to login page
  → Screenshot: login_initial.png
  → Record: field count, social login, "forgot password" link, passkey option

STEP 2: Test invalid credentials
  → Enter valid email format + wrong password
  → Submit
  → Screenshot: login_invalid.png
  → Record: error message (does it reveal which field is wrong? Security concern if "incorrect password" vs "incorrect email or password")

STEP 3: Test empty submission
  → Submit empty form
  → Screenshot: login_empty.png
  → Record: validation behavior

STEP 4: Check "forgot password" flow
  → Click forgot password link
  → Screenshot: forgot_password.png
  → Record: does it navigate to a recovery page?
```

### Checks to Apply
RE1-RE7 from knowledge-base.md. Plus: I4, I5, I6, I9, I10 (if modal login), A3, A5, A12, A13.

### Invalid Test Data

| Field | Invalid value | Expected error |
|-|-|-|
| Email | `notanemail` | "Enter a valid email address" |
| Email | (empty) | "Email is required" |
| Password | `123` | "Password must be at least 8 characters" |
| Password | `abcdefgh` | "Password needs at least 1 number" (if policy requires) |
| Phone | `abc` | "Enter a valid phone number" |

---

## Checkout / Purchase Flow

### Code Identification

Search for: `Grep: checkout\|cart\|payment\|order\|stripe\|paypal` in route and component files.

Components to read:
- Cart component (item display, quantity controls, subtotal)
- Checkout form component(s) (shipping, billing, payment)
- Payment integration (Stripe, PayPal, etc.)
- Order summary component
- Confirmation/thank-you page

### Browser Test Sequence

```
STEP 1: Add item to cart
  → Navigate to a product/item page
  → Click "Add to Cart" button
  → Screenshot: product_add_to_cart.png
  → Record: feedback on add (toast, cart count update, animation)

STEP 2: View cart
  → Navigate to cart page
  → Screenshot: cart_desktop.png
  → Record: item details, quantity controls, subtotal, shipping estimate, CTA prominence

STEP 3: Proceed to checkout
  → Click checkout CTA
  → Screenshot: checkout_step1.png
  → Record: guest checkout option, progress indicator, field count, auto-fill support

STEP 4: Test shipping form validation
  → Submit shipping form with empty required fields
  → Screenshot: checkout_shipping_errors.png
  → Record: error messages, validation timing

STEP 5: Fill shipping with valid data
  → Complete shipping form with test data
  → Proceed to next step
  → Screenshot: checkout_step2.png
  → Record: data persistence, progress update

STEP 6: Test payment form
  → Note payment options available (count them)
  → Enter invalid card: 4000000000000002 (Stripe decline test card)
  → Submit
  → Screenshot: checkout_payment_error.png
  → Record: error handling for declined card

STEP 7: Test back navigation
  → Press browser back button
  → Screenshot: checkout_back.png
  → Record: does shipping data persist? Does progress indicator update?

STEP 8: Complete checkout (if possible with test mode)
  → Use test card: 4242424242424242
  → Submit
  → Screenshot: checkout_submitting.png (loading state)
  → Screenshot: checkout_confirmation.png
  → Record: confirmation details, next steps, peak-end quality

STEP 9: Mobile viewport test
  → At 375px, navigate through checkout
  → Screenshot: checkout_mobile.png
  → Record: sticky CTA presence, field usability, touch target sizes
```

**Environment fallbacks — Checkout:**

| Blocked step | Action |
|-|-|
| Payment gateway (no test mode) | Record "PAYMENT TESTING SKIPPED — no test mode detected." Test all steps up to payment submission. Screenshot the payment form layout. |
| Stripe test mode available | Use test card `4242424242424242`, exp `12/34`, CVV `123`. For decline test: `4000000000000002`. |
| Auth-gated checkout | If checkout requires login and no test credentials available, record "AUTH-GATED — checkout requires login." Test the cart page and checkout entry only. |
| Address validation API | If address autocomplete requires a live API key, enter address manually. Record "ADDRESS AUTOCOMPLETE SKIPPED — API key required." |

### Checks to Apply
EC1-EC7 from knowledge-base.md. Plus: I1, I2, I3, I5, I6, I8, I11, I13, V22, V23, V24.

### Invalid Test Data

| Field | Invalid value | Expected error |
|-|-|-|
| Email | `not@valid` | Domain-specific error |
| ZIP/Postal | `XXXXX` | "Enter a valid postal code" |
| Card number | `1234` | "Enter a valid card number" |
| Card number | `4000000000000002` | "Card declined" |
| Expiry | `01/20` | "Card has expired" |
| CVV | `1` | "Enter a valid security code" |

---

## Onboarding / FTUE Flow

### Code Identification

Search for: `Grep: onboarding\|welcome\|setup\|tutorial\|firstRun\|first.run\|isNew` in route and component files.

Components to read:
- Onboarding stepper/wizard component
- Feature highlight/tooltip components
- First-time user detection logic (localStorage flag, user profile flag)
- Skip/dismiss logic

### Browser Test Sequence

```
STEP 1: Trigger first-time state
  → Clear localStorage/cookies to simulate new user
  → Navigate to app entry point
  → Screenshot: onboarding_start.png
  → Record: what shows for first-time users? Tutorial? Feature tour? Empty state?

STEP 2: Time to first value
  → Start timer from first onboarding screen
  → Follow the onboarding flow
  → Screenshot each step: onboarding_step1.png, onboarding_step2.png, ...
  → Record: how many steps? How long to first meaningful action or reward?

STEP 3: Test skip option
  → Look for skip/dismiss button at each step
  → Screenshot: onboarding_skip_present.png or onboarding_skip_missing.png
  → Record: is skip available? At which steps?

STEP 4: Test progress indication
  → Record: is there a step indicator? Does it update?

STEP 5: Test completion
  → Complete the full onboarding flow
  → Screenshot: onboarding_complete.png
  → Record: celebration/confirmation? Clear next-step guidance? Transition to main app?

STEP 6: Test post-onboarding state
  → Navigate away and return
  → Record: does onboarding repeat? Or does the app remember completion?
```

### Checks to Apply
GA3, GA4, GA5 (if games). V22, V23, V24. I15 (empty states). I1 (feedback timing).

---

## Data Entry / Forms Flow

### Code Identification

Search for: `Grep: <form\|<Form\|useForm\|useFormik\|useForm\(\)\|v-model` in component files.

Identify ALL forms in the application, then prioritize by complexity (field count).

### Browser Test Sequence

```
STEP 1: Navigate to form page
  → Screenshot: form_initial.png
  → Record: field count, grouping, label positioning, required field marking

STEP 2: Test empty submission
  → Submit with all fields empty
  → Screenshot: form_all_errors.png
  → Record: which fields show errors, error positions (inline vs summary), timing

STEP 3: Test field-by-field validation
  → For each field type:
    - Enter invalid data
    - Tab to next field (blur test)
    - Record: when does error appear? What does it say?
  → Screenshot representative states

STEP 4: Test auto-fill
  → Check if browser auto-fill works on standard fields (name, email, address)
  → Record: does auto-fill populate correctly? Are autocomplete attributes present?

STEP 5: Test multi-step navigation (if applicable)
  → Fill step 1, advance to step 2
  → Go back to step 1
  → Record: data persistence
  → Advance again
  → Record: data in step 2 still intact?

STEP 6: Test successful submission
  → Fill all fields validly
  → Submit
  → Screenshot: form_submitting.png (loading state)
  → Screenshot: form_success.png
  → Record: loading indicator, success feedback, next steps

STEP 7: Test long text fields
  → If textarea fields exist: enter very long text (500+ chars)
  → Record: does the field resize? Character count shown? Truncation handling?

STEP 8: Test keyboard navigation
  → Tab through all fields
  → Record: logical order? All fields reachable? Submit via Enter key?
```

### Checks to Apply
I4, I5, I6, I8, I9, I11. RE3-RE7 (if registration-like). A3, A5, A12, A13.

### Invalid Test Data by Field Type

| Type | Invalid values to test |
|-|-|
| Email | `notanemail`, `@domain.com`, `user@`, empty |
| Phone | `abc`, `123`, `+1-555-FAKE`, empty |
| URL | `notaurl`, `http://`, `ftp://example.com`, empty |
| Number | `abc`, `-1` (if non-negative), `99999999` (overflow), empty |
| Date | `99/99/9999`, past date (if future required), `02/30/2025`, empty |
| Password | `123`, `abcdefgh` (no number), `12345678` (no letter), empty |
| Required text | empty, single space (` `), only whitespace |
| File upload | Wrong file type, oversized file (if possible to test) |

---

## Navigation / Browse Flow

### Code Identification

Search for: `Grep: <nav\|<Nav\|Navigation\|Menu\|Sidebar\|Breadcrumb\|search` in component files.

Components to read:
- Main navigation component (header, sidebar, bottom tabs)
- Search component
- Filter/sort components
- Breadcrumb component
- Pagination component

### Browser Test Sequence

```
STEP 1: Map navigation structure
  → Screenshot: nav_desktop.png
  → Record: nav type (top bar, sidebar, bottom tabs), item count, dropdown depth

STEP 2: Test mobile navigation
  → At 375px viewport
  → Screenshot: nav_mobile_closed.png
  → Open mobile nav (hamburger or bottom tabs)
  → Screenshot: nav_mobile_open.png
  → Record: is it hamburger or bottom tabs? All items accessible?

STEP 3: Test search functionality
  → Enter a search query
  → Screenshot: search_results.png
  → Record: autocomplete? Results relevant? No results state handling?

STEP 4: Test search with no results
  → Enter gibberish query
  → Screenshot: search_no_results.png
  → Record: helpful empty state? Suggestions?

STEP 5: Test filter/sort (if applicable)
  → Apply filters
  → Screenshot: filtered_results.png
  → Record: do filters update URL? Can filters be shared/bookmarked?
  → Remove filters — does content reset?

STEP 6: Test deep navigation + back button
  → Navigate 3+ levels deep (category → subcategory → item)
  → Press back button at each level
  → Record: correct navigation history? Scroll position preserved?

STEP 7: Test breadcrumbs (if applicable)
  → Record: present? Accurate? Clickable?
  → Click a breadcrumb level — does it navigate correctly?

STEP 8: Test pagination (if applicable)
  → Navigate to page 2+
  → Record: URL updates? Back button goes to previous page?
```

### Checks to Apply
I7, I8, I13, I14, I20. V3, V6, V17, V18. A1, A7, A8 (touch targets on mobile).

---

## Settings / Profile Flow

### Code Identification

Search for: `Grep: settings\|profile\|account\|preferences\|<Settings\|<Profile` in route and component files.

Components to read:
- Settings/profile page component
- Form components for editing profile data
- Theme/preference toggle components
- Account deletion or password change components

### Browser Test Sequence

```
STEP 1: Navigate to settings
  → Screenshot: settings_initial.png
  → Record: sections visible, edit options, navigation within settings

STEP 2: Test edit mode
  → Click edit on a profile field
  → Change the value
  → Screenshot: settings_editing.png
  → Record: inline edit or separate page? Save button clear?

STEP 3: Test save behavior
  → Save the change
  → Screenshot: settings_saved.png
  → Record: success feedback? Optimistic update or waiting for server?

STEP 4: Test cancel/discard
  → Make a change but don't save
  → Navigate away
  → Record: unsaved changes warning? Data discarded silently?

STEP 5: Test destructive actions
  → Find "Delete account" or similar destructive action
  → Click it
  → Screenshot: settings_destructive_confirm.png
  → Record: confirmation dialog? Clear warning? Undo option?
  → Cancel the action (do NOT complete deletion)

STEP 6: Test password change (if available)
  → Navigate to password change
  → Record: requires current password? Show/hide toggle? Validation rules shown?

STEP 7: Test theme/preference toggles
  → Toggle dark mode or notification preferences
  → Record: immediate effect? Persisted on reload?
```

### Checks to Apply
I1, I3, I8, I12, I19. V22 (if multi-step). A5, A9.

---

## Viewport Testing Quick Reference

For each flow, test responsive layout at these viewports after completing the interaction tests:

| Viewport | Size | Check for |
|-|-|-|
| Mobile | 375x812 | Touch target sizes (>=44px), sticky CTA, bottom nav, content overflow, form input zoom (>=16px) |
| Tablet | 768x1024 | Layout adaptation, nav structure, image scaling, column collapse |
| Desktop | 1440x900 | Content width constraint (max-width), readability (line length <75 chars), proper use of space |

At each viewport, screenshot the key pages of the flow being tested. Focus on layout-breaking issues, not re-testing all interactions.

---

=== RECALL: BROWSER TESTING PROTOCOL ===
Every browser test MUST produce screenshots saved to `/tmp/ui_audit_<timestamp>/`. No finding about dynamic behavior is valid without a screenshot or observed behavior record. If browser testing is unavailable, findings about dynamic behavior must be tagged "CODE-ONLY — behavior unverified."
=== END RECALL ===
