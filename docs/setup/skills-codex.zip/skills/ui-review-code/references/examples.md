# UI Audit Calibration Examples

Two complete output examples demonstrating expected quality, evidence triangulation, severity calibration, and the "so what" test. Read these BEFORE generating any audit output. Match this quality bar.

---

## Example 1: React E-Commerce Checkout Flow

### Project Context
- Framework: Next.js 14 (App Router)
- UI Library: Tailwind CSS + Radix UI
- State: Zustand
- App URL: http://localhost:3000

### Discovery Output

```
Framework: Next.js 14 (App Router)
Routes discovered: 12
  /                     → Homepage
  /products             → Product listing
  /products/[id]        → Product detail
  /cart                 → Shopping cart
  /checkout             → Checkout (single page)
  /checkout/success     → Order confirmation
  /auth/login           → Login
  /auth/register        → Registration
  /account              → User account
  /account/orders       → Order history
  /account/settings     → Account settings
  /search               → Search results

Critical flows identified:
  1. Checkout (HIGH) — /cart → /checkout → /checkout/success
  2. Registration (HIGH) — /auth/register
  3. Product Browse (MEDIUM) — / → /products → /products/[id] → /cart

Available tools: agent-browser YES, Chrome DevTools YES
Mode: FULL
```

### Findings

---

**[CRITICAL] I3 + I6: Checkout form has no error handling and allows double-submit**

Code evidence:
- `app/checkout/page.tsx:47` — `handleSubmit` calls `createOrder(formData)` without try/catch
- `app/checkout/page.tsx:52` — No `isSubmitting` state. Button never disabled during submission.
- `lib/api/orders.ts:23` — `createOrder` function has no error handling wrapper

```tsx
// app/checkout/page.tsx:45-55
const handleSubmit = async (e: FormEvent) => {
  e.preventDefault()
  const order = await createOrder(formData)  // No try/catch
  router.push(`/checkout/success?id=${order.id}`)
  // Button never disabled — user can click again during await
}
```

Browser evidence:
- Clicked "Place Order" 3 times rapidly → Network tab shows 3 POST requests to `/api/orders`
- Screenshot: `checkout_double_submit.png` — button remained styled as active during all 3 clicks
- With network throttled to Slow 3G: button clickable for 4.2 seconds during submission with zero visual feedback

So what: Users on slow connections will click the submit button multiple times, creating duplicate orders and duplicate charges. On fast connections, rapid double-clicks produce duplicate orders. API returns 201 for each request — no server-side idempotency protection either.

Fix: In `app/checkout/page.tsx:45`:
1. Add `const [isSubmitting, setIsSubmitting] = useState(false)` to component state
2. Wrap `handleSubmit` body in `try/catch/finally`
3. Set `setIsSubmitting(true)` before API call, `setIsSubmitting(false)` in `finally`
4. Add `disabled={isSubmitting}` to submit button
5. Show existing `<Spinner />` component from `components/ui/Spinner.tsx` on the button during submission
6. Consider: add idempotency key to the API request

---

**[HIGH] I2 + C8: Product listing has no loading state — shows blank white screen during data fetch**

Code evidence:
- `app/products/page.tsx:12` — Uses `useProducts()` hook which returns `{ data, isLoading, error }`
- `app/products/page.tsx:18` — Renders `data.map(...)` directly. No check for `isLoading`. No check for `error`.
- Project has a `components/ui/Skeleton.tsx` component that is NOT imported on this page.

```tsx
// app/products/page.tsx:12-22
const { data } = useProducts()  // isLoading and error destructured but unused
return (
  <div className="grid grid-cols-3 gap-4">
    {data?.map(product => <ProductCard key={product.id} {...product} />)}
  </div>
)
```

Browser evidence:
- With network throttled to Slow 3G: white screen for 3.8 seconds before products appear
- Screenshot: `products_loading_blank.png` — empty grid container visible, no content, no loading indicator
- FCP measured at 0.9s but LCP at 4.1s (LCP element is the first product image)

So what: On mobile networks (75% of traffic), users see a blank page for 2-4 seconds. 57% of users abandon after 3 seconds of no feedback (Contentsquare). The skeleton component already exists in the project but isn't used here.

Fix: In `app/products/page.tsx:12`:
```tsx
const { data, isLoading, error } = useProducts()
if (isLoading) return <ProductGridSkeleton />  // Use existing Skeleton component
if (error) return <ErrorMessage message="Could not load products" retry={() => mutate()} />
```

---

**[HIGH] EC2: Shipping costs hidden until final checkout step**

Code evidence:
- `app/cart/page.tsx` — Cart component shows subtotal only. No shipping estimate. Grep for "shipping" in cart component returns 0 matches.
- `app/checkout/page.tsx:89` — Shipping cost calculated and displayed only after address is entered in checkout form.
- `components/CartSummary.tsx:15` — Shows `Subtotal`, `Tax (estimated)`, `Total` but no shipping line.

Browser evidence:
- Screenshot: `cart_no_shipping.png` — Cart page shows "Subtotal: $89.99" and "Total: $89.99" with no mention of shipping
- Screenshot: `checkout_with_shipping.png` — After entering address, "$12.99 shipping" appears, changing total from $89.99 to $102.98

So what: Hidden extra costs are the #1 cart abandonment cause at 47% (Baymard, 59 studies). Users who see $89.99 in the cart and $102.98 at checkout feel deceived. This $13 surprise at the final step directly causes abandonment.

Fix: In `components/CartSummary.tsx`:
- Add a "Shipping: Calculated at checkout" line, or better: estimate shipping based on user's stored address or IP geolocation
- If flat-rate shipping: show it on the cart page
- If free shipping threshold exists: show "Free shipping on orders over $X" and progress toward it

---

**[MEDIUM] I4: Registration form validates on every keystroke**

Code evidence:
- `app/auth/register/page.tsx:34` — Uses Formik with `validateOnChange={true}` (Formik default)
- `lib/validation/auth.ts:8` — Yup schema with email regex and password rules

Browser evidence:
- Typing in email field: error "Invalid email" appears on first character, updates every keystroke
- Screenshot: `register_onchange_errors.png` — Error visible while user is still typing "j" in email field

So what: Each keystroke triggers a validation cycle that shows then hides error messages, creating micro-interruptions. This compounds attention residue (Leroy 2009) — the user is fighting the form instead of completing it.

Fix: In `app/auth/register/page.tsx:34`:
```tsx
<Formik validateOnChange={false} validateOnBlur={true} ...>
```

---

**[REJECTED FINDING] V8: Product cards have inconsistent spacing**

Initial observation: Product cards on /products appeared to have uneven margins.
Challenge: Re-examined at all three viewports. Spacing is consistent — the visual unevenness was caused by variable product title lengths creating different card heights in the grid. The grid itself uses `gap-4` consistently.
Code evidence: `app/products/page.tsx:19` uses `grid grid-cols-3 gap-4` — uniform spacing confirmed.
Verdict: REJECTED. This is a variable content length issue, not a spacing inconsistency. The grid is correctly implemented. Could improve with `grid-rows` or equal-height cards, but this is a polish item, not a deficiency.

---

### Summary Scorecard

| Category | Checks applied | Pass | Fail | Critical |
|-|-|-|-|-|
| Interaction (I1-I20) | 14 | 9 | 5 | 2 |
| Performance (P1-P8) | 6 | 4 | 2 | 0 |
| Accessibility (A1-A15) | 10 | 7 | 3 | 0 |
| Code Quality (C1-C12) | 8 | 5 | 3 | 1 |
| Visual (V1-V24) | 18 | 15 | 3 | 0 |
| E-Commerce (EC1-EC7) | 7 | 4 | 3 | 0 |
| **Total** | **63** | **44 (70%)** | **19** | **3** |

Rating: **Needs Work** (70%) — 3 critical issues require immediate attention before launch.

---

## Example 2: Vue SaaS Registration Page

### Project Context
- Framework: Nuxt 3
- UI Library: Vuetify 3
- State: Pinia
- App URL: http://localhost:3001

### Discovery Output

```
Framework: Nuxt 3
Routes discovered: 8
  /                     → Landing page
  /register             → Registration
  /login                → Login
  /dashboard            → Main dashboard
  /settings             → Settings
  /projects             → Project list
  /projects/[id]        → Project detail
  /billing              → Billing/subscription

Auditing: Registration flow (/register)
Mode: FULL
```

### Findings

---

**[CRITICAL] A3 + A13: Form inputs have no programmatic label association**

Code evidence:
- `pages/register.vue:24-38` — All 5 form fields use Vuetify `<v-text-field>` with `label` prop, which renders a floating label. However, the generated HTML uses `<label>` elements that are NOT associated with the input via `for`/`id` pairing.
- `pages/register.vue:30` — Password field has `aria-describedby` referencing an error element that doesn't exist until an error occurs (`id="password-error"` is conditionally rendered).

```vue
<!-- pages/register.vue:24-38 -->
<v-text-field label="Full Name" v-model="form.name" />
<v-text-field label="Email" v-model="form.email" type="email" />
<v-text-field label="Company" v-model="form.company" />
<v-text-field label="Password" v-model="form.password" type="password" />
<v-text-field label="Confirm Password" v-model="form.confirmPassword" type="password" />
```

Browser evidence:
- DevTools Accessibility tree: inputs show "no accessible name" warning
- Screen reader test (VoiceOver): tabbing to email field announces "edit text" instead of "Email, edit text"
- Screenshot: `register_a11y_tree.png` — accessibility tree showing unlabeled inputs

So what: Screen reader users cannot identify which field they are in. They hear "edit text" five times with no distinguishing information. This makes the form completely unusable for the ~8% of users who rely on assistive technology. Additionally, 50-72% of mobile users have at least one accessibility setting enabled.

Fix: In `pages/register.vue`, add explicit `id` to each input and `for` to labels. Or use Vuetify's `id` prop:
```vue
<v-text-field label="Full Name" v-model="form.name" id="name" />
```
Verify in Vuetify's rendered HTML that the `<label>` receives a matching `for` attribute. If Vuetify doesn't do this automatically, add `aria-label` as fallback:
```vue
<v-text-field label="Full Name" v-model="form.name" aria-label="Full Name" />
```

---

**[HIGH] RE5 + I4: Confirm-password field on mobile + onChange validation**

Code evidence:
- `pages/register.vue:37` — Confirm password field present unconditionally (no mobile detection)
- `composables/useRegisterForm.ts:15` — Vuelidate validation with `$touch()` called in a `watch()` on every model change (effectively onChange)

Browser evidence:
- At 375px viewport: both password fields visible. No show/hide toggle on either.
- Typing in confirm-password field: "Passwords don't match" appears on every keystroke as user types
- Screenshot: `register_mobile_confirm_pw.png` — two password fields taking significant vertical space on mobile

So what: Mobile password entry takes 2x longer than desktop (Zuko). A confirm-password field doubles this. Combined with onChange validation flashing "Passwords don't match" during typing, this creates compounding friction. The confirm-password field adds no security benefit when a show/hide toggle is available.

Fix:
1. Remove confirm-password field. Add a password visibility toggle instead (Vuetify `append-inner-icon` with `@click:append-inner` handler).
2. In `composables/useRegisterForm.ts:15`, change the `watch()` to trigger `$touch()` on blur instead:
```ts
// Remove: watch(form, () => v$.value.$touch())
// Add blur handler in template: @blur="v$.password.$touch()"
```

---

**[MEDIUM] A5: Focus indicators removed globally**

Code evidence:
- `assets/css/main.css:12` — `*:focus { outline: none; }` — global outline removal
- No replacement focus styles found in any CSS file
- Vuetify provides focus styles, but they are overridden by this global rule

```css
/* assets/css/main.css:12 */
*:focus {
  outline: none;  /* Removes all focus indicators */
}
```

Browser evidence:
- Tab through registration form: no visible focus indicator on any element
- Screenshot: `register_no_focus.png` — cursor in email field but no visual indication of focus

So what: Keyboard users cannot see which element is focused. They are navigating blind. This fails WCAG 2.4.7 Focus Visible (Level AA). Given that 50-72% of mobile users have accessibility settings enabled, this affects a significant user base.

Fix: In `assets/css/main.css:12`, replace with:
```css
*:focus-visible {
  outline: 2px solid var(--v-theme-primary);
  outline-offset: 2px;
}
```
This preserves the designer's intent (no focus ring on mouse click) while providing focus visibility for keyboard navigation.

---

### Summary Scorecard

| Category | Checks applied | Pass | Fail | Critical |
|-|-|-|-|-|
| Interaction (I1-I20) | 8 | 5 | 3 | 0 |
| Accessibility (A1-A15) | 12 | 7 | 5 | 1 |
| Code Quality (C1-C12) | 6 | 5 | 1 | 0 |
| Visual (V1-V24) | 10 | 8 | 2 | 0 |
| Registration (RE1-RE7) | 7 | 4 | 3 | 0 |
| **Total** | **43** | **29 (67%)** | **14** | **1** |

Rating: **Needs Work** (67%) — 1 critical accessibility issue + 3 high-severity interaction/registration issues.

---

## Anti-Example: What NOT to Write

The following demonstrates SUPERFICIAL findings that violate the anti-platitude protocol. Do NOT produce output like this.

**BAD: "Consider improving the loading experience"**
- No file reference. No observed behavior. No specific component. No research citation. No "so what."

**BAD: "The form could benefit from better validation"**
- Which form? Which fields? What is the current validation? What should it be instead?

**BAD: "Accessibility could be improved"**
- Which accessibility criteria? Which elements fail? What WCAG level? What impact?

**BAD: "The checkout flow has room for optimization"**
- This says nothing. Every checkout flow has room for optimization.

**GOOD version of each:**

| Bad finding | Good version |
|-|-|
| "Consider improving the loading experience" | "`app/products/page.tsx:18` — `useProducts()` returns `isLoading` but it's never checked. Blank white screen for 3.8s on Slow 3G. Existing `Skeleton.tsx` component unused. Fix: add `if (isLoading) return <Skeleton />`." |
| "The form could benefit from better validation" | "`pages/register.vue:15` — Vuelidate `$touch()` in `watch()` fires onChange. Error 'Passwords don't match' flashes every keystroke. Fix: move `$touch()` to blur handler." |
| "Accessibility could be improved" | "`assets/css/main.css:12` — `*:focus { outline: none }` removes all focus indicators globally. No replacement defined. WCAG 2.4.7 failure. Fix: use `*:focus-visible` with outline." |
| "The checkout flow has room for optimization" | "`app/checkout/page.tsx:47` — No `isSubmitting` state. Button clickable during submission. 3 rapid clicks = 3 POST requests. Fix: add loading state + disable button." |

Every finding MUST include: specific file:line, observed behavior, research principle, and actionable fix. Anything less is a platitude.
