# UI Audit Evaluation Criteria

Mechanically executable checks for project-level UI audit. Each check specifies what to look for in CODE, what to verify in BROWSER, how to determine pass/fail, and which research principle applies.

=== EXECUTION PROTOCOL (IMMUTABLE) ===

1. Execute checks by category. Skip a category only if the project has zero matching components.
2. For each check: read the code signal FIRST, then verify in browser IF browser is available.
3. Record BOTH the code evidence (file:line) AND the browser evidence (observed behavior or screenshot).
4. A finding requires evidence from at least ONE source. Findings with BOTH code + browser evidence are CONFIRMED. Findings from code-only are UNVERIFIED-BEHAVIOR. Findings from browser-only are UNVERIFIED-CODE.
5. Never report a finding without citing a specific file path, line number, component name, or observed behavior.

=== END EXECUTION PROTOCOL ===

---

## Table of Contents

- [Interaction Checks (I1-I20)](#interaction-checks)
- [Performance Checks (P1-P8)](#performance-checks)
- [Accessibility Checks (A1-A15)](#accessibility-checks)
- [Code Quality Checks (C1-C12)](#code-quality-checks)
- [Visual Checks (V1-V24)](#visual-checks)
- [E-Commerce Checks (EC1-EC7)](#e-commerce-checks)
- [Games Checks (GA1-GA8)](#games-checks)
- [Registration Checks (RE1-RE7)](#registration-checks)
- [KYC Checks (KY1-KY5)](#kyc-checks)

---

## Interaction Checks

### I1. Feedback within 400ms (Doherty Threshold)

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Search for click handlers, form submits, and navigation triggers. Check if they immediately update UI state (set loading flag, disable button, show spinner) BEFORE starting async work. |
| Code patterns | React: `useState` for `isLoading` set before `await`. Vue: reactive `loading` ref set before async call. Any framework: button `disabled` attribute bound to loading state. |
| Browser verify | Click each interactive element. Observe: does the UI change within 400ms? Does the button disable? Does a spinner appear? |
| Pass | Every user-initiated action produces visible feedback (state change, spinner, disabled button, animation) within 400ms. |
| Fail | Any click or submit produces no visible change for >400ms. Button remains clickable during async operation. |
| Evidence | Doherty Threshold — users perceive systems as sluggish beyond 400ms. 57% abandon after 3s without feedback. (Contentsquare) |

### I2. Loading states for async operations

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Find all API calls (`fetch`, `axios`, `useSWR`, `useQuery`, `$fetch`, etc.). For each, check: is there a loading state variable? Is it rendered in the template/JSX? |
| Code patterns | React: `if (isLoading) return <Skeleton />`. Vue: `v-if="loading"`. Next.js: `loading.tsx` file per route. Nuxt: `<NuxtLoadingIndicator>`. Svelte: `{#await promise}`. |
| Browser verify | Throttle network to Slow 3G in DevTools. Navigate to pages with data fetching. Observe: skeleton screen, spinner, or blank white screen? |
| Pass | Every async data fetch shows a skeleton screen or spinner during loading. No blank/white screens during data fetch. |
| Fail | Any page shows blank white screen or partially rendered content while data loads. |
| Evidence | Skeleton screens reduce perceived load time. Users abandon blank screens at 3x the rate of screens with loading indicators. (NN/g) |

### I3. Error state rendering

| Field | Value |
|-|-|
| Severity | CRITICAL |
| Code signal | Find all API calls. For each, check: is there error handling (`.catch`, `try/catch`, `onError`, error boundary)? Does the error handler render user-facing UI? |
| Code patterns | React: `<ErrorBoundary>` wrapping async components, `if (error) return <ErrorMessage />`. Vue: `onErrorCaptured`, `<Suspense>` with `#fallback`. Next.js: `error.tsx` per route. |
| Browser verify | Simulate API failure (block API requests via DevTools network tab, or navigate to invalid resource). Observe: does the user see a helpful error message or a white screen / raw error? |
| Pass | API failures render a user-friendly error message with recovery action ("Try again", "Go back"). No white screens. No raw stack traces. |
| Fail | Any API failure causes: white screen, raw error text, unhandled promise rejection visible in console, or component crash without fallback. |
| Evidence | GPT-4o scores 0% on error recovery heuristic assessment — this is the most commonly missed UX pattern. (Verified, synthesis.md C072) |

### I4. Form validation timing

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Find form validation logic. Check trigger event: `onChange`/`onInput` (bad — fires every keystroke) vs `onBlur`/`onSubmit` (good — fires after field exit). |
| Code patterns | React: `validate` prop on form library (Formik `validateOnChange` vs `validateOnBlur`). Vue: Vuelidate `$touch()` on blur. HTML5: `pattern` attribute (validates on submit). |
| Browser verify | Fill a form field with invalid data character by character. Observe: does the error message flash on every keystroke (onChange) or appear after tabbing away (onBlur)? |
| Pass | Inline validation triggers on blur (after user leaves field) or on submit. Error messages appear once, not flickering. |
| Fail | Validation fires on every keystroke, causing error messages to flash/flicker during typing. |
| Evidence | Each micro-interruption creates attention residue — up to 40% productive time lost from task-switching. onChange validation compounds this. (Leroy 2009; NN/g 10 Error Guidelines) |

### I5. Form error message quality

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Find error message strings in validation logic, translation files, or error constants. Check: are they specific and actionable, or generic? |
| Code patterns | Bad: `"Invalid input"`, `"Error"`, `"Required"`. Good: `"Email must include @ and a domain"`, `"Password needs at least 8 characters and 1 number"`. |
| Browser verify | Submit a form with intentionally invalid data. Read the error messages. Do they tell the user WHAT is wrong and HOW to fix it? |
| Pass | Every error message names the specific problem AND suggests the fix. No error codes, no generic "Invalid" messages. |
| Fail | Any error message that says only "Invalid", "Error", "Required", or shows a technical error code. |
| Evidence | Errors must be explicit, human-readable, polite, precise, and give constructive advice. (NN/g 10 Error Guidelines) |

### I6. Double-submit prevention

| Field | Value |
|-|-|
| Severity | CRITICAL |
| Code signal | Find form submit handlers and action buttons. Check: does the handler disable the trigger element or set a mutex/loading flag before starting the async operation? |
| Code patterns | `button.disabled = true` or `setSubmitting(true)` BEFORE the API call. Optimistic locking. Debounce on submit. |
| Browser verify | Click the submit button rapidly multiple times. Observe: does it send multiple requests? (Check network tab for duplicate POSTs.) |
| Pass | Submit button disables immediately on click. Multiple rapid clicks produce exactly one request. |
| Fail | Rapid clicking sends multiple duplicate requests. Button remains clickable during submission. |
| Evidence | Double-submit causes duplicate orders, duplicate charges, duplicate account creation. Most common missed interaction pattern in e-commerce. |

### I7. Navigation feedback (active state)

| Field | Value |
|-|-|
| Severity | LOW |
| Code signal | Check navigation components for active/current route styling. Look for `activeClassName`, `router-link-active`, `aria-current="page"`, conditional CSS classes based on current route. |
| Code patterns | React Router: `<NavLink activeClassName="active">`. Vue Router: `.router-link-active` class. Next.js: `usePathname()` comparison. |
| Browser verify | Navigate between pages. Observe: does the nav highlight update to show the current page? |
| Pass | Current page/section is visually highlighted in navigation at all times. |
| Fail | Navigation shows no indication of current location. All nav items look identical regardless of active route. |
| Evidence | Nielsen Heuristic #1 (Visibility of System Status) — user must always know where they are. |

### I8. Back button behavior

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Check for `history.pushState`, `router.push` vs `router.replace`. Check for `beforeRouteLeave` guards that warn about unsaved changes. Check for `popstate` event handlers. |
| Code patterns | Multi-step forms: each step should push to history (not replace). Modals: should not break back button (use hash routing or intercepting). SPAs: check that route changes produce history entries. |
| Browser verify | Complete 3+ steps in any flow, then press browser back button. Observe: does it go back one step, or jump to a completely different page / break the UI? |
| Pass | Back button navigates to the previous logical step in every flow. Unsaved data prompts a confirmation dialog. |
| Fail | Back button skips steps, navigates to unexpected pages, breaks modal state, or loses user-entered data without warning. |
| Evidence | Nielsen Heuristic #3 (User Control and Freedom) — "emergency exits" must always work. Back button is the primary emergency exit. |

### I9. Keyboard navigation (tab order)

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Check interactive elements for `tabIndex` attributes. Check for non-semantic interactive elements (`<div onClick>` without `tabIndex={0}` and `role="button"`). Check for focus traps in modals (`focus-trap` library or manual implementation). |
| Code patterns | Bad: `<div onClick={handleClick}>Click me</div>` (not keyboard accessible). Good: `<button onClick={handleClick}>Click me</button>` or `<div role="button" tabIndex={0} onKeyDown={handleKeyDown} onClick={handleClick}>`. |
| Browser verify | Tab through the page using only keyboard. Observe: can you reach all interactive elements? Is the order logical (top-to-bottom, left-to-right)? Can you activate buttons with Enter/Space? |
| Pass | All interactive elements reachable via Tab. Logical tab order matching visual layout. Buttons activate with Enter/Space. |
| Fail | Any interactive element unreachable by keyboard. Tab order jumps illogically. Non-semantic elements (`div`, `span`) used as buttons without keyboard support. |
| Evidence | 50-72% of mobile users have accessibility settings enabled — keyboard navigation is mainstream, not niche. (AccessibilityChecker 2026) |

### I10. Focus management (modals and overlays)

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Find modal/dialog components. Check: does opening the modal move focus INTO the modal? Does closing return focus to the trigger element? Is focus trapped inside the modal while open? |
| Code patterns | React: `useRef` + `focus()` on mount. Radix UI/Headless UI: built-in focus management. HTML `<dialog>` element: native focus trapping. `focus-trap-react` library. |
| Browser verify | Open a modal using keyboard (Tab to trigger, press Enter). Observe: does focus move to the modal? Tab through the modal — does focus stay inside? Close the modal — does focus return to the trigger? |
| Pass | Focus moves to modal on open. Focus is trapped inside modal. Focus returns to trigger on close. Escape key closes modal. |
| Fail | Focus remains behind the modal (user tabs through background elements). Focus lost on close (goes to document top). No Escape key handler. |
| Evidence | WCAG 2.1 Focus Management — modal content must trap focus. Screen reader users are completely lost if focus is not managed. |

### I11. State preservation in multi-step flows

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Find multi-step forms/wizards. Check: is form data stored in component state that survives step navigation? Or does each step mount a new component losing previous data? |
| Code patterns | Good: Form state in parent component, context, or store. Data persists when navigating between steps. Bad: Each step is a separate route with no shared state. |
| Browser verify | Fill in Step 1 of a multi-step form. Navigate to Step 2. Go back to Step 1. Observe: is the data still there? |
| Pass | All entered data persists when navigating between steps in any direction. |
| Fail | Going back to a previous step shows empty fields. Data entered in prior steps is lost. |
| Evidence | Up to 10% conversion improvement by fixing data persistence between multi-step form pages. (Zuko) |

### I12. Destructive action confirmation

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Find delete/remove/cancel/unsubscribe handlers. Check: is there a confirmation dialog before the destructive action executes? |
| Code patterns | `window.confirm()` (basic). Custom confirmation modal with explicit "Delete" button (better). Undo pattern with timer (best — Gmail-style). |
| Browser verify | Trigger a destructive action (delete an item, cancel a subscription). Observe: is there a confirmation step, or does it execute immediately? |
| Pass | All destructive actions require explicit confirmation. Confirmation uses descriptive button labels ("Delete this item" not just "OK"). |
| Fail | Any destructive action executes on single click without confirmation. Confirmation dialog uses "OK/Cancel" instead of descriptive labels. |
| Evidence | Nielsen Heuristic #5 (Error Prevention) — prevent errors through confirmation dialogs for irreversible actions. |

### I13. Responsive layout integrity

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Check CSS for responsive breakpoints (`@media`, Tailwind responsive prefixes `sm:`, `md:`, `lg:`). Check for `overflow: hidden` that might clip content. Check for fixed widths that don't adapt. |
| Code patterns | Good: Fluid grids, responsive breakpoints, `max-width` constraints. Bad: Fixed `width: 1200px`, `position: absolute` with pixel values, hardcoded pixel widths on containers. |
| Browser verify | Resize viewport to: 375px (mobile), 768px (tablet), 1440px (desktop). At each size, check: does content overflow? Do elements overlap? Is text readable? Are touch targets adequate? |
| Pass | Layout adapts cleanly at all three breakpoints. No horizontal overflow. No overlapping elements. Text remains readable. |
| Fail | Content overflows viewport. Elements overlap. Text truncated without ellipsis. Horizontal scroll appears. |
| Evidence | Mobile abandonment rate 75-80% vs desktop 65-70%. Broken mobile layout directly drives abandonment. (Baymard/Contentsquare) |

### I14. Scroll behavior and infinite lists

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Find list/grid components rendering dynamic data. Check: is there pagination, infinite scroll, or virtualization? For infinite scroll: is there a loading indicator at the bottom? |
| Code patterns | React: `react-window`, `react-virtuoso`, intersection observer for infinite scroll. Vue: `vue-virtual-scroller`. Pagination: page number params in URL. |
| Browser verify | Scroll to the bottom of a long list. Observe: does it load more items? Is there a loading indicator? Does scroll position reset on navigation? |
| Pass | Long lists use pagination or infinite scroll with loading indicator. Scroll position preserved on back navigation. Virtualization for 100+ items. |
| Fail | All items rendered at once (performance degradation). No loading indicator during infinite scroll. Scroll position lost on back navigation. |
| Evidence | Rendering 1000+ DOM nodes causes jank. Scroll position loss forces users to re-navigate. |

### I15. Empty state handling

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Find list/grid/dashboard components. Check: is there a conditional render for when data is empty (`items.length === 0`)? Does the empty state provide guidance? |
| Code patterns | Good: `{items.length === 0 ? <EmptyState message="No orders yet" action="Browse products" /> : <ItemList />}`. Bad: Renders an empty container with no guidance. |
| Browser verify | Navigate to a page that could have no data (empty cart, no orders, no notifications). Observe: does it show helpful empty state or just blank space? |
| Pass | Empty states show: explanatory message + illustration/icon + primary action to resolve ("Add your first item"). |
| Fail | Empty pages show blank space, empty tables with headers but no rows, or "No data" with no guidance. |
| Evidence | Empty dashboard redesign increased first-transaction activation from 30% to 67%. (Phenomenon Studio) |

### I16. Notification/permission request timing

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Search for push notification permission requests, geolocation requests, camera/microphone requests. Check: do they fire on page load or after a user-initiated action? |
| Code patterns | Bad: `Notification.requestPermission()` in `useEffect([], ...)` or `mounted()`. Good: Permission requested after user clicks a relevant feature (e.g., "Enable notifications" button). |
| Browser verify | Load the app fresh. Observe: does a permission dialog appear immediately, or only after relevant user action? |
| Pass | Permissions requested only after user-initiated action with pre-permission explanation of benefit. |
| Fail | Permission dialog appears on page load without context or explanation. |
| Evidence | Users are 12% more likely to grant permission when given a reason. Best explanation produces 81% lift over worst. (NN/g, citing Tan et al.) |

### I17. Link and button distinction

| Field | Value |
|-|-|
| Severity | LOW |
| Code signal | Check for `<a>` tags used as buttons (no `href`, only `onClick`) and `<button>` tags used as links (navigate on click). Check for proper semantic HTML. |
| Code patterns | Bad: `<a onClick={handleAction}>Submit</a>` (link semantics for button action). Bad: `<button onClick={() => navigate('/page')}>Go</button>` (button semantics for navigation). Good: `<a href="/page">Go</a>` and `<button type="submit">Submit</button>`. |
| Browser verify | Right-click links — do they offer "Open in new tab"? Do buttons look like buttons and links look like links? |
| Pass | `<a>` tags for navigation (have `href`), `<button>` tags for actions. Visual styling matches semantic role. |
| Fail | Semantic mismatch: links without href, buttons that navigate, divs as interactive elements. |
| Evidence | Screen readers announce elements by their semantic role. Mismatched semantics confuse assistive technology users. |

### I18. Toast/snackbar behavior

| Field | Value |
|-|-|
| Severity | LOW |
| Code signal | Find toast/snackbar/notification components. Check: do they auto-dismiss? What is the duration? Do they stack or replace? Is there a dismiss button? |
| Code patterns | Good: 5-8s auto-dismiss for success messages. Persistent for errors (user must dismiss). Stacking with max 3 visible. Bad: 2s auto-dismiss for error messages. Infinite stacking. |
| Browser verify | Trigger multiple toasts rapidly. Observe: do they stack properly? Can you dismiss them? Do error toasts persist long enough to read? |
| Pass | Success toasts auto-dismiss (5-8s). Error toasts persist until dismissed. Max 3 visible. Dismiss button on each. |
| Fail | Error messages auto-dismiss before user can read them. Toasts stack infinitely, covering content. No dismiss option. |
| Evidence | Error messages must persist — users need time to read and act on them. Auto-dismissing errors is information loss. |

### I19. Optimistic UI updates

| Field | Value |
|-|-|
| Severity | LOW |
| Code signal | Find toggle/like/favorite/bookmark actions. Check: does the UI update immediately (optimistic) and rollback on failure, or wait for server response? |
| Code patterns | Good: Update UI state immediately, then send API request. On failure, revert state and show error. Bad: Show spinner, wait for API, then update UI. |
| Browser verify | Toggle a setting or like a post. Observe: does it update instantly or after a loading delay? |
| Pass | Toggle-type actions update UI immediately. Failures show clear rollback. |
| Fail | Every toggle action shows a loading spinner and waits for server response before UI update. |
| Evidence | Doherty Threshold — 400ms feedback window. Optimistic updates provide instant feedback for low-risk actions. |

### I20. URL reflects application state

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Check router configuration. Do filters, search queries, pagination, selected tabs, and modal states reflect in the URL? |
| Code patterns | Good: `/products?category=shoes&sort=price&page=2`. Bad: All filter state in component memory, URL always shows `/products`. |
| Browser verify | Apply filters or navigate to a specific state. Copy the URL. Open in a new tab. Observe: does it restore the same state? |
| Pass | Meaningful application state (filters, pagination, search, tabs) reflected in URL. Sharing/bookmarking URLs restores the correct view. |
| Fail | URL never changes despite navigation/filtering. Refreshing the page resets all user selections. |
| Evidence | URLs are the primary sharing and bookmarking mechanism. State loss on refresh is a top user frustration. |

---

## Performance Checks

### P1. First Contentful Paint (FCP)

| Field | Value |
|-|-|
| Severity | HIGH |
| Tool | Chrome DevTools Lighthouse or Performance panel |
| Threshold | Good: <1.8s. Needs improvement: 1.8-3.0s. Poor: >3.0s. |
| Code signal | Check `<head>` for render-blocking CSS/JS. Check for `async`/`defer` on scripts. Check for critical CSS inlining. Check for preload hints (`<link rel="preload">`). |
| Pass | FCP < 1.8s on throttled connection (Slow 4G). |
| Fail | FCP > 3.0s. Or: large render-blocking resources in `<head>` without `async`/`defer`. |
| Evidence | Core Web Vital. Google ranking signal. |

### P2. Largest Contentful Paint (LCP)

| Field | Value |
|-|-|
| Severity | HIGH |
| Tool | Chrome DevTools Lighthouse or Performance panel |
| Threshold | Good: <2.5s. Needs improvement: 2.5-4.0s. Poor: >4.0s. |
| Code signal | Identify the largest visible element (hero image, heading, video poster). Check: is it lazy-loaded (bad for LCP element)? Is the image optimized (WebP/AVIF, proper sizing)? Is there a `fetchpriority="high"` on the LCP image? |
| Pass | LCP < 2.5s. LCP element has `fetchpriority="high"` and is not lazy-loaded. |
| Fail | LCP > 4.0s. LCP image is lazy-loaded. No image optimization. |
| Evidence | Core Web Vital. Google ranking signal. |

### P3. Cumulative Layout Shift (CLS)

| Field | Value |
|-|-|
| Severity | HIGH |
| Tool | Chrome DevTools Lighthouse or Performance panel |
| Threshold | Good: <0.1. Needs improvement: 0.1-0.25. Poor: >0.25. |
| Code signal | Check images for explicit `width`/`height` attributes or CSS `aspect-ratio`. Check for dynamic content injection above the fold (ads, banners, lazy-loaded elements). Check for font loading strategy (`font-display: swap` without size-adjust). |
| Pass | CLS < 0.1. All images have explicit dimensions. No content shifts visible during load. |
| Fail | CLS > 0.25. Images without dimensions cause reflow. Dynamic content pushes existing content down. |
| Evidence | Core Web Vital. Layout shifts directly cause mis-clicks and user frustration. |

### P4. Total Blocking Time (TBT)

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Tool | Chrome DevTools Lighthouse |
| Threshold | Good: <200ms. Needs improvement: 200-600ms. Poor: >600ms. |
| Code signal | Check for large synchronous JavaScript bundles. Check for heavy computations in render path. Check bundle size (`npm run build` output or bundle analyzer). |
| Pass | TBT < 200ms. No single JS task blocks main thread for >50ms. |
| Fail | TBT > 600ms. Large monolithic bundles. Heavy computation in render path. |
| Evidence | TBT correlates with First Input Delay. High TBT = unresponsive UI during load. |

### P5. Image optimization

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Check image formats (JPEG/PNG vs WebP/AVIF). Check for `srcset`/`sizes` attributes for responsive images. Check for lazy loading on below-fold images. Check image dimensions vs display size. |
| Code patterns | Good: `<img src="photo.webp" srcset="photo-400.webp 400w, photo-800.webp 800w" sizes="(max-width: 600px) 400px, 800px" loading="lazy" />`. Bad: `<img src="photo.png" />` (no optimization, no lazy load, no responsive sizing). |
| Browser verify | Open DevTools Network tab. Filter by images. Check: are images served in modern formats? Are below-fold images lazy-loaded? Are image sizes appropriate for display size? |
| Pass | Images use WebP/AVIF. Below-fold images lazy-loaded. Responsive `srcset` on variable-size images. No images >200KB on mobile. |
| Fail | Large PNG/JPEG images. No lazy loading. Images served at 2000px width for 400px display. |
| Evidence | Images are typically 50%+ of page weight. Unoptimized images are the #1 cause of slow LCP. |

### P6. Bundle size

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Check `package.json` dependencies. Look for heavy libraries (`moment.js` → use `date-fns` or `dayjs`; `lodash` full import → use `lodash-es` tree-shaking). Check for code splitting on routes. |
| Code patterns | Good: Dynamic imports for routes (`lazy(() => import('./HeavyPage'))`). Tree-shakeable imports (`import { debounce } from 'lodash-es'`). Bad: `import _ from 'lodash'` (imports entire library). |
| Browser verify | Check DevTools Network tab, JS size on initial load. Or run Lighthouse and check "Reduce unused JavaScript" audit. |
| Pass | Initial JS bundle < 200KB gzipped. Route-based code splitting. No full-library imports when tree-shaking available. |
| Fail | Initial JS > 500KB gzipped. No code splitting. Full `lodash` or `moment.js` imports. |
| Evidence | Each 100KB of JS adds ~300ms parse time on mobile devices. |

### P7. Font loading strategy

| Field | Value |
|-|-|
| Severity | LOW |
| Code signal | Check CSS `@font-face` declarations for `font-display` property. Check for font preloading (`<link rel="preload" as="font">`). Check number of font files loaded. |
| Code patterns | Good: `font-display: swap` with `size-adjust` to minimize CLS. `<link rel="preload" href="font.woff2" as="font" crossorigin>`. Bad: No `font-display` (FOIT — flash of invisible text). Loading 10+ font weights. |
| Pass | `font-display: swap` or `optional`. Critical fonts preloaded. Max 4-6 font files total. |
| Fail | No `font-display` strategy. 10+ font files. No preloading. Flash of invisible text visible. |
| Evidence | FOIT makes content unreadable for 100-3000ms. Each font file is an additional request. |

### P8. Caching headers

| Field | Value |
|-|-|
| Severity | LOW |
| Code signal | Check server config or CDN settings for `Cache-Control` headers on static assets. Check for content hashing in filenames (e.g., `app.abc123.js`). |
| Browser verify | Open DevTools Network tab. Check response headers on JS/CSS/image files. Look for `Cache-Control: max-age=31536000` on hashed assets and `no-cache` on HTML. |
| Pass | Hashed static assets cached for 1 year. HTML served with `no-cache` or short max-age. Service worker for offline support if applicable. |
| Fail | No caching headers. Or HTML cached long-term (stale content risk). |
| Evidence | Proper caching eliminates redundant downloads on repeat visits, improving load time by 50-90%. |

---

## Accessibility Checks

### A1. Semantic HTML structure

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Check page structure: `<header>`, `<nav>`, `<main>`, `<footer>`, `<article>`, `<section>`, `<aside>`. Check heading hierarchy: `<h1>` through `<h6>` in order, no skipped levels. |
| Code patterns | Bad: `<div class="header">`, `<div class="nav">`, nested `<div>`s everywhere. Good: Semantic elements with ARIA landmarks where needed. |
| Browser verify | Open DevTools Accessibility tree. Check: are landmarks identified? Is heading hierarchy sequential? |
| Pass | Page uses semantic HTML. One `<h1>` per page. Heading levels sequential (no h1 → h3 skip). Landmarks present. |
| Fail | Page is entirely `<div>` based. Multiple `<h1>` tags. Heading levels skip (h1 → h4). No landmarks. |
| Evidence | Screen readers navigate by landmarks and headings. Without semantic structure, screen reader users cannot orient themselves. |

### A2. Image alt text

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Find all `<img>` elements. Check: does every informational image have a meaningful `alt` attribute? Do decorative images have `alt=""` (empty alt) or `role="presentation"`? |
| Code patterns | Bad: `<img src="product.jpg">` (no alt). Bad: `<img src="decorative-line.svg" alt="decorative line">` (unnecessary alt on decorative). Good: `<img src="product.jpg" alt="Blue running shoe, side view">`. Good: `<img src="divider.svg" alt="" role="presentation">`. |
| Pass | All informational images have descriptive alt text. All decorative images have empty alt or role="presentation". |
| Fail | Any informational image missing alt attribute. Decorative images with meaningless alt text ("image", "photo", "icon"). |
| Evidence | WCAG 1.1.1 Non-text Content (Level A). Screen readers read alt text aloud — missing or poor alt makes images invisible to blind users. |

### A3. Form label association

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Find all `<input>`, `<select>`, `<textarea>` elements. Check: does each have an associated `<label>` (via `for`/`htmlFor` attribute matching input `id`) or `aria-label`/`aria-labelledby`? |
| Code patterns | Good: `<label htmlFor="email">Email</label><input id="email" />`. Good: `<input aria-label="Search" />`. Bad: `<input placeholder="Email" />` (placeholder is NOT a label). |
| Pass | Every form input has an associated label (visible label with `for`/`htmlFor`, or `aria-label` for icon-only inputs). |
| Fail | Any input with only a placeholder as its label. Any input without label association. |
| Evidence | WCAG 1.3.1 Info and Relationships (Level A). Unlabeled inputs are invisible to screen readers. |

### A4. ARIA attributes correctness

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Find all `aria-*` attributes. Check: are `aria-expanded`, `aria-selected`, `aria-checked`, `aria-hidden` dynamically updated to match visual state? Are ARIA roles correct (`role="button"` on non-button interactive elements)? |
| Code patterns | Bad: `aria-expanded="true"` hardcoded on a collapsible that can be closed. Bad: `aria-hidden="true"` on visible, interactive content. Good: `aria-expanded={isOpen}` bound to state. |
| Browser verify | Toggle interactive elements (dropdowns, accordions, tabs). Check DevTools Accessibility tree: do ARIA states update to match visual state? |
| Pass | All ARIA attributes dynamically reflect current visual state. No stale ARIA values. |
| Fail | ARIA attributes that don't update when visual state changes. `aria-hidden="true"` on visible interactive content. |
| Evidence | Incorrect ARIA is worse than no ARIA — it actively misleads assistive technology users. |

### A5. Focus indicator visibility

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Search for `outline: none`, `outline: 0`, `:focus { outline: none }` in CSS. Check if custom focus styles are defined as replacements. |
| Code patterns | Bad: `*:focus { outline: none }` with no replacement. Good: `*:focus-visible { outline: 2px solid #4A90D9; outline-offset: 2px; }`. |
| Browser verify | Tab through the page. Observe: can you see which element is focused at all times? |
| Pass | Every focusable element has a visible focus indicator (outline, ring, or highlight). Focus indicator has sufficient contrast (3:1 against adjacent colors). |
| Fail | Focus indicator removed globally with `outline: none` and no replacement. Invisible focus state on any interactive element. |
| Evidence | WCAG 2.4.7 Focus Visible (Level AA). Users navigating by keyboard cannot use the interface if they cannot see what is focused. |

### A6. Color contrast compliance

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Check color definitions (CSS variables, theme tokens, Tailwind config). Compute contrast ratios for text/background pairs using defined color values. |
| Code patterns | Check: text colors against background colors. Placeholder text against input backgrounds. Disabled state colors. Error/success message colors. |
| Browser verify | Run Lighthouse accessibility audit or use Chrome DevTools "CSS Overview" panel for contrast issues. |
| Pass | All text meets WCAG AA: 4.5:1 for normal text, 3:1 for large text (18px+ or 14px+ bold). |
| Fail | Any text-background pair below minimum contrast ratio. Especially: light gray placeholder text, low-contrast disabled states. |
| Evidence | WCAG 1.4.3 Contrast Minimum (Level AA). 9% of population has color vision deficiency. |

### A7. Skip navigation link

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Check for a skip link as the first focusable element: `<a href="#main-content" class="sr-only focus:not-sr-only">Skip to content</a>`. Check that `#main-content` target exists. |
| Browser verify | Press Tab once on page load. Observe: does a "Skip to content" link appear? Does activating it jump focus to main content? |
| Pass | Skip link is first focusable element. Becomes visible on focus. Jumps to main content area. |
| Fail | No skip link. Or skip link present but target ID missing (link does nothing). |
| Evidence | WCAG 2.4.1 Bypass Blocks (Level A). Keyboard users must navigate past header/nav on every page without a skip link. |

### A8. Touch target sizing

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Check button/link dimensions in CSS. Look for `min-height`, `min-width`, `padding` on interactive elements. Check for spacing between adjacent targets. |
| Code patterns | Good: `min-height: 44px; min-width: 44px;` or padding that achieves 44x44px minimum. Bad: Icon buttons with no padding (`width: 24px; height: 24px;`). |
| Browser verify | On mobile viewport (375px), inspect interactive element dimensions. Check: are all touch targets >= 44x44 CSS px? Is spacing between adjacent targets >= 8px? |
| Pass | All interactive elements >= 44x44px. Adjacent targets have >= 8px spacing. |
| Fail | Any interactive element < 44x44px. Tightly packed targets with < 8px gap. |
| Evidence | WCAG 2.5.8 Target Size Minimum (Level AA). Apple HIG: 44pt. Google Material: 48dp. 35% of mobile users report small targets as a common issue. |

### A9. Color not sole indicator

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Find status indicators, error states, success states, required field markers, active tabs. Check: does color have a secondary indicator (icon, text, border style, pattern)? |
| Code patterns | Bad: Red border only for error. Green only for success. Bad: Required fields marked only with red asterisk (fails for red-green colorblind). Good: Red border + error icon + error text. Required fields with asterisk + "(required)" text. |
| Pass | Every color-coded state has a secondary non-color indicator (icon, text, pattern, underline). |
| Fail | Any status communicated solely by color. Especially: red/green success/error without icons or text. |
| Evidence | ~9% of population has color vision deficiency. Red-green colorblindness affects ~8% of males. |

### A10. Reduced motion support

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Search for CSS animations/transitions. Check for `@media (prefers-reduced-motion: reduce)` that disables or minimizes animations. Check for JavaScript animation libraries respecting this preference. |
| Code patterns | Good: `@media (prefers-reduced-motion: reduce) { *, *::before, *::after { animation-duration: 0.01ms !important; transition-duration: 0.01ms !important; } }`. Also: checking `matchMedia('(prefers-reduced-motion: reduce)')` in JS. |
| Pass | Animations respect `prefers-reduced-motion`. Essential animations replaced with fade or instant transitions. |
| Fail | Animations ignore reduced motion preference. Especially: parallax effects, auto-playing carousels, bouncing elements. |
| Evidence | Vestibular disorders affect ~35% of adults over 40. Excessive motion causes dizziness and nausea. |

### A11. Language attribute

| Field | Value |
|-|-|
| Severity | LOW |
| Code signal | Check `<html>` tag for `lang` attribute. For multilingual content, check for `lang` attributes on specific elements. |
| Pass | `<html lang="en">` (or appropriate language code) present. |
| Fail | Missing `lang` attribute on `<html>`. |
| Evidence | WCAG 3.1.1 Language of Page (Level A). Screen readers use the lang attribute to select pronunciation rules. |

### A12. Autocomplete attributes on forms

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Find input fields for common data (name, email, address, phone, credit card). Check for `autocomplete` attributes. |
| Code patterns | Good: `<input name="email" type="email" autocomplete="email">`, `<input name="cc-number" autocomplete="cc-number">`. |
| Pass | All standard personal data inputs have appropriate `autocomplete` values. |
| Fail | Common fields (name, email, address, phone) missing `autocomplete` attribute. |
| Evidence | WCAG 1.3.5 Identify Input Purpose (Level AA). Autocomplete enables browser autofill, reducing form completion time. Address autofill lookup: +19% form completion. (Zuko) |

### A13. Error identification

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Find form validation error rendering. Check: are errors associated with their fields via `aria-describedby`? Is `aria-invalid="true"` set on erroneous fields? |
| Code patterns | Good: `<input aria-invalid="true" aria-describedby="email-error" />` + `<span id="email-error" role="alert">Enter a valid email</span>`. Bad: Error message rendered visually near field but not programmatically associated. |
| Pass | Error messages associated with fields via `aria-describedby`. `aria-invalid` set on erroneous fields. `role="alert"` or `aria-live` on error containers. |
| Fail | Errors not programmatically associated with fields. No `aria-invalid`. Screen readers cannot identify which field has an error. |
| Evidence | WCAG 3.3.1 Error Identification (Level A). Screen reader users cannot locate errors without programmatic association. |

### A14. Page title uniqueness

| Field | Value |
|-|-|
| Severity | LOW |
| Code signal | Check `<title>` or `document.title` setting per route. Each page/view should have a unique, descriptive title. |
| Code patterns | Good: `<title>Checkout - Step 2 of 3 | ShopName</title>`. Bad: Every page has `<title>App</title>`. |
| Pass | Every route has a unique, descriptive page title. Title updates on navigation (SPA). |
| Fail | All pages share the same generic title. Or SPA doesn't update document title on route change. |
| Evidence | WCAG 2.4.2 Page Titled (Level A). Screen reader users use page titles to orient and differentiate tabs. |

### A15. Live region announcements

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Find dynamic content updates (toast notifications, cart count updates, search results count, form submission feedback). Check for `aria-live`, `role="alert"`, `role="status"`. |
| Code patterns | Good: `<div aria-live="polite">3 items in cart</div>` updates when cart changes. `<div role="alert">Form submitted successfully</div>` for important notifications. |
| Pass | Dynamic status updates use `aria-live="polite"`. Urgent notifications use `role="alert"`. |
| Fail | Dynamic content changes silently — screen reader users are unaware of updates. |
| Evidence | WCAG 4.1.3 Status Messages (Level AA). Without live regions, screen readers don't announce dynamic changes. |

---

## Code Quality Checks

### C1. Error boundary coverage

| Field | Value |
|-|-|
| Severity | CRITICAL |
| Code signal | Find the top-level app component and each route/page component. Check: are there error boundaries wrapping async content? |
| Code patterns | React: `<ErrorBoundary>` components wrapping route-level and data-fetching components. Next.js: `error.tsx` per route segment. Vue: `onErrorCaptured` in parent components. Svelte: `+error.svelte` files. |
| Pass | Every route/page has error boundary coverage. Error boundaries render user-friendly fallback UI. |
| Fail | No error boundaries. Or error boundaries only at app root (catches everything but provides no granular recovery). |
| Evidence | Without error boundaries, a single component error crashes the entire app to a white screen. |

### C2. API error handling completeness

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Find all API call sites. For each, verify: (1) network error handling (connection refused, timeout), (2) HTTP error handling (4xx, 5xx), (3) data validation (unexpected response shape), (4) user-facing error rendering. |
| Code patterns | Bad: `const data = await fetch(url).then(r => r.json())` (no error handling). Good: try/catch with specific error types, toast notifications for failures, retry logic for transient errors. |
| Pass | Every API call handles: network errors, HTTP errors, and unexpected response shapes. Each error path renders user-facing feedback. |
| Fail | Any API call without error handling. Any error that logs to console but shows nothing to the user. |
| Evidence | Unhandled API errors are the #1 cause of white screens and broken states in SPAs. |

### C3. Environment variable safety

| Field | Value |
|-|-|
| Severity | CRITICAL |
| Code signal | Check for API keys, secrets, or tokens in client-side code. In Next.js: only `NEXT_PUBLIC_*` vars reach the client. In Vite: only `VITE_*` vars. Check `.env` files for sensitive values without proper prefix. |
| Code patterns | Bad: `const API_KEY = "sk-live-abc123"` hardcoded. Bad: `process.env.SECRET_KEY` used in client component (may leak in bundle). Good: Server-side API routes handle secrets. Client calls server endpoints. |
| Pass | No secrets in client-side code. API keys only on server side. `.env.example` documents required variables. |
| Fail | Hardcoded API keys or secrets. Server environment variables accessible in client bundle. |
| Evidence | OWASP Top 10. Exposed API keys lead to account compromise and financial loss. |

### C4. Component decomposition

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Check component file sizes. Components over 300 lines are candidates for decomposition. Check for "God components" that handle multiple concerns (data fetching + rendering + business logic). |
| Code patterns | Bad: Single 500-line component handling form, validation, API calls, and rendering. Good: Container/presentational split. Custom hooks for logic. Subcomponents for repeated UI patterns. |
| Pass | No component exceeds 300 lines. Each component handles one responsibility. Shared patterns extracted to reusable components. |
| Fail | Components over 500 lines. Single components mixing data fetching, business logic, and complex rendering. |
| Evidence | Large components are harder to test, debug, and maintain. They also increase re-render scope. |

### C5. Prop drilling depth

| Field | Value |
|-|-|
| Severity | LOW |
| Code signal | Trace props through component trees. Check: are any props passed through 3+ intermediate components that don't use them? |
| Code patterns | Bad: `App → Layout → Sidebar → NavItem → Icon` all passing `userId` through props. Good: Context/store for shared state. Props only for direct parent-child relationships. |
| Pass | No prop passed through more than 2 intermediate components. Shared state uses context or state management. |
| Fail | Props threaded through 3+ components that don't use them. |
| Evidence | Prop drilling makes refactoring fragile — changing a prop type requires updating every component in the chain. |

### C6. Type safety on API boundaries

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Check TypeScript usage at API boundaries. Are API response types defined? Is there runtime validation (zod, yup, io-ts) or only TypeScript compile-time types? |
| Code patterns | Good: `const response = schema.parse(await fetch(url).then(r => r.json()))`. Bad: `const data = await fetch(url).then(r => r.json()) as MyType` (type assertion, no runtime validation). |
| Pass | API responses validated at runtime (zod, yup). TypeScript types generated from or aligned with API schema. |
| Fail | Type assertions (`as Type`) on API responses without runtime validation. `any` types on API data. |
| Evidence | APIs return unexpected shapes during outages, version mismatches, and edge cases. Type assertions give false confidence. |

### C7. Consistent error handling pattern

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Sample 5+ API call sites. Check: do they all handle errors the same way? Same toast library? Same error message format? Same retry pattern? |
| Pass | All API calls follow the same error handling pattern (centralized error handler, consistent toast notifications, uniform error message format). |
| Fail | Mixed error handling: some use `try/catch`, some use `.catch()`, some don't handle at all. Different toast libraries in different components. |
| Evidence | Inconsistent error handling means some errors are caught and some aren't. Users experience unpredictable behavior. |

### C8. Loading state architecture

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Check for a consistent loading state pattern. Is there a shared `<Skeleton>` or `<Spinner>` component? Or does each component implement its own loading UI? |
| Code patterns | Good: Shared `<Skeleton>` component with variants. Loading state convention (e.g., `isLoading` variable name). Bad: Each page has ad-hoc loading implementation. Some use spinners, some use text, some show nothing. |
| Pass | Consistent loading component used across the app. Loading state convention followed. |
| Fail | No shared loading component. Each page implements loading differently. Some pages have no loading state at all. |
| Evidence | Visual consistency builds user confidence. Inconsistent loading patterns feel unpolished and untrustworthy. |

### C9. Route-level code splitting

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Code signal | Check route definitions for dynamic imports. Static imports of page components mean they're all in the initial bundle. |
| Code patterns | React: `lazy(() => import('./pages/Dashboard'))`. Next.js: automatic per-page splitting. Vue: `() => import('./views/Dashboard.vue')`. Nuxt: automatic. |
| Pass | Routes use dynamic imports (or framework provides automatic splitting). |
| Fail | All page components statically imported at the route definition level. |
| Evidence | Route-level code splitting reduces initial bundle by 30-70%, directly improving FCP and TTI. |

### C10. Hardcoded strings vs i18n

| Field | Value |
|-|-|
| Severity | LOW |
| Code signal | Check for hardcoded user-facing strings in component templates/JSX. Check if an i18n library is configured (react-intl, vue-i18n, next-intl). |
| Pass | If i18n is a project requirement: all user-facing strings use translation keys. If not: strings are at least centralized in constants (not inline). |
| Fail | Mix of i18n keys and hardcoded strings in the same project. Or: i18n configured but many components bypass it with hardcoded text. |
| Evidence | Hardcoded strings make localization impossible without touching every component. |

### C11. State management consistency

| Field | Value |
|-|-|
| Severity | LOW |
| Code signal | Check what state management patterns are used. Count distinct patterns: local state, context, Redux/Zustand/Pinia, URL state, localStorage. Are they used consistently for similar use cases? |
| Pass | Consistent pattern: global state in store, form state local, URL state for shareable selections. Clear boundaries. |
| Fail | Same type of state managed 3+ different ways across the app. No clear pattern for when to use which approach. |
| Evidence | Inconsistent state management makes bugs harder to trace and behavior harder to predict. |

### C12. Security headers and CSP

| Field | Value |
|-|-|
| Severity | HIGH |
| Code signal | Check server configuration or middleware for security headers: `Content-Security-Policy`, `X-Content-Type-Options`, `X-Frame-Options`, `Strict-Transport-Security`. |
| Browser verify | Check response headers in DevTools Network tab on the HTML document request. |
| Pass | CSP header present. `X-Content-Type-Options: nosniff`. `X-Frame-Options: DENY` or `SAMEORIGIN`. HSTS header on HTTPS sites. |
| Fail | No security headers. Missing CSP. Missing HSTS on HTTPS site. |
| Evidence | OWASP Top 10. Missing security headers enable XSS, clickjacking, and MIME-type attacks. |

---

## Visual Checks

Apply these checks to screenshots captured during behavioral testing. Use the preprocessing script output (`grid.png`, `blur.png`, `grayscale.png`, `analysis.txt`) for systematic visual analysis.

### V1. CTA pop-out

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Screenshot signal | Examine `grayscale.png`. Identify the primary action button. Does it stand out from surrounding elements by size, weight, or contrast alone — without relying on color? |
| Pass | CTA has at least one unique pre-attentive attribute (size, shape, contrast) — findable without reading text. |
| Fail | CTA shares color/size/weight with other buttons, or blends into surrounding elements. |
| Evidence | Treisman Feature Integration Theory — unique pre-attentive features detected in <200ms. (NC State Perception Lab) |

### V2. Single primary action

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Screenshot signal | Count equally-weighted CTAs per visible screen section. Check for competing buttons of similar size, color, and prominence. |
| Pass | One primary CTA per section. Secondary actions visually subordinate (smaller, lighter, ghost/outline style). |
| Fail | 3+ CTAs competing at equal visual weight in the same section. |
| Evidence | Every.org split multi-CTA → single-CTA: +26.5% conversions. (Contentsquare; Hick's Law) |

### V3. Information scent

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Screenshot signal | Read navigation labels, headings, and CTA text. Do they contain goal-specific trigger words or are they generic? |
| Pass | Specific, descriptive labels — "See pricing plans", "Track your order", "Compare features". |
| Fail | Generic labels — "Learn More", "Get Started", "Solutions", "Click Here". |
| Evidence | Pirolli & Card 1999, information foraging theory. |

### V4. Cognitive load (squint test)

| Field | Value |
|-|-|
| Severity | HIGH |
| Screenshot signal | Use `blur.png`. Can you identify: (a) primary action, (b) information groupings, (c) current position in flow? |
| Pass | All three identifiable when blurred. Clear visual zones. |
| Fail | 3+ visual groupings competing at equal weight, or primary action disappears when blurred. |
| Evidence | Sweller Cognitive Load Theory. |

### V5. Visual hierarchy without color

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Screenshot signal | Use `grayscale.png`. Are headings, body text, and CTAs distinguishable by size and weight alone? |
| Pass | Clear hierarchy through size and weight — heading > subheading > body > caption distinguishable. |
| Fail | Everything appears at same gray weight. No size differentiation between heading and body. |
| Evidence | Von Restorff 1933. |

### V6. F-pattern content placement

| Field | Value |
|-|-|
| Severity | LOW |
| Screenshot signal | Check position of key content and primary CTA relative to grid quadrants. Use `grid.png`. |
| Pass | Key content in top-left quadrant and first two horizontal scan bands. CTA in natural scan path. |
| Fail | Primary information or CTA placed in bottom-right quadrant (F-pattern dead zone). |
| Evidence | NN/g eye-tracking, 45-47 participants. |

### V7. Grouping and proximity

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Screenshot signal | Check spatial relationships: labels near their fields? Prices near products? Related items grouped with whitespace or borders separating groups? |
| Pass | Related items proximate. Unrelated items separated by whitespace or visual dividers. |
| Fail | Labels far from their inputs. Price disconnected from product. Form fields in illogical groupings. |
| Evidence | Gestalt proximity principle. |

### V8. Professional visual design

| Field | Value |
|-|-|
| Severity | HIGH |
| Screenshot signal | Examine alignment, spacing rhythm, color coherence, typography consistency across the entire page. |
| Pass | Consistent grid alignment, uniform spacing increments, cohesive color palette, consistent font sizes. |
| Fail | Misaligned elements, inconsistent spacing, clashing colors, mixed font sizes without hierarchy purpose. |
| Evidence | 46.1% assess credibility by visual design alone — #1 factor. (Stanford, Fogg 2002, N=2684) |

### V9. Organizational identity

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Screenshot signal | Look for company name, logo, "About" link, physical address, or other organizational identifiers. |
| Pass | Real organization clearly identified — logo + name visible. |
| Fail | Anonymous page — no name, logo, or identity signals. |
| Evidence | Stanford 10 Credibility Guidelines. |

### V10. Contact information

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Screenshot signal | Look for email, phone number, chat widget, or "Contact" link visible on page. |
| Pass | At least one contact method visible or prominently linked in header/footer. |
| Fail | No contact information visible anywhere on the page. |
| Evidence | Fogg Prominence-Interpretation Theory. |

### V11. Social proof

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Screenshot signal | Look for reviews, star ratings, testimonials, user counts, client logos, or trust badges near conversion points. |
| Pass | At least one social proof element visible near the primary conversion action. |
| Fail | Conversion-critical page (product detail, pricing, checkout) with zero social proof elements. |
| Evidence | +270% purchase likelihood with reviews. (WiserNotify) |

### V12. Dark pattern detection

| Field | Value |
|-|-|
| Severity | CRITICAL |
| Screenshot signal | Look for: confirmshaming (guilt-trip decline text), fake scarcity (resetting timers), pre-checked consent boxes, disguised ads, trick questions, hidden costs. |
| Pass | No emotional manipulation. Straightforward opt-out with neutral language. |
| Fail | Confirmshaming ("No thanks, I don't want to save money"), resetting countdown timers, pre-checked marketing consent, misdirection. |
| Evidence | 76% of websites use at least one dark pattern. (FTC 2024) |

### V13. Contrast ratios

| Field | Value |
|-|-|
| Severity | HIGH |
| Screenshot signal | Use `analysis.txt` computed WCAG contrast ratios for all text-background color pairs. |
| Pass | All text-background pairs meet WCAG AA: 4.5:1 for normal text, 3:1 for large text (18px+ or 14px+ bold). |
| Fail | Any text-background pair below 3:1 contrast ratio. |
| Evidence | WCAG 2.1 SC 1.4.3; ~9% color vision deficiency prevalence. |

### V14. Color not sole indicator

| Field | Value |
|-|-|
| Severity | HIGH |
| Screenshot signal | Use `grayscale.png`. Identify all status indicators, error states, success states, and interactive elements. Are they distinguishable without color? |
| Pass | All status indicators use icons, text labels, or patterns in addition to color. |
| Fail | Red/green as sole differentiator for status. Error states indicated only by color change. |
| Evidence | ~9% color vision deficiency (8% males, 0.5% females). |

### V15. Banner blindness risk

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Screenshot signal | Check if critical information or CTAs are placed in ad-like rectangular blocks, especially in the right column or top banner area. |
| Pass | Critical actions and information embedded in content flow, not in banner-like containers. |
| Fail | Important CTA in bright, rectangular banner block — especially in right sidebar or top strip. |
| Evidence | Benway 1998 + NN/g 1997-2024 eye-tracking studies. |

### V16. Interruption count

| Field | Value |
|-|-|
| Severity | HIGH |
| Screenshot signal | Count modals, badges, alerts, toast notifications, and overlays visible simultaneously. Were they user-initiated or automatic? |
| Pass | 0-1 involuntary interruptions on initial page load. |
| Fail | 2+ simultaneous competing interruptions (cookie banner + newsletter popup + notification permission). |
| Evidence | Attention residue — 40% time lost per involuntary context switch. (Leroy 2009) |

### V17. Menu structure

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Screenshot signal | Count top-level navigation items. Check dropdown depth if visible. |
| Pass | 5-7 primary navigation items. Maximum 2-level dropdown depth. |
| Fail | 8+ undifferentiated navigation items. 3+ level dropdown nesting. |
| Evidence | Hick's Law — decision time increases logarithmically with choices; Miller 3-4 meaningful chunks. |

### V18. Serial position

| Field | Value |
|-|-|
| Severity | LOW |
| Screenshot signal | Check order of navigation items. Are the most important actions placed at the start and end of the list? |
| Pass | Key items positioned first and last in navigation sequence. |
| Fail | Most important navigation items buried in the middle of the list. |
| Evidence | Primacy/recency effects — first and last items recalled best. |

### V19. Anchoring (pricing)

| Field | Value |
|-|-|
| Severity | LOW |
| Screenshot signal | On pricing pages: check the first visible price and left-to-right reading order of plans. Check for strikethrough/original price display. |
| Pass | Strategic anchoring — premium plan shown first, or strikethrough original price with discount visible. |
| Fail | Cheapest plan presented first, anchoring user expectations low. |
| Evidence | Anchoring Index 0.477-0.818. (Frontiers in Psychology 2022, N=194) |

### V20. Defaults serve user

| Field | Value |
|-|-|
| Severity | HIGH |
| Screenshot signal | Check pre-selected options in dropdowns, radio buttons, checkboxes, and plan selectors. Do defaults match likely user preference? |
| Pass | Defaults match most common user choice. No pre-checked marketing consent. |
| Fail | Most expensive option pre-selected. Marketing/newsletter consent pre-checked. Auto-enrollment in paid tier. |
| Evidence | Johnson & Goldstein — defaults persist 70-90% of the time; McKenzie 2006. |

### V21. Loss framing honesty

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Screenshot signal | Look for urgency messaging ("Only 2 left!"), countdown timers, scarcity claims ("Selling fast!"). Check if timers reset on page reload. |
| Pass | Urgency used sparingly and appears genuine. No fake countdown timers. |
| Fail | Stacked urgency signals. Countdown timer that resets on reload. Scarcity claims on unlimited digital goods. |
| Evidence | Loss aversion is strongest conversion driver, but overuse destroys trust. (Jankus ISM, ~21K sessions) |

### V22. Progress indicator

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Screenshot signal | On multi-step flows (checkout, registration, onboarding): is there a visible step indicator showing current position and total steps? |
| Pass | Clear progress indicator showing current step, total steps, and completed steps. |
| Fail | Multi-step flow with no progress indication — user cannot tell how many steps remain. |
| Evidence | +11-25% conversion with progress indicators. (Kivetz 2006, JMR) |

### V23. Endowed progress

| Field | Value |
|-|-|
| Severity | LOW |
| Screenshot signal | On multi-step flows: does the progress bar start above 0% when information is already known (e.g., email from login, address from profile)? |
| Pass | Progress shows partial completion from pre-existing data — user feels ahead. |
| Fail | Progress starts at 0% despite system already having some user data. |
| Evidence | 34% vs 19% redemption rate with endowed progress. (Nunes & Dreze 2006) |

### V24. Peak-end (final screens)

| Field | Value |
|-|-|
| Severity | MEDIUM |
| Screenshot signal | Examine completion/confirmation screens. Is there a positive final moment? Check for celebratory elements, clear next steps, and positive messaging. |
| Pass | Celebratory elements (checkmark, animation, positive copy), clear next-step guidance, warm tone. |
| Fail | Bare transactional text ("Order #12345") with no warmth. Exit pop-ups on completion screen. |
| Evidence | Peak-end rule — experiences judged by peak moment and ending. (Kahneman & Fredrickson 1993) |

---

## E-Commerce Checks

Apply when project contains: shopping cart, product pages, checkout flow, payment processing.

### EC1. Guest checkout
Code signal: Find checkout route/component. Check for authentication gate vs guest flow option.
Pass: Guest checkout option visible alongside login.
Fail: Forced account creation.
Evidence: 25% abandon on forced registration. (Baymard)

### EC2. Cost transparency
Code signal: Check product page and cart components for shipping/tax display logic.
Browser verify: Add item to cart. Observe: are shipping costs visible before final checkout step?
Pass: Shipping/tax shown on product page or cart.
Fail: Costs hidden until payment step.
Evidence: Hidden costs = #1 abandonment cause at 47%. (Baymard, 59 studies)

### EC3. Payment options
Code signal: Check checkout component for payment method integrations.
Browser verify: Count visible payment method icons/logos.
Pass: 3+ payment methods.
Fail: Fewer than 3.
Evidence: +8-19% completion per additional option. (Stripe 2023)

### EC4. Product reviews
Code signal: Check product page for review/rating component integration.
Pass: Reviews visible on product page.
Fail: No reviews section.
Evidence: +34% conversion. (WiserNotify; PowerReviews 2023)

### EC5. Trust signals on payment
Code signal: Check checkout/payment components for trust badge rendering.
Pass: Security badges/logos visible near payment form.
Fail: No trust indicators.
Evidence: +11-19% new customer conversion. (TrustPilot 2023)

### EC6. Sticky CTA on mobile
Code signal: Check product/cart page CSS for `position: fixed` or `position: sticky` on CTA button.
Browser verify: At 375px viewport, scroll the product page. Does CTA remain visible?
Pass: CTA stays visible during scroll on mobile.
Fail: CTA scrolls off screen.
Evidence: +23% conversion. (Unbounce 2024)

### EC7. Delivery information
Code signal: Check product page for shipping/delivery display component.
Pass: Delivery info on product page.
Fail: No delivery info until checkout.
Evidence: +14-26% conversion. (Brillmark)

---

## Games Checks

Apply when project contains: game UI, in-app store, reward screens, tutorial/onboarding, progression systems.

### GA1. Store accessibility
Code signal: Check for store/shop route. Trace navigation path from main game screen to store. Count clicks.
Browser verify: Starting from main game screen, navigate to store. Count taps/clicks.
Pass: Store reachable in <=2 clicks. + symbol or currency icon visible.
Fail: 3+ clicks to store. No recognizable entry point.
Evidence: 2-click rule. Top-grossing games use + symbol. (Gamedeveloper)

### GA2. Store visual hierarchy
Code signal: Check store item components for badge/label rendering, visual differentiation logic.
Pass: "Most Popular", "Best Value" badges. High-revenue items emphasized.
Fail: Flat grid, identical styling.
Evidence: Badge labels help evaluation without mental math. (Gamedeveloper)

### GA3. Tutorial format
Code signal: Find tutorial/onboarding components. Check: interactive gameplay or text screens?
Pass: Interactive tutorial with minimal text. Reward within 60s.
Fail: Text walls before gameplay.
Evidence: 70% disengage in first 20 minutes with poor onboarding. (MoldStud)

### GA4. Tutorial skip option
Code signal: Check tutorial component for skip button/option.
Pass: Skip option available.
Fail: No skip.
Evidence: Returning players forced through tutorials abandon.

### GA5. Progression indicators
Code signal: Find level/XP/progress bar components in main game UI.
Pass: Visible progression system.
Fail: No progression feedback.
Evidence: 67.1% continue due to strong progression. (Keewano)

### GA6. Reward screen design
Code signal: Check reward/result screen components. Do they show earned AND potential rewards?
Pass: Shows earned + unfilled indicators.
Fail: Only earned rewards shown.
Evidence: Unfilled stars motivate replay. Zeigarnik effect. (Gamedeveloper; Zeigarnik 1927)

### GA7. FOMO/scarcity elements
Code signal: Check for countdown timer components, limited-time offer logic, "Exclusive" labels.
Pass: Time-limited offers with clear countdown.
Fail: No urgency on offers, or overuse (every item has timer).
Evidence: FOMO drives IAP engagement. (Gamedeveloper)

### GA8. SDT elements
Code signal: Check for choice/branching (autonomy), skill feedback/difficulty (competence), social features (relatedness).
Pass: 2+ of 3 SDT needs represented.
Fail: Pure reward mechanics without choice, skill, or social.
Evidence: Ryan, Rigby & Przybylski 2006, PENS model.

---

## Registration Checks

Apply when project contains: signup forms, login pages, authentication flows, account creation.

### RE1. Social login
Code signal: Check auth page for social login button components (Google, Apple, Facebook OAuth).
Pass: At least one social option alongside email/password.
Fail: Email/password only.
Evidence: 75% want social login. 86% bothered by new accounts. (Selleo; CXL)

### RE2. Passkey/biometric option
Code signal: Check for WebAuthn/passkey integration, biometric auth components.
Pass: Passkey or biometric option present and prominent.
Fail: Only email/password.
Evidence: 93% passkey success vs 63% traditional. (FIDO 2024)

### RE3. Label alignment
Code signal: Check form field CSS for label positioning (top-aligned vs left-aligned).
Pass: Labels above fields.
Fail: Labels to the left.
Evidence: Top-aligned = fastest completion. (Das et al. 2008, N=312)

### RE4. Form field count and grouping
Code signal: Count form fields per page. Check for multi-step breakdown on 6+ fields.
Pass: <=5 fields per step. 6+ fields split into multi-step with progress.
Fail: 6+ ungrouped fields single-page.
Evidence: Multi-step: +86% conversion for long forms. (HubSpot/Zuko)

### RE5. No confirm-password on mobile
Code signal: Check registration form for confirm/repeat password field.
Pass: Single password field (with show/hide toggle).
Fail: Confirm password field present.
Evidence: Mobile password entry 2x slower. (Zuko)

### RE6. Phone field explanation
Code signal: Check for helper text near phone number input.
Pass: Helper text explains purpose.
Fail: Phone field with no explanation.
Evidence: Unexplained phone = direct abandonment cause. Only 38% accurate. (Baymard/Zuko)

### RE7. Error message quality
Code signal: Find validation error strings. Check specificity and actionability.
Pass: "Password needs at least 1 number" — specific, actionable.
Fail: "Invalid password" — vague.
Evidence: NN/g 10 Error Guidelines.

---

## KYC Checks

Apply when project contains: identity verification, document upload, compliance flows, fintech onboarding.

### KY1. Document list upfront
Code signal: Check KYC flow entry point for document requirement display before upload step.
Pass: Required documents listed before flow starts.
Fail: Documents discovered mid-flow.
Evidence: 38% abandon because documents not on hand. (Bynn)

### KY2. Security messaging
Code signal: Check KYC components for security/privacy messaging throughout flow.
Pass: Security messaging visible on each screen.
Fail: No security reassurance during document upload.
Evidence: 88% cite security as most important. (Bynn)

### KY3. Progress indicator
Code signal: Check KYC flow for step indicator component.
Pass: "Step X of Y" visible.
Fail: No progress indication. Average KYC: 14 screens.
Evidence: 63% fintech drop-off. (Signicat 2022)

### KY4. Post-submission status
Code signal: Check verification completion page for status display.
Pass: Clear status + timeline + next steps.
Fail: Generic "Thank you" with no status.
Evidence: Signicat.

### KY5. Screen complexity
Code signal: Count fields, buttons, and decisions per KYC screen.
Pass: Minimal fields per step, one primary action.
Fail: Dense screen with many fields and competing actions.
Evidence: <3 minutes, <14 screens. 74% switch on complexity. (Bynn; Eleken)

---

=== RECALL: EXECUTION PROTOCOL ===
Before reporting ANY finding, verify: (1) you have a specific code reference (file:line) OR a specific observed behavior, (2) you can name the exact criterion ID violated, (3) the finding includes "so what" — the concrete user harm. Findings without these three elements are REJECTED.
=== END RECALL ===
