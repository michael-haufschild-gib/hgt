import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import './ProgressBarsCelebrationBurst.css'

interface MilestoneAnimation {
  id: number
  index: number
}

export function ProgressBarsCelebrationBurst() {
  const containerRef = useRef<HTMLDivElement>(null)
  const [, setMilestoneAnimations] = useState<MilestoneAnimation[]>([])

  const milestonePositions = useMemo(() => [0, 0.25, 0.5, 0.75, 1], [])

  const timeoutHandlesRef = useRef<Array<ReturnType<typeof setTimeout>>>([])
  const animationControlsRef = useRef<Animation[]>([])
  const reachedMilestonesRef = useRef<Set<number>>(new Set())
  const lastProgressRef = useRef(0)
  const milestoneIdRef = useRef(0)

  const registerTimeout = useCallback((callback: () => void, delay: number) => {
    const handle = setTimeout(() => {
      timeoutHandlesRef.current = timeoutHandlesRef.current.filter((h) => h !== handle)
      callback()
    }, delay)
    timeoutHandlesRef.current.push(handle)
    return handle
  }, [])

  const registerAnimation = useCallback((control: Animation) => {
    animationControlsRef.current.push(control)
    return control
  }, [])

  const clearScheduledWork = useCallback(() => {
    timeoutHandlesRef.current.forEach(clearTimeout)
    timeoutHandlesRef.current = []
    animationControlsRef.current.forEach((control) => control.cancel())
    animationControlsRef.current = []
  }, [])

  const triggerMilestone = useCallback(
    (index: number, markerContainer: HTMLElement, marker: HTMLElement) => {
      const milestoneId = milestoneIdRef.current++
      setMilestoneAnimations((prev) => [...prev, { id: milestoneId, index }])

      // Activate marker with scale animation
      marker.style.transform = 'scale(1.3)'
      marker.style.backgroundColor = 'rgba(168, 85, 247, 1)'
      marker.style.opacity = '1'

      registerTimeout(() => {
        marker.style.transform = 'scale(1)'
      }, 150)

      // Create burst rings
      for (let i = 0; i < 2; i++) {
        const ring = document.createElement('div')
        ring.className = 'burst-ring'
        ring.style.position = 'absolute'
        ring.style.inset = '-4px'
        ring.style.border = `2px solid rgba(168, 85, 247, ${0.8 - i * 0.2})`
        ring.style.borderRadius = '50%'
        ring.style.pointerEvents = 'none'
        markerContainer.appendChild(ring)

        const delay = 40 + i * 40
        registerTimeout(() => {
          const anim = ring.animate(
            [
              { transform: 'scale(0.8)', opacity: '0' },
              { transform: 'scale(2.0)', opacity: '0.6', offset: 0.3 },
              { transform: 'scale(2.0)', opacity: '0' },
            ],
            {
              duration: 300,
              easing: 'cubic-bezier(0.2, 0.8, 0.2, 1)',
            }
          )
          registerAnimation(anim)
          anim.onfinish = () => ring.remove()
        }, delay)
      }

      // Create particles
      const angles = [0, 90, 180, 270]
      angles.forEach((angle) => {
        const particle = document.createElement('div')
        particle.className = 'particle'
        particle.style.position = 'absolute'
        particle.style.left = '50%'
        particle.style.top = '50%'
        particle.style.width = '6px'
        particle.style.height = '6px'
        particle.style.marginLeft = '-3px'
        particle.style.marginTop = '-3px'
        particle.style.borderRadius = '50%'
        particle.style.backgroundColor = 'rgba(168, 85, 247, 1)'
        particle.style.pointerEvents = 'none'
        markerContainer.appendChild(particle)

        const radians = (angle * Math.PI) / 180
        const distance = 30
        const x = Math.cos(radians) * distance
        const y = Math.sin(radians) * distance

        registerTimeout(() => {
          const anim = particle.animate(
            [
              { transform: 'translate(0, 0) scale(0.5)', opacity: '0' },
              { transform: `translate(${x}px, ${y}px) scale(1)`, opacity: '1', offset: 0.3 },
              { transform: `translate(${x}px, ${y}px) scale(0)`, opacity: '0' },
            ],
            {
              duration: 400,
              easing: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
            }
          )
          registerAnimation(anim)
          anim.onfinish = () => particle.remove()
        }, 60)
      })

      // Remove milestone animation marker
      registerTimeout(() => {
        setMilestoneAnimations((prev) => prev.filter((m) => m.id !== milestoneId))
      }, 500)
    },
    [registerAnimation, registerTimeout]
  )

  const updateProgress = useCallback(
    (
      latest: number,
      milestoneMarkers: Array<{
        container: HTMLElement
        marker: HTMLElement
        position: number
        index: number
      }>
    ) => {
      const previous = lastProgressRef.current

      if (latest < previous - 1) {
        // Progress reset
        reachedMilestonesRef.current.clear()
        setMilestoneAnimations([])
      } else {
        // Check each milestone for crossing
        milestonePositions.forEach((pos, index) => {
          const progressPercent = latest * 100
          const milestonePercent = pos * 100

          if (
            !reachedMilestonesRef.current.has(index) &&
            previous * 100 < milestonePercent &&
            progressPercent >= milestonePercent
          ) {
            reachedMilestonesRef.current.add(index)
            const milestoneData = milestoneMarkers.find((m) => m.index === index)
            if (milestoneData) {
              triggerMilestone(index, milestoneData.container, milestoneData.marker)
            }
          }
        })
      }

      lastProgressRef.current = latest
    },
    [milestonePositions, triggerMilestone]
  )

  // Custom animation function using requestAnimationFrame
  const animateProgress = useCallback(
    (
      from: number,
      to: number,
      duration: number,
      onUpdate: (value: number) => void,
      onComplete?: () => void
    ): { cancel: () => void } => {
      const startTime = performance.now()
      let animationId: number | null = null
      let cancelled = false

      const easeInOut = (t: number): number => {
        // cubic-bezier(0.4, 0.0, 0.2, 1) approximation
        return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t
      }

      const updateLoop = (currentTime: number) => {
        if (cancelled) return

        const elapsed = currentTime - startTime
        const progress = Math.min(elapsed / duration, 1)
        const easedProgress = easeInOut(progress)
        const currentValue = from + (to - from) * easedProgress

        onUpdate(currentValue)

        if (progress < 1) {
          animationId = requestAnimationFrame(updateLoop)
        } else {
          onComplete?.()
        }
      }

      animationId = requestAnimationFrame(updateLoop)

      return {
        cancel: () => {
          cancelled = true
          if (animationId !== null) {
            cancelAnimationFrame(animationId)
          }
        },
      }
    },
    []
  )

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const trackContainer = container.querySelector('.track-container') as HTMLElement
    const fill = container.querySelector('.pf-progress-fill') as HTMLElement
    if (!trackContainer || !fill) return

    let stopped = false
    let currentAnimation: { cancel: () => void } | null = null

    const resetAnimation = () => {
      clearScheduledWork()
      if (currentAnimation) {
        currentAnimation.cancel()
        currentAnimation = null
      }

      // Clean up any existing animations
      const existingElements = container.querySelectorAll('.animation-element')
      existingElements.forEach((el) => el.remove())

      reachedMilestonesRef.current.clear()
      milestoneIdRef.current = 0
      lastProgressRef.current = 0

      // Reset fill
      fill.style.transform = 'scaleX(0)'
      fill.style.transformOrigin = 'left center'

      setMilestoneAnimations([])
    }

    const startAnimation = () => {
      if (stopped) return

      resetAnimation()

      // Create milestone markers
      const milestoneMarkers: Array<{
        container: HTMLElement
        marker: HTMLElement
        position: number
        index: number
      }> = []

      milestonePositions.forEach((pos, index) => {
        const markerContainer = document.createElement('div')
        markerContainer.className = 'animation-element milestone-container'
        markerContainer.style.position = 'absolute'
        markerContainer.style.left = `${pos * 100}%`
        markerContainer.style.top = '50%'
        markerContainer.style.transform = 'translate(-50%, -50%)'
        markerContainer.style.width = '24px'
        markerContainer.style.height = '24px'
        markerContainer.style.pointerEvents = 'none'
        trackContainer.appendChild(markerContainer)

        // Main marker
        const marker = document.createElement('div')
        marker.className = 'milestone-marker'
        marker.style.position = 'absolute'
        marker.style.inset = '0'
        marker.style.backgroundColor = 'rgba(147, 51, 234, 0.3)'
        marker.style.border = '2px solid rgba(168, 85, 247, 0.8)'
        marker.style.borderRadius = '50%'
        marker.style.transform = 'scale(0.6)'
        marker.style.opacity = '0.6'
        marker.style.transition = 'all 0.25s cubic-bezier(0.34, 1.56, 0.64, 1)'
        markerContainer.appendChild(marker)

        milestoneMarkers.push({
          container: markerContainer,
          marker,
          position: pos,
          index,
        })
      })

      // Animate progress from 0 to 1 over 4 seconds
      currentAnimation = animateProgress(
        0,
        1,
        4000,
        (progress) => {
          if (!stopped) {
            fill.style.transform = `scaleX(${progress})`
            updateProgress(progress, milestoneMarkers)
          }
        },
        () => {
          if (!stopped) {
            // Animation complete, schedule restart
            registerTimeout(startAnimation, 2000)
          }
        }
      )
    }

    startAnimation()

    return () => {
      stopped = true
      clearScheduledWork()
      if (currentAnimation) {
        currentAnimation.cancel()
      }
      const elements = container.querySelectorAll('.animation-element')
      elements.forEach((el) => el.remove())
    }
  }, [
    animateProgress,
    clearScheduledWork,
    milestonePositions,
    registerAnimation,
    registerTimeout,
    updateProgress,
  ])

  return (
    <div
      ref={containerRef}
      className="pf-progress-demo pf-celebration-burst"
      data-animation-id="progress-bars__celebration-burst"
    >
      <div className="track-container" style={{ position: 'relative' }}>
        <div className="pf-progress-track">
          <div className="pf-progress-fill"></div>
        </div>
      </div>
    </div>
  )
}
