# Interaction Flow Design

Use for workflow design, not visual styling.

## Anchors

- Task analysis: separate user goal from UI task; design around how goal is achieved.
- Wireflow: represent each user action, hotspot, state transition, and system feedback.
- Cognitive walkthrough: inspect learnability step by step.
- Accessibility: every pointer-only path needs a keyboard/menu path; focus and state changes must be perceivable.
- Professional tools: optimize for confidence, control, scanability, recovery, and repeated expert use.

Research sources when citations are needed:
NN/g task analysis, journey maps, wireflows, cognitive walkthroughs; GOV.UK service design; WCAG 2.2; Atlassian forms and drag/drop accessibility.

## Task Frame

Define before UI:

| Field | Ask |
|-|-|
| Actor | Which role is acting? |
| Trigger | What starts the task? |
| Goal | What outcome does the actor need? |
| Success | What proves completion? |
| Failure | Where can work stop, corrupt, mislead, or be lost? |
| Frequency | First-time, occasional, daily, expert loop? |
| State | Draft, dirty, saved, invalid, pending, locked, published? |
| Data | What entity/config/asset/permission changes? |
| Constraint | Compliance, audit, latency, mobile, accessibility, irreversible action? |

## Flow Row

Each step must answer:

| Field | Ask |
|-|-|
| View/region | Where is the user? |
| Intent | What are they trying to do now? |
| Action | What target do they use? |
| Response | What does system do? |
| Feedback | What proves response happened? |
| State | What changed? |
| Next | What is the natural next step? |
| Recovery | Undo, cancel, retry, skip, compare, edit, or preserve draft? |

Missing feedback or recovery means flow is incomplete.

## Cognitive Walkthrough

For each step:

1. Will this actor know this step is needed?
2. Can they find the correct action?
3. Does label/icon/control imply the right outcome?
4. After acting, can they see progress?
5. If wrong or blocked, can they recover without losing work?

Report failures as interaction defects.

## Professional Tool Patterns

| Need | Pattern |
|-|-|
| Select entity | Navigator, list, tree, table, or tile grid |
| Edit entity | Inspector/editor with target title and dirty state |
| See result | Preview/canvas/result pane |
| Validate | Inline errors plus summary for publish/blocking |
| Long operation | Progress, cancellability when safe, preserved draft |
| Risky change | Warning near control; confirm only if irreversible |
| Expert speed | Keyboard path, search/command, bulk action |
| Spatial/reorder edit | Direct manipulation plus accessible alternative |
| Publish/release | Review, diff, validation, owner, rollback/recovery |
| Empty state | Explain missing thing and first useful action |

## Anti-Patterns

- Styling before workflow.
- Dashboard dumping every feature.
- Configuration controls inside navigator tabs when an editor should own them.
- Hidden primary actions.
- Action with no visible feedback.
- Error with no recovery.
- Static mockup for dynamic state-heavy tool.
