---
name: user-interaction-design
description: "Use for flow-first interaction design: task flows, wireflows, workbench/editor UX, state changes, feedback, recovery, forms, wizards, accessibility paths, and UX handoff. Prefer over frontend-design when deciding what users do next, which view/control appears, or how UI responds; use frontend-design after flow is defined for visual polish or component build."
---

## Priority

Design interaction before interface.

Use this skill when the hard problem is user behavior, workflow, state, feedback, recovery, or view composition. Do not start with visual style, component polish, color, typography, animation, or brand mood. Use `frontend-design` only after the interaction model is stable.

For non-trivial tasks, produce an interaction-flow contract before layout, copy, components, or code.

## L7+ Interaction Designer Frame

Approach like a senior staff interaction designer for an Apple-grade professional tool:

1. Status quo: what is broken, ambiguous, slow, risky, hidden, unrecoverable, or mismatched to user intent?
2. User job: who is acting, what triggered the task, what outcome do they need, what must they trust?
3. Task anatomy: what steps, decisions, data changes, system delays, permissions, and edge states exist?
4. Perception: after each action, what does the user see that proves progress, success, failure, or reversibility?
5. Control: where can the user undo, cancel, retry, skip, compare, preview, or recover without losing work?
6. Future flow: what is the fewest clear steps that preserve confidence, auditability, accessibility, and expert speed?
7. Handoff: which views/components own selection, editing, preview, validation, persistence, and tests?

State what is wrong before what is right. Say when evidence is missing.

## Process

1. Load `references/INTERACTION-FLOW-DESIGN.md`.
2. Read local product/code context before proposing UI.
3. Define one actor, one task, trigger, success state, failure states, and constraints.
4. Map the flow: step, view/region, user action, system response, feedback/state, recovery/edge.
5. Plan views/elements only after the flow is mapped.
6. For reviews, run the cognitive walkthrough questions from the reference against every step.
7. For implementation, name component/view ownership, state/data ownership, accessibility paths, and test probes.

Ask only if actor, task, or success state cannot be inferred. Otherwise state assumptions and proceed.

## Professional Tool Defaults

- Stable navigation selects entities; inspector/editor edits selected target.
- Center/primary workspace shows preview, canvas, result, or current work context.
- Detailed configuration belongs in the editor/inspector, not navigator tabs.
- Draft, saved, invalid, loading, permission, conflict, and publish states must be visible.
- Prefer inline validation, reversible edits, autosave/draft preservation, and explicit saved/dirty feedback.
- Pointer interactions need keyboard/menu alternatives.
- Risky actions need local warning, review, undo, or confirm depending on reversibility.

## Output

Default:

```markdown
## Interaction Flow Contract
Actor:
Goal:
Trigger:
Success:
Main risk:

| Step | View/region | User action | System response | Feedback/state | Recovery/edge |
|-|-|-|-|-|-|

## View Plan
| View/region | Purpose | Elements | States |
|-|-|-|-|

## Handoff
- Components/views:
- State/data:
- Accessibility:
- Test probes:
- Open questions:
```

Compress for small tasks, but keep actor, goal, steps, feedback, recovery, and handoff.

## Final Check

- Flow precedes visual design.
- Every element exists because a step needs it.
- Every action has feedback.
- Every failure has recovery.
- User can finish, leave safely, or preserve work.
