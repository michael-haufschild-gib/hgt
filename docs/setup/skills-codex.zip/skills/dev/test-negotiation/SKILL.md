---
name: test-negotiation
description: "Use to negotiate tests before implementation: spec-first, TiCoder, proposed tests, user-confirmed behavior."
---

# Test Negotiation

## INVARIANTS

These rules are immutable. No phase, user request, or schedule pressure overrides them:

- Tests are behavioral specifications negotiated with the user — not verification afterthoughts
- **Phase 4 begins only with ≥1 confirmed test.** Zero confirmed = return to Phase 1, not skip forward
- The user's accept/reject/modify decisions are authoritative — never argue
- Implementation code without a confirmed test is unspecified behavior
- **5 negotiation rounds maximum** — convergence beats perfection
- Never write implementation code during Phases 1-3

This is specification negotiation, not TDD. Sequence: propose → user validates → confirmed tests become the spec → then implement.

---

## Workflow

Execute phases in strict order. Do not skip Phase 1 or Phase 2.

---

### Phase 1: Understand Intent

Extract from the user's feature description:

| Element | Question |
|-|-|
| **Inputs** | What data does this receive? Types, ranges, formats. |
| **Outputs** | What does it return or produce? |
| **Happy path** | What happens when everything is valid? |
| **Edge cases** | Empty inputs, nulls, boundaries, overflow, duplicates. |
| **Error paths** | What happens on invalid input, network failure, missing data? |
| **Side effects** | Does it write to DB, send events, modify state? |
| **Constraints** | Performance, security, idempotency, ordering. |

State understanding back to the user in 2-3 sentences. Ask ONE clarifying question if a critical element is ambiguous. Infer reasonable defaults for the rest.

**Gate**: Understanding stated (2-3 sentences)? ≤1 question asked? → Proceed.

---

### Phase 2: Propose Candidate Tests

Propose 5-10 tests in three tiers, in a **single message**:

**Tier 1 — Core behavior (2-4 tests)**
Primary happy-path behavior. If these fail, the feature is broken.

**Tier 2 — Edge cases and boundaries (2-4 tests)**
Empty inputs, boundary values, unusual-but-valid inputs, concurrency, ordering.

**Tier 3 — Error handling and negative cases (1-3 tests)**
Invalid input, missing dependencies, permission failures.

#### Test Format

```
## Test [N]: [descriptive name]
- **Tier**: Core | Edge | Error
- **Given**: [precondition / setup state]
- **When**: [action performed]
- **Then**: [expected observable outcome]
- **Rationale**: [one sentence: what bug does this catch?]
```

End the message with:

> Review each test. For each one:
> - **Accept** — this correctly specifies required behavior
> - **Reject** — this is wrong or out of scope
> - **Modify** — the intent is right but the expectation needs adjustment
>
> Add any tests I missed. We proceed to implementation only after you confirm the final set.

**Gate**: All tests in one message, grouped by tier? → Await user response.

---

### Phase 3: Negotiate

| User says | Action |
|-|-|
| Accept | Mark confirmed. |
| Reject | Remove. State what assumption it invalidated. If rejection reveals a feature misunderstanding, propose 1-2 replacement tests. |
| Modify | Update test with user's correction. Re-present for confirmation. |
| Add new | Assign a tier. Confirm with user. |

**Convergence target**: Complete within 3-5 rounds. After round 5, present the confirmed set and ask: "Is this sufficient to begin, or do you want another round?"

**Gate**: ≥1 confirmed test? All user decisions processed? → Proceed to Phase 4.

If zero confirmed tests: do not skip forward. Ask what the feature should do — the problem is intent capture, not test design.

---

### Phase 4: Write Confirmed Tests

Write actual test code for every confirmed test. Read the project's CLAUDE.md or existing test files to determine the framework and conventions.

Requirements:
- Each test maps 1:1 to a confirmed test from Phase 3
- Test names match the descriptive names from proposals
- Tests **must currently fail** (implementation doesn't exist yet)
- No `toBeDefined()`, no default-value assertions, no type-only checks
- Every assertion answers: "What specific bug would make this fail?"

Run the tests. Confirm they fail. Report failure output to the user.

If any test passes before implementation exists, the test is wrong — flag it and ask the user to keep or revise it.

**Gate**: All tests written? All tests FAIL? Failure output reported? → Proceed to Phase 5.

---

### Phase 5: Implement

Write the minimal implementation that passes all confirmed tests:

1. Implement against the confirmed test set
2. Run tests — all must pass
3. Report results with actual output

Do NOT add behavior not covered by a confirmed test. If implementation reveals an uncovered case, propose an additional test to the user rather than silently handling it.

**Gate**: All tests pass? Results reported? → Proceed to Phase 6.

---

### Phase 6: Gap Check

Review for:
- Obvious edge cases the confirmed tests don't cover
- Implicit behavior revealed during implementation that should be tested

If gaps exist: propose 1-3 additional tests marked "post-implementation gap fill." User can accept or decline. This is the **last round** — do not loop.

---

## Anti-Patterns

| Pattern | Why it's wrong | Do this instead |
|-|-|-|
| Proposing 20+ tests | Overwhelms the user, stalls negotiation | Cap at 10 proposals per round |
| Writing implementation during Phases 1-3 | Anchors to an approach before spec is confirmed | Implementation starts at Phase 5 |
| Proposing tests that assert implementation details | Couples tests to approach, not behavior | Test observable outcomes only |
| Accepting "looks good" without per-test confirmation | User may not have read each test | Ask for explicit accept/reject on each |
| Skipping Phase 1 to look productive | Proposals without intent understanding waste rounds | State understanding (2-3 sentences) first |

## RECALL — Core Invariants

- Tests = specification format, not afterthought
- User decisions are authoritative — never argue
- A rejected test = a successfully eliminated incorrect assumption
- Implementation without a confirmed test = unspecified behavior
- **Phase 4 requires ≥1 confirmed test. Phase 5 requires all Phase 4 tests to fail first.**
