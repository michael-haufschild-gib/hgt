---
name: pull-request
description: Commit all uncommitted changes as atomic logical commits and push. Open a PR. Use targeted validation; do not repeat checks that already passed in the current session.
allowed-tools:
  - Bash
  - Read
  - Grep
  - Glob
---

## Task
Commit all uncommitted changes in the working tree as atomic commits, with optional context for commit messages. Fix any issue found during validation.

Then push to the remote. Open a PR.

## Validation Budget
- Reuse passing command results from the current session. Do not rerun a passed check unless relevant files changed after that pass, the result was partial/flaky, or the user explicitly asks for a rerun.
- Run the smallest meaningful checks for the changed files. Prefer package-level typecheck/lint/test or the exact failed test class/spec over root `validate`, full test suites, or E2E.
- Run at most one broad validation command per PR task, only when project instructions require it or the diff is cross-cutting enough that targeted checks cannot cover risk.
- After a failure, fix the cause and rerun only the failed command or narrower failing test. One retry per failed command; if it still fails, stop and report the blocker with command/output.
- Do not run dev servers or long E2E suites unless the user asks or project instructions require them for the touched surface.
- Put validation commands and results in the PR body and final response.

## Speed Anchor
Do not repeat checks that already passed in the current session unless files relevant to that check changed after the pass.
