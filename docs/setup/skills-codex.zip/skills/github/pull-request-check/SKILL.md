---
name: pull-request-check
description: Check an open PR for issues and comments and fix those. Use failed-check evidence and targeted validation; do not repeat checks that already passed.
allowed-tools:
  - Bash
  - Read
  - Grep
  - Glob
---

## Task
Get the latest coderabbit comments on the open PR. Stop if there is no open PR.
Check for failed checks, and fix all valid issues found during validation.

Get all comments on the PR, including nitpicks. Fix all valid issues, including nitpicks. Mark resolved comments as resolved.

Then commit all edits and uncommitted changes from other sessions and push them.

## Validation Budget
- Treat passed CI checks and passed local checks from the current session as evidence. Do not rerun them unless relevant files changed after the pass, the result was partial/flaky, or the user explicitly asks for a rerun.
- For failed CI, inspect the failing job/test/log first. Reproduce only the failing command, package, class, or spec when local reproduction is useful.
- After a fix, rerun only the failed command or narrower failing test. One retry per failed command; if it still fails, stop and report the blocker with command/output.
- Do not run root `validate`, full test suites, dev servers, or E2E unless the failed check is that exact surface or project instructions require it for the touched files.
- If comments request only text, import, lint, or type changes, run only the relevant static check.
- Put validation commands and results in the final response and PR comment if you post one.

## Speed Anchor
Do not repeat checks that already passed in CI or the current local session unless files relevant to that check changed after the pass.
