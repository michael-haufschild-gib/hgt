# Navigation and Header Checks — Persistent UI Chrome

Apply these checks when a bottom navigation bar or persistent header with gamification elements is visible.

=== TRIGGER ===

Run when the screenshot shows:
- A bottom navigation bar (tab bar) with 3+ items
- A persistent header bar with currency displays, XP bars, streak counters, or other gamification indicators
- Both together (common in mobile games and gamified apps)

Do NOT run on: modals/popups that obscure navigation, screenshots where navigation is not visible, or desktop-only layouts.

=== END TRIGGER ===

---

## Bottom Navigation (NV-B)

**NV-B1. Item count**
Look for: Count the items in the bottom navigation bar.
Pass: 3-5 items. Each item has both an icon and a text label.
Fail: More than 5 items (tap targets too close). Or 2 or fewer (underutilized). Or icon-only items with no text labels.
Evidence: Material Design 3 and Apple HIG both specify 3-5 destinations. 70% of app uninstalls cite confusing navigation.

**NV-B2. Active state clarity**
Look for: How is the currently active tab indicated?
Pass: Active state uses at least two visual differentiators — color change + filled icon, or color change + indicator shape (pill, underline). Contrast between active and inactive meets WCAG 4.5:1.
Fail: Active tab distinguished only by color tint. Or active state barely distinguishable from inactive.
Evidence: Material Design 3 uses a filled pill indicator + color. Apple uses filled vs. outline icons + accent color. Single-differentiator active states fail for color-vision-deficient users.

**NV-B3. Destination hierarchy**
Look for: Are the destinations of equal importance? Is the most critical action (e.g., Deposit, Play) in a prominent position?
Pass: Core destinations in the bar. Most important items at the start and end positions (serial position effect). No action-type buttons masquerading as navigation.
Fail: Mix of navigation and action buttons. Or secondary features (Settings, Help) taking nav slots instead of primary features.
Evidence: Tab bars should be navigation only — not action triggers. Primary features at first and last positions benefit from primacy and recency effects.

**NV-B4. Badge usage**
Look for: Notification badges on bottom nav items. Count how many items are badged simultaneously.
Pass: 0-2 badges visible. Badges appear only on items with genuinely actionable or time-sensitive content (unclaimed rewards, pending messages).
Fail: 3+ simultaneous badges. Or badges on items with no time-sensitive content (badge inflation).
Evidence: Badge overuse creates notification fatigue — if everything has a badge, none feel important. 64% of users delete apps receiving 5+ notifications per week.

---

## Header Bar (NV-H)

**NV-H1. Height and density**
Look for: How much vertical screen space does the header consume? Count distinct elements in the persistent header.
Pass: Header occupies less than ~20% of screen height. Contains no more than 7 distinct elements. Content-to-chrome ratio is at least 5:1.
Fail: Header consumes more than ~25% of screen. Or 8+ elements crammed into the header. Content area feels squeezed.
Evidence: User satisfaction drops when more than 20-30% of the screen is occupied by headers. Working memory limits (Miller's Law) cap meaningful header elements at 5-7.

**NV-H2. Background contrast**
Look for: Does the header have a clear visual boundary against the content below?
Pass: Opaque background with visible contrast against content area. Clear visual separation.
Fail: Translucent or semi-transparent header where content bleeds through, making both header and content hard to read.
Evidence: Low contrast from translucent headers makes semi-visible content hard to read and frequently annoys users.

---

## Gamification Elements (NV-G)

**NV-G1. Currency display format**
Look for: How are currencies (coins, gems, tokens) displayed in the header or navigation area?
Pass: Each currency uses icon + numeric value format. Icons are distinct in both color and shape. Multiple currencies are visually separated with clear grouping.
Fail: Numeric values without icons. Or multiple currencies using similar-looking icons differentiated only by color.
Evidence: Icon + number is the universal game currency pattern. Color-only differentiation fails for ~1 in 11 users.

**NV-G2. Gamification element placement**
Look for: Where are gamification indicators (XP bar, streak counter, level badge, currency) positioned relative to the header zones?
Pass: View-only indicators (balance, streak) in the header. Interactive elements (shop entry, claim reward) in the bottom half of the screen or bottom nav. No more than 3 gamification indicators in the persistent non-collapsible header.
Fail: Interactive gamification elements (requiring taps) placed in the top corners (hard zone for one-handed use). Or 4+ gamification indicators crowding the persistent header.
Evidence: Top corners are the hardest to reach one-handed. 49% of users navigate one-handed. View-only elements can stay in the header; interactive elements need the thumb zone.

**NV-G3. Progression visibility**
Look for: Is there a visible progression indicator (XP bar, level, streak) that communicates the user's overall progress?
Pass: At least one progression element visible — streak counter, level indicator, or XP progress. Compact and readable at a glance.
Fail: No visible progression. Or progression indicator so small or buried it cannot be read at a glance.
Not applicable: Non-gamified apps without progression systems.
Evidence: Visible progression is the primary driver of continued engagement. Streak visibility alone increased user commitment by 60% (Duolingo).

---

## Output framing

**Research-backed:** "Navigation research indicates [principle]. This screen's [element] uses [current approach] — [alternative] is associated with better discoverability and engagement."

**Never use:** "This navigation will cause X% uninstalls", "Users will not find [feature]", "This violates platform guidelines" (frame as deviation from best practice, not violation).
