# What Static Screenshots Cannot Show

These limitations apply to ALL visual analysis — they are inherent to the medium, not to the model.

- **Dynamic behavior**: Hover states, animations, scroll behavior, transitions, loading sequences
- **Page load speed**: Requires live measurement
- **Font families**: Describe legibility, weight, and hierarchy. Do not name font families.
- **Exact pixel measurements**: Touch target sizes, spacing in px — describe as "appears adequate" or "appears small, verify against 44px minimum"
- **Post-interaction flows**: What happens after a button tap, form submission, navigation action
- **Audience segmentation**: Who sees this page and why — requires analytics data
- **A/B test performance**: Conversion rates, CTR, bounce rates — requires live data
- **Actual tap target sizes**: Screenshot pixel dimensions do not map to device-independent pixels without knowing the export scale
- **Content below the viewport**: A single screenshot captures one scroll position

When uncertain about any visual detail, use the crop tool to zoom in and re-examine at higher resolution.
