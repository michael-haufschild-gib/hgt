# Conversion Page Checks — Landing Pages and Promotion Pages

=== CONVERSION PAGE CONTEXT GATE (MANDATORY) ===

Before running ANY check below, classify the conversion page context level.

**LANDING PAGE REVIEW** — any of these:
- User explicitly identifies the screenshot as a landing page
- User states the page is for new-user acquisition, registration, or first-visit conversion

Run: CV + LP + CV-K (if sweepstakes casino domain active)

**PROMOTION PAGE REVIEW** — any of these:
- User explicitly identifies the screenshot as a promotion
- User states the page is for existing-user monetization, upsell, re-engagement, or retention

Run: CV + PP + CV-K (if sweepstakes casino domain active)

**CONVERSION SIGNALS** — all of these:
- No explicit user identification as landing or promotion page
- Page exhibits 3+ of these visual signals:
  (a) Single dominant CTA with no or minimal global navigation
  (b) Hero headline + subheadline + CTA above fold
  (c) Specific social proof block (reviews, player counts, testimonials)
  (d) Form fields as primary interaction element
  (e) Urgency or countdown messaging visible
  (f) Stripped or minimal navigation (no full nav bar)

Run: CV only. Do NOT label the page as "landing page" or "promotion page."

**NEITHER** — no user identification AND fewer than 3 signals:
- Do NOT run any conversion checks
- Do NOT suggest the screenshot is a landing or promotion page
- Apply universal checks only

=== END CONVERSION PAGE CONTEXT GATE ===

=== CONVERSION-SPECIFIC PERCEPTUAL BOUNDARIES (IMMUTABLE) ===

**Evaluate freely:**
- Headline clarity and specificity (text content at DocVQA 95.2% accuracy)
- CTA text wording and framing (gain vs loss, curiosity vs commitment, first vs second person)
- Social proof presence, type, and specificity
- Trust signal presence (badges, compliance text, contact info, security icons)
- Urgency/scarcity messaging quality (authentic vs manufactured, overuse)
- Benefit framing (features vs benefits, concrete vs vague)
- Reference pricing and anchoring structure
- Form field count and grouping (for groups of 1-5)
- Navigation presence or absence
- Endowment indicators visible

**Flag as MEDIUM confidence:**
- Above-fold value proposition completeness (depends on device viewport)
- Whether visual hierarchy serves the conversion goal
- Whether urgency appears authentic or manufactured

**Never claim:**
- Predicted conversion rates, bounce rates, or signup rates
- Target audience or demographic from visual appearance alone
- Traffic source, funnel stage, or campaign context (invisible in screenshot)
- Page load speed impact (requires live measurement)
- Personalization effectiveness (requires live data)
- A/B test performance vs alternatives

=== END CONVERSION-SPECIFIC PERCEPTUAL BOUNDARIES ===

---

## Conversion Visual (CV) — Run on ANY conversion context

**CV1. Headline clarity and specificity**
Look for: The primary headline text. Does it communicate a specific value proposition or make a vague promise?
Pass: Specific, benefit-driven headline — "Get 45 Million Free Sweepstake Coins — No Purchase Needed", "Save 2 Hours Per Week on Reporting."
Fail: Vague, generic headline — "Welcome", "The Best Platform", "Get Started Today."
Evidence: Headline clarity is the highest-impact visually assessable conversion factor. Specific headlines significantly outperform vague ones. More people read the headline than the body.

**CV2. CTA text framing**
Look for: Text on the primary action button. Classify the framing:
- Curiosity/discovery: "See My Bonus", "Show Me Deals", "Reveal My Offer"
- Ownership/claim: "Claim My Coins", "Get My Bonus", "Start My Free Trial"
- Directive/generic: "Sign Up", "Submit", "Buy Now", "Learn More"
Pass: First-person curiosity or ownership framing.
Fail: Generic directive framing ("Submit", "Sign Up", "Click Here").
Compound with U1: If U1 (CTA pop-out) also fails, the CTA is both invisible AND unconvincing.
Evidence: First-person framing directionally outperforms second-person. Curiosity-driven CTAs outperform commitment-driven CTAs.

**CV3. Social proof specificity**
Look for: Social proof elements. Classify specificity:
- Specific: "50,000 players online now", "Rated 4.8 by 200K+ players"
- Generic: "Millions of players", "Top rated"
- Absent: No social proof visible
Pass: Specific social proof with concrete numbers near a conversion point.
Acceptable: Generic social proof present.
Fail: No social proof visible on a page asking users to take action.
Compound with U11: If U11 also flags this, report once with the specificity dimension added.
Evidence: Social proof is the strongest persuasion lever. Specific numbers outperform vague claims. Reviews are trusted far more than manufacturer descriptions.

**CV4. Urgency and scarcity quality**
Look for: Countdown timers, "Limited time", "Only X remaining", "Last chance" messaging. Assess:
- Authentic urgency: Timer tied to a specific offer with a clear end condition
- Manufactured urgency: Every element has a timer, or timer on a non-time-limited offer
- Urgency overuse: 2+ stacked urgency mechanisms on a single page
Pass: One authentic time-limited element with a specific countdown. No emotional pressure language.
Fail: Every item has a timer. Forceful language ("You MUST act NOW"). 3+ urgency mechanisms stacked.
Compound with U21: If U21 also fires, report the compound effect.
Evidence: Limited-time offers increase purchase likelihood. But forceful language triggers psychological reactance. Resolution: implied urgency with autonomy restoration. Overuse of scarcity erodes trust.

**CV5. Above-fold value proposition**
Look for: What is visible in the top portion of the page without scrolling? Can a visitor understand the offer within ~5 seconds?
Pass: Headline, supporting visual or subheadline, and CTA all visible above fold.
Fail: Fold area consumed by a large image with no text. CTA below fold. Value proposition requires scrolling.
Note: "Fold" position depends on the viewing device — classify what appears in the top 40-50% of the screenshot. Flag as MEDIUM confidence.
Evidence: Mobile sessions are very short. If a user cannot understand the offer without scrolling, they leave before understanding it.

**CV6. Benefit vs feature framing**
Look for: How the product or offer is described in body copy, bullet points, or feature lists.
- Benefit framing: "Save 2 hours per week", "Win real prizes", "Never miss a bonus"
- Feature framing: "Auto-sync", "Dual currency system", "Daily rewards"
- Hybrid: Feature + benefit together — "Auto-sync (saves 2 hours per week)"
Pass: Benefits dominate. User can understand what they gain without inferring from features.
Fail: Feature-only list with no translation into user value. Technical jargon without explanation.
Evidence: Concrete, benefit-oriented language outperforms abstract feature lists. Users cannot evaluate raw numbers (like coin amounts) without context.

**CV7. Trust signal placement**
Look for: Trust signals — security badges, compliance text, payment logos, "money-back guarantee", privacy policy links. Where are they relative to the CTA?
Pass: Trust signals visible adjacent to or near the CTA — processed peripherally without requiring direct attention.
Fail: No trust signals visible. Or trust signals isolated in the footer, far from the conversion point.
Compound with U9, U10: If organizational identity or contact info also fail, the trust deficit compounds.
Evidence: The brain processes trust indicators from peripheral vision without direct fixation. Trust signals need to be present and adjacent to decision points, not prominent.

**CV8. Reference pricing and anchoring**
Look for: Price presentation structure. Is there a reference price, strikethrough, "was/now" comparison, or high-value anchor?
Pass: High anchor visible before the offer price — "~~$49.99~~ $9.99", "$100 value — yours FREE."
Not applicable: No pricing visible on this page.
Compound with U19: If U19 also fires, report once with the conversion context.
Evidence: First price seen dominates perception (anchoring). Less knowledgeable consumers are more susceptible.

**CV9. Navigation stripping assessment**
Look for: Global navigation elements. Is navigation present, reduced, or absent?
- Full navigation: Standard site nav with multiple links
- Reduced: Logo + minimal links
- Stripped: No navigation — only the conversion flow
Note: Navigation stripping is a DESIGN CHOICE. For landing pages, stripped is typically better. For in-app promotions, some navigation context is expected.
Evidence: Removing navigation focuses attention on the conversion action but also removes trust signals. Report the observation; do not prescribe without context.

**CV10. Endowment indicators**
Look for: Elements that create psychological ownership before asking for payment or signup:
- Progress bars showing partial completion
- "You've earned X" or "Your bonus is waiting" language
- Interactive elements (wheel of fortune, scratch card, pick-a-box)
- Pre-filled form fields showing known information
- Accumulated value displays (piggy bank, coin vault, streak counter)
Pass: At least one endowment mechanism visible that creates ownership before the commitment ask.
Not applicable: Page does not include a multi-step flow or interactive element.
Evidence: Endowment effect drives conversion of non-spenders. The pattern: create ownership before asking for payment. Starting a progress bar above 0% significantly increases completion.

**CV11. Reactance risk assessment**
Look for: Language tone in CTAs, headlines, and body copy. Classify:
- Controlling: "You MUST", "Don't miss", "Act NOW", "You need this"
- Autonomy-preserving: "Available until midnight", "Claim anytime", "No strings attached"
- Neutral: Standard product descriptions without pressure
Pass: Autonomy-preserving language accompanies any urgency messaging. OR no urgency present.
Fail: Controlling language without a restoration postscript. Multiple forceful directives stacked.
Evidence: Forceful language triggers threat perception and persuasion resistance. Loss-framed messages generate stronger reactance. Resolution: pair urgency with autonomy restoration.

---

## Landing Page (LP) — Run ONLY at LANDING PAGE REVIEW

**LP1. First-impression trust architecture**
Look for: Within the above-fold area — count trust-building elements visible to a first-time visitor:
- Organization identity (logo, company name)
- Social proof (ratings, player counts, testimonials)
- Security indicators (badges, compliance text)
- Recognizable payment/platform logos
- Contact or support access
Pass: 3+ trust elements visible above fold.
Fail: 0-1 trust elements above fold. Page asks for commitment before establishing credibility.
Evidence: Visual design is the primary credibility factor for a large share of users. First-time visitors have no prior relationship — trust must be established visually before any ask.

**LP2. Message-match readiness**
Look for: Does the headline contain specific, campaign-alignable language?
Pass: Headline specific enough to match a likely traffic source.
Fail: Headline is generic and could not match any specific campaign — "Welcome", "Get Started."
Note: The agent CANNOT verify actual message match — this evaluates whether the headline is CAPABLE of matching, not whether it does.
Evidence: Message match (headline echoing the ad or search query) is foundational. Cognitive dissonance between ad and landing page causes immediate bounce.

**LP3. Single conversion path**
Look for: Count the number of distinct actions a user can take on this page.
Pass: 1 primary CTA dominates. 0-2 secondary links (privacy policy, terms). No competing navigation.
Fail: Multiple equal-weight CTAs. Full navigation menu present. Social media links competing with the CTA.
Evidence: Decision time increases with choice count (Hick's Law). Landing pages with a single CTA eliminate decision paralysis.

**LP4. Endowment-before-signup mechanic**
Look for: Does the page offer something interactive or valuable BEFORE asking for registration or payment?
- Interactive engagement: Wheel of fortune, scratch card, quiz, configurator
- Value preview: "See your results", "Preview your bonus"
- Pre-earned reward: "Your 2x welcome bonus is ready" (ownership language before signup)
Pass: At least one endowment mechanism before the signup form.
Fail: Page leads directly to a signup form or payment without creating earned value.
Evidence: People value things more once they feel ownership. Pre-commitment engagement outperforms direct asks.

**LP5. Form friction assessment**
Look for: If a signup form is visible — count fields, assess grouping, check for friction indicators.
Pass: 3 or fewer fields visible. OR multi-step with progress indicator. Helper text explains each field.
Fail: 5+ ungrouped fields. Unexplained fields (phone number with no "why"). Confirm-password on mobile.
Compound with RE checks: If RE1-RE7 fire, report the compound effect.
Evidence: Multi-step forms outperform single-step for long forms. Caveat: "fewer fields = more conversion" is NOT universal — qualifying questions can increase conversion in some contexts.

---

## Promotion Page (PP) — Run ONLY at PROMOTION PAGE REVIEW

**PP1. Offer-segment visual signals**
Look for: Does the offer show signs of being tailored to a specific user segment?
- Segment-specific language: "Welcome back", "VIP exclusive", "Your personalized offer"
- Tiered or personalized pricing
- Behavioral triggers: "Your coins are running low", "You haven't played in 3 days"
Pass: At least one signal of segmentation or personalization.
Fail: Generic broadcast offer with no personalization signals.
Note: The agent CANNOT determine whether the offer IS actually personalized — only whether it APPEARS personalized.
Evidence: Personalization produces the largest measured lifts across all conversion research. Segmented offers significantly outperform broadcast.

**PP2. Contextual trigger appropriateness**
Look for: Does the promotion appear to be triggered by a user context or behavior?
- Resource depletion: "Your coins are low — here's a special refill offer"
- Achievement: "Congratulations! Here's a reward for reaching Level 10"
- Time-based: "Your daily bonus is ready"
- Lapsed: "We missed you! Here's a welcome-back bonus"
- Arbitrary: No visible connection to user state
Pass: Visible language suggests the offer is triggered by user behavior or state.
Fail: No contextual trigger visible — the offer appears arbitrary.
Note: Whether the trigger is ACTUALLY behavioral requires backend knowledge.
Evidence: Promotion timing at natural moments outperforms arbitrary timing. Early aggressive monetization repels high-value players.

**PP3. Escalation structure visibility**
Look for: If multiple tiers or packages are visible — does value per dollar increase with price?
Pass: Higher-priced tiers offer visibly more value. Price escalation is clear and incentivizes upgrading.
Fail: Flat value across tiers (no incentive to buy larger). Escalation invisible — user must do mental math.
Compound with SD-E6: If shop bonus escalation check also fires, report once with the promotion context.
Evidence: Non-linear bonus escalation drives upsell. The promotion page's job is to make the upgrade feel obvious and rewarding, not to require calculation.

**PP4. Promotion fatigue indicators**
Look for: Signs that this promotion may contribute to fatigue:
- Multiple stacked offers competing for attention
- "One-time" or "Exclusive" labels on what appears to be a recurring offer type
- No cooldown signal
Pass: Single focused offer. Or clear "next offer in X hours" cooldown language.
Fail: 3+ competing offers on one screen. Every offer labeled "exclusive" or "limited" (label inflation).
Evidence: Cooldown between repeat offers prevents fatigue. Every offer labeled "exclusive" trains users to ignore the label.

**PP5. Loss-frame vs gain-frame balance**
Look for: How the offer communicates value:
- Loss frame: "Don't lose your 2x bonus", "Your coins expire at midnight"
- Gain frame: "Get 50,000 bonus coins", "Earn your reward"
- Balanced: Loss frame + autonomy postscript
Pass: Balanced framing with loss frame + autonomy restoration. OR gain frame only.
Fail: Pure loss frame with no autonomy restoration. Multiple loss-frame messages stacked.
Evidence: Loss framing outperforms other urgency mechanics but also triggers stronger reactance. Resolution: pair loss framing with autonomy restoration.

---

## Casino Conversion (CV-K) — Run ONLY with casino/sweepstake context

Run these checks when the sweepstakes casino domain is active (detected via filename keywords, visible text, or user identification). Do not infer casino context from coin or reward imagery alone.

**CV-K1. AMOE as trust signal**
Look for: "No purchase necessary", "Free entry available", "Alternate Method of Entry", or AMOE-related text. How is it positioned?
Pass: AMOE or free-entry language visible near the CTA, framed as trust signal.
Fail: AMOE absent. OR AMOE buried in footer fine print where it serves no trust function.
Evidence: AMOE / free-entry language functions as a trust signal when positioned near CTAs. Trust indicators are processed from peripheral vision.

**CV-K2. Dual-currency framing**
Look for: How Gold Coins (GC) and Free Sweepstake Coins (SC) are referenced on the page.
Pass: GC is the primary product. SC framed as promotional bonus ("PLUS Free Sweepstake Coins"). No dollar value attached to SC. "Free Sweepstake Coins" is the correct term.
Fail: SC framed as the primary product. SC with dollar values attached.
Cross-reference: Mirrors SD-E3 (shop) and AD-K2 (ad). Report once if multiple contexts trigger.
Evidence: Sweepstakes platforms consistently use GC-primary framing. Reversing it confuses the currency hierarchy for users.

**CV-K3. Welcome offer structure**
Look for: First-purchase or welcome offer. Assess pricing, value anchor, and framing.
Pass: Starter priced under $10. Higher-value anchor visible. "One-time" or "Welcome" framing.
Fail: Starter priced above $10 without value justification. No visible value anchor. Generic pricing.
Note: Only assess if a welcome/first-purchase offer is visible. Absence is not a failure.
Evidence: Most game price starters are under $10. First-purchase buyers tend to make additional purchases. Low starter prices anchor future spending expectations.

**CV-K4. Interactive engagement mechanic**
Look for: Pre-commitment engagement elements: wheel of fortune, scratch card, pick-a-box, quiz or game demo.
Pass: An interactive mechanic is visible that lets the user "play" or "reveal" before committing.
Fail: Page jumps directly to signup form or payment with no engagement mechanic.
Note: Mechanic effectiveness depends on implementation — this check assesses presence only.
Evidence: Gamified engagement mechanics create endowment before commitment, converting passive reading to active participation.

**CV-K5. Responsible gaming as trust signal**
Look for: Responsible gaming messaging, age verification, privacy policy, terms of service. How are they presented?
Pass: Responsible gaming elements visible and framed positively — "Play responsibly" with support links. Present as credibility markers.
Fail: No responsible gaming messaging visible. OR trust-building text too small to serve its function.
Evidence: Responsible gaming messaging functions as a trust signal for users unfamiliar with the sweepstake model. Visible responsibility signals build credibility.

---

## Output framing

When reporting conversion page findings:

**Research-backed:** "Research indicates [principle]. This page's [element] uses [current approach] — [alternative] is associated with stronger conversion."

**Casino-specific:** "Sweepstake casino research indicates [principle]. Note: direct sweepstake casino A/B test data is not publicly available — evidence is extrapolated from adjacent domains."

**Context-dependent:** "If this page targets [segment/source/stage], research indicates [principle]. Without knowing the [missing context], this observation is conditional."

**Never use:** "This page will convert at X%", "Expect X% improvement", "This will fail because...", "This targets [demographic]" (unless user stated it).
