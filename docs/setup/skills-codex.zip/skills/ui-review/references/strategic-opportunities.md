# Strategic Opportunities — Monetization Psychology

Read this AFTER the rewrite (`report.md`) is saved. You already have deep context about the screenshot. Now apply these principles to identify what the UI could be leveraging but isn't.

=== PROCESSING RULE (MANDATORY) ===

Evaluate EVERY category in the checklist below against the screenshot. For each category, decide: does this screenshot present an opportunity from any principle in this category? Check off each category as you evaluate it. Only after evaluating all 10 categories, select the 3-7 strongest opportunities to write up.

- [ ] 1. Behavioral Conditioning (#1-4): variable ratio reinforcement, operant conditioning, vicarious reinforcement, attentional bias
- [ ] 2. Social Influence (#5-11): social proof, conformity, reciprocity, bandwagon, social identity, groupthink, informational influence, deindividuation, spotlight effect
- [ ] 3. Economic Psychology (#12-23): loss aversion, prospect theory, sunk cost, mental accounting, anchoring, decoy, endowment, hyperbolic discounting, present bias, transaction utility, denomination, payment depreciation, hedonic adaptation, reference point manipulation
- [ ] 4. Cognitive Engagement (#24-32): FOMO, Zeigarnik, near-miss, illusion of control, halo effect, IKEA effect, scarcity, commitment bias, functional fixedness
- [ ] 5. Self-Determination & Motivation (#33-34): autonomy/competence/relatedness, peak-end rule
- [ ] 6. Personalization & Attention (#35-36): cocktail party effect, context collapse
- [ ] 7. Cultural Adaptation (#37-39): cultural scripts, collectivism/individualism, face-saving
- [ ] 8. Social Display (#40-42): deindividuation, spotlight effect, informational social influence
- [ ] 9. Currency & Value Framing (#43-46): denomination effect, payment depreciation, hedonic adaptation, reference point manipulation
- [ ] 10. Compound Effect Chains: loss spiral, social trap, identity capture, FOMO cascade

=== END PROCESSING RULE ===

## Output

Append directly to `report.md` under the heading `## Things You Could Try`. Do not create a separate file.

For each opportunity:

### [Opportunity title]

**Principle:** [Name — one sentence explaining the mechanism]
**Current state:** [What the screen does now — reference specific elements from the review]
**Opportunity:** [What could be added or changed]
**Expected impact:** [What research suggests, without predicting specific percentages]

End with a `### Not applicable` section listing categories you evaluated but found no relevant opportunity for, with one-line reasons. This demonstrates all 10 categories were considered.

Limit to 3-7 opportunities. Quality over quantity. Each must reference something specific in the screenshot — no generic advice.

## Business Model Context

Social sweepstakes casinos use a dual-currency system:

- **Free Sweepstake Coins (SC)**: Redeemable 1:1 for USD after wagering requirements. Primary player motivator. Distributed via promotions, purchases, bonuses.
- **Gold Coins (GC)**: No cash value. Given in large quantities (millions) to maintain "social casino" legal classification. Enables operation as sweepstakes rather than gambling.

**Platform controls**: Registration, purchase flows, bonus distribution, VIP/loyalty programs, tournaments, social features, notifications, cashout processes, lobby design, game recommendations.

**Platform does NOT control**: Slot RTPs, game volatility, symbol distributions, payline structures, in-game bonus triggers, near-miss programming, game math/algorithms. All applications below target platform-level features only.


## BEHAVIORAL CONDITIONING

### 1. Variable Ratio Reinforcement Schedule

Unpredictable reward timing creates the strongest, most extinction-resistant behavioral patterns. The uncertainty of when the next reward arrives produces compulsive repetition.

**Applications**:
- Randomize bonus timing so players cannot predict when rewards arrive
- Use mystery boxes and surprise daily login rewards with varying values
- Structure VIP benefits to deliver unexpected perks at irregular intervals
- Design promotional offers that appear at unpredictable times during sessions


### 2. Operant Conditioning

Behavior shaped through consequences. Positive reinforcement (adding rewards) is most effective for sustained engagement; negative reinforcement (removing discomfort) drives purchase decisions.

**Applications**:
- Reward desired behaviors (daily login, social sharing, tournament entry) with SC/GC
- Remove friction or cooldowns when players make purchases (negative reinforcement)
- Create achievement systems that positively reinforce exploration of platform features
- Use progressive reward ladders that reinforce consistent daily engagement


### 3. Vicarious Reinforcement

Learning from observing others being rewarded. Seeing other players win increases the observer's motivation to play.

**Applications**:
- Display real-time winner feeds showing recent big wins across the platform
- Feature winner stories and testimonials in marketing materials
- Show tournament leaderboard progress and prize distributions live
- Create "win celebration" animations visible in shared social spaces


### 4. Attentional Bias

Selective attention toward stimuli associated with current goals or emotional states. Players focused on winning preferentially notice win-related information.

**Applications**:
- Highlight wins, bonuses, and positive outcomes prominently in UI
- Feature jackpot amounts, recent winners, and available promotions in high-visibility areas
- Use notification systems that emphasize opportunities over warnings
- Design lobby layouts that draw attention to high-engagement content


## SOCIAL INFLUENCE

### 5. Social Proof

People follow others' behavior when uncertain. Seeing others act a certain way validates that behavior as correct.

**Applications**:
- Show player counts, active users, and concurrent tournament participants
- Display "X players purchased this package" indicators on offers
- Feature community activity feeds showing real-time platform engagement
- Highlight popular games with "most played" and "trending" labels


### 6. Conformity

Adjusting behavior to match group norms. Normative influence (desire to fit in) and informational influence (assuming the group knows best) both drive behavior alignment.

**Applications**:
- Display community spending norms ("average player invests $X/month in entertainment")
- Create tier systems where advancement matches visible peer behavior
- Use chat features showing how other players engage with promotions
- Design social challenges where participation is the visible norm


### 7. Reciprocity

Receiving something creates felt obligation to give back. Free gifts, bonuses, and perks generate psychological pressure to reciprocate through purchases or continued engagement.

**Applications**:
- Offer generous free SC bonuses for new registrations and daily logins
- Provide unexpected "gifts" (bonus spins, extra GC) before presenting purchase offers
- Send personalized rewards on player milestones (anniversaries, birthdays)
- Give free tournament entries that create social obligation to participate regularly


### 8. Bandwagon Effect

Adoption of behaviors because many others have. Automatic, often unconscious adoption of popular trends.

**Applications**:
- Show rising participation numbers in real-time during events and promotions
- Feature "fastest growing" game categories and trending tournaments
- Create viral referral mechanics where joining feels like joining a movement
- Display community milestones ("10,000 players joined this week!")


### 9. Social Identity Theory

People derive self-concept from group membership. In-group favoritism and out-group differentiation create loyalty and competitive engagement.

**Applications**:
- Create team-based tournaments with named groups and shared identity markers
- Design VIP tiers as identity groups with exclusive communities and badges
- Enable player-created clubs/guilds with shared goals and leaderboards
- Use "us vs. them" framing in competitive events between player groups


### 10. Groupthink

Groups prioritize consensus over critical evaluation. In platform communities, groupthink normalizes engagement and creates shared momentum.

**Applications**:
- Design community features that facilitate positive shared experiences
- Create forums and chat spaces where experienced players mentor newcomers
- Build consensus around platform events through shared anticipation and discussion
- Use community voting on features to build collective ownership


### 11. Informational Social Influence

Accepting others' information as evidence about reality. When uncertain, people look to perceived experts for guidance.

**Applications**:
- Feature expert player tips and strategy guides (for platform navigation, not game odds)
- Display streamer/influencer endorsements and gameplay sessions
- Create "recommended for you" sections informed by similar player preferences
- Provide tutorial content from experienced community members


## ECONOMIC PSYCHOLOGY

### 12. Loss Aversion

Losses feel approximately 2x more painful than equivalent gains feel pleasurable. This asymmetry drives risk-seeking behavior to avoid realized losses.

**Applications**:
- Frame bonuses as "don't lose your daily reward" rather than "claim your bonus"
- Use expiring currency mechanics (SC/GC that must be used within a timeframe)
- Design VIP tier maintenance where inactivity risks losing earned status
- Create limited-time offers framed as opportunities that will be "lost" if not taken


### 13. Prospect Theory

People evaluate outcomes relative to a reference point, not in absolute terms. The value function is steeper for losses than gains.

**Applications**:
- Set reference points through initial generous bonuses so subsequent play feels like potential loss
- Frame purchases as "getting value" relative to higher reference prices
- Bundle SC with GC purchases so the "gain" (GC) offsets the "loss" (money spent)
- Use tiered pricing where higher tiers appear as better relative value


### 14. Sunk Cost Fallacy

Continuing investment based on past expenditure rather than future value. Players who have spent significantly feel compelled to keep playing.

**Applications**:
- Show cumulative achievement progress and collection status to reinforce investment
- Create loyalty programs that accumulate visible value over time
- Design VIP tiers requiring sustained engagement, with progress always visible
- Remind players of their "journey" and accumulated status during re-engagement campaigns


### 15. Mental Accounting

Treating money differently depending on its source or intended use. Players mentally categorize "entertainment budget" differently from "savings."

**Applications**:
- Provide bonus SC as separate "play money" that feels distinct from purchased SC
- Frame purchases as "entertainment spending" within a dedicated budget category
- Create separate wallet displays for earned vs. purchased vs. bonus currencies
- Design GC as "free play" currency that establishes separate mental accounts


### 16. Price Anchoring

First price encountered becomes reference point for all subsequent valuations. A high initial anchor makes subsequent prices seem more reasonable.

**Applications**:
- Display premium packages first, making standard packages seem affordable
- Show "full value" before discount price on all promotional bundles
- Use highest tier as anchor in VIP program pricing comparisons
- Present "most popular" mid-tier option between expensive anchor and cheap option


### 17. Decoy Effect (Asymmetric Dominance)

Introducing a third inferior option makes one of the other two appear more attractive.

**Applications**:
- Structure SC packages in three tiers where the middle option has clearly worse value-per-SC than the large package
- Offer a "basic" bonus that makes the "premium" bonus appear vastly superior
- Design VIP tiers where one tier is clearly inferior to the next, nudging upgrades
- Present promotional bundles with a decoy that makes the target offer look optimal


### 18. Endowment Effect

Overvaluing things simply because you own them. Once players possess virtual items, status, or currency, they value it disproportionately higher.

**Applications**:
- Grant trial VIP status so players experience benefits before deciding to maintain them
- Provide temporary exclusive items or avatars that revert unless maintained through engagement
- Give new players a starting SC balance that creates immediate ownership attachment
- Design collections and inventories that accumulate and feel personally valuable


### 19. Hyperbolic Discounting

Disproportionate preference for immediate rewards over larger future rewards.

**Applications**:
- Offer instant small bonuses vs. delayed larger bonuses (most choose instant)
- Front-load subscription benefits (large immediate SC grant + small daily drip)
- Create flash bonuses requiring immediate use ("50 SC if you play in the next 5 minutes")


### 20. Present Bias

Stronger weight given to immediate payoffs. The present feels vivid and concrete; the future feels abstract.

**Applications**:
- Design every interaction to deliver instant feedback (sounds, animations, micro-rewards)
- Use present-focused language ("Feel the excitement now!" not "Build your bankroll")
- Minimize friction between purchase decision and play (one-click, instant activation)
- Create continuous streams of present-moment micro-rewards (badges, progress ticks)


### 21. Transaction Utility

Perceived value from the deal itself, separate from the item's actual utility. People feel pleasure from getting a "good deal."

**Applications**:
- Structure promotions as percentage discounts from displayed reference prices
- Create personalized "exclusive deals" that feel specially curated for the player
- Show itemized value breakdowns ("50 SC + 100K GC + VIP day = $150 value for $40!")
- Rotate promotional offers so there is always an active "deal" available


### 22. Denomination Effect

People spend more freely with smaller denominations or abstract currencies. Spending 10,000 GC feels less impactful than spending $10.

**Applications**:
- Use GC in large denominations (millions) to make spending feel abstract
- Display SC balances in whole numbers rather than dollar equivalents where possible
- Create intermediate currencies (tokens, gems) adding abstraction layers between money and play
- Design purchase flows that emphasize currency units received, not dollars spent


### 23. Payment Depreciation

The psychological pain of a payment fades over time while the consumption persists. Pre-paid credits feel "free" when spent later.

**Applications**:
- Offer prepaid SC bundles and subscription models that front-load the payment
- Create "entertainment fund" pre-loading where players deposit before playing
- Time promotional bundle sales to be purchased well before event usage
- Design monthly subscriptions where daily benefits feel disconnected from the payment


## COGNITIVE ENGAGEMENT

### 24. Fear of Missing Out (FOMO)

Pervasive anxiety that others are having rewarding experiences from which one is absent. Strongest when experiences seem unique, time-limited, and socially valuable.

**Applications**:
- Create limited-time events and promotions with visible participant counts
- Show real-time feeds of players winning during active events
- Use "ending soon" and "X players already joined" indicators on promotions


### 25. Zeigarnik Effect

Incomplete tasks occupy the mind more than completed ones. Unfinished progress creates persistent cognitive tension demanding resolution.

**Applications**:
- Design multi-step challenges and quests with visible progress bars
- Create collection systems (card sets, badge series) with visible gaps
- Use "almost there" messaging for loyalty tier advancement
- Structure tournaments across multiple sessions with running scores


### 26. Near-Miss Effect

Outcomes just short of winning create arousal and motivation comparable to actual wins.

**Applications**:
- Design tournament leaderboards showing near-top placements prominently
- Show how close players are to bonus thresholds ("Just 5 more SC to unlock!")
- Create challenges where partial completion is visible and tantalizingly close
- Display VIP tier progress showing proximity to the next level


### 27. Illusion of Control

Belief that personal actions influence outcomes. Any element of choice creates false sense of skill-based influence.

**Applications**:
- Offer meaningful platform choices (game selection, tournament entry timing, bonus selection)
- Provide strategy guides for platform navigation (not for game odds manipulation)
- Create "player's choice" bonus formats where players select their reward type
- Design customizable dashboards giving players control over their experience layout


### 28. Halo Effect

Positive impressions in one area create broadly favorable assumptions across unrelated areas. A polished UI creates assumptions of fair odds and trustworthy operations.

**Applications**:
- Invest in high-quality UI/UX design that signals professionalism and trust
- Maintain consistent brand quality across all touchpoints
- Feature legitimate licensing, audit certificates, and trust indicators prominently
- Ensure customer support quality matches the platform's visual polish


### 29. IKEA Effect

Overvaluing things one has helped create or build. Players who invest effort in customizing their experience value it disproportionately more.

**Applications**:
- Allow avatar and profile customization with meaningful personalization options
- Create player-built tournament brackets or challenge configurations
- Design loyalty programs where players choose their reward path
- Enable community-contributed content (reviews, guides, event themes)


### 30. Scarcity Principle

Perceived scarcity increases perceived value. Limited availability creates urgency and elevates desirability.

**Applications**:
- Offer limited-edition promotional bundles available for fixed time windows
- Create exclusive VIP-only offers with genuinely limited access
- Design seasonal events with time-bound unique rewards
- Use real inventory counts ("Only 50 spots left in this tournament")


### 31. Commitment Bias

Once committed to a position or course of action, people resist changing it to appear consistent.

**Applications**:
- Create progressive onboarding where early small commitments lead to larger engagement
- Design loyalty programs with visible public progress (badges, ranks)
- Use goal-setting features where players declare intentions and track them
- Build community participation that creates social commitment to the platform


### 32. Functional Fixedness

Inability to see objects beyond their typical use. Players think of the platform only as "gambling" and fail to see alternative engagement modes.

**Applications**:
- Design social features, mini-games, and community activities beyond slot play
- Create entertainment value independent of gambling outcomes (social events, collectibles)
- Offer content discovery features highlighting non-gambling platform experiences
- Build community spaces where social value doesn't depend on spending


## SELF-DETERMINATION AND MOTIVATION

### 33. Self-Determination Theory

Three basic needs drive motivation: autonomy (feeling self-directed), competence (feeling effective), and relatedness (feeling connected).

**Applications**:
- **Autonomy**: Offer meaningful choices (game selection, reward type, play style)
- **Competence**: Provide skill-building through tournaments, leaderboards, and progress systems
- **Relatedness**: Build community features (chat, teams, shared events, social challenges)
- Design platform experiences that satisfy these needs through engagement, not just spending


### 34. Peak-End Rule

Experiences are remembered primarily by their most intense moment (peak) and how they ended, not by the average.

**Applications**:
- Design memorable peak moments in tournaments (dramatic finales, surprise bonuses)
- Ensure sessions end on positive notes (end-of-session summaries highlighting achievements)
- Create strong positive endings for promotional events (closing ceremonies, final rewards)
- Structure player journeys with memorable highlight moments at key milestones


## PERSONALIZATION AND ATTENTION

### 35. Cocktail Party Effect

Ability to selectively attend to relevant information (especially one's own name) in noisy environments. Personalized cues cut through information overload.

**Applications**:
- Use the player's name in important notifications and responsible gaming alerts
- Personalize critical messages so they penetrate notification fatigue
- Design alerts with individually relevant context (personal spending trends, not generic warnings)
- Make responsible gaming information personally relevant, not boilerplate


### 36. Context Collapse

Merging of distinct social contexts into one digital space. Entertainment, social life, and financial activity blur together on the platform.

**Applications**:
- Design clear visual separation between entertainment and financial areas of the platform
- Use distinct UI contexts for social features vs. purchase flows vs. gameplay
- Create "wallet mode" with a distinct look/feel when real money is involved
- Maintain clear boundaries between play money (GC) and real value (SC) contexts


## CULTURAL ADAPTATION

### 37. Cultural Scripts

Implicit, culturally shared behavioral sequences activated by situational cues. Gambling framed to match cultural scripts activates automatic behavioral compliance.

**Applications**:
- Design culturally relevant promotional events (Lunar New Year, Diwali, holidays)
- Localize platform themes and aesthetics for different cultural markets
- Create culturally appropriate community features and social norms
- Adapt communication style and promotional framing for cultural context


### 38. Collectivism/Individualism

Different cultural orientations shape engagement drivers. Collectivist cultures respond to group harmony; individualist cultures respond to personal achievement.

**Applications**:
- Offer both team-based and individual competition formats
- Create community features for collectivist-oriented players (shared goals, group rewards)
- Design personal achievement systems for individualist-oriented players (solo leaderboards)
- Allow players to choose their preferred engagement style (social vs. solo)


### 39. Face-Saving Mechanisms

Preserving social reputation and dignity. Losses threaten social face; private defaults protect dignity.

**Applications**:
- Design private by default — never expose individual losses publicly
- Allow optional sharing of achievements (opt-in, not opt-out)
- Create discreet responsible gaming tools that don't require public self-identification
- Build support systems that protect player privacy and dignity


## SOCIAL DISPLAY

### 40. Deindividuation

Loss of self-awareness in group settings. Online crowd dynamics reduce inhibitions and create shared excitement.

**Applications**:
- Create tournament chat environments fostering shared excitement
- Design group play features where individual actions feel part of collective energy
- Use pseudonym systems allowing comfortable social participation
- Enable crowd-reactive features (animations scale with participant count)


### 41. Spotlight Effect

Overestimating how much others notice and judge one's behavior. Players feel their wins are celebrated and losses scrutinized more than they actually are.

**Applications**:
- Create win celebration systems that validate achievement moments
- Design discrete loss handling (no public shame or loss displays)
- Offer optional sharing — let players choose what to publicize
- Build leaderboards based on achievements and participation, not just spending


### 42. Hedonic Adaptation

The tendency to return to a baseline happiness level after positive events. Initial excitement from rewards diminishes with repetition, requiring variety.

**Applications**:
- Rotate reward types and bonus structures to maintain novelty
- Introduce new game categories, tournament formats, and social features regularly
- Escalate VIP perks progressively to stay ahead of adaptation
- Use surprise and variety in reward delivery to prevent predictability


## CURRENCY AND VALUE FRAMING

### 43. Reference Point Manipulation

Altering the baseline against which outcomes are evaluated. By shifting what players consider "normal," the platform redefines what feels like a win or loss.

**Applications**:
- Show recent jackpot winners to shift upward what players consider an achievable outcome
- Set initial bonus levels high to establish elevated expectations
- Use personalized messaging that frames results relative to curated benchmarks
- Design tier systems where the player's current tier always feels close to the next level


## COMPOUND EFFECT CHAINS

These effects do not operate in isolation. Key amplification chains visible in UI:

| Chain | Effects Involved | Combined Impact |
|-|-|-|
| Loss spiral | Loss aversion → Sunk cost → Commitment bias | Players chase losses with increasing commitment while rationalizing each step |
| Social trap | Social proof → Conformity → Bandwagon | False norms emerge where heavy engagement appears universally accepted |
| Identity capture | Social identity → Commitment bias → Endowment → IKEA effect | Platform engagement becomes fused with personal identity, making exit feel like self-loss |
| FOMO cascade | Scarcity → FOMO → Bandwagon → Deindividuation | Manufactured urgency drives impulsive group-accelerated engagement |
