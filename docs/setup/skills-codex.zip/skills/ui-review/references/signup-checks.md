# Signup, Login, and Welcome Screen Checks

Apply these checks when the screenshot shows a registration, authentication, or first-session screen. These supplement the Registration (RE1-RE7) checks in the knowledge base with screen-specific detail.

=== TRIGGER ===

Run when the screenshot shows:
- A signup or registration form
- A login screen
- An email/phone verification or OTP screen
- A welcome or onboarding screen (first-session)
- A permission request pre-prompt
- A tutorial or coach mark overlay

Do NOT run on: in-app profile edit screens (use profile-checks), password reset flows (only RE7 error quality applies), or mid-session popups (use popup-checks).

=== END TRIGGER ===

---

## Signup Form (SU-F) — Supplements RE1-RE7

**SU-F1. Password field UX**
Look for: Password field design on signup or login screens.
Pass: Show/hide toggle (eye icon) on the right side of the password field. Default state is masked. No "Confirm Password" field (show/hide toggle replaces it). If password requirements exist, they appear as a live-updating checklist below the field.
Fail: No show/hide toggle. Or "Confirm Password" field present alongside a show/hide toggle.
Evidence: Removing confirm-password and adding show/hide toggle produced 56% increase in conversion in documented testing. Confirm field adds friction without security benefit when visibility toggle exists.

**SU-F2. Forgot password placement**
Look for: On login screens — where is the "Forgot password?" link?
Pass: Adjacent to the password field (typically below-left), following left-to-right eye tracking. Visible without scrolling.
Fail: "Forgot password?" below the submit button or buried in footer text.
Not applicable: Signup screens (no forgot-password needed).
Evidence: Users scanning a login form expect password recovery near the password field. Placing it below the CTA delays discovery.

**SU-F3. Above-fold completeness**
Look for: Does the entire form fit within the visible screen area?
Pass: All form fields and the CTA button visible without scrolling on a standard mobile viewport.
Fail: CTA button below the fold. Or form extends so far down that users may not realize there are more fields.
Evidence: If the CTA is invisible, conversion drops. Single-column layout is mandatory on mobile.

---

## Social Login (SU-S)

**SU-S1. Provider brand compliance**
Look for: Social login buttons (Google, Apple, Facebook).
Pass: Each button follows its provider's official branding (correct logo, approved color, approved text like "Sign in with Google"). Maximum 3 social login providers shown.
Fail: Custom-styled social buttons that don't match provider branding. Or 4+ social login options creating choice overload.
Evidence: Brand compliance is required by providers and builds trust. More than 3 options increases decision time (Hick's Law).

**SU-S2. Social-form separation**
Look for: Visual relationship between social login buttons and the email/password form.
Pass: Clear visual separator ("or" divider line, spacing, or distinct section) between social login area and traditional form.
Fail: Social buttons and form fields blended together with no visual boundary.
Evidence: Users need to quickly identify two distinct paths (social vs. email). Without separation, the interface reads as one confusing form.

---

## Verification Screen (SU-V)

**SU-V1. OTP input design**
Look for: The code entry interface on verification screens.
Pass: Individual character boxes (one per digit) matching the expected code length. Numeric keyboard triggered. Sent-to address/phone displayed with an "Edit" option.
Fail: Single text input field for OTP (user can't gauge expected length). Or full alphanumeric keyboard for a numeric code. Or no indication of where the code was sent.
Evidence: Individual boxes make expected length obvious and reduce entry errors. Displaying the destination prevents indefinite waiting for a code sent to the wrong address.

**SU-V2. Resend and fallback**
Look for: Recovery options if the code doesn't arrive.
Pass: "Resend code" button (visible after a timed delay, e.g., 45 seconds). Alternative delivery method available (voice call if SMS, email if phone).
Fail: No resend option visible. Or resend immediately available with no cooldown (spam risk).
Evidence: Verification screens are high-anxiety moments. Clear recovery paths prevent abandonment.

---

## Welcome Screen (SU-W)

**SU-W1. Value proposition clarity**
Look for: The primary headline on the welcome or onboarding screen.
Pass: Benefit-oriented headline (5-8 words) stating what the user gains — "Track your workouts in 30 seconds." Supporting subheading adds specificity. Social proof visible if available ("Join 2M+ users").
Fail: Generic headline — "Welcome to AppName" or "Get Started." No value proposition before the CTA.
Evidence: 25% of users abandon after a single session. Well-structured onboarding increases retention by up to 50%. The headline must answer "why should I stay?" in under 5 seconds.

**SU-W2. Onboarding screen count**
Look for: If visible — how many onboarding steps or pages are indicated?
Pass: 3-5 onboarding screens total. Progress indicator visible (dots, step counter). Skip option available.
Fail: 6+ onboarding screens. Or no indication of total steps (user doesn't know when it ends). Or no skip option.
Not applicable: Only one screen visible; cannot count total.
Evidence: 3-5 screens produce optimal activation rates. More causes drop-offs. A skip option respects user autonomy.

---

## Permission Pre-Prompt (SU-P)

**SU-P1. Pre-prompt design**
Look for: A custom permission request screen (appearing before the OS system dialog).
Pass: Custom screen explains the specific user benefit of granting permission ("...so you can quickly find departure airports near you"). Primary action ("Allow") and secondary action ("Not Now") both visible. No dark patterns.
Fail: No pre-prompt — OS dialog fires without context. Or pre-prompt uses shaming language or hides the decline option.
Not applicable: No permission request visible.
Evidence: Users are 12% more likely to grant permission when given a reason. Compelling rationales yield up to 81% higher acceptance rates.

---

## Tutorial Overlay (SU-T)

**SU-T1. Coach mark quality**
Look for: Tutorial overlays, coach marks, or instructional tooltips.
Pass: Each overlay teaches one interaction only. Text is ultra-short (one sentence). Overlay is visually distinct from the app UI (tinted background, different styling). Dismiss/close control visible.
Fail: Multiple tips stacked on one screen. Lengthy text paragraphs in overlays. Overlay styling indistinguishable from actual UI elements. No dismiss option.
Not applicable: No tutorial overlay visible.
Evidence: Short-term memory fades in ~20 seconds. Multi-tip overlays overwhelm rather than teach. Coach marks do not fix bad UI design — if the interface requires extensive explanation, redesign the interface.

---

## First-Session Reward (SU-R) — Run when visible on welcome/onboarding screens

**SU-R1. Reward presentation**
Look for: First-session reward, welcome bonus, or daily reward calendar.
Pass: Reward presented during or immediately after the tutorial (not before). Full-screen celebration with clear labeling — item name, quantity, and what it does. "Claim" CTA is obvious.
Fail: Reward shown with no explanation of what it is or does. Or in-app purchase prompts appearing before the user has experienced normal gameplay.
Not applicable: No reward mechanic visible.
Evidence: Only ~33% of users return after day 1. Early reward presentation builds engagement before monetization. Average time to first purchase is ~2 days post-install.

---

## Output framing

**Research-backed:** "Registration/onboarding research indicates [principle]. This screen's [element] uses [current approach] — [alternative] is associated with higher completion rates."

**Never use:** "This form will have X% abandonment", "Users will not complete signup", "This violates App Store requirements" (frame as deviation from best practice).
