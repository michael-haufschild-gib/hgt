# Offer Design Checks — Purchase Offers in Any Context

Apply these checks whenever a purchase offer is visible — in a shop, popup, modal, promotion page, or inline offer. These evaluate the offer itself, not its container.

=== TRIGGER ===

Run these checks when the screenshot shows one or more purchase offers with visible prices. This includes:
- Shop/store offer cards
- Purchase popups and modals
- Promotional offer screens
- Bundle or package presentations
- First-purchase / welcome offers

Do NOT run on screens that show no purchase offers (gameplay, settings, navigation).

=== END TRIGGER ===

---

## Single Offer (OF-S) — Run on every visible offer

**OF-S1. Charm pricing**
Look for: Price endings on every visible price tag.
Pass: Prices end in .99 ($0.99, $4.99, $9.99, $19.99, $49.99, $99.99).
Fail: Round prices ($5.00, $10, $20) or non-.99 endings.
Evidence: Prices ending in 9 increase conversion by 24%. The left-digit effect makes $4.99 feel closer to $4 than $5.

**OF-S2. Reference pricing / anchoring**
Look for: Strikethrough "original" prices, "Was $X / Now $Y", or a high-value anchor visible before the actual price.
Pass: High anchor visible before the offer price. Savings frame is clear ("~~$24.99~~ $9.99" or "$100 value — yours for $9.99").
Not applicable: No reference pricing present (not a failure for standard offers, but a missed opportunity for promotional offers).
Evidence: First price seen dominates perception. Anchoring increases purchase likelihood by up to 30%.

**OF-S3. Value communication**
Look for: Can the user evaluate what they're getting? Is value translated into terms the user understands?
Pass: At least one of: (a) gameplay translation ("enough for 500 spins"), (b) value ratio visible ("X% more value"), (c) comparison to another tier or to regular pricing.
Fail: Raw numbers only with no context. A new user cannot evaluate whether 50,000 coins is a lot or a little.
Evidence: Users who can't evaluate value experience decision paralysis. Value translation reduces cognitive load and increases purchase confidence.

**OF-S4. Offer completeness**
Look for: Does the offer card/popup contain all elements needed for a purchase decision?
Pass: Product visual, quantity/amount, price, and purchase button all visible. The user can decide without scrolling or tapping for more info.
Fail: Missing price. Missing quantity. Purchase button not visible. User must tap "details" to understand what they're buying.
Evidence: Every missing element adds friction. Purchase decisions require product, price, and action in one view.

**OF-S5. Price button clarity and placement**
Look for: Position and text of the purchase button.
Pass: Button in bottom portion of offer (thumb zone on mobile). Text shows price or clear action ("$9.99" or "Buy Now"). High contrast against background.
Fail: Button at top. Button text is ambiguous ("Go", "OK"). Low contrast against offer background.
Evidence: Mobile interactions are thumb-driven. Ambiguous button text adds cognitive load.

**OF-S6. Urgency quality**
Look for: Countdown timers, "Limited time", "Expires in", "Last chance" messaging on the offer.
Pass: One authentic time-limited element with a specific countdown tied to this offer. Urgency language is factual.
Partial: Timer present but no clear end condition. Generic "Limited time" without specifics.
Fail: Aggressive urgency stacking (timer + "LAST CHANCE" + "HURRY"). Or no urgency on an offer that would benefit from it (promotional/featured offers).
Not applicable: Standard always-available offers don't need urgency.
Evidence: Countdown timers improve performance by ~8%. But urgency overuse triggers reactance.

**OF-S7. Endowment indicators**
Look for: Elements that create psychological ownership before the purchase:
- Partially filled progress bars
- "Your bonus is waiting" / "You've earned this" language
- Interactive reveal mechanics (scratch card, wheel)
- Pre-accumulated value displays (piggy bank showing coins)
Pass: At least one endowment mechanism creates ownership before the purchase ask.
Not applicable: Standard shop cards (endowment is more relevant for promotional/popup offers).
Evidence: Endowment effect: people value things more once they feel ownership. Pre-filled progress bars significantly increase completion rates. 48% of second purchases occur within one hour — endowment mechanics capture this momentum.

---

## Sweepstakes Offer (OF-K) — Run when sweepstakes casino context

**OF-K1. Currency hierarchy**
Look for: How Gold Coins (GC) and Free Sweepstake Coins (SC) are presented.
Pass: GC amount is the headline number (largest, boldest). SC amount is secondary with "FREE" or "BONUS" label. SC does not have a dollar value attached.
Fail: SC larger or more prominent than GC. SC presented as the primary product.
Evidence: Sweepstakes platforms consistently use GC-primary framing. Reversing it confuses the currency hierarchy for users.

**OF-K2. SC/$ and GC/$ ratio clarity**
Look for: Can the user compare value across tiers? Are the ratios visible or computable?
Pass: Bonus percentage, coins-per-dollar, or "X% more value" visible on cards. Or ratio is easily computable from displayed numbers.
Fail: Raw GC and SC numbers with no comparative context. User must do mental math across cards.
Evidence: 67% of paying sweepstakes players evaluate offers by SC value. If the ratio isn't visible or obvious, the user can't evaluate the offer.

---

## Multi-Offer (OF-M) — Run when 2+ offers are visible together

**OF-M1. Target tier identification**
Look for: Which offer is the business trying to sell? Is there a visually emphasized "target" tier?
Pass: One tier is clearly the target — badge ("Most Popular", "Best Value"), visual emphasis (larger card, highlighted border, different color), or positioning (center of grid).
Fail: All tiers styled identically. No visual emphasis on any tier. Or emphasis on the lowest-priced tier (undermines upsell).
Evidence: The target option must be unmistakable at a glance. Social proof badges ("Most Popular") outperform value badges ("Best Value") for new users.

**OF-M2. Bonus escalation**
Look for: Compare value-per-dollar across visible price tiers.
Pass: Higher-priced tiers offer more value per dollar. The escalation is visible (bonus % label, "X% MORE" text) — user doesn't need to compute it.
Fail: Flat value across tiers (no incentive to buy larger). Or higher tier offers worse value without being an intentional decoy.
Skip: Only 1 tier visible, or amounts not legible.
Evidence: Non-linear bonus escalation is the primary upsell driver. Players who can see the value increase buy larger packages.

**OF-M3. Decoy structure**
Look for: Within 3+ visible tiers, is one tier clearly dominated by an adjacent tier?
Pass: A tier exists that makes the target tier look obviously better (e.g., $5 for 5,000 coins next to $7 for 15,000 coins).
Not applicable: Fewer than 3 tiers visible, or all tiers offer genuinely different value propositions.
Evidence: Asymmetric dominance shifts choice share toward the target option by up to 30%.

**OF-M4. Price range coverage**
Look for: What price range do visible offers span?
Pass: Range covers micro ($0.99-$2.99) to mid ($9.99-$19.99) to premium ($49.99+). Entry point is accessible.
Fail: All offers above $10 (no accessible entry). Or all offers below $5 (no premium option for high-value players).
Evidence: Starter offers under $10 drive first purchases. 37% of first-time buyers make second purchases. Premium tiers serve high-value segments (1-2% of players generating 50-70% of revenue).

**OF-M5. Comparison ease**
Look for: Can the user compare offers at a glance?
Pass: Offers use consistent layout — same element positions, same visual hierarchy. Price and value differences are the only variables.
Fail: Inconsistent card layouts across tiers. Different information shown on different cards. User must hunt for comparable data points.
Evidence: Comparison requires consistent visual structure. Inconsistent layouts force serial reading instead of parallel comparison.

---

## Output framing

**Research-backed:** "Research indicates [principle]. This offer's [element] uses [current approach] — [alternative] is associated with stronger performance."

**Never use:** "This offer will convert at X%", "Expect X% improvement", "This creates legal/compliance risk."
