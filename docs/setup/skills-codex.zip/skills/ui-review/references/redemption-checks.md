# Redemption / Withdrawal Screen Checks

Apply these checks when the screenshot shows a cashout, withdrawal, or redemption screen — where users convert virtual currency or balances into real-world value (cash, gift cards, bank transfers).

=== TRIGGER ===

Run when the screenshot shows:
- A withdrawal or cashout screen with a balance and payout method
- A redemption screen for converting virtual currency to real value
- A payout confirmation or pre-confirmation summary screen

Do NOT run on: shop/purchase screens (use offer-design-checks), general account/settings pages, or transaction history lists.

=== END TRIGGER ===

---

## Balance Display (RD-B)

**RD-B1. Withdrawable balance prominence**
Look for: The user's withdrawable balance. Is it the largest, most prominent number on screen?
Pass: Withdrawable amount is the primary number — largest type size, top of visual hierarchy.
Fail: Total balance shown as primary with withdrawable amount buried or secondary. Or no balance visible.
Evidence: Users experience anxiety about available funds at the transaction moment. Balance must be accessible instantly.

**RD-B2. Balance type separation**
Look for: Are different balance types (total vs. withdrawable, or dual currencies like GC vs. SC) visually separated?
Pass: Distinct fields with clear labels. Locked/pending/ineligible amounts explained inline with brief text or tooltip icon.
Fail: Single undifferentiated balance number. Or multiple balances with identical visual treatment and no explanation of differences.
Evidence: Users frequently encounter confusion about why their full balance is not available for withdrawal.

**RD-B3. Minimum threshold visibility**
Look for: Is the minimum withdrawal amount displayed on the screen?
Pass: Minimum threshold shown on the withdrawal screen (not buried in terms). If below minimum, a progress indicator or explanation is visible. Withdrawal button disabled with reason when ineligible.
Fail: No minimum threshold displayed. Or user can attempt withdrawal only to receive an error.
Evidence: Unclear thresholds generate support tickets and frustration. Inline validation prevents submission of sub-threshold amounts.

---

## Fee and Processing Transparency (RD-F)

**RD-F1. Fee disclosure before confirmation**
Look for: Are fees visible before the user taps the final confirmation button?
Pass: Fee amount (or "No fee") shown explicitly. Net amount (after fees) displayed alongside gross amount.
Fail: No fee information visible. Or fees only revealed post-confirmation.
Evidence: Unexpected charges create a strongly negative experience. Users must see exact deductions before committing.

**RD-F2. Processing time per method**
Look for: Is the estimated processing time shown for each payment method, visible at the selection stage?
Pass: Plain-language time estimates ("Arrives in 1-2 business days") shown alongside each method before selection.
Fail: No processing time information. Or jargon like "T+2" instead of plain language.
Evidence: Processing time information reduces post-submission anxiety and helps users choose methods that match their urgency.

---

## Payment Method Selection (RD-P)

**RD-P1. Method presentation with icons**
Look for: How are payment methods displayed?
Pass: Recognizable brand icons (PayPal, bank logos, gift card images) with text labels. Methods ordered by popularity or speed. Similar methods grouped together.
Fail: Text-only list with no icons. Or methods in arbitrary order with no grouping.
Evidence: Brand icons serve as trust signals and speed recognition. Grouping reduces cognitive load.

**RD-P2. Method differentiation**
Look for: Can the user compare methods at a glance?
Pass: Speed, fee, and/or minimum differences visible per method. A "Recommended" or "Fastest" label on the optimal method.
Fail: All methods displayed identically with no differentiating information.
Evidence: Users need to compare speed and cost without tapping into each method individually.

**RD-P3. Saved method recall**
Look for: If this appears to be a returning user — are previously used payment methods shown?
Pass: Saved/previous methods displayed with recall cues (last 4 digits, method name).
Fail: No saved method indication despite likely returning user context.
Not applicable: Cannot determine if user is new or returning from screenshot.
Evidence: Saved methods reduce friction for repeat withdrawals.

---

## Confirmation and CTA (RD-C)

**RD-C1. Pre-confirmation summary completeness**
Look for: Before the final button — is a complete transaction summary visible?
Pass: Summary shows: withdrawal amount, fee (if any), net amount received, payment method/destination, and estimated arrival time.
Fail: Missing any of: amount, fee, net, method, or ETA. Or user must scroll/navigate to find summary.
Evidence: The pre-confirmation summary is the highest-trust moment. Incomplete summaries create uncertainty.

**RD-C2. CTA label specificity**
Look for: Text on the confirmation button.
Pass: Specific label including amount and/or method: "Withdraw $50 to PayPal" or "Redeem 100 SC."
Fail: Generic label: "Confirm," "Submit," or "OK."
Evidence: Specific CTA labels outperform generic ones by reducing ambiguity at the commitment moment.

**RD-C3. Dynamic CTA updates**
Look for: Does the CTA button text reflect the user's current selections?
Pass: Button text updates when payment method or amount changes.
Fail: Static button text regardless of selections.
Not applicable: Only one payment method or fixed amount visible.
Evidence: Dynamic button text confirms the user's choices without requiring re-reading the form.

---

## Sweepstakes Redemption (RD-K) — Run ONLY with sweepstakes casino context

**RD-K1. Currency eligibility clarity**
Look for: Is it clear which currency qualifies for redemption?
Pass: Only redeemable currency (Free Sweepstake Coins) shown as withdrawable. Non-redeemable currency (Gold Coins) either absent or clearly marked as not eligible.
Fail: Both currencies displayed without clear indication of which is redeemable. Or GC shown alongside withdrawal options.
Evidence: Dual-currency confusion is the primary support issue on sweepstakes redemption screens.

**RD-K2. Redemption method options**
Look for: Are the available redemption methods appropriate for a sweepstakes platform?
Pass: Standard methods visible (PayPal, bank transfer, gift cards) with recognizable icons. Per-method minimums displayed.
Fail: Single method only with no alternatives. Or methods without minimum/processing information.
Evidence: Sweepstakes platforms offer varied methods with different minimums and processing times. Users need this information upfront.

---

## Output framing

**Research-backed:** "Withdrawal UX research indicates [principle]. This screen's [element] uses [current approach] — [alternative] is associated with higher completion and reduced support inquiries."

**Never use:** "This screen will cause abandonment at X%", "This creates legal/compliance risk", "Users will lose money because of [element]."
