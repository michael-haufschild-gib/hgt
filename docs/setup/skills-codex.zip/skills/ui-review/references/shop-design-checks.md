# Shop Design Checks — Social Casino / Virtual Currency Store

=== COVERAGE GATE (MANDATORY) ===

Before running ANY check below, classify the screenshot's shop coverage level.

**FULL** — any ONE of these:
- Preprocessing generated >2 section crops (tall scroll capture)
- User explicitly states "full shop" or "entire shop"
- ALL three: (a) 2+ distinct shop sections visible, (b) both shop header and footer/bottom-nav visible, (c) no content cut off at any edge

**VIEWPORT** — all of these:
- Header and bottom navigation both visible
- 1-2 shop sections visible
- Not classified as FULL

**PARTIAL** — any ONE of these:
- Header OR bottom navigation missing
- Content visibly cut off at screen edges
- Fewer than 1 complete section visible

**Run checks by level:**
- FULL → SD-E + SD-S + SD-A (all checks)
- VIEWPORT → SD-E + SD-S only
- PARTIAL → SD-E only

When a check is SKIPPED due to coverage, do not report it as a finding. List skipped check categories once in the "Not assessable" line.

=== END COVERAGE GATE ===

---

## Element-Level (SD-E) — Run on ANY visible card

**Offer-level checks**: Also run all applicable checks from [offer-design-checks.md](offer-design-checks.md) (OF-S, OF-K, OF-M) on visible offer cards. The checks below are shop-specific — they evaluate how offers are presented within a shop layout.

**SD-E2. Card anatomy completeness**
Look for: Each visible offer card. Check for: (1) coin pile/currency illustration, (2) Gold Coin amount as primary text, (3) Free Sweepstake Coins amount as secondary text, (4) price button, (5) value indicator (badge, bonus %, or coins-per-dollar).
Pass: All 5 elements present on every card.
Fail: Missing any essential element.
Evidence: Offer cards need 3-tier visual hierarchy: hero image + price (Tier 1), badges + bonus (Tier 2), fine print (Tier 3).


---

## Section-Level (SD-S) — Run when a complete section is visible

**SD-S1. Grid layout for standard packages**
Look for: How standard coin packages are arranged within their section.
Pass: Card-based grid layout (2 or 3 columns). Vertical scroll for additional rows.
Fail: Single-column list layout. Horizontal carousel hiding packages behind swipe.
Evidence: Vertical scroll with card-based grid is optimal for IAP shops. Grid enables simultaneous comparison.

**SD-S2. Featured deal prominence**
Look for: If a featured/promotional section is visible — is it visually distinct from standard packages?
Pass: Featured deal has full-width banner, larger card, or distinct visual treatment.
Fail: Featured deal styled identically to standard packages.
Note: Only assess if a featured section is visible.
Evidence: Top-to-bottom hierarchy: featured deal → free daily reward → standard packages → bundles.

**SD-S5. Daily reward placement in shop**
Look for: A free daily reward claim button or section within the shop.
Pass: Free daily reward visible within the shop, positioned near the top, before paid offers.
Fail: No free daily reward visible within the shop area.
Note: At VIEWPORT coverage, if not visible, state "may exist in scrolled area."
Evidence: Placing daily claim inside the shop forces daily exposure to paid offers, creating reciprocity.

**SD-S6. Section header clarity**
Look for: Text labels on visible shop sections ("Special Offers," "Gold Coin Packages," "Bundles").
Pass: Each section has a clear, descriptive header. Headers differentiate sections meaningfully.
Fail: No section headers. Generic/identical headers. Headers that don't explain section differences.
Evidence: When offering more than 6 packages, use categories to reduce cognitive load.

---

## Architecture-Level (SD-A) — Run ONLY at FULL coverage

**SD-A1. Tier count (6 recommended)**
Look for: Count all distinct price tiers in the standard packages section.
Pass: ~6 standard tiers fitting in a 3x2 grid. Price range spans micro ($0.99-$1.99) to premium ($99.99).
Fail: Fewer than 4 tiers (insufficient anchoring). More than 8 tiers in a single view (choice overload).
Evidence: 6 tiers in a 3x2 grid is optimal — fits without scrolling and provides enough range for anchoring and decoy structure.

**SD-A2. Section ordering**
Look for: The top-to-bottom sequence of shop sections.
Pass: Featured/limited-time deal at top → free daily reward → standard packages → bundles below.
Fail: Standard packages above featured deals. Daily reward at the bottom.
Evidence: Free reward before paid offers creates reciprocity.

**SD-A3. First-purchase offer presence**
Look for: A visually distinct first-purchase or "Welcome Bonus" offer.
Pass: First-purchase offer with special pricing, bonus value, "one-time"/"Welcome" framing.
Fail: No first-purchase offer visible anywhere in the shop.
Note: Only flag absence at FULL coverage.
Evidence: First-purchase buyers tend to make additional purchases. Optimal price range under $10 with bonus value.

**SD-A4. Bundle section presence**
Look for: A section offering bundles (Gold Coins + extras like boosters, VIP points, exclusive items).
Pass: Bundles section exists separately from standard packages. Both individual and bundles available (mixed bundling).
Fail: Only individual coin packages with no bundles. OR only bundles with no individual packages.
Evidence: Mixed bundling outperforms pure bundling or pure individual sales.

**SD-A5. Scarcity mechanics implementation**
Look for: Countdown timers, "Limited" labels, "Only X remaining" indicators.
Pass: At least one time-limited offer with a visible, specific countdown. Timer appears authentic.
Fail: No urgency mechanics anywhere in the shop. OR every package has a timer (overuse).
Evidence: Limited-time IAP offers are present in every top-grossing game. Authentic scarcity converts better than manufactured urgency.

**SD-A6. Advanced monetization mechanics (piggy bank, progressive complexity)**
Look for: (a) A visual accumulator (piggy bank, vault, chest) showing partially-filled coins. (b) Signs the shop adapts to user progression (level indicators, VIP tier badges).
Pass: Either mechanic present.
Fail: Neither present.
Output: If absent, report as a single sentence: "No piggy bank or progression-scaling mechanics visible — these are growth-phase features, not launch requirements."
Evidence: Endowment effect drives piggy bank conversions. Level-scaled offers prevent choice overload for new users.

**SD-A7. Checkout friction indicators**
Look for: Payment method icons (Apple Pay, Google Pay, credit card logos) visible in the shop or on cards.
Pass: Multiple payment method icons visible.
Fail: No payment method indicators visible anywhere.
Output: If absent, state: "No payment method icons visible — verify checkout supports Apple Pay / Google Pay."
Evidence: Biometric checkout significantly improves conversion. Mobile checkout has very high abandonment.
