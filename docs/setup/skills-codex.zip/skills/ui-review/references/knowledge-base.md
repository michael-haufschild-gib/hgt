# Visual Assessment Checklist

## Universal (every screenshot)

**U1. CTA pop-out**
Look for: The primary action button. Does it have a unique color, size, or shape that nothing else on screen shares?
Pass: CTA has at least one attribute unique to it alone — instantly findable without reading.
Fail: CTA shares its color with other buttons, or blends into the page. Multiple elements compete for attention.
Check with: `grayscale.png` — does the CTA still stand out without color?
Check with: `saliency.png` — does the CTA appear in a high-saliency (red/yellow) zone? If decorative elements generate higher saliency than the CTA, it fails pop-out.
Evidence: Unique pre-attentive features detected in <200ms; conjunctions require slow serial search.

**U2. Single primary action**
Look for: Count the number of equally-weighted CTAs on screen.
Pass: One clear primary CTA per screen section. Secondary actions are visually subordinate.
Fail: 3+ CTAs competing at equal visual weight. User must read all to decide.
Evidence: Decision time increases with choice count (Hick's Law). Single-CTA pages outperform multi-CTA.

**U3. Information scent**
Look for: Navigation labels, headings, and CTA text. Do they contain words a user with a specific goal would scan for?
Pass: Labels are specific and descriptive — "See pricing plans", "Download the report", "Track your order."
Fail: Labels are generic — "Learn More", "Get Started", "Solutions", "Resources."
Evidence: Users make stay-or-leave decisions based on whether visible labels contain their goal's trigger words.

**U4. Cognitive load (squint test)**
Look for: Use `blur.png` result from Phase 3. Can you identify (a) the primary action, (b) the information groupings, (c) where you are in a flow?
Pass: All three identifiable even when blurred.
Fail: More than 3 visual groupings competing for attention, or primary action disappears when blurred.
Evidence: Extraneous cognitive load from poor layout degrades task performance.

**U5. Visual hierarchy without color**
Look for: Use `grayscale.png` result from Phase 3. Do headings, body text, and CTAs remain distinguishable by size/weight alone?
Pass: Clear hierarchy through font size and weight differences. Sections remain separated.
Fail: Everything becomes same gray weight. Headings indistinguishable from body.
Evidence: The distinct item is remembered; if nothing is distinct, nothing stands out (Von Restorff).

**U6. Scan-pattern alignment**
Look for: Where is the most important content and primary CTA positioned? Match the layout type to the applicable scan pattern:
- **Text-heavy pages**: F-pattern. Key content in top-left quadrant. CTA in a natural stopping point of the left-side vertical scan.
- **Visual-led marketing pages**: Z-pattern. CTA belongs at the terminal position (bottom-right or center-bottom).
- **Card/grid layouts**: Center-out. Primary action in or near center.
- **Mobile app screens**: Center-bottom. Thumb zone (bottom half, center) is the primary interaction area.
Pass: Primary content and CTA positioned in the high-attention zones of the applicable scan pattern.
Fail: Primary content or CTA in the dead zone of the applicable pattern.
Evidence: F-pattern on content-heavy pages, Z-pattern on simple visual layouts. Mobile sessions are very short.

**U7. Grouping and proximity**
Look for: Are related elements visually grouped? Labels near their fields? Prices near their products? Actions near the content they affect?
Pass: Related items are proximate, separated from unrelated items by whitespace or borders.
Fail: Labels far from inputs. Price disconnected from product card. Action buttons detached from the content they apply to.
Evidence: Elements near each other are perceived as related (Gestalt proximity).

**U8. Professional visual design**
Look for: Overall visual consistency — alignment, spacing rhythm, color palette coherence, typography consistency.
Pass: Consistent grid, uniform spacing, cohesive color palette, elements aligned to common axes.
Fail: Misaligned elements, inconsistent spacing, clashing colors, mixed visual styles for same-function elements.
Evidence: Visual design is the primary credibility factor for a large share of users.

**U9. Organizational identity**
Look for: Company name, logo, "About" link, physical address, or team page link visible anywhere on screen.
Pass: Real organization clearly identified — name/logo prominent, "About us" or address visible.
Fail: Anonymous — no company name, no logo, no way to verify who runs this.
Evidence: Sites without visible organizational identity fail credibility for most users.

**U10. Contact information**
Look for: Email, phone number, chat widget, or "Contact" link visible without scrolling or navigating.
Pass: Contact method visible or prominently linked.
Fail: No contact information visible. Contact buried in footer sub-links or entirely absent.
Evidence: Visible contact info signals trustworthiness.

**U11. Social proof**
Look for: Reviews, star ratings, testimonials, user counts, purchase counts, client logos, or "X people viewing this" indicators.
Pass: At least one form of social proof visible near a conversion point.
Fail: Conversion page with zero social proof elements.
Evidence: Social proof near conversion points significantly increases purchase likelihood.

**U12. Dark pattern detection**
Look for: Confirmshaming language ("No thanks, I don't want to save money"), fake scarcity (countdown timers, "only 2 left"), pre-checked consent boxes, disguised ads that look like content.
Pass: Opt-out is straightforward. No emotional manipulation. Scarcity claims appear genuine.
Fail: Confirmshaming on decline buttons. Countdown timers on non-time-limited offers. Pre-checked marketing consent. Ads disguised as content.
Evidence: Dark patterns are common and users are increasingly aware and distrustful of them.

**U13. Contrast ratios**
Look for: Use `analysis.txt` computed WCAG contrast ratios. Check text-likely colors against background-likely colors.
Pass: All text-background pairs meet WCAG AA (4.5:1 normal text, 3:1 large text).
Fail: Any pair below 3:1. Critical text below 4.5:1.
Evidence: WCAG 2.1 requires 4.5:1 normal / 3:1 large.

**U14. Color not sole indicator**
Look for: Status indicators, error states, success states, active tabs, selected items. Is color the ONLY differentiator?
Pass: Icons, text labels, or borders supplement color (e.g., red X icon + "Error" text, not just red border).
Fail: Red/green as sole status indicator. Active tab distinguished only by color tint.
Check with: `deuteranopia.png` — do status indicators, badges, and CTAs remain distinguishable when red-green contrast is removed?
Evidence: Color-only indicators fail for ~1 in 11 users.

**U15. Banner blindness risk**
Look for: Critical information or CTAs placed in banner-like rectangular blocks with promotional colors, especially in right column or page top/bottom.
Pass: Critical actions are embedded in content flow, not isolated in ad-like containers.
Fail: Important CTA in a bright rectangular banner in the right column or page top. Users will ignore it.
Evidence: Stable avoidance of ad-like structures across decades of eye-tracking.

**U16. Interruption count**
Look for: Count visible modals, notification badges, alert banners, overlays, and interstitials that appear without user initiation.
Pass: 0-1 involuntary interruptions visible.
Fail: 2+ simultaneous modals/banners/alerts competing for attention.
Evidence: Each interruption creates attention residue and degrades task performance.

**U17. Menu structure**
Look for: Count top-level navigation items. Check for deep dropdown hierarchies.
Pass: 5-7 primary nav items. Dropdowns max 2 levels deep. Options grouped/categorized.
Fail: 8+ undifferentiated nav items. Deep nested dropdowns (3+ levels). Flat list of 20+ ungrouped options.
Evidence: Decision time increases with choice count (Hick's Law). 3-4 chunks for novel items.

**U18. Serial position**
Look for: Order of navigation items or list options. Are the most important items at the start and end?
Pass: Key items positioned first and last in nav/lists. Less critical items in middle.
Fail: Most important feature buried in the middle of the nav bar.
Evidence: Primacy and recency effects — middle positions are forgotten.

**U19. Anchoring (pricing)**
Look for: On pricing pages — which price is the user exposed to FIRST? Left-to-right reading order.
Pass: Most expensive tier shown first (leftmost or most prominent), or strikethrough "original price" visible before sale price.
Fail: Cheapest plan shown first — anchors perception low, making middle tier feel expensive.
Evidence: First price seen dominates perception (anchoring). Less knowledgeable users are more susceptible.

**U20. Defaults serve the user**
Look for: Pre-selected options, pre-checked checkboxes, pre-chosen plans or settings.
Pass: Defaults match likely user preference (e.g., most popular plan pre-selected, marketing consent unchecked).
Fail: Most expensive plan pre-selected. Marketing consent pre-checked. Data sharing pre-enabled.
Evidence: Users perceive defaults as implicit recommendations — exploiting this is a dark pattern.

**U21. Loss framing honesty**
Look for: Urgency messaging — "Don't miss out", "Your cart will expire", countdown timers, "only X left" claims.
Pass: Urgency messaging used sparingly. Scarcity claims appear genuine (tied to real inventory or time).
Fail: Multiple urgency mechanisms stacked. Countdown timers on non-time-limited offers. "Only 2 left" that never changes.
Evidence: Loss framing is the strongest conversion driver but overuse destroys trust.

**U22. Progress indicator**
Look for: Any multi-step flow — is there a visible step indicator, progress bar, or "Step X of Y"?
Pass: Clear progress visualization showing current position and total steps.
Fail: Multi-step flow with no indication of progress or total steps remaining.
Evidence: Users accelerate toward visible goals (goal gradient effect).

**U23. Endowed progress**
Look for: Does a progress indicator start above zero when info is already known (e.g., email from signup pre-fills step 1)?
Pass: Progress bar shows partial completion based on already-provided information.
Fail: Progress starts at 0% despite having user data from a previous step.
Evidence: Starting above 0% significantly increases completion rates (endowed progress effect).

**U24. Peak-end (final screens)**
Look for: If screenshot shows a flow completion screen (checkout confirmation, onboarding done, signup success) — is the final moment positive?
Pass: Celebratory elements, clear next-step guidance, positive messaging. No exit pop-ups.
Fail: Transactional "Order #12345 placed" with no warmth. Exit pop-up on the confirmation page.
Evidence: Users judge experiences by peak and end moments, not the average.

**U25. Text truncation and overflow**
Look for: Text cut off with ellipsis (...), text extending beyond container boundaries, overlapping text, or text hidden behind other elements.
Pass: All visible text fits within its containers. No truncation, overflow, or overlap.
Fail: Truncated labels, buttons, or headings. Text overlapping other elements. Ellipsis on critical information.
Note: Flag as HIGH confidence — text truncation is directly visible without inference.
Evidence: Truncated text forces users to guess content. Truncated CTAs destroy information scent.

**U26. Image and icon distortion**
Look for: Product images, avatars, icons, or illustrations that appear stretched, squished, pixelated, or at incorrect aspect ratios.
Pass: All images and icons appear at correct proportions. No visible pixelation or stretching.
Fail: Stretched or squished images. Pixelated icons. Non-square avatars. Logo aspect ratio appears wrong.
Note: Flag as MEDIUM confidence — subtle distortions may be ambiguous. Only flag obviously visible distortion.
Evidence: Distorted images signal technical incompetence and reduce credibility.

**U27. Empty state quality**
Look for: If the screenshot captures an empty state (no search results, first-time use, empty list) — does it provide guidance?
Pass: Helpful illustration, clear explanation of why the state is empty, and a CTA showing what to do next.
Fail: Blank white space. Generic "No results" with no guidance. Technical error message for a normal empty state.
Not applicable: Screenshot does not show an empty state.
Evidence: Empty states are high-abandonment moments. A helpful empty state converts confusion into action.

---

## Mobile (portrait / app screens)

**MO1. Thumb zone CTA**
Look for: Position of the primary CTA on a mobile screen. Is it in the bottom-center arc?
Pass: Primary CTA in bottom half, center to right — natural thumb reach zone.
Fail: Primary CTA at top-left or top-right corner. Requires awkward one-handed reach.
Evidence: Most mobile interactions are thumb-driven. Top-left on large phones fails thumb zone.

**MO2. Touch target adequacy**
Look for: Button and tap target visual size relative to surrounding elements.
Pass: Tap targets appear finger-sized with visible spacing between them.
Fail: Small, tightly-packed tap targets. Tiny icons without padding.
Note: Cannot measure exact px from screenshot. Flag as "appears adequate" or "appears small — verify >=44x44 CSS px per WCAG."
Evidence: WCAG 2.2 AAA: 44x44px minimum. Targets below 48px at screen edges cause most tap mistakes.

**MO3. Bottom navigation**
Look for: Where are primary navigation features? Bottom tab bar vs top hamburger menu.
Pass: Primary features (Home, Search, Cart, Profile) in bottom tab bar. Hamburger reserved for secondary features.
Fail: All navigation hidden behind a hamburger menu icon at the top.
Evidence: Bottom nav improves cart reach vs hamburger-only navigation.

**MO4. Dropdown/menu depth**
Look for: Visible dropdown menus or multi-level navigation. How many levels deep?
Pass: Dropdowns max 2 levels. Wide mega-menu alternatives for complex nav.
Fail: 3+ level nested dropdown submenus. Each level is a narrow steering tunnel.
Evidence: Long narrow tunnels exponentially increase error rate (Steering Law).

**MO5. iOS form input zoom**
Look for: Form input fields on mobile screens. Do they appear to use standard body-text sizing?
Pass: Input text appears same size as body text (16px+ prevents iOS auto-zoom).
Fail: Input text appears noticeably smaller than body text — likely triggers iOS auto-zoom.
Note: Cannot measure exact px. Flag for verification if inputs appear smaller than body text.
Evidence: Form inputs <16px trigger iOS auto-zoom.

---

## E-Commerce (product / cart / checkout)

**EC1. Guest checkout**
Look for: On checkout/login gate screens — is there a "Continue as Guest" or "Guest Checkout" option?
Pass: Guest checkout option visible alongside login/signup.
Fail: Forced account creation with no guest alternative visible.
Evidence: Forced registration is a major cart abandonment cause.

**EC2. Cost transparency**
Look for: Are shipping costs, taxes, and total visible on the product page or cart page?
Pass: Shipping cost (or "Free shipping") and estimated total visible before the final checkout step.
Fail: Only product price shown. No shipping/tax information until payment step.
Evidence: Hidden extra costs are the #1 abandonment cause.

**EC3. Payment options**
Look for: Count visible payment method icons/logos on checkout or footer.
Pass: 3+ payment methods visible (credit card, PayPal, Apple Pay, etc.).
Fail: Single payment method, or fewer than 3 options shown.
Evidence: Additional payment options improve checkout completion.

**EC4. Product reviews**
Look for: Star ratings, review counts, or review text on the product page.
Pass: Reviews visible on or near the product detail area.
Fail: Product page with no reviews, ratings, or social proof.
Evidence: Reviews near the product significantly increase purchase likelihood.

**EC5. Trust signals on payment**
Look for: Security badges, SSL icons, payment provider logos, "Secure checkout" messaging on cart/checkout pages.
Pass: Trust indicators visible near the payment area.
Fail: Payment form with no security indicators.
Evidence: Trust signals near payment increase new customer conversion.

**EC6. Sticky CTA on mobile**
Look for: On mobile product/cart pages — does the primary CTA stay visible while scrolling?
Pass: CTA appears in a fixed/sticky position at screen bottom.
Fail: CTA only visible when scrolled to its position in the page flow.
Note: Cannot confirm sticky behavior from a single screenshot. Flag for live verification unless fixed bottom bar is clearly visible.
Evidence: Sticky CTAs improve mobile conversion.

**EC7. Delivery information**
Look for: Shipping timeframe, delivery options, or "Free delivery" messaging on product pages.
Pass: Delivery info visible on or near the product detail area.
Fail: No delivery information until checkout.
Evidence: Prominent delivery info improves conversion.

---

## Games (game UI / store / reward screens)

**GA1. Store accessibility**
Look for: The path from gameplay to the in-app store. Is there a recognizable + symbol, coin/gem icon, or store button?
Pass: Store entry point uses the universally recognized + symbol or currency icon. Appears reachable in 1-2 taps from gameplay.
Fail: No recognizable store entry point. Store buried in settings or sub-menus.
Evidence: Top-grossing games use the + symbol derivative. 2-click rule to purchase.

**GA2. Store visual hierarchy**
Look for: In store/shop screens — are items differentiated with badges, contrast, and visual weight?
Pass: "Most Popular", "Best Value" badge labels. High-revenue items emphasized with whitespace/contrast.
Fail: Flat grid of identically-styled items. No visual differentiation or value indicators.
Evidence: Badge labels help players evaluate worth without mental math.

**GA3. Tutorial format**
Look for: If a tutorial or onboarding screen is visible — is it text walls or interactive gameplay?
Pass: Tutorial teaches through gameplay with minimal text overlays. Reward visible early.
Fail: Text-heavy instruction screens. Multiple paragraphs before any gameplay.
Evidence: Slow tutorials and text walls cause high early disengagement.

**GA4. Tutorial skip option**
Look for: A skip or "Skip Tutorial" button on tutorial/onboarding screens.
Pass: Skip option visible for returning players.
Fail: No skip option — forced unskippable tutorial.
Evidence: Returning players forced through tutorials abandon.

**GA5. Progression indicators**
Look for: Level indicators, progress bars, XP bars, completion percentages, star ratings on levels.
Pass: Visible progression system — player can see where they are and what's next.
Fail: No progression feedback in the first session view. Player can't gauge progress.
Evidence: Strong progression systems are the primary driver of continued play.

**GA6. Reward screen design**
Look for: On reward/result screens — does it show only what was earned, or also what could have been earned?
Pass: Shows earned rewards AND unfilled indicators (empty stars, locked items, missed bonuses).
Fail: Only shows what was earned. No indication of potential.
Evidence: Unfilled indicators create replay motivation (Zeigarnik tension).

**GA7. FOMO/scarcity elements**
Look for: Limited-time banners, countdown timers on offers, "Exclusive" or "Limited" labels.
Pass: Time-limited offers with clear countdown timers and "Limited" labels visible.
Fail: No urgency mechanics on promotional offers, or overuse (every item has a timer).
Note: Assess presence and visual prominence, not whether the timer is genuine.
Evidence: Time pressure and exclusivity drive IAP engagement.

**GA8. SDT elements visible**
Look for: Signs of autonomy (meaningful choices), competence (skill feedback), and relatedness (social features, guilds, leaderboards).
Pass: At least 2 of 3 SDT needs represented in visible UI elements.
Fail: Pure reward mechanics (spin wheels, daily boxes) with no choice, skill, or social elements visible.
Skip: Purchase modals, popups, and single-offer screens — these are transaction UI, not gameplay. Do not judge a game's engagement model from a purchase screen.
Evidence: Games relying solely on variable-ratio rewards without SDT show shallow, extinction-prone engagement.

---

## Registration & Auth (signup / login)

**RE1. Social login**
Look for: Social login buttons (Google, Apple, Facebook) or SSO options on signup/login screens.
Pass: At least one social login option visible alongside email/password.
Fail: Email + password as the only registration method.
Evidence: Most users prefer social login. Creating new accounts is a major friction point.

**RE2. Passkey/biometric option**
Look for: "Sign in with Face ID", "Use fingerprint", passkey icon, or biometric login button.
Pass: Passkey or biometric option visible and visually prominent (large, top position).
Fail: Only email/password fields visible. No alternative auth method.
Evidence: Passkeys have much higher login success than traditional auth.

**RE3. Label alignment**
Look for: Position of form field labels relative to their input fields.
Pass: Labels positioned above their fields (top-aligned).
Fail: Labels to the left of fields (forces horizontal eye saccades on mobile).
Evidence: Top-aligned labels → fastest completion and least confusion.

**RE4. Form field count and grouping**
Look for: Count visible form fields. Are they grouped into logical sections?
Pass: Fields logically grouped. 5 or fewer visible fields, or 6+ broken into multi-step with progress indicator.
Fail: 6+ ungrouped fields on a single page with no step indicator.
Evidence: Multi-step forms significantly outperform single-step for long forms.

**RE5. No confirm-password on mobile**
Look for: On mobile signup screens — is there a "Confirm password" or "Re-enter password" field?
Pass: Single password field.
Fail: Two password fields (password + confirm password) on mobile.
Evidence: Confirm field adds friction without security benefit when "show password" toggle exists.

**RE6. Phone field explanation**
Look for: If a phone number field is present — is there helper text explaining why it's needed?
Pass: Helper text like "For delivery updates only" or "We'll text your verification code."
Fail: Phone number field with no explanation of purpose.
Evidence: Unexplained phone requests cause form abandonment.

**RE7. Error message quality**
Look for: If error messages are visible in the screenshot — are they human-readable with fix suggestions?
Pass: "Password needs at least 1 number" — specific, actionable, polite.
Fail: "Invalid password" or error code "ERR_AUTH_422" — vague, unhelpful.
Note: Only assessable if error state is captured in the screenshot.
Evidence: Errors must be explicit, human-readable, polite, precise, and constructive.

---

## KYC (identity verification)

**KY1. Document list upfront**
Look for: Before the upload/capture step — is there a list of required documents (ID, proof of address, selfie)?
Pass: Clear list showing exactly what documents are needed before the flow begins.
Fail: User discovers required documents mid-flow. No upfront preparation.
Evidence: Many users abandon because documents weren't on hand.

**KY2. Security messaging**
Look for: Encryption icons, "Your data is secure" text, privacy policy links, security badge — visible throughout the flow.
Pass: Security messaging visible on the current screen.
Fail: No security reassurance visible. User asked to upload ID with no trust indicators.
Evidence: Data security is the primary concern during KYC.

**KY3. Progress indicator**
Look for: Step indicator or progress bar showing current position in the verification flow.
Pass: "Step 2 of 4" or equivalent progress visualization visible.
Fail: No indication of how many steps remain.
Evidence: KYC has high drop-off. Goal gradient effect reduces abandonment.

**KY4. Post-submission status**
Look for: If screenshot shows post-submission state — is verification status clearly shown?
Pass: Clear status message — "Verification in progress", "Estimated time: 24 hours", next steps visible.
Fail: Generic "Thank you" with no status, timeline, or next-step guidance.
Evidence: Unclear post-submission status contributes to drop-off.

**KY5. Screen/flow complexity**
Look for: How complex does this single screen appear? How many fields, buttons, and decisions are visible?
Pass: Clean, focused screen with minimal fields per step. One primary action.
Fail: Dense screen with many fields, multiple upload areas, and competing actions.
Evidence: KYC complexity drives users to competitors.

---

