# CTA, Button, and Headline Checks

Apply these checks on every screenshot that contains a button, CTA, or headline — which is nearly every screenshot.

These checks evaluate how CTAs, buttons, and headlines work together to drive action. They supplement the Universal checks (U1-U27) with specific evidence on button design, headline quality, and CTA-content relationships.

---

## Button Design (CB-B)

**CB-B1. Ghost button as primary CTA**
Look for: Is the primary CTA a ghost button (transparent/no fill, outline or border only)?
Pass: Primary CTA uses a solid fill with clear contrast against its background.
Fail: Primary CTA is a ghost/outline button — no fill, just a border. Ghost buttons as the main action element underperform solid buttons significantly.
Exception: Ghost button as a *secondary* CTA alongside a solid primary CTA is acceptable — the contrast between solid primary and ghost secondary reinforces hierarchy.
Compound with U1: If U1 (CTA pop-out) also fails, the CTA is both invisible and lacking affordance.
Evidence: Meta-analysis of 6 A/B tests (128M+ visitors) found ghost buttons produce a median -9.6% effect. On mobile, ghost buttons received the fewest clicks of all variants tested. The mechanism is the affordance crisis: ghost buttons lack the visual signifiers that communicate "I am clickable."

**CB-B2. Button affordance strength**
Look for: Does the primary button have strong visual signifiers that communicate clickability?
- Strong signifiers: Solid fill, visible border, drop shadow or elevation, clear hover/active state cue
- Mixed signifiers: Some depth cues present (subtle shadow or slight fill) but not a full button treatment
- Weak signifiers: Flat, borderless, no shadow — visually indistinguishable from a text label or decorative element
Pass: Strong signifiers. Button is immediately recognizable as interactive without reading its text.
Fail: Weak signifiers. User must read the text or guess to identify it as a button.
Compound with U8: If overall design is flat, check whether buttons still stand out from non-interactive elements.
Evidence: Eye-tracking study (n=71) found flat/weak-signifier designs required 22% more time on task and 25% more fixations than strong-signifier designs (p<0.05). Extended exposure to flat design did not train users to identify clickable elements — it trained trial-and-error clicking behavior. The preference-performance paradox: users say they prefer flat design but perform measurably worse with it.

---

## CTA-Content Relationship (CB-C)

**CB-C1. CTA-headline language coherence**
Look for: Compare the primary CTA button text to the primary headline. Does the CTA echo, complete, or directly respond to the headline language?
- Verbatim match: Headline says "Claim Your Free Coins" → CTA says "Claim My Free Coins"
- Thematic match: Headline about saving money → CTA says "Start Saving"
- Disconnected: Headline about one topic → CTA is generic "Submit" or "Get Started"
Pass: CTA text verbatim repeats or directly echoes the headline language.
Acceptable: CTA text thematically matches the headline.
Fail: CTA text is disconnected from the headline — generic label that could appear on any page.
Compound with U3: If U3 (information scent) also fails, the CTA lacks both headline coherence and goal-relevant language.
Evidence: Field experiment (n=956, 2x2x2 factorial, peer-reviewed) found verbatim repetition of headline language on the CTA achieved 58% CTR vs 48% for thematic match and 44% for a new message (OR=1.14, p=0.003). The mechanism is processing fluency: identical language creates easier cognitive processing.

**CB-C2. Motivation before prompt**
Look for: What content appears above or before the primary CTA? Is there motivational content (value proposition, benefits, social proof, product explanation) that builds the case before asking for action?
Pass: Motivational content (headline + value proposition, benefits, or social proof) is visible above/before the CTA. The user encounters reasons to act before being asked to act.
Fail: CTA appears before any value proposition or explanation. The button is the first or most prominent element, with supporting content below or absent.
Not applicable: Single-purpose screens where the CTA IS the content (e.g., a "Claim" button on a reward notification).
Compound with CV5: If CV5 (above-fold value proposition) also fires, the page has both a sequencing problem and a completeness problem.
Evidence: The Fogg Behavior Model predicts that a prompt (CTA) fails when motivation is insufficient. Placing a CTA before motivation is established means prompting before the user understands why they should act. Practitioner testing confirmed higher conversion when CTA followed motivational content vs appearing above the fold without context.

**CB-C3. False floor**
Look for: Does a full-width visual element (hero image, video, illustration, or heavy horizontal line) create a visual boundary that suggests the page is complete — potentially hiding a CTA or important content below?
Pass: Content "bleeds" below the fold boundary — partial text, partial images, or visual cues signal that more content exists below.
Fail: A full-width element creates a clean visual "floor" with no continuation signal. Users may believe the page ends there.
Not applicable: Single-viewport screens (modals, popups, mobile screens where all content fits).
Evidence: Usability testing found 75% of participants (6 of 8) failed to scroll past a full-screen hero video because it created a visual "false floor." Large hero images, horizontal lines, and excessive whitespace above the fold prevent users from seeing content below.

---

## Headline Quality (CB-H)

**CB-H1. Headline front-loading**
Look for: Read the primary headline and any section headings. Do the most important, value-carrying words appear at the beginning?
- Front-loaded: "Save 4 hours per week on reporting" — value word "Save" leads
- Back-loaded: "Our new AI-powered platform helps you save time" — value buried at end
Pass: Key value words appear in the first 3-4 words of the headline.
Fail: Headline opens with filler ("Introducing...", "Welcome to...", "Discover the...") or buries the value proposition after preamble.
Evidence: F-pattern eye-tracking (232 users, reconfirmed on mobile) shows users read the first few words of each line in a vertical scan. The first 2-3 words carry outsized importance because they may be the only words most users process. Users read only 28% of words on a web page on average.

**CB-H2. Headline readability and specificity**
Look for: Is the primary headline concrete and immediately understandable, or abstract and requiring interpretation?
- Concrete: "Get 45 Million Free Sweepstake Coins — No Purchase Needed" — specific, immediate comprehension
- Abstract: "Unlock the Ultimate Gaming Experience" — vague, requires interpretation
- Jargon: "Leverage Our Omnichannel Synergies" — inaccessible without domain knowledge
Pass: Headline uses concrete language that a first-time visitor comprehends within 2 seconds. Numbers or specifics present where applicable.
Fail: Headline uses abstract language, industry jargon, or requires interpretation to extract the value proposition.
Compound with CV1: If CV1 (headline clarity) also fires on a conversion page, report once with the readability dimension added.
Evidence: SVM model predicts conversion from text readability features with 78% accuracy. Optimal: ~10-11 words per sentence, Gunning Fog Index ~8 (middle-school reading level). Processing fluency research shows easy-to-process content correlates with trust (beta=0.38) and purchase intention (beta=0.12). Simplified content nearly doubled information retention (65% vs 33%).

**CB-H3. Headline personal address**
Look for: Does the primary headline or value proposition use "you" or "your" to address the reader directly?
- Personal: "Your bonus is waiting" / "You get 50,000 coins free"
- Impersonal: "Players receive 50,000 coins" / "Bonuses available for new members"
Pass: Headline directly addresses the reader with "you/your."
Acceptable: Headline uses imperative voice addressing the reader implicitly ("Claim your coins" — implicit "you").
Fail: Headline uses third-person or passive voice with no personal address.
Not applicable: Brand taglines, app names, or decorative headings where personal address would be unnatural.
Evidence: Nature Communications study (25,679 exchanges + controlled experiment, n=1,601) found second-person "you" increases personal engagement (d=0.32, 95% CI [0.22, 0.42]) with full mediation through perceived personal communication and a dose-dependent relationship. Effect survived six robustness checks. Note: this applies to headlines/copy addressing the reader — CTA buttons use first-person "my" (different speech act; see CV2).

**CB-H4. Layer-cake heading structure**
Look for: If the page has multiple section headings — do they function as standalone scannable propositions, or are they generic labels?
- Scannable propositions: "Win Real Prizes Every Day" / "Play 500+ Games Free" / "Trusted by 2 Million Players"
- Generic labels: "Features" / "Benefits" / "How It Works" / "About"
Pass: Section headings convey value independently — a user who reads only the headings absorbs the core message.
Fail: Section headings are single-word labels that convey no information about the content below them.
Not applicable: Screens with only one heading, or screens where section headings are inappropriate (modals, popups, single-purpose screens).
Evidence: Eye-tracking research identified the "layer-cake" scanning pattern — horizontal stripes of attention on headings with skipped body text — as the most effective pattern for information extraction. This pattern only works when headings are descriptive enough to function without body text. Generic labels force the user into F-pattern scanning (worse comprehension) or commitment reading (rare, requires high motivation).

---

## Output framing

**Research-backed:** "Research indicates [principle]. This screen's [element] uses [current approach] — [alternative] is associated with stronger performance."

**Never use:** "This will increase CTR by X%", "Changing this button will improve conversion by X%", "This headline will fail."
