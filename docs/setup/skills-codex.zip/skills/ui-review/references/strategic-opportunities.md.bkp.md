# Strategic Opportunities — Monetization Psychology

Use this reference to identify strategic opportunities based on psychological principles. This is NOT a checklist — it's a lens for spotting what the UI could be leveraging but isn't.

Read this AFTER completing the standard review. You already have deep context about the screenshot. Now apply these principles to identify opportunities.

---

## How to use this document

For each principle below: Does the screenshot show this being used? If not, would it make sense for this screen type? Write up only the opportunities that are relevant and actionable for what you see.

Do not list every principle. Only surface the 3-5 most impactful opportunities for this specific screen.

---

## Behavioral Principles

**Variable ratio reinforcement.** Unpredictable rewards create the strongest engagement loops. Look for: spin wheels, mystery bonuses, random multipliers, loot-box-style reveals. Opportunity when: rewards are fixed and predictable — adding variability increases return visits.

**Endowed progress.** Starting a progress bar above zero increases completion rates. Look for: partially filled bars, "you've earned X" language, pre-accumulated value. Opportunity when: a multi-step flow starts at 0% despite having prior user data, or a collection mechanic shows no initial progress.

**Zeigarnik effect.** Incomplete tasks are remembered more strongly than completed ones. Look for: empty collection slots, unfilled stamp cards, locked reward tiers. Opportunity when: a reward screen shows only what was earned without showing what was missed.

**Near-miss effect.** Almost winning feels similar to winning and drives continued play. Look for: "so close!" messaging, almost-complete collections, near-threshold progress. Opportunity when: loss/failure screens have no near-miss framing.

**Flow state disruption as monetization.** Removing friction from gameplay but adding friction at monetization points. Look for: smooth gameplay interrupted by purchase gates. Opportunity when: the purchase flow itself has unnecessary friction (too many taps, confirmation screens, slow loading).

---

## Economic Psychology

**Loss aversion (2x stronger than gains).** People feel losses twice as strongly as equivalent gains. Look for: "expires in", "don't lose your progress", protective positioning. Opportunity when: offers use only gain framing ("get X") without any loss framing ("don't miss X").

**Sunk cost leverage.** Prior investment compels continued spending. Look for: visible cumulative progress, total-purchased counters, VIP tier displays. Opportunity when: the user's purchase history or progression is not visible at the point of purchase.

**Mental accounting.** People treat money differently based on its category. Look for: separate currency wallets, "bonus" labels, earned-vs-purchased distinction. Opportunity when: all currency is pooled with no distinction between earned and purchased.

**Transaction utility.** The perceived deal matters as much as the item. Look for: "was/now" pricing, % savings labels, "X% more value" badges. Opportunity when: offers show raw prices without any savings or deal framing.

**Hyperbolic discounting.** People prefer smaller immediate rewards over larger future ones. Look for: instant gratification options, "skip the wait" mechanics, immediate unlocks. Opportunity when: rewards are all delayed with no instant option.

---

## Social Psychology

**Social proof at decision points.** People copy others' actions. Look for: "X players bought this", "most popular", player counts, testimonials. Opportunity when: purchase decisions have no social proof nearby.

**Reciprocity.** Free gifts create purchase obligation. Look for: daily free rewards positioned near paid offers, free spins before purchase prompts. Opportunity when: the shop or offer has no free element — jumping straight to "buy."

**IKEA effect.** People value things they helped create. Look for: customizable offers, "build your bundle", player-chosen rewards. Opportunity when: all offers are fixed with no player choice or customization.

---

## Progression and Retention

**Goal gradient effect.** People accelerate effort as they approach a goal. Look for: progress bars, "X more to unlock", milestone displays. Opportunity when: a multi-purchase or multi-play system has no visible progress toward the next reward.

**Commitment escalation.** Small initial commitments lead to larger ones. Look for: micro-entry offers ($0.99), "starter pack" positioning, first-purchase bonuses. Opportunity when: the cheapest offer is $5+ with no accessible entry point.

**Streak mechanics.** Consecutive-day engagement increases retention. Look for: daily login rewards, streak counters, streak-break warnings. Opportunity when: no daily engagement mechanic is visible.

**VIP/status systems.** Status loss aversion creates urgency to maintain levels. Look for: tier badges, VIP labels, exclusive access indicators. Opportunity when: high-value users see no differentiated treatment.

---

## Sweepstakes-Specific

**Dual-currency anchoring.** Large GC numbers (millions) anchor value perception, making SC amounts feel like meaningful bonuses. Opportunity when: GC amounts are small enough that the anchoring effect is weak.

**Post-purchase momentum.** 48% of second purchases happen within one hour of the first. Opportunity when: no complementary offer is visible after or during a purchase flow.

**Piggy bank mechanics.** Accumulated value that requires a purchase to unlock creates endowment-driven conversion. Opportunity when: no passive accumulation mechanic is visible in the shop or gameplay.

**Event layering.** Parallel short-term and long-term events maintain engagement across multiple time horizons. Opportunity when: only one event or promotion is visible at a time.

---

## Output format

Write a separate document: `{output_dir}/opportunities.md`

```markdown
# Strategic Opportunities: [Product/Screen Name]

Based on the UI review of [screen], these opportunities apply monetization psychology principles to the current design.

## [Opportunity 1 title]

**Principle:** [Name the psychological principle in one sentence]
**Current state:** [What the screen does now — reference specific elements]
**Opportunity:** [What could be added or changed]
**Expected impact:** [What research suggests, without predicting specific percentages]

## [Opportunity 2 title]
...

## Not applicable

[List principles you evaluated but determined don't apply to this screen type, with one-line reasons. This shows the analysis was thorough.]
```

Limit to 3-5 opportunities. Quality over quantity. Each must reference something specific in the screenshot — no generic advice.
