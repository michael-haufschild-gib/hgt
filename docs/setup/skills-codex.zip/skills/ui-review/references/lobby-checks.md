# Game Lobby and Game Page Checks

Apply these checks when the screenshot shows a game lobby (catalog of games), a game detail page, or a game selection interface.

=== TRIGGER ===

Run when the screenshot shows:
- A game lobby with multiple game tiles/thumbnails in a grid or list
- A game detail/info page for a specific game
- A game category or filtered view of games

Do NOT run on: active gameplay screens, purchase modals (use offer-design-checks), or settings screens.

=== END TRIGGER ===

---

## Lobby Layout (LB-L)

**LB-L1. Grid layout quality**
Look for: How are game tiles arranged?
Pass: Card-based grid (2-3 columns on mobile). Tiles have consistent aspect ratio and uniform spacing. Grid allows parallel comparison of multiple games in one viewport.
Fail: Single-column list (wastes space, hides options). Or horizontal-only carousel as the primary catalog navigation (users miss content beyond first 2-3 slides).
Evidence: Grid layouts support rapid scanning and side-by-side comparison. Carousel engagement decays exponentially — the first slide captures ~40% of clicks, subsequent slides far less.

**LB-L2. Thumbnail readability**
Look for: Game thumbnails in the grid. Can you identify what each game is?
Pass: Each thumbnail has a recognizable visual (character, symbol, theme) identifiable at grid size. Game name is legible — high-contrast text with drop shadow or solid background bar.
Fail: Thumbnails are generic or indistinguishable at small size. Game names truncated or unreadable against busy thumbnail backgrounds.
Evidence: Thumbnails are the primary decision touchpoint in lobbies. Inconsistent or unreadable thumbnails reduce click-through and harm brand perception.

**LB-L3. Featured section prominence**
Look for: Is there a featured or promoted section at the top of the lobby?
Pass: Featured section uses full-width banner or enlarged tiles — visually distinct from the standard grid. Contains 3-5 items maximum. Clear CTA ("Play Now") on featured items.
Fail: Featured games styled identically to the standard grid (no visual distinction). Or 6+ items in the featured section (dilutes promotion).
Not applicable: No featured section visible.
Evidence: The hero section is prime lobby real estate. More than 5 featured items means most will never be seen.

**LB-L4. Section organization**
Look for: Is the lobby divided into labeled sections?
Pass: Clear section headers ("Popular," "New," "Jackpot Games," "Recently Played") that differentiate content meaningfully. Sections in a logical order — featured/promoted at top, personalized next, then standard categories.
Fail: No section headers. Or generic/identical headers that don't explain differences. Or standard packages above featured deals.
Evidence: Category chunking reduces decision time dramatically compared to a flat grid of all games. Hick's Law: grouping 100 games into 5 categories is far more navigable than presenting all 100.

**LB-L5. Recently played section**
Look for: A "Recently Played" or "Continue Playing" section for returning users.
Pass: Recently played games visible near the top of the lobby (below featured section), showing 4-6 games with the most recent first.
Fail: No recently played section visible.
Note: At viewport coverage, recently played may exist below the visible area. State "may exist below fold" if not visible.
Evidence: Recently played is among the highest-converting lobby elements because it serves the most valuable user segment (returning players) with zero-friction re-engagement.

---

## Game Tile Information (LB-T)

**LB-T1. Tile information hierarchy**
Look for: What information is visible on each game tile at default state?
Pass: Game thumbnail and name always visible. Badges ("New," "Hot," "Jackpot") present where relevant. Additional info (provider, RTP) available on interaction or game detail page.
Fail: Tiles overloaded with metadata (RTP, volatility, player count, provider all crammed on the tile). Or tiles showing only a thumbnail with no name.
Evidence: Progressive disclosure resolves the tension between clean visuals and useful metadata. Default state should be clean; detail on demand.

**LB-T2. Jackpot display**
Look for: If jackpot games are present — are jackpot amounts visible?
Pass: Active jackpot value displayed on the tile or in a prominent lobby element. Tiered jackpots (Mini, Minor, Major, Grand) use distinct visual treatment.
Fail: Jackpot games present but no jackpot values visible in the lobby.
Not applicable: No jackpot games visible.
Evidence: Jackpot visibility correlates with +11% average bet, +8% rounds per session, and +9% deposit frequency. Real-time jackpot counters drive engagement.

**LB-T3. Social proof indicators**
Look for: Player counts, "Hot" badges, recent winner displays, or "Popular" labels on game tiles.
Pass: At least one form of social proof visible on high-traffic games. Specific numbers used ("1,247 playing" not just "Popular"). Counts only shown when impressive (not "3 players").
Fail: No social proof indicators in the lobby. Or anti-social-proof (very low player counts displayed).
Evidence: Social proof notifications produce 10-15% conversion uplift. Showing low player counts is counter-productive.

---

## Category and Filter (LB-F)

**LB-F1. Filter bar presence**
Look for: Is there a filter or category bar for navigating the game catalog?
Pass: Horizontal filter bar or tabs visible near the top of the grid. Categories use text labels (not icon-only). Active category is clearly indicated.
Fail: No visible filtering mechanism in a lobby with many games. Or filters hidden behind a hamburger menu.
Not applicable: Small lobby with fewer than ~15 games (filtering unnecessary).
Evidence: Combinable filters simplify discovery in large catalogs. Text labels for filter entry points significantly outperform cryptic icons.

**LB-F2. Search discoverability**
Look for: Is a search function visible in the lobby?
Pass: Search bar or recognizable magnifying glass icon visible without expanding a menu. Positioned in the header or accessible via bottom nav.
Fail: No search access visible in a lobby with a large game catalog.
Not applicable: Small lobby where all games are visible without searching.
Evidence: Users should locate their preferred game in three keystrokes or fewer. Hiding search behind menus reduces discoverability.

---

## Game Detail Page (LB-D) — Run when a game detail/info page is visible

**LB-D1. Above-fold essentials**
Look for: What is visible in the top portion of the game detail page?
Pass: Game title, provider logo/name, hero screenshot or preview, and primary CTA ("Play Now" / "Try Demo") all visible without scrolling.
Fail: CTA below fold. Or hero area consumed by a large image with no title or CTA visible.
Evidence: The game detail page is the final conversion gate before gameplay. Users decide within 3-5 seconds.

**LB-D2. Key stats visibility**
Look for: RTP, volatility, and min/max bet information.
Pass: Key stats visible in a compact bar or section — RTP as percentage, volatility as visual scale or label (Low/Med/High), bet range clear.
Fail: No game stats visible. Or stats buried below the fold.
Not applicable: Non-casino game pages (e.g., bingo, sports).
Evidence: RTP and volatility are the two most decision-relevant data points for informed players.

**LB-D3. Dual CTA pattern**
Look for: Does the page offer both real-play and demo options?
Pass: "Play for Real" (primary, high-contrast) and "Try Demo" (secondary, outlined/ghost) both visible.
Fail: Only one play option. Or demo option hidden.
Not applicable: Games that don't offer demo mode.
Evidence: Dual CTA captures both high-intent and exploratory users. Demo access produces longer sessions and lower bounce rates.

---

## Output framing

**Research-backed:** "Game lobby research indicates [principle]. This lobby's [element] uses [current approach] — [alternative] is associated with stronger engagement."

**Never use:** "This lobby will lose X% of players", "Users will not find games", "This layout violates UX guidelines."
