# Domain: Sweepstakes Casino

Load when domain is social casino / sweepstake casino. This file provides business context for interpreting UI elements — not additional checks to run.

---

## Dual-Currency Model

Sweepstakes casinos sell Gold Coins (GC) as digital entertainment goods and bundle Free Sweepstake Coins (SC) as a promotional bonus. The GC sale is the revenue event. SC create the prize incentive that drives the purchase.

| Currency | Purchased? | Cash Value | Display Numbers | Role |
|-|-|-|-|-|
| Gold Coins (GC) | Yes — digital good | None | Large (millions) | Primary product in transaction |
| Free Sweepstake Coins (SC) | No — free promotional bonus | Redeemable at 1:1 USD | Small (tens to thousands) | Actual purchase motivator |

GC is always the primary displayed product. The preferred full term is **"Free Sweepstake Coins"** — never "Sweeps Coins" or "Sweep Coins." The word "Free" should accompany SC references, but word order is flexible ("Free Sweepstake Coins", "Sweepstake Coins Free", "x Free SC" are all acceptable). In space-constrained elements (buttons, badges, small labels), abbreviations like "Free SC" or "SC" with a "FREE" badge are normal.

**What this means for UI review:** Large GC numbers (7,360,000) are intentional value anchoring, not deception. The small secondary number (368) is the SC bonus — the real value driver for the player. When both appear on a deal card, GC is the primary product by design. Large GC numbers without gameplay-value translation IS a finding (the player can't evaluate whether 7M GC is a lot).

---

## Package Pricing Architecture

| Tier | Price Range | Target Segment | Purpose |
|-|-|-|-|
| Entry | $2.99–$10 | Minnows (80-88% of players, 5-10% of revenue) | Convert free players into first-time purchasers |
| Mid | $50–$100 | Dolphins (10-15% of players, 15-20% of revenue) | Regular purchase habit |
| Premium | $500–$4,999 | Whales (2-5% of players, up to 80% of revenue) | Primary revenue driver |

**Welcome packages** offer 133–330% SC bonus rates. Standard (non-promotional) packages revert to baseline ~1:1 SC ratio. "% MORE" bonuses on deal cards reference the standard package rate — the baseline is the non-promotional SC amount for that GC quantity at that price point.

**SC value and playthrough.** SC redeems at 1:1 USD (100 SC = $100 in cash prizes) after a 1x playthrough requirement — play the SC amount once before redemption. This is far lower than real-money casino deposit bonuses (typically 20x–60x wagering requirements). Because playthrough is low, promotional SC offers are modest: typically ~120% of the purchase price in SC value, sometimes up to 140%. A $10 purchase bundling 12 SC represents $12 in potential redemption value — a 20% perceived return, not a 300% windfall.

**Perceived value.** 67% of paying players evaluate offers primarily by SC/USD ratio — SC is redeemable for cash and drives purchase motivation. 33% still pay attention to GC/USD. Both ratios matter when evaluating an offer's monetary value, but SC/USD is the more important metric for most players.

**Bonus reward types with SC value.** Some packages include additional rewards beyond GC and SC:
- **Free spins**: Always played with SC. Typical value ~0.2 SC per spin.
- **Wheels, chests, mystery boxes**: Random reward mechanics that award SC among other prizes. The SC reward size is random — do not assign a fixed value, but note they add SC value to the package.

These extras contribute to the package's total SC value and should be considered when comparing tiers.

---

## Chain Offers and Progression Mechanics

A chain offer is a sequential purchase progression — NOT a simultaneous choice between options.

Structure: buy step 1 → step 2 unlocks → buy step 2 → step 3 unlocks → continue to final reward. Evidence in the UI: "unlock," "next step," lock icons, one active button among multiple grayed-out buttons, progress counter.

**What this means for UI review:**
- Starting with the cheapest tier is by design — not an anchoring error
- Grayed-out buttons on future steps are intentionally [LOCKED] — not CTA failures
- The active (colored) button is the ONLY current CTA — evaluate only this one for pop-out
- Bonus percentages across steps are sequential rewards, not options to compare — non-monotonic progression (5% → 10% → 20% → 15%) IS still a valid finding if it creates confusion about the chain's value trajectory
- Critiques about "positioning the highest-value tier most prominently" do not apply — position is determined by the chain sequence

---

## Standard Retention Mechanics

These elements are industry-standard for social casino UIs. Their presence is expected, not remarkable:

- Daily login bonuses (escalating for consecutive days)
- Progress trackers, XP bars, level systems
- Collection systems (card albums, themed sets)
- Countdown timers on promotional offers
- Leaderboards, tournaments, club/guild systems
- VIP/loyalty tier indicators
- Mission/challenge lists
- Mystery/reveal mechanics (spin wheels, scratch cards, mystery bags)

**What this means for UI review:** A countdown timer on a promotional offer is a standard conversion tool — not inherently manipulative. Flag urgency only when it compounds with a credibility gap (per Phase 3.75 Step 4) or when multiple urgency mechanisms stack on a single screen. Mystery/reveal mechanics ("FREE" mystery bag, "?") create endowment before purchase — this is effective design, not a dark pattern, when the reward is genuinely free.

---

## Player Value Perception

67% of paying players view the platform as a real-money gambling experience driven by prize-winning opportunity. 33% view it as entertainment-first free-to-play gaming.

**What this means for UI review:** Most players (67%) evaluate purchases by SC value (potential cash redemption). A significant minority (33%) still evaluate by GC AND SC value. Both GC/$ and SC/$ ratios are relevant when analyzing offers — report both. A shop screen that highlights GC amounts without translating to gameplay value or SC value leaves the player unable to evaluate the purchase — this IS a finding. Dual-currency display with GC-primary framing is the industry standard, so the structure itself is not a UX failure.
