# Profile and Social Screen Checks

Apply these checks when the screenshot shows a user profile, account page, or social profile screen.

=== TRIGGER ===

Run when the screenshot shows:
- A user's own profile or account screen
- Another user's public profile (social viewing)
- An achievement or badge display screen
- A profile edit or settings screen

Do NOT run on: login/signup screens (use signup-checks), general settings with no profile content, or in-game HUD.

=== END TRIGGER ===

---

## Identity Display (PR-I)

**PR-I1. Avatar prominence**
Look for: The user's avatar or profile image. How prominent is it?
Pass: Avatar is large enough to be recognizable at a glance (minimum ~64dp on mobile), positioned at the top of the profile. Accompanied by display name and secondary identifier (handle, level, or title).
Fail: Avatar is a small thumbnail relegated to a corner. Or no avatar visible on a profile screen.
Evidence: Avatar is the primary identity signal — users invest in platforms that give control over self-presentation. Prominent avatar display increases psychological investment.

**PR-I2. Identity cluster grouping**
Look for: Are identity elements (avatar, name, handle, level) grouped together?
Pass: Identity elements form a visually cohesive cluster (Gestalt common region) — typically centered or left-aligned at the top, enclosed in a card or distinct visual area.
Fail: Identity elements scattered across the screen. Name in one location, avatar in another, level somewhere else.
Evidence: Gestalt proximity and common region: elements placed near each other within a bounded area are perceived as belonging together.

---

## Stats and Achievements (PR-S)

**PR-S1. Stat chunking**
Look for: How are stats (wins, losses, level, trophies, XP, etc.) organized?
Pass: Related stats grouped into labeled clusters (e.g., "Performance," "Social," "Progress"). Total visible stat categories limited to 5-7 groups. Progressive disclosure for detailed breakdowns.
Fail: Flat list of 10+ ungrouped statistics. Or stats presented without category labels.
Evidence: Miller's Law: working memory holds 7 +/- 2 items. Chunking related information into meaningful groups reduces cognitive load.

**PR-S2. Key metric emphasis**
Look for: Is one or two key metrics visually distinguished from the rest?
Pass: A primary metric (rank, level, trophies) is larger, bolder, or distinctly colored compared to secondary stats. Creates clear visual hierarchy.
Fail: All stats given equal visual weight — nothing stands out.
Evidence: Von Restorff isolation effect: when multiple similar objects are present, the distinct one is most remembered. Works best when 1-2 items are highlighted and everything else is visually consistent.

**PR-S3. Achievement visibility**
Look for: Are achievements, badges, or milestones displayed on the profile?
Pass: Achievement/badge section visible on the profile — completed achievements visually distinct from locked/incomplete ones. Achievements not hidden behind a separate navigation.
Fail: No achievement display on a profile that clearly has a gamification system. Or achievements buried in a sub-screen requiring multiple taps.
Not applicable: App without an achievement/badge system.
Evidence: Achievement visibility is paramount — hiding them behind separate navigation greatly decreases their motivational value. The endowment effect drives retention through earned badges.

---

## Profile Completeness (PR-C)

**PR-C1. Completeness indicator**
Look for: Is there a profile completeness bar, percentage, or step indicator?
Pass: Visual progress indicator visible (bar, circle, filling container). Starts above 0% (endowed progress). Shows specific next steps, not just a percentage. Explains the benefit of completion.
Fail: No completeness indicator on an incomplete profile. Or indicator starts at 0% with no explanation.
Not applicable: Profile appears fully complete, or app does not use profile completion mechanics.
Evidence: LinkedIn's completeness bar drove 55% increase in profile completion. Endowed progress (starting above 0%) increases completion rates by ~79% relative to starting at zero.

---

## Social Features (PR-F)

**PR-F1. Social metric display**
Look for: Friend count, follower count, clan/guild membership, or similar social metrics.
Pass: Social metrics visible but proportional to app type — prominent in social-first apps, secondary to performance stats in gaming apps. Specific numbers used.
Fail: Social metrics dominating a gaming profile where performance stats should lead. Or no social indicators on a profile with social features.
Not applicable: App without social features.
Evidence: Display patterns vary by category: social apps prioritize follower counts; gaming apps prioritize performance with social features woven into activity feeds.

**PR-F2. Social action accessibility**
Look for: Social action buttons (Add Friend, Follow, Message, Challenge).
Pass: Primary social action visible and accessible — ideally in the bottom half of the screen (thumb zone). Clear, specific label.
Fail: No social action visible when viewing another user's profile. Or social actions hidden behind a menu.
Not applicable: Viewing own profile (edit is the primary action, not social).
Evidence: Primary actions should be within the thumb's easy zone. Hidden social actions reduce engagement.

---

## Activity History (PR-A)

**PR-A1. Activity feed organization**
Look for: If an activity history or feed is visible — how is it organized?
Pass: Reverse chronological with clear date separators. Activity type indicators (icons or color coding) enable rapid scanning. Tap-to-expand for details.
Fail: Flat, undifferentiated feed with no date markers or type indicators. Or cluttered entries with too much detail shown by default.
Not applicable: No activity feed visible.
Evidence: Chronological ordering with type indicators applies Gestalt similarity for rapid scanning. Progressive disclosure prevents overwhelm.

---

## Edit and Settings Access (PR-E)

**PR-E1. Edit access visibility**
Look for: How does the user access profile editing?
Pass: Visible "Edit Profile" button or gear icon — not hidden behind a hamburger menu. Positioned in a consistent, expected location (top-right or near identity cluster).
Fail: Edit/settings access hidden behind a hamburger menu or requiring navigation to a separate settings section.
Evidence: Hidden navigation reduces content discoverability by ~50% and increases perceived task difficulty by 21%. Profile edit should be directly accessible.

---

## Privacy (PR-V)

**PR-V1. Privacy control indicators**
Look for: Any indication of privacy controls (visibility toggles, public/private indicator, audience selector).
Pass: Privacy state visible (e.g., "Public Profile" indicator, or visibility toggles adjacent to information sections).
Fail: No indication of what is public vs. private on a profile with personal information.
Not applicable: App without privacy-sensitive profile content, or viewing own profile in a non-social context.
Evidence: Visible privacy controls increase willingness to share information (the "control paradox"). Users who feel in control share more and engage more.

---

## Output framing

**Research-backed:** "Profile UX research indicates [principle]. This screen's [element] uses [current approach] — [alternative] is associated with stronger engagement and retention."

**Never use:** "This profile will cause X% churn", "Users will feel unsafe", "This violates privacy regulations."
