# Ad Creative Checks — Banner Ads and Promotional Creatives

=== AD CONTEXT GATE (MANDATORY) ===

**CREATIVE REVIEW** — either of these:
- User explicitly identifies the screenshot as an ad
- User provides the screenshot as a creative asset for evaluation

The screenshot IS the ad. Run all applicable AD checks against the entire image.

**LABELED AD** — both of these:
- No explicit user identification as an ad
- "Sponsored", "Ad", "Ads by [network]", or ad network attribution text is visible

The ad occupies a defined region. Run AD-E checks ONLY against the labeled ad region.

**NEITHER** — no user identification AND no visible ad label:
- Do NOT run any ad checks. Apply universal checks only.

=== END AD CONTEXT GATE ===

=== AD-SPECIFIC PERCEPTUAL BOUNDARIES (IMMUTABLE) ===

**Evaluate freely:**
- CTA text wording and framing
- Copy specificity (vague vs concrete claims, numbers, names)
- Social proof presence and type
- Headline format (question, how-to, statement)
- Emotional vs rational appeal balance
- Face presence and approximate gaze direction
- Color palette emotional alignment (from `analysis.txt`)
- Text overlay presence on imagery
- Sweepstake naming consistency in visible copy (GC/SC hierarchy)

**Flag as MEDIUM confidence:**
- UGC vs polished production style
- Sound-off viability (inferring from a still frame)
- Ad blindness resistance
- Demographic alignment of depicted people

**Never claim:**
- Predicted conversion rate, CTR, or ROAS
- Ad format type from a still frame
- Target audience demographics (unless user states)
- Whether the ad "works" or "doesn't work"
- Exact percentage improvements

=== END AD-SPECIFIC PERCEPTUAL BOUNDARIES ===

---

## Element-Level (AD-E) — Run on visible ad elements

**AD-E1. CTA text optimization**
Look for: Text on the primary action button or link.
Pass: Ownership or action language — "Claim Now", "Get My Bonus", "Start Winning". First-person framing is stronger.
Fail: Passive or optional language — "Play Now", "Learn More", "Check It Out."
Casino-specific: "Claim Now" outperforms "Play Now" — ownership framing leverages loss aversion.
Evidence: "Play Now" is an IPM drag, "Claim Now" is neutral-to-positive. First-person CTA phrasing is directionally supported.

**AD-E2. Specificity gradient**
Look for: Claims, numbers, and offers in headline and body copy.
Pass: Specific amounts, names, or figures — "45 million Free Sweepstake Coins", "Sarah from Ohio won $50,000."
Fail: Vague promises — "Free coins", "Win big", "Great prizes."
Evidence: Specificity gradient is the most consistent cross-domain pattern. Concrete information activates faster processing than abstract claims.

**AD-E3. Social proof presence**
Look for: Player counts, testimonials, ratings, download numbers, win announcements.
Pass: Specific social proof visible with concrete numbers or named individuals.
Acceptable: Generic social proof — "Millions of players", star rating without count.
Fail: No social proof elements anywhere in the creative.
Evidence: Social proof is the strongest persuasion lever. Specific numbers outperform vague claims.

**AD-E4. Loss vs gain framing**
Look for: How the offer or benefit is framed in copy.
Loss frame: "Don't miss your bonus", "Your coins expire at midnight"
Gain frame: "Get your bonus today", "Earn free coins"
Pass: Loss frame present as primary or secondary framing.
Acceptable: Gain framing only — functional but leaves measurable lift on the table.
Evidence: Loss framing outperforms gain framing for direct-response objectives. Loss-to-gain ratio ~2:1 is well-established in behavioral economics.

**AD-E5. Headline format**
Look for: The primary headline or first visible text line.
Pass: Question format ("Ready to win tonight?") or how-to format ("How to claim your free bonus").
Acceptable: Specific statement with a concrete claim.
Fail: Generic statement ("The best casino game", "Play the #1 slots app").
Evidence: Questions outperform statements. How-to format promises competence. More people read the headline than the body.

**AD-E6. Face and gaze direction**
Look for: Human faces in the ad creative. If present, note gaze direction.
Pass: Face present with gaze directed toward the product, CTA, or key message (averted gaze).
Partial: Face present looking directly at viewer (mutual gaze). Attracts attention to the face but does not guide toward CTA.
Not applicable: No faces present — not a failure.
Evidence: Averted gaze increases product attention and implicit memory vs no-face condition. The directional principle (gaze guides attention) is robust.

**AD-E7. Text overlay on imagery**
Look for: Text placed directly over images or video thumbnails.
Pass: On-screen text overlays present — value proposition readable on the image itself.
Fail: Image-only with no text overlay — relies on surrounding copy that may not be seen.
Evidence: On-screen text overlays boost performance for casino creatives. Most mobile video is watched without sound — visual text is essential.

**AD-E8. Anchoring in offer presentation**
Look for: Reference pricing, crossed-out values, "was/now" comparisons, or high-value anchors.
Pass: High anchor visible before the actual offer.
Not applicable: No pricing or value comparison present.
Evidence: First price/value seen dominates perception (anchoring). Less expert consumers are more susceptible.

---

## Composition-Level (AD-C) — Assess the creative's overall strategy

Run at CREATIVE REVIEW context level. At LABELED AD, run only if the ad region is large enough.

**AD-C1. Emotional vs rational appeal balance**
Look for: What dominates — emotional imagery (jackpot celebration, cascading coins) or rational content (feature lists, statistics)?
Pass: Emotional hook is primary. Rational proof plays supporting role.
Partial: Pure emotional with no rational grounding. OR pure rational with no emotional engagement.
Evidence: Emotional campaigns outperform rational for hedonic/low-involvement products. Optimal balance is roughly 60% emotional / 40% rational.

**AD-C2. Visual hierarchy sequence**
Look for: What the eye encounters first, second, third.
Pass: (1) Emotional hook → (2) Value proposition text → (3) CTA. CTA is the terminus, not the starting point.
Fail: CTA competes with decorative elements. Value proposition buried. Multiple elements compete with no hierarchy.
Evidence: The first 3 seconds determine engagement. Use `saliency.png` to verify the emotional hook occupies the dominant saliency zone.

**AD-C3. Sound-off viability**
Look for: Whether the ad's core message is comprehensible from the still frame alone.
Pass: Message fully comprehensible without audio. Text overlays communicate the offer.
Fail: Creative appears to rely on audio for core message delivery.
Skip: When the screenshot is clearly a static banner ad.
Confidence: MEDIUM.
Evidence: Most mobile video is watched without sound. Sound should enhance but not be required.

**AD-C4. Ad blindness resistance**
Look for: Does the creative resemble traditional advertising or look native to content feeds?
Pass: UGC-style, editorial, or native-looking format.
Partial: Professionally produced but platform-native in feel.
Fail: Classic "ad box" — heavy borders, stock photos, centered logo, generic layout.
Evidence: Banner blindness affects most consumers. UGC outperforms polished production on most metrics. Note both performance and ethical dimensions when relevant.

---

## Casino-Specific (AD-K) — Run ONLY with casino/sweepstake context

**AD-K1. LIFTS framework alignment**
Look for: Elements from the LIFTS framework (derived from 20,000+ casino ad creatives).

IPM boosters — check for presence:
- On-screen text overlays
- Home/living room environment
- Text-message UI framing
- User POV gameplay footage
- Multi-person social interactions
- Legitimacy assurances ("Real players, real wins", "No purchase necessary")

IPM drags — flag if present:
- "Play Now" CTA (use "Claim Now" instead)
- Future level previews
- Skill-first messaging
- Generic seasonal imagery without specificity

Evidence: Analysis of 20,000+ casino creatives. Psychologically grounded elements (user POV, legitimacy, relatability) are most likely to generalize across platforms.

**AD-K2. Sweepstake naming consistency in ad copy**
Look for: How GC and SC are referenced in the creative.
Pass: GC is the primary product mention. SC framed as bonus. Naming is consistent with platform conventions.
Fail: SC framed as the primary value proposition. Naming inconsistent with how the platform presents its currencies.
Cross-reference: Mirrors CV-K2 and SD-E3. Report once if multiple contexts trigger.
Evidence: Sweepstakes platforms consistently use GC-primary framing. Reversing it confuses the currency hierarchy.

**AD-K3. Casino creative specifications**
Look for: Creative format and pacing cues visible in the still.
Optimal: Portrait orientation, UGC style, emotional hook in opening frame, "Claim Now" CTA.
Sub-optimal: Landscape orientation, generic gameplay, "Play Now" CTA, hyperbolic testimonials.
Evidence: Portrait mobile-first orientation. UGC outperforms polished production in casino. Caveat: duration/pacing only assessable if timeline indicator visible.

**AD-K4. Demographic alignment observation**
Look for: Who is depicted — approximate age range, gender, setting, activity.
Observation only: Describe who is depicted and in what context.
Research context: Social casino audiences skew female, aged 25-44, and play in casual home settings. This is the demographic inverse of traditional gambling.
Do NOT claim: "This ad targets the wrong demographic." The advertiser may have segment-specific creative. Flag as MEDIUM confidence.

**AD-K5. High-converting creative approach identification**
Look for: Which documented approach is used:
1. **Storytelling of ordinary person winning** — named individual, specific amount, relatable context
2. **Personalization** — tailored to visible player segment
3. **Win-win framing** — everyone benefits, risk-free positioning
4. **CTA urgency** — time-limited bonus
5. **Question-based headline** — ("Ready to win big tonight?")
6. **Educational format** — ("How to claim your free bonus")
Pass: Creative clearly employs at least one documented approach.
Fail: Creative does not match any documented approach — generic gameplay or brand-only messaging.
Evidence: These six approaches are identified as high-converting patterns. Storytelling with specifics leverages both social proof and the specificity gradient.

---

## Output framing

**Research-backed:** "Research indicates [principle]. This creative's [element] uses [current approach] — [alternative] is associated with stronger performance."

**Casino-specific:** "Based on analysis of 20,000+ casino creatives, [element] is classified as an IPM [booster/drag]. Note: this data is from a single ad network and may not generalize across all platforms."

**Never use:** "This will increase CTR by X%", "This ad will fail because...", "Expect X% improvement if you change..."
