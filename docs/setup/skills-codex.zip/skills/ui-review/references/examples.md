# Calibration Examples

Two complete outputs demonstrating expected depth. Note how findings reference check IDs, cite evidence, AND reason about compound effects and goal obstruction — not just isolated pass/fail.

---

## Example A: Mobile E-Commerce Product Page

> **UI Overview**
> Mobile product detail page for an e-commerce app, portrait orientation. Header with brand name (A1) and cart icon with badge (C1). Search bar spanning A1-C1 below header. Product image placeholder occupying A2-C2. Product title "Premium Headphones," pricing with strikethrough original ($299.99) and sale price ($199.99), star rating with review count (234 reviews) in A3-B3. Full-width "Add to Cart" CTA in A3-C3, red/coral fill with white text. Partial second product card visible below. Bottom tab navigation with Home, Search, Deals, Profile in A4-C4.
>
> **Inferred user goal**: Evaluate this product and decide whether to add it to cart.
>
> **Squint Test Results**
> **Blur test**: PASS — The red "Add to Cart" bar in row 3 is the most visually prominent element. Content sections (header, product image, details, second card) remain distinguishable as separate groups. Bottom navigation visible as distinct footer zone.
>
> **Grayscale test**: PARTIAL PASS — Heading weight distinguishes product title from body text. "Add to Cart" CTA is mid-gray and stands out moderately via size (full-width) but loses its strong color contrast. Bottom nav items become nearly identical in weight without the active-state color on "Home."
>
> **Deuteranopia test**: PASS — Red "Add to Cart" CTA shifts to dark olive/brown but remains distinguishable from blue-gray secondary elements by luminance difference. Star rating orange becomes ambiguous against a green-shifted background — flag for U14 verification.
>
> **Saliency observation**: The product image placeholder dominates as the largest high-contrast region, generating the highest saliency. The red "Add to Cart" bar generates moderate saliency as a secondary hotspot. Two competing attention zones: product image and CTA. Decorative element (placeholder) generates more saliency than the functional CTA.
>
> **Critical Issues**
>
> **[A2-C3] Product image + CTA position creates a compound conversion barrier** — Confidence: HIGH
> What: The product image occupies the entire A2-C2 area (~50% of viewport). This pushes "Add to Cart" to row 3, outside the natural thumb arc for one-handed use (MO1 fail). Combined with the grayscale test showing the CTA loses distinctiveness without color (U5 partial), the user's ability to find AND reach the purchase action is doubly compromised.
> Why: The layout serves browsing (large image) but obstructs the user's goal of purchasing. 75% of mobile interactions are thumb-driven — a CTA in upper-middle requires a deliberate hand shift. On a product page, the buy button is the #1 action; it should be the easiest to reach, not the hardest.
> Fix: Make "Add to Cart" a sticky bottom bar above the tab navigation. This solves both thumb reach (MO1) and persistent visibility regardless of scroll position (EC6). The image can remain large since the CTA no longer competes for vertical space.
>
> **Improvements**
>
> **[A3] Star rating likely fails non-text contrast** — Confidence: MEDIUM
> What: Star symbols appear in a light orange/tan color. `analysis.txt` shows the closest detected accent (#F7E0CD) against white (#FFFFFF) — if these are the actual star colors, they may fall below WCAG AA 3:1 for non-text elements (U13). Cannot confirm exact star color from automated extraction.
> Fix: Darken star color to meet 3:1, or add numeric rating text ("4.7") alongside stars for redundancy (U14 — color not sole indicator).
>
> **[A1-C1] Search bar placeholder has weak information scent** — Confidence: HIGH
> What: Placeholder reads "Search products..." — a generic label (U3 fail). A user looking for wireless headphones must trust that this search will understand their query. Placeholder text also appears low-contrast (MEDIUM confidence — verify exact colors).
> Fix: "Search headphones, earbuds, speakers..." provides both information scent and teaches the user what categories exist.
>
> **Considerations**
>
> **[A1-C4] Social proof is present but thin** — Confidence: LOW
> What: 234 reviews mentioned with star rating (U11 partial pass), but no featured review text, user photos, or "X bought this week" indicators visible. The social proof exists at the factual level but lacks the persuasive depth that drives conversion.
> Why: Video testimonials deliver 80% conversion improvement; real-time social proof boosts 98%. A review count alone is the weakest form of social proof.
> Fix: Add a featured review snippet near the CTA, or "1,200 bought this month" indicator.
>
> **Strengths**
> - **[A3] Anchoring applied correctly (U19 pass)**: Strikethrough original ($299.99) precedes sale price ($199.99) — the high anchor makes the discount feel substantial. (Anchoring Index 0.477-0.818, Frontiers 2022.)
> - **[A4] Bottom tab navigation (MO3 pass)**: Primary features use bottom nav, not hamburger. (+3.3% cart reach, BodyGuardz.)
> - **[A3] Single dominant CTA (U1 pass)**: Red "Add to Cart" has a unique color — good pre-attentive pop-out.
> - **[A3] Review count present (EC4 pass)**: 234 reviews at the decision point. (270% higher purchase likelihood with reviews.)
>
> **Aesthetic Assessment**
>
> **Symmetry**: PASS — Overall score: 0.941
> Per-strip scores: Row 1 (header): 0.872 | Row 2 (product image): 0.987 | Row 3 (details + CTA): 0.952 | Row 4 (bottom nav): 0.951
> Row 1 scores lowest due to brand name left-aligned against cart icon right-aligned — this is expected header asymmetry, not a finding. Content rows 2-3 score high, indicating well-centered product layout. No framing artifacts visible in `symmetry.png`.
>
> **Color Harmony**: PASS — Scheme: monochromatic (HIGH confidence)
> Hues: primary achromatic (white/gray), single red accent at ~5°. Distribution: dominant 80% (white/gray) / secondary 6% (off-white) / accent 14% (red CTA).
> Monochromatic with single accent is appropriate for e-commerce product pages — keeps visual focus on the product image. The 60-30-10 distribution is skewed toward dominant, creating a clean, uncluttered feel.
>
> **Visual Complexity**: PASS — Level: LOW
> Edge density: 3.2%, Significant contours: 38.
> LOW complexity is appropriate for a mobile product page — simplicity is the strongest positive predictor of mobile commerce aesthetics (C050). The product image area has near-zero complexity (placeholder), which will change with an actual product photo.
>
> **Prototypicality**: PASS — Confidence: HIGH
> Layout follows standard mobile e-commerce convention: header with brand/cart → product image → details/price/reviews → CTA → bottom tab nav. Users will parse this layout instantly due to pattern familiarity (C050).
>
> **Consistency**: PASS — Confidence: HIGH
> Single CTA style (red fill, full-width). Consistent spacing between sections. Typography follows visible scale (product title > price > review count). Icon style consistent in bottom nav (outline style, uniform weight).
>
> **Overall Aesthetic Impression**: Strong aesthetic foundation — monochromatic scheme with single accent, low visual complexity, and high prototypicality combine to maximize processing fluency for a mobile commerce context. Research indicates that 50ms first impressions are driven by processing fluency (C049). This page's low complexity, high prototypicality, and monochromatic scheme maximize processing fluency — research associates these properties with positive first-impression judgments in Western audiences.
>
> **Color & Contrast Report**
> Dominant palette: White (#FFFFFF, 33%), Light gray (#E0E0E0, 33%), Off-white (#F9F8F8, 14%). `analysis.txt` classified #80616F as "Text-likely (dark)" — against white: 5.44:1, PASS AA normal. Against light gray (#E0E0E0): 4.12:1, PASS AA large text only. Red CTA color not isolated in automated extraction — verify CTA text contrast manually.
>
> **Beyond This Analysis**
> - Font identification (cannot identify font families from screenshots)
> - Exact touch target sizes for cart icon, nav tabs, star rating tap area
> - Add to Cart button tap responsiveness and feedback animation
> - Scroll behavior below the fold (second product card partially visible)
> - Cart badge update animation when adding items
> - Product image carousel/zoom interaction

---

## Example B: Desktop SaaS Landing Page

> **UI Overview**
> Desktop SaaS landing page, landscape orientation. Top navigation bar (A1-F1) with logo, nav links (Products, Solutions, Pricing, Resources), and "Start Free Trial" CTA button. Large hero section (A1-F2) with headline, subheadline, and centered "Get Started" CTA. Three feature cards in a row (A2-F2) with icons, titles, and descriptions. Social proof bar (A3-F3) showing client logos. Pricing section (A3-F3) with three tiers: Starter, Pro, Enterprise. Footer (A4-F4) with link columns and legal text.
>
> **Inferred user goal**: Understand what this product does and decide whether to start a trial or view pricing.
>
> **Squint Test Results**
> **Blur test**: PASS — Hero headline dominates. "Get Started" CTA visible as distinct colored block. Feature cards form clear triad. Pricing tiers distinguishable as three columns.
>
> **Grayscale test**: PASS — Headline weight separates from body. CTA distinguishable by size and position without color. Card icons provide anchors. Pricing columns maintain separation through card boundaries.
>
> **Deuteranopia test**: PASS — Primary blue CTA is unaffected by red-green CVD simulation. No red-green differentiators visible in the layout. All elements remain distinguishable.
>
> **Saliency observation**: Hero headline generates the highest saliency due to large text size and contrast. "Get Started" CTA is the second-highest hotspot. Feature cards distribute attention evenly across the triad without any single card dominating. Consistent with blur and grayscale test results.
>
> **Critical Issues**
>
> **[A1-F1] Two of four nav labels have weak information scent** — Confidence: HIGH
> What: "Solutions" and "Resources" are generic category names (U3 fail). A user evaluating the product cannot predict what "Solutions" contains — is it use cases, integrations, industry pages, or product features? "Resources" could be docs, blog, case studies, or webinars.
> Why: Users make stay-or-leave decisions based on information scent. Generic labels force serial exploration — clicking each to see what's inside. With 40% of sessions lasting <15 seconds on mobile (and desktop attention budgets shrinking similarly), two wasted clicks can lose the visitor.
> Fix: "Solutions" → "Use Cases" or "How It Works". "Resources" → "Docs & Guides". If these sections contain multiple things, use a mega-menu with descriptive sub-labels visible on hover.
>
> **[A3-F3] Pricing anchors on the cheapest tier** — Confidence: HIGH
> What: Tiers appear left-to-right as Starter ($19), Pro ($49), Enterprise ($299) (U19 fail). The leftmost price — where left-to-right reading begins — is the lowest. This sets a low anchor, making $49 feel expensive relative to $19 rather than cheap relative to $299.
> Why: Anchoring Index 0.477-0.818 (Frontiers 2022, N=194). The first price seen dominates perception. Users with less product knowledge show 177% higher anchoring vulnerability — and landing page visitors ARE low-knowledge by definition.
> Fix: Either reorder to Enterprise → Pro → Starter, or make Pro the visual focal point with a "Most Popular" badge and elevated card styling that draws the eye before the user reads left-to-right.
>
> **Improvements**
>
> **[A1-F4] No contact information or organizational identity visible** — Confidence: HIGH
> What: No phone, email, address, or team page link in nav or footer area (U9 fail + U10 fail). Combined with a landing page that asks users to "Start Free Trial" — this means the page asks for commitment while providing zero trust foundation.
> Why: 46.1% assess credibility from visual design, and visible organizational identity is a top-10 credibility factor. The compound effect: trust deficit (U9+U10 fail) meets conversion ask (hero CTA) — users who might trial hesitate because they can't verify who they're giving their data to.
> Fix: Add company name and "About" link to footer. Add a contact email or chat widget to nav bar.
>
> **[A1-F2] Hero has two competing CTAs** — Confidence: MEDIUM
> What: "Start Free Trial" in the nav bar AND "Get Started" in the hero section are both primary-styled CTAs. If they lead to the same destination, the duplication splits attention (U2 partial fail). If they lead to different destinations, the user must figure out which one to click.
> Fix: If same destination — make the nav version a text link or ghost button, keep only the hero CTA as the full-styled primary. If different — differentiate visually and verbally ("Start Free Trial" for the form, "Watch Demo" for exploration).
>
> **Considerations**
>
> **[A2-F2] Feature cards may exceed novel-item memory** — Confidence: MEDIUM
> What: Three cards are visible. If more exist below fold (cannot verify), the total may exceed the 3-4 chunk limit for novel items (U17). Three is within bounds; four would be borderline.
> Why: Glanzer & Cunitz 1966 — short-term memory for novel items: 3-4 chunks, not Miller's 7.
> Fix: If more features exist below fold, group into 2-3 named categories rather than extending the flat card row.
>
> **Strengths**
> - **[A1-F2] Strong processing fluency (U4 pass)**: Hero communicates purpose and primary action immediately. Blur test PASS confirms hierarchy.
> - **[A3-F3] Client logos provide social proof (U11 pass)**: Brand logos below hero serve as authority + social proof before the conversion decision.
> - **[A3-F3] Pricing visible without clicks**: Not hidden behind "Contact Sales" gate. Supports information scent for price-sensitive visitors.
> - **[A1-F2] Clear visual hierarchy**: Hero headline → subheadline → CTA follows natural reading flow. Good F-pattern alignment (U6 pass).
>
> **Color & Contrast Report**
> [Populated from analysis.txt data for the actual screenshot. Report pre-filtered text-likely vs background-likely pairs with computed ratios and WCAG verdicts.]
>
> **Beyond This Analysis**
> - Font compliance and typographic consistency
> - Exact spacing and alignment precision across feature cards
> - Hover states on navigation items and CTA buttons
> - Pricing toggle behavior (monthly/annual switching)
> - Mobile responsiveness of this layout
> - Form behavior on "Start Free Trial" and "Get Started" clicks
> - Page load performance and above-the-fold rendering

---

## Example 3: E-Commerce Checkout Page (HIGH Commitment — Trust Assessment Focus)

This example demonstrates the Trust & Credibility Assessment output (Phase 3.75) for a HIGH-commitment page.

**Context**: Checkout page of a mid-sized e-commerce retailer. User has items in cart and is being asked for payment information.

---

## Trust & Credibility Assessment

**Commitment level**: HIGH
The page presents a payment form requesting credit card number, expiration, CVV, and billing address — a financial commitment with fraud risk.

### Always-Negative Findings

**Confirmshaming**: In grid cell D7, the coupon dismissal link reads "No thanks, I'd rather pay full price." Research indicates confirmshaming language in decline options is associated with reduced perceived site credibility and increased bounce rates, independent of page type or context [S043, E086].

**Error**: In grid cell C4, the shipping address section header reads "Shiping Address" — a misspelling. Research indicates errors, typos, and placeholder text are associated with reduced perceived competence and professionalism [S043, S066].

### Credibility Inventory
**Social proof**: Absent — no customer reviews, testimonials, purchase counts, or "X people bought this" indicators visible on the checkout page.
**Organization identity**: Partial — company logo in header (grid cell A1), but no physical address, phone number, or "About Us" link visible on this page.
**Verifiable claims**: Absent — no specific claims requiring verification on this page (appropriate for a checkout flow).
**Security indicators**: Present — padlock icon next to "Secure Checkout" text in grid cell B2; Visa/Mastercard/Amex logos in grid cell D6 near the card number field.
**CTA clarity**: Clear — "Place Order — $147.93" button in grid cell D8 specifies the exact action and total amount.

### Proportionality Verdict
This is a HIGH-commitment page (payment information) with a credibility gap: security indicators and CTA clarity are strong, but social proof is absent and organization identity is only partial. For a page requesting financial information, research indicates 18-19% of e-commerce cart abandonment is specifically attributable to trust deficits [E062]. The missing social proof and partial organization identity (no visible contact information or physical address) leave the credibility evidence below what is typical for HIGH-commitment checkout flows. Note: the countdown timer showing "Sale ends in 2:34:17" in grid cell A3 is a conversion optimization element — it is not a trust signal and is assessed under conversion/LP criteria, not here.

### Trust Implications of Design Quality
Research indicates visual design is the primary credibility assessment factor for 46.1% of users [S066], and high visual complexity is the strongest negative predictor of first-impression website trust [S045, E026]. The Phase 3 complexity score of MEDIUM and the Phase 3.5 symmetry score of 0.82 (heuristic threshold) are within ranges that research associates with positive first-impression trust judgments for e-commerce contexts [S045, E026]. However, the AE2 color harmony finding of a split-complementary scheme with one discordant accent (the red urgency banner) creates mild disfluency that research associates with reduced processing ease and, consequently, reduced aesthetic-trust transfer [S008, S002].

### What This Assessment Cannot Determine
- Whether users actually trust this interface (requires user testing)
- Trust impact of page load speed (the #2 trust factor — requires live measurement [E036])
- Dynamic trust signals: error handling on invalid card entry, address validation behavior
- Mere exposure / familiarity effects from prior visits or brand recognition
- Whether this retailer is actually credible (visual signals only)
- Font-content congruency beyond extreme cases (font identification unreliable at ~31% accuracy)
- Whether the padlock icon and "Secure Checkout" text correspond to actual SSL/TLS implementation
- Whether the social proof absence on this page is compensated by earlier funnel stages (product page reviews, homepage testimonials) — the checkout page is assessed in isolation

**Note on urgency elements**: The "Sale ends in 2:34:17" countdown timer and "Limited stock — only 3 left" badge are NOT flagged as trust concerns. These are standard conversion optimization tools assessed under LP/CV criteria. The only urgency-adjacent finding is confirmshaming in the coupon dismissal text, which is a text-content issue independent of the urgency mechanism.

---

## Example C: Mobile Game Store Screen

> **Critical Issues**
>
> **[B3-C3] Two purchase buttons appear too small for reliable touch interaction** — Confidence: MEDIUM
> What: The "$4.99" and "$9.99" buttons appear noticeably smaller than the "$19.99" and "$49.99" buttons below them. They look too small for comfortable one-handed tapping.
> Why: WCAG 2.2 AAA requires 44x44px minimum targets. Undersized targets cause tap errors, especially during one-handed use. Verify exact dimensions meet the 44px minimum.
> Fix: Increase button height. Full-width buttons in a vertical stack provide maximum target area.
>
> **[B3] Adjacent purchase buttons appear too close together** — Confidence: MEDIUM
> What: The "$4.99" and "$9.99" buttons have minimal visible gap between them. Users may frequently tap the wrong button.
> Why: Google Material Design recommends minimum 8dp between touch targets. Verify spacing meets minimum.
> Fix: Increase gap to minimum 12px between buttons, or separate with visual dividers.
>
> **Improvements**
>
> **[A2-C2] Inconsistent spacing between store items** — Confidence: HIGH
> What: Product cards have visibly uneven vertical spacing — some rows are tightly packed while others have generous gaps. The rhythm feels uneven.
> Why: Inconsistent spacing breaks visual rhythm, reducing processing fluency and perceived design quality.
> Fix: Standardize vertical gaps between product cards to a consistent value (12px or 16px).
>
> **Strengths**
> - **[A1-C1] CTA pop-out confirmed**: The red "BUY" button is the only element with that red color (#E63946 per analysis.txt) against the dark page background — contrast ratio 5.2:1 (PASS AA). Strong pre-attentive uniqueness (U1 pass).
> - **[B2] Elements appear well-aligned**: Product cards and price columns align consistently across the grid.
