# Output Template

Generate output in this exact structure. Omit domain-specific sections (Shop, Popup, Conversion, Ad) when their Phase 2 context gate classified as NEITHER.

```
## UI Overview
[Screen type, purpose, platform, domain. 3-5 sentences from Phase 2 perception. Reference key grid cells.]

## Squint Test Results
**Blur test**: [PASS / PARTIAL / FAIL]
[One sentence per sub-question.]

**Grayscale test**: [PASS / PARTIAL / FAIL]
[One sentence per sub-question.]

**Deuteranopia test**: [PASS / PARTIAL / FAIL]
[One sentence per sub-question.]

**Saliency observation**: [1-2 sentences on CTA saliency position and competing hotspots. No verdict — informational only. Note disagreements with blur/grayscale results.]

## Aesthetic Assessment

**Symmetry**: [PASS/PARTIAL/FAIL] — Overall score: [X.XXX]
Per-strip scores: [Row 1 (header): X.XXX | Row 2 (content): X.XXX | Row 3 (content): X.XXX | Row 4 (footer): X.XXX]
[Interpret which strips are header/content/footer. Flag content-strip scores below 0.85. Note framing artifacts in symmetry.png vs genuine UI asymmetry.]

**Color Harmony**: [PASS/PARTIAL/FAIL] — Scheme: [scheme] ([confidence])
Hues: [list chromatic hue angles]. Distribution: [dominant X% / secondary X% / accent X%].
[Assess scheme appropriateness for detected domain.]

**Visual Complexity**: [PASS/PARTIAL/FAIL] — Level: [LOW/MEDIUM/HIGH]
Edge density: [X.X%], Significant contours: [N].
[Assess level appropriateness for screen type.]

**Prototypicality**: [PASS/PARTIAL/FAIL] — Confidence: [HIGH/MEDIUM/LOW]
[How well layout matches conventions for this screen type.]

**Consistency**: [PASS/PARTIAL/FAIL] — Confidence: [HIGH/MEDIUM/LOW]
[Specific inconsistencies with grid cell references, or confirmation of consistency.]

**Overall Aesthetic Impression**: [1-2 sentence synthesis. Ground in specific findings, not subjective preference.]

## Trust & Credibility Assessment

**Commitment level**: [HIGH / MEDIUM / LOW / AMBIGUOUS]
[One sentence: what the page asks, based on visible CTAs and form fields.]

### Always-Negative Findings
[Confirmshaming or error findings from Phase 3.75 Step 2. Each with grid cell, exact text quote, and "Research indicates..." citation. If none: "No confirmshaming language or errors detected in visible text."]

### Credibility Inventory
**Social proof**: [Specific / Vague / Absent] — [details with grid cell references]
**Organization identity**: [Present / Partial / Absent] — [details]
**Verifiable claims**: [Specific / Vague / Absent] — [details]
**Security indicators**: [Present / Absent] — [details]
**CTA clarity**: [Clear / Ambiguous / Misleading] — [quote the CTA text]

### Proportionality Verdict
[1-3 sentences. Cross-reference commitment level with credibility inventory. Name specific missing signals if gap exists.]

### Trust Implications of Design Quality
[Single paragraph connecting Phase 3/3.5 scores to trust. Use "Research indicates..." framing.]

### What This Assessment Cannot Determine
[MANDATORY. Always include ALL of:]
- Whether users actually trust this interface (requires user testing)
- Trust impact of page load speed (requires live measurement)
- Dynamic trust signals: error handling, form validation, responsive behavior
- Mere exposure / familiarity effects from prior visits (requires session data)
- Whether the organization behind this page is actually credible (visual signals only)
- Font-content congruency beyond extreme cases (font identification unreliable at ~31% accuracy)
- Whether visible trust signals are genuine (visual presence does not equal authenticity)
[Add items specific to this screenshot.]

## Critical Issues
[HIGH confidence findings with major UX impact. If none: "No critical issues identified."]

**[Grid ref] Issue title** — Confidence: HIGH
What: [Specific issue observed]
Why: [Principle violated + evidence citation + tier: REPLICATED / DIRECTIONAL / CASE-STUDY]
Fix: [Specific, actionable recommendation]

## Improvements
[HIGH-MEDIUM confidence findings. Same format.]

## Considerations
[MEDIUM-LOW confidence findings or issues needing live testing. State why confidence is lower.]

## Strengths
[What the UI does well. Reference grid cells and name design principles applied correctly.]

## Shop Design Assessment
> **Scope**: Evaluates visible shop elements against behavioral economics principles and competitor benchmarks. Does not predict revenue impact. Findings are directional, not predictive.

[Include ONLY when shop detected in Phase 2. Omit entirely otherwise.]

**Coverage**: [FULL / VIEWPORT / PARTIAL]
**Visible sections**: [list]
**Not assessable**: [skipped check categories due to coverage, or "None — full shop visible"]

### Element-Level Findings (SD-E)
### Section-Level Findings (SD-S)
[Present only if coverage ≥ VIEWPORT.]
### Architecture-Level Findings (SD-A)
[Present only if coverage = FULL.]

## Popup/Modal Assessment
> **Scope**: Evaluates visible popup elements against research-backed principles. Does not predict conversion rate or popup effectiveness. Top factors (trigger timing, frequency capping, segmentation) are invisible in a screenshot. Directional, not predictive.

[Include ONLY when popup context is POPUP REVIEW or POPUP DETECTED. Omit entirely otherwise.]

**Context level**: [POPUP REVIEW / POPUP DETECTED]
**Detection signals**: [what triggered detection]
**User-provided context**: [or "None provided"]

### Element-Level Findings (PO-E)
### Design-Level Findings (PO-D)
### Casino Popup Findings (PO-K)
[Only at POPUP REVIEW with explicit casino context.]

### Beyond This Popup Analysis
[MANDATORY. List invisible factors that matter more than visible ones:]
- Trigger timing (exit-intent, scroll depth, timer — requires session data)
- Frequency capping (6-7% churn per disruptive exposure — requires analytics)
- Audience segmentation (personalized CTAs convert 202% better — requires backend data)
- Popup sequence position (requires session context)
- A/B test performance vs alternatives
- Page/game context at popup appearance
- Animation and transition quality
- Post-interaction flow
[Add items specific to this popup.]

## Conversion Page Assessment
> **Scope**: Evaluates visible elements against research-backed conversion principles. Does not predict whether this page will convert. Top 2 factors (segmentation at 42-202% lift and page speed at 4.5x gap) are invisible in a screenshot. Directional, not predictive.

[Include ONLY when conversion context is not NEITHER. Omit entirely otherwise.]

**Context level**: [LANDING PAGE REVIEW / PROMOTION PAGE REVIEW / CONVERSION SIGNALS]
**Page type**: [Landing page / Promotion page / Conversion-focused page (unspecified)]
**User-provided context**: [or "None provided"]

### Conversion Visual Findings (CV)
### Landing Page Findings (LP)
[Only at LANDING PAGE REVIEW.]
### Promotion Page Findings (PP)
[Only at PROMOTION PAGE REVIEW.]
### Casino Conversion Findings (CV-K)
[Only with explicit casino context.]

### Beyond This Conversion Analysis
[MANDATORY. List invisible factors:]
- Page load speed (4.5x gap between 1s and 4s load — requires live measurement)
- Personalization/segmentation (42-202% lift — requires analytics)
- Message match with traffic source
- Mobile checkout friction (requires interaction testing)
- A/B test performance vs alternatives
- User segment behavior differences
- Scroll behavior and below-fold content
- Form validation and error handling
[Add items specific to this screenshot.]

## Ad Creative Assessment
> **Scope**: Evaluates visible creative elements against research-backed advertising principles. Does not predict CTR, ROAS, or campaign performance. Directional, not predictive.

[Include ONLY when ad context is CREATIVE REVIEW or LABELED AD. Omit entirely otherwise.]

**Context level**: [CREATIVE REVIEW / LABELED AD]
**Ad region**: [Entire screenshot / Grid cells bounding the ad]
**User-provided context**: [or "None provided"]

### Persuasion Element Findings (AD-E)
### Composition Findings (AD-C)
[Only at CREATIVE REVIEW.]
### Casino-Specific Findings (AD-K)
[Only with explicit casino context.]

### Beyond This Ad Analysis
[Actual conversion performance, audience response, platform rendering, sound/animation quality, creative fatigue, A/B test results.]

## Color & Contrast Report
[From analysis.txt. Dominant palette, then each text-background pair with computed contrast ratio and WCAG verdict. Use only computed values. Note elements that collapse in deuteranopia simulation.]

## Spatial Metrics Report
[Include ONLY when AI element detection is active (analysis.txt shows "Status: ACTIVE"). Omit entirely otherwise.]

## Beyond This Analysis
- Font identification (cannot identify font families from screenshots)
- Dynamic behavior: animations, hover states, transitions, loading times
- Error recovery and form validation behavior
- Keyboard and screen reader accessibility
- Scroll behavior and off-screen content
- Performance metrics (load time, responsiveness)
[Add items specific to this screenshot.]
```

## Output Rules

- Use "Research indicates..." framing for all trust and conversion findings. Never use predictive language ("this will reduce trust", "users won't trust this").
- Every finding must reference a grid cell and describe specific visual evidence.
- Every finding must carry a confidence tag (HIGH / MEDIUM / LOW).
- When domain-specific findings overlap with universal findings (e.g., CV2 + U1), report the compound effect once.
- For HIGH commitment pages, reference cart abandonment data in proportionality verdict.
- For "Absent" credibility ratings with ABOVE-FOLD or PARTIAL viewport: append "(within visible area — may exist in uncaptured regions)".
- Use `analysis.txt` computed values for contrast ratios. Format: "Computed: [ratio] (analysis.txt)".
