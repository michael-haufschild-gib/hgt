# Popup/Modal/Dialog Checks

=== POPUP CONTEXT GATE (MANDATORY) ===

**POPUP REVIEW** — any ONE of:
- User explicitly identifies the screenshot as a popup, modal, dialog, overlay, or interstitial
- Filename contains: `popup`, `pop-up`, `modal`, `dialog`, `dialogue`, `overlay`, `lightbox`, `interstitial`

Run: PO-E + PO-D + PO-K (if sweepstakes casino domain active). Auto-imply CONVERSION SIGNALS for CV checks.

**POPUP DETECTED** — ALL of:
- No explicit user identification or filename signal
- Screenshot exhibits 3+ of these visual signals:
  (a) Visible darkened/dimmed/blurred background layer behind a content container
  (b) A content container floating above underlying page content
  (c) A close or dismiss element visible: X button, "Close", "No thanks", "Maybe later"
  (d) Container centered or positioned as overlay — not flush with page edges
  (e) Single-purpose structure: one CTA, one message, or one form
  (f) Container occupies <80% of screen area with visible page content around it

Run: PO-E + PO-D. Auto-imply CONVERSION SIGNALS for CV checks. Do NOT run PO-K unless sweepstakes casino domain active.

**NEITHER** — no user identification AND fewer than 3 visual signals:
- Do NOT run any popup checks. Apply universal checks only.

**Full-screen takeovers**: Occupy 100% of screen, fail signals (a), (b), (f), route to NEITHER unless identified by user or filename. This is correct — a full-screen takeover is visually indistinguishable from a regular page.

=== END POPUP CONTEXT GATE ===

=== POPUP-SPECIFIC PERCEPTUAL BOUNDARIES (IMMUTABLE) ===

**Evaluate freely:**
- All text content in the popup (headline, CTA, decline text, body copy, fine print)
- Close/dismiss element presence, approximate size, and position
- Background overlay presence
- CTA button presence, text, and visual prominence
- Form field count (for groups of 1-5)
- Gamification mechanic type if visible
- Social proof elements within the popup
- Urgency/scarcity messaging
- Confirmshaming language in decline options
- Dual-currency display hierarchy (GC/SC) if casino context

**Flag as MEDIUM confidence:**
- Whether popup is appropriately sized for mobile
- Whether close button appears adequately sized for touch
- Content density and whitespace adequacy
- Whether offer appears contextually triggered vs arbitrary

**Never claim:**
- Trigger type, frequency, modality, animation, or sequence position
- Predicted conversion rate
- Whether the popup is shown to the right audience
- A/B test performance vs alternatives
- Whether the popup contributes to user fatigue (requires cumulative exposure data)

=== END POPUP-SPECIFIC PERCEPTUAL BOUNDARIES ===

---

## Element-Level (PO-E) — Run on ANY popup context

**PO-E1. Dismissal accessibility**
Look for: How can the user dismiss this popup? Count visible dismiss methods: X/close button, text decline link, visible overlay for tap-to-dismiss.
Pass: 2+ dismiss methods visible. Close button in expected position. Close button appears finger-sized on mobile.
Fail: Only 1 dismiss method visible. Close button missing, unexpected position, or very small.
Note: Cannot confirm tap-outside-to-dismiss from screenshot. Flag as "verify tap-to-dismiss."
Evidence: Restricting dismissal triggers reactance. Three dismiss methods (X, escape/back, tap-outside) is the standard.

**PO-E2. Decline option framing (confirmshaming)**
Look for: If a text-based decline option exists, read the decline text.
- Neutral: "No thanks", "Maybe later", "Not now", "Skip", "Close"
- Shaming: "No thanks, I don't want to save money", "I prefer to miss out"
Pass: Decline text is neutral and respectful. Accept and decline have equal visual prominence.
Fail: Decline text uses confirmshaming. Decline option visually minimized while CTA is maximized.
Evidence: Confirmshaming produces short-term signup increase but long-term trust damage. Accept and reject must have equal visual prominence.

**PO-E3. Content-to-container ratio**
Look for: How much of the popup's interior is content versus whitespace?
Pass: Generous whitespace. Content scannable in ~3-5 seconds. Under ~15 words of body text on mobile.
Fail: Text-heavy with multiple paragraphs. Content fills container edge-to-edge.
Evidence: Clean layouts are perceived as more credible. Popups have ~3-5 seconds of attention before dismissal.

**PO-E4. Mobile popup sizing and CTA placement**
Look for: On mobile — does the popup use appropriate width? Is the CTA in the thumb zone?
Pass: Popup uses ~90-95% screen width. CTA in the bottom portion of the popup.
Fail: Popup too narrow or extends beyond screen edges. CTA at the top of the popup.
Note: Cannot measure exact px. Flag as MEDIUM confidence.
Evidence: Mobile modals outperform slide-ins. CTA in bottom half aligns with thumb reach.

**PO-E5. Interruption stacking**
Look for: Does this popup appear alongside OTHER visible interruptions?
Pass: Popup is the only overlay/interruption visible.
Fail: 2+ simultaneous interruptions visible (popup + cookie bar, popup + chat widget, etc.).
Compound with U16: If U16 also fires, report the compound effect.
Evidence: Each interruption creates attention residue. One quality popup outperforms multiple competing ones.

**PO-E6. Gamification mechanic assessment**
Look for: Gamified element: spin wheel, scratch card, pick-a-box, slot-machine reveal, or other interactive reward mechanic.
Pass: Gamified mechanic visible, thematically appropriate, with visible variable rewards.
Fail: Gamified mechanic present but visually cluttered or confusing. Multiple competing gamified elements.
Not applicable: No gamification mechanic present (not a failure).
Note: Cannot assess animation or interactivity from a static screenshot.
Evidence: Gamified popups convert significantly higher than standard formats. The mechanism is variable ratio reinforcement.

---

## Design-Level (PO-D) — Run on ANY popup context

**PO-D1. Overlay clarity**
Look for: Is the background behind the popup visibly dimmed, blurred, or de-emphasized?
Pass: Clear visual separation between popup and background. Background noticeably dimmed or blurred.
Fail: Popup blends into page content. No visible overlay darkening. Container boundaries ambiguous.
Evidence: Popups must create a clear visual layer above the page to signal their transient, focused nature.

**PO-D2. Information hierarchy**
Look for: Does the popup follow a scannable hierarchy? Expected: headline → value proposition → CTA → dismiss option.
Pass: Clear hierarchy. CTA is the most prominent interactive element. Dismiss option visible but secondary.
Fail: Headline and CTA compete at equal weight. No clear reading order. Dismiss more prominent than CTA.
Evidence: F-pattern scanning applies within popup containers. First-person CTA text outperforms second-person. The 3-5 second attention window makes hierarchy critical.

---

## Casino/Gaming Popup (PO-K) — Run ONLY with casino/sweepstake context

**PO-K1. Contextual trigger language**
Look for: Does the popup's text suggest it was triggered by a specific player event?
- Resource-based: "Your coins are running low", "Refill your balance"
- Achievement-based: "Congratulations!", "You reached Level 10!"
- Time-based: "Your daily bonus is ready", "Welcome back!"
- Loss-recovery: "Better luck next time — here's a boost"
- Arbitrary: No visible connection to player state
Pass: Popup text suggests a contextual trigger tied to player behavior or state.
Fail: Generic offer text with no contextual connection.
Note: The agent CANNOT determine whether the trigger is ACTUALLY behavioral — only whether visible language SUGGESTS it.
Evidence: Contextual triggers at natural game moments outperform arbitrary timing. Early aggressive monetization repels high-value players.

**PO-K2. Popup fatigue risk indicators**
Look for: Visual signals of fatigue-inducing design:
- Multiple stacked offers visible simultaneously
- Every offer label says "Exclusive" or "Limited" (label inflation)
- No cooldown or frequency signal visible
- Aggressive tone combined with hidden dismiss
Pass: Single focused offer. Labels used sparingly. Dismiss is easy and accessible.
Fail: 3+ competing offers stacked. Every element labeled "exclusive." Aggressive urgency with hidden dismiss.
Note: Popup fatigue depends on CUMULATIVE exposure — invisible in a single screenshot. Frame as visual risk indicators, not confirmation of fatigue.
Evidence: Disruptive popup exposure increases churn. Repeated disruption causes significant player loss. Cooldown between repeat offers prevents fatigue.

---

## Output framing

**Research-backed:** "Popup research indicates [principle]. This popup's [element] uses [current approach] — [alternative] is associated with stronger performance."

**Casino popup:** "Social casino popup research indicates [principle]. Note: direct sweepstake casino popup data is not publicly available — evidence is extrapolated from adjacent domains."

**Behavior-dependent:** "If this popup is triggered by [game event], research indicates [timing principle]. Without knowing the trigger, this is conditional."

**Never use:** "This popup will convert at X%", "This popup is causing fatigue", "This popup appears at the wrong time", "This popup is shown too frequently."

---

## Beyond This Popup Analysis

**MANDATORY when any popup context is detected.** List what cannot be assessed but matters MORE than what can:

- Trigger timing (the #1 popup conversion factor — requires session data)
- Frequency capping (the #1 popup failure factor — requires analytics)
- Audience segmentation (requires backend data)
- Popup sequence position (requires session context)
- A/B test performance vs alternatives
- Page/game context at popup appearance
- Animation and transition quality
- Post-interaction flow
[Add items specific to this popup.]
