# Checkout and Purchase Screen Checks

Apply these checks when the screenshot shows a checkout, payment, or purchase confirmation screen. These supplement Offer Design (OF) and E-Commerce (EC) checks with purchase-flow-specific detail.

=== TRIGGER ===

Run when the screenshot shows:
- A checkout or payment form screen
- A subscription paywall or plan selection screen
- An order/purchase confirmation or receipt screen
- A screen with Apple Pay / Google Pay buttons

Do NOT run on: shop grids or offer cards without a checkout flow visible (use offer-design-checks or shop-design-checks), or in-app purchase modals that are popup-style (use popup-checks + offer-design-checks).

=== END TRIGGER ===

---

## Express Checkout (CK-X)

**CK-X1. Digital wallet placement**
Look for: Apple Pay, Google Pay, or other express checkout buttons.
Pass: Digital wallet buttons positioned at the top of the payment section, above manual card entry fields. Visually prominent with recognizable brand icons.
Fail: Digital wallet buttons buried below card form fields. Or wallet buttons present but styled inconsistently with provider branding.
Not applicable: No digital wallet buttons visible.
Evidence: Express checkout at the top of payment options produces 10-15% conversion uplift for iOS users and up to 30% overall. Digital wallets eliminate form-filling friction.

**CK-X2. Payment method diversity**
Look for: Count distinct payment methods visible.
Pass: 3+ payment methods visible with recognizable brand icons and text labels. Methods grouped logically (wallets together, cards together).
Fail: Single payment method only. Or methods shown as a text-only list without icons.
Evidence: Payment diversity lifts conversion by 12-15%. 8% of users abandon checkout solely because their preferred method was not shown. Brand icons are trust signals.

---

## Subscription and Plan Selection (CK-S)

**CK-S1. Plan visual distinction**
Look for: On screens showing subscription tiers or plan options — is the recommended plan visually dominant?
Pass: Recommended plan has visual emphasis — larger card, highlighted border, "Best Value" or "Most Popular" badge. Savings clearly shown for longer terms ("Save 50%").
Fail: All plans styled identically. Or emphasis on the cheapest plan (undermines upsell).
Not applicable: Single plan only, or non-subscription purchase.
Evidence: Pre-selecting and visually emphasizing the recommended plan exploits the default effect. Users tend to accept the pre-selected option.

**CK-S2. Subscription vs. one-time clarity**
Look for: If both subscription and one-time purchase options are present — are they visually distinct?
Pass: Clear labeling distinguishes recurring from one-time ("$9.99/month" vs. "One-Time Purchase — Yours Forever"). Toggle or segmented control for plan switching.
Fail: Ambiguous pricing that doesn't indicate frequency. Or subscription framed in misleading terms (daily rate instead of annual charge).
Not applicable: Only one purchase type visible.
Evidence: 35% of apps now mix subscriptions with consumables or lifetime purchases. Confusion about recurring vs. one-time charges drives cancellations and chargebacks.

---

## Order Summary (CK-O)

**CK-O1. Cost transparency**
Look for: Is the total cost visible before the final purchase button?
Pass: Total price visible alongside the CTA. Itemized breakdown available (at minimum: subtotal, fees/tax, total). Shipping cost or "Free" shown before the final step.
Fail: Only product price shown with no total. Or fees revealed only after tapping the purchase button.
Evidence: 39% of US consumers abandon checkout when unexpected costs appear. 61% abandon due to unexpected shipping fees.

**CK-O2. Pre-confirmation summary**
Look for: On the final purchase step — is a complete summary visible?
Pass: Summary shows: what is being purchased (item/plan name), quantity, price, any applied discounts, total charged, and payment method. All visible without scrolling or expanding.
Fail: User must tap to see what they're buying. Or summary omits key details (payment method, total).
Evidence: The pre-confirmation moment is when purchase anxiety peaks. Complete information reduces last-moment abandonment.

---

## Confirmation Screen (CK-C)

**CK-C1. Success state clarity**
Look for: On a purchase confirmation screen — is the success state obvious?
Pass: Clear success indicator (checkmark, green elements, "Order Confirmed" or "Payment Successful" text). Transaction/order ID visible. Next-step guidance present ("Your items will arrive by..." or "Continue" CTA).
Fail: Ambiguous state — user cannot tell if the purchase succeeded. Or transactional "Order #12345" with no warmth or next steps.
Not applicable: Not a confirmation screen.
Evidence: Confirmation screens must answer "What happens now?" Users linger on confirmation pages uncertain whether to close them. Peak-end effect means the last moment of the purchase disproportionately shapes perception.

**CK-C2. Receipt completeness**
Look for: Does the confirmation screen contain enough information to serve as a standalone receipt?
Pass: Shows: order/transaction ID, item(s) purchased, cost breakdown, payment method (last 4 digits), delivery/availability estimate, and support contact.
Fail: Bare confirmation with just "Thank you" and no details. Or receipt requires navigating to email.
Not applicable: In-app purchase confirmation (simplified receipt is acceptable: item, amount, "Done" button).
Evidence: Users do not dare close the confirmation page before receiving a confirmation email. The screen itself must contain enough information to serve as a receipt.

---

## Output framing

**Research-backed:** "Checkout UX research indicates [principle]. This screen's [element] uses [current approach] — [alternative] is associated with higher completion rates."

**Never use:** "This checkout will have X% abandonment", "Users will not complete purchase", "This violates payment provider requirements."
