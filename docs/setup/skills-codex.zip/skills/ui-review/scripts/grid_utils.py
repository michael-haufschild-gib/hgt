"""Shared grid cell mapping and bbox utilities for UI Review preprocessing.

All scripts that map bounding boxes to grid cells must use these functions
to ensure consistent cell labels across the pipeline.

The grid overlays the image with alphanumeric cells (e.g., "B3") used as
spatial references throughout the UI review workflow. Grid dimensions
adapt to image orientation and size.
"""


def pick_grid_dims(w: int, h: int) -> tuple[int, int]:
    """Return (cols, rows) for the grid overlay.

    Larger images get a finer grid. Portrait images get more rows.
    """
    large = max(w, h) > 1200
    if w >= h:
        return (6, 4) if large else (4, 3)
    else:
        return (4, 6) if large else (3, 4)


def bbox_to_grid_cell(
    x1: float, y1: float, x2: float, y2: float,
    img_w: int, img_h: int,
    cols: int | None = None, rows: int | None = None,
) -> str:
    """Map a bounding box center to a grid cell label like 'B3'.

    Args:
        x1, y1, x2, y2: Bounding box coordinates in pixels.
        img_w, img_h: Image dimensions.
        cols, rows: Pre-computed grid dimensions. If None, computed
            from img_w/img_h via pick_grid_dims.
    """
    if cols is None or rows is None:
        cols, rows = pick_grid_dims(img_w, img_h)
    cx = (x1 + x2) / 2.0
    cy = (y1 + y2) / 2.0
    col_idx = min(int(cx / (img_w / cols)), cols - 1)
    row_idx = min(int(cy / (img_h / rows)), rows - 1)
    col_label = chr(ord("A") + col_idx)
    row_label = str(row_idx + 1)
    return f"{col_label}{row_label}"


def bbox_iou(
    a: tuple[float, float, float, float],
    b: tuple[float, float, float, float],
) -> float:
    """Compute Intersection over Union between two (x1, y1, x2, y2) bboxes."""
    ix1 = max(a[0], b[0])
    iy1 = max(a[1], b[1])
    ix2 = min(a[2], b[2])
    iy2 = min(a[3], b[3])

    if ix1 >= ix2 or iy1 >= iy2:
        return 0.0

    inter = (ix2 - ix1) * (iy2 - iy1)
    area_a = max(1, (a[2] - a[0]) * (a[3] - a[1]))
    area_b = max(1, (b[2] - b[0]) * (b[3] - b[1]))
    union = area_a + area_b - inter
    return inter / union if union > 0 else 0.0
