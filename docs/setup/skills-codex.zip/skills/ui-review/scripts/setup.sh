#!/usr/bin/env bash
# Bootstrap dependencies for UI Review skill.
# Creates a virtual environment, installs packages.
# Fast on repeat runs — skips already-installed packages.
#
# Exit codes:
#   0 — all dependencies ready
#   1 — missing dependencies (install instructions printed)

set -euo pipefail

VENV="$HOME/.ui-review-env"
VENV_PYTHON="$VENV/bin/python3"
MIN_MAJOR=3
MIN_MINOR=9

# import_name|pip_package|description
PACKAGES=(
    "PIL|Pillow|Image processing"
    "numpy|numpy|Color analysis, deuteranopia, saliency, symmetry"
    "cv2|opencv-python-headless|Saliency heatmap overlay"
)

# ---------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------

find_python() {
    for cmd in python3 python; do
        if command -v "$cmd" &>/dev/null; then
            local ver
            ver=$("$cmd" -c "import sys; v=sys.version_info; print(f'{v.major}.{v.minor}')" 2>/dev/null) || continue
            local major="${ver%%.*}"
            local minor="${ver##*.}"
            if [[ "$major" -ge "$MIN_MAJOR" && "$minor" -ge "$MIN_MINOR" ]]; then
                command -v "$cmd"
                return 0
            fi
        fi
    done
    return 1
}

# ---------------------------------------------------------------
# 1. Python
# ---------------------------------------------------------------

echo ""
echo "=== UI Review — Dependency Check ==="
echo ""

PYTHON_CMD=""
if ! PYTHON_CMD=$(find_python); then
    echo "MISSING  Python ${MIN_MAJOR}.${MIN_MINOR}+"
    echo ""
    case "$(uname)" in
        Darwin)
            echo "Install Python:"
            echo "  brew install python@3.12"
            echo "  or: https://www.python.org/downloads/"
            ;;
        *)
            echo "Install Python:"
            echo "  sudo apt install python3 python3-venv python3-pip"
            ;;
    esac
    echo ""
    exit 1
fi

PYTHON_VER=$("$PYTHON_CMD" -c "import sys; v=sys.version_info; print(f'{v.major}.{v.minor}')")
echo "OK       Python ${PYTHON_VER}"

# ---------------------------------------------------------------
# 2. Virtual environment
# ---------------------------------------------------------------

VENV_CREATED=false

if [[ -f "$VENV_PYTHON" ]]; then
    if "$VENV_PYTHON" -c "import sys" &>/dev/null; then
        : # healthy
    else
        echo "         Rebuilding broken venv ..."
        rm -rf "$VENV"
        "$PYTHON_CMD" -m venv "$VENV"
        VENV_CREATED=true
    fi
else
    echo "         Creating virtual environment at $VENV ..."
    if ! "$PYTHON_CMD" -m venv "$VENV" 2>/dev/null; then
        echo "FAILED   Could not create venv."
        case "$(uname)" in
            Darwin) echo "Try: brew install python@3.12" ;;
            *) echo "Try: sudo apt install python3-venv" ;;
        esac
        exit 1
    fi
    VENV_CREATED=true
fi

echo "OK       Virtual environment"

# ---------------------------------------------------------------
# 3. Install packages
# ---------------------------------------------------------------

if $VENV_CREATED; then
    "$VENV_PYTHON" -m pip install --upgrade pip --quiet 2>/dev/null || true
fi

MISSING=()

for entry in "${PACKAGES[@]}"; do
    IFS='|' read -r import_name pip_pkg desc <<< "$entry"
    if "$VENV_PYTHON" -c "import $import_name" &>/dev/null; then
        echo "OK       $desc"
    else
        MISSING+=("$pip_pkg")
        echo "         Installing $desc ..."
    fi
done

if [[ ${#MISSING[@]} -gt 0 ]]; then
    if ! "$VENV_PYTHON" -m pip install "${MISSING[@]}" --quiet 2>/dev/null; then
        echo ""
        echo "FAILED   Could not install: ${MISSING[*]}"
        echo ""
        echo "Try manually:"
        echo "  $VENV_PYTHON -m pip install ${MISSING[*]}"
        echo ""
        exit 1
    fi
    # Verify
    STILL_MISSING=()
    for entry in "${PACKAGES[@]}"; do
        IFS='|' read -r import_name pip_pkg desc <<< "$entry"
        if "$VENV_PYTHON" -c "import $import_name" &>/dev/null; then
            echo "OK       $desc"
        else
            STILL_MISSING+=("$desc ($pip_pkg)")
        fi
    done
    if [[ ${#STILL_MISSING[@]} -gt 0 ]]; then
        echo ""
        echo "FAILED   These packages did not install:"
        for s in "${STILL_MISSING[@]}"; do
            echo "         - $s"
        done
        echo ""
        exit 1
    fi
fi

# ---------------------------------------------------------------
# 4. Summary
# ---------------------------------------------------------------

echo ""
echo "=== All dependencies ready ==="
echo ""
echo "UI_REVIEW_PYTHON=$VENV_PYTHON"
