"""Image variant generation for UI Review preprocessing."""

from PIL import Image, ImageDraw, ImageFilter

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False

try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False

from grid_utils import pick_grid_dims

# ---------------------------------------------------------------------------
# Constants (moved from preprocess.py)
# ---------------------------------------------------------------------------

BLUR_RADIUS = 7
SALIENCY_BLUR_RADIUS = 11
SALIENCY_OVERLAY_ALPHA = 0.4

# Symmetry overlay constants
SYMMETRY_CENTER_LINE_COLOR = (255, 0, 255, 180)  # magenta center line
SYMMETRY_DIFF_ALPHA = 0.4  # overlay opacity for asymmetry regions

# Machado et al. 2009 deuteranopia simulation matrix (severity 1.0)
# Transforms linear RGB to simulate red-green color vision deficiency
DEUTERANOPIA_MATRIX = [
    [0.367322, 0.860646, -0.227968],
    [0.280085, 0.672501,  0.047413],
    [-0.011820, 0.042940, 0.968881],
]


# ---------------------------------------------------------------------------
# Blur variant (squint test)
# ---------------------------------------------------------------------------

def generate_blur(img: Image.Image) -> Image.Image:
    """Apply Gaussian blur to simulate the squint test."""
    return img.filter(ImageFilter.GaussianBlur(radius=BLUR_RADIUS))


# ---------------------------------------------------------------------------
# Grayscale variant (hierarchy test)
# ---------------------------------------------------------------------------

def generate_grayscale(img: Image.Image) -> Image.Image:
    """Convert to luminance-preserving grayscale."""
    return img.convert("L").convert("RGB")


# ---------------------------------------------------------------------------
# Deuteranopia simulation (red-green CVD)
# ---------------------------------------------------------------------------

def _srgb_to_linear_array(arr: "np.ndarray") -> "np.ndarray":
    """Vectorized sRGB to linear RGB conversion."""
    normalized = arr / 255.0
    low = normalized / 12.92
    high = ((normalized + 0.055) / 1.055) ** 2.4
    return np.where(normalized <= 0.04045, low, high)


def _linear_to_srgb_array(arr: "np.ndarray") -> "np.ndarray":
    """Vectorized linear RGB to sRGB conversion."""
    low = arr * 12.92
    high = 1.055 * (np.maximum(arr, 0) ** (1.0 / 2.4)) - 0.055
    result = np.where(arr <= 0.0031308, low, high)
    return np.clip(result * 255.0, 0, 255).astype(np.uint8)


def generate_deuteranopia(img: Image.Image) -> Image.Image | None:
    """Simulate deuteranopia (red-green color blindness) using Machado 2009 matrices.

    Returns None if numpy is unavailable.
    """
    if not HAS_NUMPY:
        return None

    arr = np.array(img, dtype=np.float64)
    linear = _srgb_to_linear_array(arr)

    matrix = np.array(DEUTERANOPIA_MATRIX, dtype=np.float64)
    # Apply transformation: each pixel (R,G,B) is multiplied by the matrix
    transformed = linear @ matrix.T

    srgb = _linear_to_srgb_array(transformed)
    return Image.fromarray(srgb, "RGB")


# ---------------------------------------------------------------------------
# Saliency map (Itti-Koch inspired)
# ---------------------------------------------------------------------------

def generate_saliency(img: Image.Image) -> Image.Image | None:
    """Generate an Itti-Koch inspired saliency heatmap overlay.

    Computes bottom-up saliency from intensity, color, and orientation channels,
    then overlays as a semi-transparent heatmap on the original image.

    Returns None if numpy or cv2 is unavailable.
    """
    if not HAS_NUMPY or not HAS_CV2:
        return None

    arr = np.array(img)
    bgr = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)

    # --- Intensity channel ---
    intensity = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY).astype(np.float64)

    # --- Color channel (R-G and B-Y opponent) ---
    b = bgr[:, :, 0].astype(np.float64)
    g = bgr[:, :, 1].astype(np.float64)
    r = bgr[:, :, 2].astype(np.float64)
    rg = np.abs(r - g)
    by = np.abs(b - (r + g) / 2.0)
    color_saliency = rg + by

    # --- Orientation channel (Sobel gradients) ---
    sobel_x = cv2.Sobel(intensity, cv2.CV_64F, 1, 0, ksize=3)
    sobel_y = cv2.Sobel(intensity, cv2.CV_64F, 0, 1, ksize=3)
    orientation = np.sqrt(sobel_x ** 2 + sobel_y ** 2)

    # --- Normalize each channel to 0-1 ---
    def _normalize(ch: np.ndarray) -> np.ndarray:
        cmin, cmax = ch.min(), ch.max()
        if cmax - cmin < 1e-6:
            return np.zeros_like(ch)
        return (ch - cmin) / (cmax - cmin)

    intensity_norm = _normalize(intensity)
    color_norm = _normalize(color_saliency)
    orientation_norm = _normalize(orientation)

    # --- Combine with equal weights ---
    combined = (intensity_norm + color_norm + orientation_norm) / 3.0

    # --- Smooth to create broad attention zones ---
    combined_u8 = (combined * 255).astype(np.uint8)
    smoothed = cv2.GaussianBlur(combined_u8, (0, 0), SALIENCY_BLUR_RADIUS)

    # --- Re-normalize after blur ---
    smin, smax = smoothed.min(), smoothed.max()
    if smax - smin > 0:
        smoothed = ((smoothed - smin) / (smax - smin) * 255).astype(np.uint8)

    # --- Create heatmap overlay ---
    heatmap = cv2.applyColorMap(smoothed, cv2.COLORMAP_JET)
    alpha = SALIENCY_OVERLAY_ALPHA
    blended = cv2.addWeighted(bgr, 1.0 - alpha, heatmap, alpha, 0)

    # Convert back to RGB PIL Image
    rgb = cv2.cvtColor(blended, cv2.COLOR_BGR2RGB)
    return Image.fromarray(rgb)


# ---------------------------------------------------------------------------
# Symmetry analysis
# ---------------------------------------------------------------------------

def generate_symmetry(img: Image.Image) -> tuple[Image.Image | None, float | None, list[float] | None]:
    """Compute per-strip bilateral symmetry scores and generate difference overlay.

    Splits image into horizontal strips aligned with grid rows, then compares
    each strip's left half with its horizontally-flipped right half.

    Returns (symmetry_overlay_image, overall_score, per_strip_scores)
    or (None, None, None) if numpy unavailable.
    """
    if not HAS_NUMPY:
        return None, None, None

    arr = np.array(img, dtype=np.float64)
    h, w = arr.shape[:2]

    # Use same row divisions as grid overlay
    _cols, rows = pick_grid_dims(w, h)
    row_h = h / rows

    # Use the narrower half so both sides have equal width
    half_w = w // 2
    left = arr[:, :half_w, :]
    right = arr[:, w - half_w:, :]
    right_flipped = right[:, ::-1, :]

    # Full-image difference map (used for overlay)
    diff = np.abs(left - right_flipped) / 255.0
    diff_gray = diff.mean(axis=2)

    # Per-strip scores
    strip_scores = []
    for r in range(rows):
        y_start = int(r * row_h)
        y_end = int((r + 1) * row_h)
        strip_diff = diff_gray[y_start:y_end, :]
        strip_score = 1.0 - float(strip_diff.mean())
        strip_scores.append(round(strip_score, 3))

    overall = round(sum(strip_scores) / len(strip_scores), 3)

    # Build overlay image: original + center line + magenta highlight on asymmetric regions
    base = img.copy().convert("RGBA")
    overlay = Image.new("RGBA", base.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)

    # Vertical center line
    cx = w // 2
    draw.line([(cx, 0), (cx, h)], fill=SYMMETRY_CENTER_LINE_COLOR, width=2)

    # Highlight regions where difference exceeds threshold
    threshold = 0.15
    mask = (diff_gray > threshold).astype(np.uint8) * 255

    # Create highlight on both halves
    highlight = np.zeros((h, w, 4), dtype=np.uint8)
    highlight[:, :half_w, 0] = mask
    highlight[:, :half_w, 3] = (mask * SYMMETRY_DIFF_ALPHA).astype(np.uint8)
    highlight[:, w - half_w:, 0] = mask[:, ::-1]
    highlight[:, w - half_w:, 3] = (mask[:, ::-1] * SYMMETRY_DIFF_ALPHA).astype(np.uint8)

    highlight_img = Image.fromarray(highlight, "RGBA")
    result = Image.alpha_composite(base, overlay)
    result = Image.alpha_composite(result, highlight_img)
    return result.convert("RGB"), overall, strip_scores
