"""Color sampling and classification utilities for CTA detection."""

import math
import re

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False

try:
    from PIL import Image  # noqa: F401
    HAS_PILLOW = True
except ImportError:
    HAS_PILLOW = False


# ---------------------------------------------------------------------------
# Named color mapping
# ---------------------------------------------------------------------------

NAMED_COLORS: dict[str, tuple[int, int, int]] = {
    "RED": (220, 40, 40),
    "DARK RED": (139, 0, 0),
    "MAROON": (128, 0, 0),
    "CORAL": (255, 110, 90),
    "ORANGE": (240, 140, 20),
    "YELLOW": (245, 230, 40),
    "GOLD": (230, 180, 30),
    "LIME": (100, 240, 50),
    "GREEN": (30, 180, 90),
    "DARK GREEN": (0, 100, 0),
    "OLIVE": (128, 128, 0),
    "TEAL": (0, 128, 128),
    "CYAN": (0, 220, 220),
    "BLUE": (40, 100, 240),
    "LIGHT BLUE": (100, 180, 255),
    "NAVY": (0, 0, 128),
    "PURPLE": (128, 0, 180),
    "MAGENTA": (230, 0, 230),
    "PINK": (240, 105, 180),
    "BROWN": (139, 90, 43),
    "WHITE": (255, 255, 255),
    "LIGHT GRAY": (192, 192, 192),
    "GRAY": (128, 128, 128),
    "DARK GRAY": (64, 64, 64),
    "BLACK": (15, 15, 15),
}


def rgb_to_named_color(r: int, g: int, b: int) -> str:
    """Map an RGB value to the nearest human-readable color name.

    Uses Euclidean distance in RGB space.
    """
    best_name = "UNKNOWN"
    best_dist = float("inf")
    for name, (nr, ng, nb) in NAMED_COLORS.items():
        dist = (r - nr) ** 2 + (g - ng) ** 2 + (b - nb) ** 2
        if dist < best_dist:
            best_dist = dist
            best_name = name
    return best_name


# ---------------------------------------------------------------------------
# Color sampling
# ---------------------------------------------------------------------------

def _sample_fill_and_text_color(
    img_arr: "np.ndarray",
    x1: float, y1: float, x2: float, y2: float,
) -> tuple[tuple[int, int, int], tuple[int, int, int]] | None:
    """Sample fill (background) and text (foreground) colors for a bbox.

    Returns ((fill_r, fill_g, fill_b), (text_r, text_g, text_b)) or None.
    """
    h, w = img_arr.shape[:2]
    bx1 = max(0, int(x1))
    by1 = max(0, int(y1))
    bx2 = min(w, int(x2))
    by2 = min(h, int(y2))

    if (bx2 - bx1) < 4 or (by2 - by1) < 4:
        return None

    # Expand slightly to include button padding around text
    pad = max(4, int((by2 - by1) * 0.3))
    ex1 = max(0, bx1 - pad)
    ey1 = max(0, by1 - pad)
    ex2 = min(w, bx2 + pad)
    ey2 = min(h, by2 + pad)

    expanded_region = img_arr[ey1:ey2, ex1:ex2]
    if expanded_region.size < 12:
        return None

    # Fill color: median of the expanded region's border ring
    mask = np.ones((ey2 - ey1, ex2 - ex1), dtype=bool)
    inner_y1 = by1 - ey1
    inner_y2 = by2 - ey1
    inner_x1 = bx1 - ex1
    inner_x2 = bx2 - ex1
    # Clamp inner coords
    inner_y1 = max(0, inner_y1)
    inner_y2 = min(mask.shape[0], inner_y2)
    inner_x1 = max(0, inner_x1)
    inner_x2 = min(mask.shape[1], inner_x2)
    mask[inner_y1:inner_y2, inner_x1:inner_x2] = False

    border_pixels = expanded_region[mask]
    if len(border_pixels) < 4:
        border_pixels = expanded_region.reshape(-1, 3)

    fill_r = int(np.median(border_pixels[:, 0]))
    fill_g = int(np.median(border_pixels[:, 1]))
    fill_b = int(np.median(border_pixels[:, 2]))

    # Text color: pixels inside bbox that differ from fill
    inner_region = img_arr[by1:by2, bx1:bx2]
    if inner_region.size < 3:
        return ((fill_r, fill_g, fill_b), (255, 255, 255))

    inner_flat = inner_region.reshape(-1, 3).astype(float)
    fill_vec = np.array([fill_r, fill_g, fill_b], dtype=float)
    distances = np.sqrt(np.sum((inner_flat - fill_vec) ** 2, axis=1))

    fg_mask = distances > 40.0
    if np.sum(fg_mask) >= 3:
        fg_pixels = inner_flat[fg_mask]
    else:
        cy = (by1 + by2) // 2
        cx = (bx1 + bx2) // 2
        cy = min(cy, h - 1)
        cx = min(cx, w - 1)
        fg_pixels = img_arr[cy:cy + 1, cx:cx + 1].reshape(-1, 3).astype(float)

    text_r = int(np.median(fg_pixels[:, 0]))
    text_g = int(np.median(fg_pixels[:, 1]))
    text_b = int(np.median(fg_pixels[:, 2]))

    return ((fill_r, fill_g, fill_b), (text_r, text_g, text_b))


def _sample_page_bg(
    img_arr: "np.ndarray",
    x1: float, y1: float, x2: float, y2: float,
) -> tuple[int, int, int]:
    """Sample page background color from region outside the button.

    Returns (r, g, b) of the page background near this element.
    """
    h, w = img_arr.shape[:2]
    margin = 30
    # Sample a strip below the element, or above if at bottom
    by_start = min(int(y2) + 10, h - 1)
    by_end = min(by_start + margin, h)
    bx_start = max(0, int(x1))
    bx_end = min(w, int(x2))

    if by_end - by_start < 5 or bx_end - bx_start < 5:
        # Try above instead
        by_end = max(int(y1) - 10, 1)
        by_start = max(by_end - margin, 0)

    if by_end - by_start < 5 or bx_end - bx_start < 5:
        return (0, 0, 0)  # fallback

    region = img_arr[by_start:by_end, bx_start:bx_end]
    if region.size < 3:
        return (0, 0, 0)

    return (
        int(np.median(region[:, :, 0])),
        int(np.median(region[:, :, 1])),
        int(np.median(region[:, :, 2])),
    )


def _color_distance(c1: tuple[int, int, int], c2: tuple[int, int, int]) -> float:
    """Euclidean distance between two RGB colors."""
    return math.sqrt(sum((a - b) ** 2 for a, b in zip(c1, c2)))


def _is_saturated(r: int, g: int, b: int, min_s: int = 50, min_v: int = 80) -> bool:
    """Check if an RGB color has sufficient saturation and value in HSV.

    Args:
        min_s: minimum saturation (0-255 scale)
        min_v: minimum value (0-255 scale)
    """
    # Convert to HSV using the standard formula
    r_f, g_f, b_f = r / 255.0, g / 255.0, b / 255.0
    c_max = max(r_f, g_f, b_f)
    c_min = min(r_f, g_f, b_f)
    delta = c_max - c_min

    # Value (0-255)
    v = int(c_max * 255)

    # Saturation (0-255)
    if c_max == 0:
        s = 0
    else:
        s = int((delta / c_max) * 255)

    return s >= min_s and v >= min_v


def _is_light_button(r: int, g: int, b: int) -> bool:
    """Check if a color is a light/white button fill."""
    r_f, g_f, b_f = r / 255.0, g / 255.0, b / 255.0
    c_max = max(r_f, g_f, b_f)
    c_min = min(r_f, g_f, b_f)
    delta = c_max - c_min
    v = c_max * 255
    s = (delta / c_max * 255) if c_max > 0 else 0
    return v > 200 and s < 30


# ---------------------------------------------------------------------------
# CTA text patterns
# ---------------------------------------------------------------------------

# Tier 1: high confidence — almost always a button
_TIER1_SINGLE = {
    "go", "buy", "play", "claim", "spin", "bet", "shop", "login",
    "register", "subscribe", "upgrade", "unlock", "download", "submit",
    "confirm", "checkout", "pay", "donate", "book", "reserve", "order",
    "deposit", "withdraw", "swap", "trade", "stake", "redeem", "activate",
    "purchase",
}

_TIER1_MULTI = [
    "sign up", "log in", "sign in", "add to cart", "buy now", "play now",
    "play free", "try free", "claim now", "spin now", "shop now",
    "join now", "start now", "bet now", "get started", "get coins",
    "get bonus", "cash out", "check out", "create account", "deposit now",
    "learn more", "see more", "show more", "view more", "read more",
    "load more", "try now", "get it", "grab it", "sign up free",
    "bet max", "max bet", "auto spin", "deal me in",
]

# Tier 2: medium confidence — needs saturated fill validation
_TIER2_SINGLE = {
    "start", "open", "collect", "join", "try", "enter", "save", "add",
    "continue", "proceed", "accept", "close", "skip", "share", "send",
    "watch", "free", "apply", "follow", "explore", "discover", "next",
    "back", "done", "finish", "vote", "like",
}

# Words that disqualify a "free" match when adjacent
_FREE_DISQUALIFIERS = {
    "sc", "coins", "spins", "sweepstake", "sweepstakes", "gc", "gold",
    "silver", "bronze", "chips", "tokens", "credits", "points", "rolls",
    "plays", "entries", "tickets",
}

# Price pattern: $9.99, €4.99, £2.99, etc.
# Also handles EasyOCR misreads: $ → "5" or "S" (common OCR error)
_PRICE_RE = re.compile(
    r"^[\$€£¥₹5S]?\d{1,3}[,.]?\d{0,3}[,.]?\d{0,2}$"
)
_CURRENCY_RE = re.compile(
    r"^[\$€£¥₹5S]"
)

# "FOR $X.XX" pattern — common CTA format on purchase buttons
# Handles OCR misreads: "FOR 5349.99", "FOR S499.99"
_FOR_PRICE_RE = re.compile(
    r"^for\s+[\$€£¥₹5S]?\d{1,3}[,.]?\d{0,3}[,.]?\d{0,2}$",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# OCR word processing utilities
# ---------------------------------------------------------------------------

# WordResult from ocr_extract.py: (text, confidence, x1, y1, x2, y2, height)
WordResult = tuple[str, float, float, float, float, float, float]


def _group_words_by_line(
    word_results: list[WordResult],
) -> dict[int, list[WordResult]]:
    """Group words by approximate y-position (same line).

    Uses a simple approach: words within 50% of each other's height
    at similar y-centers are on the same line.
    """
    if not word_results:
        return {}

    # Sort by y-center
    sorted_words = sorted(word_results, key=lambda w: (w[3] + w[5]) / 2)

    lines: dict[int, list[WordResult]] = {}
    line_id = 0
    current_line: list[WordResult] = [sorted_words[0]]
    current_y_center = (sorted_words[0][3] + sorted_words[0][5]) / 2
    current_height = sorted_words[0][6]

    for word in sorted_words[1:]:
        word_y_center = (word[3] + word[5]) / 2
        tolerance = max(current_height * 0.5, 8)
        if abs(word_y_center - current_y_center) <= tolerance:
            current_line.append(word)
        else:
            # Sort line by x position and store
            current_line.sort(key=lambda w: w[2])
            lines[line_id] = current_line
            line_id += 1
            current_line = [word]
            current_y_center = word_y_center
            current_height = word[6]

    if current_line:
        current_line.sort(key=lambda w: w[2])
        lines[line_id] = current_line

    return lines


def _check_free_disqualified(
    word: WordResult,
    line_words: list[WordResult],
) -> bool:
    """Check if a 'free' word is adjacent to a disqualifying word like 'sc', 'spins'."""
    word_x2 = word[4]
    word_x1 = word[2]
    for other in line_words:
        if other is word:
            continue
        other_text = other[0].lower().strip()
        if other_text in _FREE_DISQUALIFIERS:
            # Check if adjacent (within reasonable horizontal gap)
            gap = min(abs(other[2] - word_x2), abs(word_x1 - other[4]))
            if gap < word[6] * 2:  # within 2x text height
                return True
    return False


def _is_cta_text(text: str) -> bool:
    """Check if text matches a known CTA pattern (Tier 1 or Tier 2)."""
    lower = text.lower().strip()
    if lower in _TIER1_SINGLE or lower in _TIER2_SINGLE:
        return True
    if _PRICE_RE.match(text.strip()) and _CURRENCY_RE.match(text.strip()):
        return True
    return lower in {p for p in _TIER1_MULTI}


# Common short words that are NOT button text
_NON_CTA_SHORT = {
    "x", "or", "an", "at", "in", "on", "to", "am", "is", "it", "of",
    "up", "by", "no", "so", "do", "if", "he", "we", "us", "my", "me",
    "vs", "ii", "ok", "sc", "gc", "mm", "px", "hr", "pm",
}
