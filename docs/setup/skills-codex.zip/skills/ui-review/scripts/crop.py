#!/usr/bin/env python3
"""Crop a region from a UI screenshot using normalized 0-1 coordinates.

Based on: https://platform.claude.com/cookbook/multimodal-crop-tool

Usage:
    python3 crop.py <image> <x1> <y1> <x2> <y2> [-o output.png] [--padding 20]

Arguments:
    image   Path to the source image
    x1      Left edge as 0-1 normalized value (0 = left edge, 1 = right edge)
    y1      Top edge as 0-1 normalized value (0 = top edge, 1 = bottom edge)
    x2      Right edge as 0-1 normalized value
    y2      Bottom edge as 0-1 normalized value

    (0, 0) = top-left corner
    (1, 1) = bottom-right corner
    (0.5, 0.5) = center of image

Options:
    -o      Output path (default: crop_<x1>_<y1>.png in same directory as source)
    --padding  Extra pixels around the crop region (default: 20)

Examples:
    # Crop the bottom-right quarter:
    python3 crop.py screenshot.png 0.5 0.5 1.0 1.0 -o bottom_right.png

    # Crop a button near the bottom center:
    python3 crop.py screenshot.png 0.1 0.85 0.9 0.95 -o button.png
"""

import argparse
import sys
from pathlib import Path

from PIL import Image


def crop_region(
    image_path: str,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    output_path: str | None = None,
    padding: int = 20,
) -> str:
    """Crop a region from an image using normalized 0-1 coordinates.

    Returns the output file path.
    """
    img = Image.open(image_path).convert("RGB")
    img_w, img_h = img.size

    # Convert normalized coordinates to pixels
    px_x1 = int(x1 * img_w)
    px_y1 = int(y1 * img_h)
    px_x2 = int(x2 * img_w)
    px_y2 = int(y2 * img_h)

    # Apply padding, clamped to image bounds
    px_x1 = max(0, px_x1 - padding)
    px_y1 = max(0, px_y1 - padding)
    px_x2 = min(img_w, px_x2 + padding)
    px_y2 = min(img_h, px_y2 + padding)

    cropped = img.crop((px_x1, px_y1, px_x2, px_y2))

    if output_path is None:
        parent = Path(image_path).parent
        output_path = str(parent / f"crop_{x1:.2f}_{y1:.2f}.png")

    cropped.save(output_path, "PNG")
    return output_path


def main():
    parser = argparse.ArgumentParser(
        description="Crop a region from a UI screenshot using normalized 0-1 coordinates",
    )
    parser.add_argument("image", help="Path to source image")
    parser.add_argument("x1", type=float, help="Left edge (0-1)")
    parser.add_argument("y1", type=float, help="Top edge (0-1)")
    parser.add_argument("x2", type=float, help="Right edge (0-1)")
    parser.add_argument("y2", type=float, help="Bottom edge (0-1)")
    parser.add_argument("-o", "--output", help="Output path")
    parser.add_argument(
        "--padding", type=int, default=20,
        help="Extra pixels around crop (default: 20)",
    )
    args = parser.parse_args()

    if not Path(args.image).exists():
        print(f"ERROR: File not found: {args.image}", file=sys.stderr)
        sys.exit(1)

    # Validate normalized coordinates
    for name, val in [("x1", args.x1), ("y1", args.y1), ("x2", args.x2), ("y2", args.y2)]:
        if not 0 <= val <= 1:
            print(f"ERROR: {name}={val} — must be between 0 and 1", file=sys.stderr)
            sys.exit(1)
    if args.x1 >= args.x2:
        print(f"ERROR: x1 ({args.x1}) must be less than x2 ({args.x2})", file=sys.stderr)
        sys.exit(1)
    if args.y1 >= args.y2:
        print(f"ERROR: y1 ({args.y1}) must be less than y2 ({args.y2})", file=sys.stderr)
        sys.exit(1)

    out = crop_region(
        args.image, args.x1, args.y1, args.x2, args.y2,
        output_path=args.output, padding=args.padding,
    )
    print(out)


if __name__ == "__main__":
    main()
