"""Color analysis and WCAG contrast computation for UI Review preprocessing."""

from collections import Counter

from PIL import Image

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False

try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False

from grid_utils import pick_grid_dims

# ---------------------------------------------------------------------------
# Constants (moved from preprocess.py)
# ---------------------------------------------------------------------------

PALETTE_K = 8  # number of dominant colors to extract

# Visual complexity thresholds
CANNY_LOW = 50
CANNY_HIGH = 150
# These thresholds are engineering heuristics, not research-derived values.
# They have not been calibrated against human aesthetic perception ratings.
# Treat the qualitative labels (LOW/MEDIUM/HIGH) as rough indicators.
COMPLEXITY_EDGE_LOW = 0.05   # edge density threshold: below = LOW
COMPLEXITY_EDGE_HIGH = 0.15  # edge density threshold: above = HIGH
COMPLEXITY_CONTOUR_LOW = 50
COMPLEXITY_CONTOUR_HIGH = 200


# ---------------------------------------------------------------------------
# Color harmony classification
# ---------------------------------------------------------------------------

def _rgb_to_hsl(r: int, g: int, b: int) -> tuple[float, float, float]:
    """Convert RGB (0-255) to HSL (H in degrees 0-360, S and L in 0-1)."""
    r_, g_, b_ = r / 255.0, g / 255.0, b / 255.0
    cmax = max(r_, g_, b_)
    cmin = min(r_, g_, b_)
    delta = cmax - cmin

    # Lightness
    l = (cmax + cmin) / 2.0

    if delta < 1e-6:
        return (0.0, 0.0, l)

    # Saturation
    s = delta / (1.0 - abs(2.0 * l - 1.0)) if abs(2.0 * l - 1.0) < 1.0 else 0.0

    # Hue
    if cmax == r_:
        h = 60.0 * (((g_ - b_) / delta) % 6)
    elif cmax == g_:
        h = 60.0 * (((b_ - r_) / delta) + 2)
    else:
        h = 60.0 * (((r_ - g_) / delta) + 4)

    return (h % 360, s, l)


def _hue_distance(h1: float, h2: float) -> float:
    """Shortest angular distance between two hues (0-180)."""
    d = abs(h1 - h2) % 360
    return min(d, 360 - d)


def classify_color_harmony(colors: list[tuple[int, int, int, float]]) -> str:
    """Classify the color harmony scheme from extracted palette colors.

    Args:
        colors: list of (r, g, b, area_pct) sorted by area descending.

    Returns:
        Multi-line string for analysis.txt with scheme, hue angles, and 60-30-10 assessment.
    """
    lines = ["## Color Harmony", ""]

    # Filter to chromatic colors (saturation > 0.08 and not near-black/near-white)
    chromatic = []
    achromatic_pct = 0.0
    for r, g, b, pct in colors:
        h, s, l = _rgb_to_hsl(r, g, b)
        if s < 0.08 or l < 0.05 or l > 0.95:
            achromatic_pct += pct
        else:
            chromatic.append((h, s, l, r, g, b, pct))

    if len(chromatic) < 2:
        lines.append("- Scheme: monochromatic or achromatic (fewer than 2 chromatic colors)")
        lines.append(f"- Achromatic area: {achromatic_pct:.1f}%")
        if chromatic:
            h, s, l, r, g, b, pct = chromatic[0]
            lines.append(f"- Dominant hue: {h:.0f}\u00b0 (#{r:02X}{g:02X}{b:02X}, {pct:.1f}%)")
        lines.append("- Classification confidence: HIGH")
        return "\n".join(lines)

    # Get hues sorted by area
    hues = [(c[0], c[6]) for c in chromatic]  # (hue, pct)
    hue_values = [h for h, _ in hues]

    # Check pairwise distances
    n = len(hue_values)
    all_distances = []
    for i in range(n):
        for j in range(i + 1, n):
            all_distances.append(_hue_distance(hue_values[i], hue_values[j]))

    max_dist = max(all_distances) if all_distances else 0

    # Classification logic
    scheme = "no discernible scheme"
    confidence = "LOW"

    if max_dist <= 15:
        scheme = "monochromatic"
        confidence = "HIGH"
    elif max_dist <= 30:
        scheme = "analogous"
        confidence = "HIGH"
    elif n == 2:
        d = all_distances[0]
        if 150 <= d <= 210:
            scheme = "complementary"
            confidence = "HIGH"
        elif 30 < d <= 60:
            scheme = "analogous"
            confidence = "MEDIUM"
    elif n >= 3:
        # Check triadic (3 hues ~120\u00b0 apart)
        top3 = sorted(hue_values[:3])
        d01 = _hue_distance(top3[0], top3[1])
        d12 = _hue_distance(top3[1], top3[2])
        d02 = _hue_distance(top3[0], top3[2])
        if all(100 <= d <= 140 for d in [d01, d12, d02]):
            scheme = "triadic"
            confidence = "HIGH"
        # Check split-complementary
        elif any(150 <= d <= 210 for d in [d01, d12, d02]):
            comp_pairs = [(d, i) for i, d in enumerate([d01, d12, d02]) if 150 <= d <= 210]
            if comp_pairs and any(20 <= d <= 60 for d in [d01, d12, d02]):
                scheme = "split-complementary"
                confidence = "MEDIUM"
        # Broader analogous check
        if scheme == "no discernible scheme" and max_dist <= 60:
            scheme = "analogous"
            confidence = "MEDIUM"

    lines.append(f"- Scheme: {scheme}")
    lines.append(f"- Classification confidence: {confidence}")
    hue_strs = ", ".join(f"{h:.0f}\u00b0" for h, _ in hues)
    lines.append(f"- Chromatic hues: {hue_strs}")
    lines.append(f"- Achromatic area: {achromatic_pct:.1f}%")
    lines.append(f"- Max hue distance: {max_dist:.0f}\u00b0")

    # Hue detail
    lines.append("- Chromatic colors:")
    for h, s, l, r, g, b, pct in chromatic:
        lines.append(f"  #{r:02X}{g:02X}{b:02X} hue={h:.0f}\u00b0 sat={s:.2f} lum={l:.2f} area={pct:.1f}%")

    # 60-30-10 assessment
    total_chromatic = sum(c[6] for c in chromatic)
    if total_chromatic > 0 and len(chromatic) >= 2:
        dominant_pct = chromatic[0][6]
        secondary_pct = chromatic[1][6] if len(chromatic) > 1 else 0
        accent_pct = sum(c[6] for c in chromatic[2:])
        lines.append(f"- 60-30-10 distribution: dominant={dominant_pct:.1f}% secondary={secondary_pct:.1f}% accent={accent_pct:.1f}%")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Per-grid-cell dominant colors
# ---------------------------------------------------------------------------

def extract_grid_cell_colors(img: Image.Image) -> str:
    """Extract top-3 dominant colors per grid cell for color-element binding.

    Returns multi-line string for analysis.txt.
    """
    w, h = img.size
    cols, rows = pick_grid_dims(w, h)
    col_w = w / cols
    row_h = h / rows

    col_labels = [chr(ord("A") + i) for i in range(cols)]
    row_labels = [str(i + 1) for i in range(rows)]

    lines = ["## Per-Cell Dominant Colors", ""]

    for r_idx, r_label in enumerate(row_labels):
        for c_idx, c_label in enumerate(col_labels):
            cell_label = f"{c_label}{r_label}"
            x1 = int(c_idx * col_w)
            y1 = int(r_idx * row_h)
            x2 = int((c_idx + 1) * col_w)
            y2 = int((r_idx + 1) * row_h)
            cell = img.crop((x1, y1, x2, y2))

            small = cell.copy()
            small.thumbnail((50, 50), Image.LANCZOS)
            try:
                quantized = small.quantize(colors=3, method=Image.Quantize.MEDIANCUT)
            except Exception:
                lines.append(f"- {cell_label}: (extraction failed)")
                continue

            palette = quantized.getpalette()
            if not palette:
                lines.append(f"- {cell_label}: (no palette)")
                continue

            get_data = getattr(quantized, "get_flattened_data", quantized.getdata)
            counts = Counter(get_data())
            total = sum(counts.values())

            cell_colors = []
            for idx, count in counts.most_common(3):
                if idx * 3 + 2 >= len(palette):
                    continue
                r = palette[idx * 3]
                g = palette[idx * 3 + 1]
                b = palette[idx * 3 + 2]
                pct = (count / total) * 100
                cell_colors.append(f"#{r:02X}{g:02X}{b:02X} ({pct:.0f}%)")

            lines.append(f"- {cell_label}: {', '.join(cell_colors)}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Visual complexity metrics
# ---------------------------------------------------------------------------

def compute_visual_complexity(img: Image.Image) -> str:
    """Compute visual complexity metrics: edge density, contour count, color clusters.

    Returns multi-line string for analysis.txt.
    """
    lines = ["## Visual Complexity", ""]

    if not HAS_CV2 or not HAS_NUMPY:
        lines.append("- Skipped (requires numpy + opencv)")
        return "\n".join(lines)

    arr = np.array(img)
    gray = cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)
    h, w = gray.shape
    total_pixels = h * w

    # Edge density via Canny
    edges = cv2.Canny(gray, CANNY_LOW, CANNY_HIGH)
    edge_pixels = int(np.count_nonzero(edges))
    edge_density = edge_pixels / total_pixels

    # Contour count (proxy for element density)
    _, thresh = cv2.threshold(edges, 127, 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    # Filter tiny contours (noise)
    min_contour_area = total_pixels * 0.0001  # 0.01% of image
    significant_contours = [c for c in contours if cv2.contourArea(c) > min_contour_area]
    contour_count = len(significant_contours)

    # Qualitative label
    if edge_density < COMPLEXITY_EDGE_LOW and contour_count < COMPLEXITY_CONTOUR_LOW:
        label = "LOW"
    elif edge_density > COMPLEXITY_EDGE_HIGH or contour_count > COMPLEXITY_CONTOUR_HIGH:
        label = "HIGH"
    else:
        label = "MEDIUM"

    lines.append(f"- Edge density: {edge_density:.3f} ({edge_density * 100:.1f}%)")
    lines.append(f"- Significant contours: {contour_count}")
    lines.append(f"- Complexity level: {label} (heuristic classification \u2014 thresholds are engineering estimates, not research-derived)")
    lines.append(f"- Thresholds: LOW < {COMPLEXITY_EDGE_LOW * 100:.0f}% edges + < {COMPLEXITY_CONTOUR_LOW} contours | HIGH > {COMPLEXITY_EDGE_HIGH * 100:.0f}% edges or > {COMPLEXITY_CONTOUR_HIGH} contours")

    return "\n".join(lines)



# ---------------------------------------------------------------------------
# Color palette extraction and contrast analysis
# ---------------------------------------------------------------------------

def _srgb_to_linear(c: float) -> float:
    """Convert sRGB channel (0-1) to linear."""
    if c <= 0.04045:
        return c / 12.92
    return ((c + 0.055) / 1.055) ** 2.4


def _relative_luminance(r: int, g: int, b: int) -> float:
    """WCAG 2.1 relative luminance from RGB 0-255."""
    rl = _srgb_to_linear(r / 255.0)
    gl = _srgb_to_linear(g / 255.0)
    bl = _srgb_to_linear(b / 255.0)
    return 0.2126 * rl + 0.7152 * gl + 0.0722 * bl


def _contrast_ratio(l1: float, l2: float) -> float:
    """WCAG contrast ratio from two relative luminances."""
    lighter = max(l1, l2)
    darker = min(l1, l2)
    return (lighter + 0.05) / (darker + 0.05)


def _wcag_verdict(ratio: float) -> str:
    """Return WCAG pass/fail string."""
    if ratio >= 7.0:
        return "PASS AAA (normal+large)"
    elif ratio >= 4.5:
        return "PASS AA normal, AAA large"
    elif ratio >= 3.0:
        return "PASS AA large text only"
    else:
        return "FAIL all WCAG levels"


def extract_color_analysis(img: Image.Image) -> str:
    """Extract dominant colors and compute contrast ratios."""
    # Quantize to K colors
    small = img.copy()
    small.thumbnail((200, 200), Image.LANCZOS)
    quantized = small.quantize(colors=PALETTE_K, method=Image.Quantize.MEDIANCUT)
    palette_data = quantized.getpalette()
    get_data = getattr(quantized, "get_flattened_data", quantized.getdata)
    counts = Counter(get_data())

    total_pixels = sum(counts.values())
    colors = []
    for idx, count in counts.most_common(PALETTE_K):
        r = palette_data[idx * 3]
        g = palette_data[idx * 3 + 1]
        b = palette_data[idx * 3 + 2]
        pct = (count / total_pixels) * 100
        colors.append((r, g, b, pct))

    # Sort by percentage descending
    colors.sort(key=lambda c: c[3], reverse=True)

    # Classify colors
    lines = ["# Color Analysis", ""]
    lines.append("## Dominant Colors (sorted by area)")
    lines.append("")
    lines.append("| Rank | Hex | RGB | Area % | Role (estimated) |")
    lines.append("|-|-|-|-|-|")

    for i, (r, g, b, pct) in enumerate(colors):
        hex_val = f"#{r:02X}{g:02X}{b:02X}"
        lum = _relative_luminance(r, g, b)
        if pct > 20:
            role = "Background (dominant)"
        elif lum < 0.15:
            role = "Text-likely (dark)"
        elif lum > 0.85:
            role = "Background-likely (light)"
        else:
            role = "Accent / UI element"
        lines.append(f"| {i+1} | {hex_val} | ({r}, {g}, {b}) | {pct:.1f}% | {role} |")

    # Compute contrast ratios for likely text-background pairs
    lines.append("")
    lines.append("## Contrast Ratios (text-likely vs background-likely pairs)")
    lines.append("")

    bg_colors = [(r, g, b, pct) for r, g, b, pct in colors if pct > 15 or _relative_luminance(r, g, b) > 0.7]
    text_colors = [(r, g, b, pct) for r, g, b, pct in colors if _relative_luminance(r, g, b) < 0.25]

    if bg_colors and text_colors:
        lines.append("| Text Color | Background | Ratio | WCAG Verdict |")
        lines.append("|-|-|-|-|")
        for tr, tg, tb, _ in text_colors:
            t_lum = _relative_luminance(tr, tg, tb)
            for br, bg_c, bb, _ in bg_colors:
                b_lum = _relative_luminance(br, bg_c, bb)
                ratio = _contrast_ratio(t_lum, b_lum)
                t_hex = f"#{tr:02X}{tg:02X}{tb:02X}"
                b_hex = f"#{br:02X}{bg_c:02X}{bb:02X}"
                verdict = _wcag_verdict(ratio)
                lines.append(f"| {t_hex} | {b_hex} | {ratio:.2f}:1 | {verdict} |")
    else:
        lines.append("No clear text-background pairs detected. Manual inspection recommended.")

    return "\n".join(lines)
