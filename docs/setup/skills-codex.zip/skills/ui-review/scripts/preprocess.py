#!/usr/bin/env python3
"""UI Review preprocessing pipeline.

Generates image variants and color analysis that Claude cannot produce
through vision alone: WCAG contrast ratios, colorblindness simulation,
saliency heatmap, blur test, symmetry analysis, and color palette extraction.

Outputs:
    original.png     - Resized to Claude-optimal dimensions
    grid.png         - Numbered cell overlay for spatial reference
    blur.png         - Gaussian blur (squint test for processing fluency)
    grayscale.png    - Luminance-only (hierarchy without color)
    deuteranopia.png - Deuteranopia (red-green CVD) simulation
    saliency.png     - Itti-Koch saliency heatmap overlay
    symmetry.png     - Bilateral symmetry difference overlay
    analysis.txt     - Color palette, WCAG contrast, harmony, complexity, metadata
    sections/        - Vertical crops if aspect ratio > 2:1
"""

import argparse
import math
import sys
import time
from collections import Counter
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False

try:
    import cv2  # noqa: F401
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False

from color_analysis import (
    PALETTE_K,
    classify_color_harmony,
    compute_visual_complexity,
    extract_color_analysis,
    extract_grid_cell_colors,
)
from grid_utils import pick_grid_dims
from image_variants import (
    generate_blur,
    generate_deuteranopia,
    generate_grayscale,
    generate_saliency,
    generate_symmetry,
)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MAX_LONGEST_EDGE = 1568
MIN_EDGE = 200
MAX_MEGAPIXELS = 1.15 * 1_000_000
GRID_LINE_COLOR = (128, 128, 128, 100)
GRID_LABEL_BG = (0, 0, 0, 140)
GRID_LABEL_FG = (255, 255, 255, 230)
TALL_ASPECT_THRESHOLD = 2.0
SECTION_OVERLAP_FRAC = 0.15



# ---------------------------------------------------------------------------
# Image optimization
# ---------------------------------------------------------------------------

def optimize_image(img: Image.Image) -> tuple[Image.Image, str]:
    """Resize image to Claude-optimal dimensions.

    Scales DOWN images exceeding 1568px / 1.15MP, scales UP images that
    underutilize the token budget. Returns (image, resize_action).
    """
    img = img.convert("RGB")
    w, h = img.size
    action = "none"

    # For very tall/wide images, constrain so the SHORT edge stays usable.
    # A 205px-wide image is unreadable. Minimum short edge: 400px.
    MIN_SHORT_EDGE = 400

    longest = max(w, h)
    if longest > MAX_LONGEST_EDGE:
        scale = MAX_LONGEST_EDGE / longest
        new_w, new_h = int(w * scale), int(h * scale)
        # Check if this would crush the short edge below usable
        if min(new_w, new_h) < MIN_SHORT_EDGE:
            # Scale by short edge instead — allow longest to exceed 1568
            scale = MIN_SHORT_EDGE / min(w, h)
            if scale < 1.0:
                w, h = int(w * scale), int(h * scale)
                img = img.resize((w, h), Image.LANCZOS)
                action = "downscaled"
            # else: image short edge already < 400, don't upscale here
        else:
            w, h = new_w, new_h
            img = img.resize((w, h), Image.LANCZOS)
            action = "downscaled"

    pixels = w * h
    if pixels > MAX_MEGAPIXELS:
        scale = math.sqrt(MAX_MEGAPIXELS / pixels)
        new_w, new_h = int(w * scale), int(h * scale)
        if min(new_w, new_h) >= MIN_SHORT_EDGE:
            w, h = new_w, new_h
            img = img.resize((w, h), Image.LANCZOS)
            action = "downscaled"
        # else: skip MP reduction to preserve readability

    pixels = w * h
    if pixels < MAX_MEGAPIXELS:
        longest = max(w, h)
        scale_by_edge = MAX_LONGEST_EDGE / longest
        scale_by_mp = math.sqrt(MAX_MEGAPIXELS / pixels)
        scale = min(scale_by_edge, scale_by_mp)
        if scale > 1.05:
            w, h = int(w * scale), int(h * scale)
            img = img.resize((w, h), Image.LANCZOS)
            action = "upscaled"

    if min(w, h) < MIN_EDGE:
        scale = MIN_EDGE / min(w, h)
        w, h = int(w * scale), int(h * scale)
        img = img.resize((w, h), Image.LANCZOS)
        if action == "none":
            action = "upscaled"

    return img, action


# ---------------------------------------------------------------------------
# Grid overlay
# ---------------------------------------------------------------------------

def generate_grid(img: Image.Image) -> Image.Image:
    """Overlay a labeled grid on the image."""
    base = img.copy().convert("RGBA")
    overlay = Image.new("RGBA", base.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    w, h = base.size
    cols, rows = pick_grid_dims(w, h)

    col_w = w / cols
    row_h = h / rows

    for c in range(1, cols):
        x = int(c * col_w)
        draw.line([(x, 0), (x, h)], fill=GRID_LINE_COLOR, width=1)
    for r in range(1, rows):
        y = int(r * row_h)
        draw.line([(0, y), (w, y)], fill=GRID_LINE_COLOR, width=1)

    draw.rectangle([(0, 0), (w - 1, h - 1)], outline=GRID_LINE_COLOR, width=1)

    font_size = max(10, min(14, int(min(col_w, row_h) / 6)))
    try:
        font = ImageFont.truetype("/System/Library/Fonts/Menlo.ttc", font_size)
    except (OSError, AttributeError):
        try:
            font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", font_size)
        except (OSError, AttributeError):
            font = ImageFont.load_default()

    col_labels = [chr(ord("A") + i) for i in range(cols)]
    row_labels = [str(i + 1) for i in range(rows)]

    for r_idx, r_label in enumerate(row_labels):
        for c_idx, c_label in enumerate(col_labels):
            label = f"{c_label}{r_label}"
            x = int(c_idx * col_w) + 3
            y = int(r_idx * row_h) + 2

            bbox = font.getbbox(label)
            tw = bbox[2] - bbox[0]
            th = bbox[3] - bbox[1]

            pad = 2
            draw.rectangle(
                [(x - pad, y - pad), (x + tw + pad + 2, y + th + pad + 2)],
                fill=GRID_LABEL_BG,
            )
            draw.text((x + 1, y), label, fill=GRID_LABEL_FG, font=font)

    result = Image.alpha_composite(base, overlay)
    return result.convert("RGB")


# ---------------------------------------------------------------------------
# Section crops for tall images
# ---------------------------------------------------------------------------

def generate_sections(img: Image.Image, out_dir: Path) -> list[str]:
    """Split tall images into overlapping vertical sections."""
    w, h = img.size
    aspect = h / w
    if aspect <= TALL_ASPECT_THRESHOLD:
        return []

    section_dir = out_dir / "sections"
    section_dir.mkdir(exist_ok=True)

    section_h = int(w * 1.2)
    overlap = int(section_h * SECTION_OVERLAP_FRAC)
    stride = section_h - overlap

    sections = []
    y = 0
    idx = 1
    while y < h:
        y_end = min(y + section_h, h)
        if y_end - y < MIN_EDGE:
            y = max(0, y_end - MIN_EDGE)
        crop = img.crop((0, y, w, y_end))
        name = f"section_{idx:02d}.png"
        crop.save(section_dir / name, "PNG")
        sections.append(name)
        idx += 1
        y += stride
        if y_end >= h:
            break

    return sections



# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="UI Review image preprocessor")
    parser.add_argument("image", nargs="?", help="Path to UI screenshot")
    parser.add_argument("--output-dir", "-o", help="Output directory")
    parser.add_argument("--check-deps", action="store_true", help="Check dependencies and exit")
    args = parser.parse_args()

    if args.check_deps:
        print("\n=== UI Review — Dependency Check ===\n")
        print(f"Python: {sys.version_info.major}.{sys.version_info.minor}")
        deps = [
            ("Pillow", True, "image processing"),
            ("numpy", HAS_NUMPY, "deuteranopia, saliency, symmetry"),
            ("OpenCV", HAS_CV2, "saliency heatmap"),
        ]
        all_ok = True
        for name, available, purpose in deps:
            mark = "OK" if available else "MISSING"
            print(f"  {mark}  {name} — {purpose}")
            if not available:
                all_ok = False
        if not all_ok:
            print("\nInstall missing: pip install numpy opencv-python-headless")
        print()
        sys.exit(0 if all_ok else 1)

    if not args.image:
        parser.error("the following arguments are required: image")

    image_path = Path(args.image).resolve()
    if not image_path.exists():
        print(f"ERROR: File not found: {image_path}", file=sys.stderr)
        sys.exit(1)

    if args.output_dir:
        out_dir = Path(args.output_dir).resolve()
    else:
        ts = time.strftime("%Y%m%d-%H%M%S")
        out_dir = image_path.parent / f"ui_review_{ts}"
    out_dir.mkdir(parents=True, exist_ok=True)

    # Load
    try:
        raw = Image.open(image_path)
    except Exception as e:
        print(f"ERROR: Cannot open image: {e}", file=sys.stderr)
        sys.exit(1)

    orig_w, orig_h = raw.size
    orientation = "landscape" if orig_w >= orig_h else "portrait"

    # Step 1: Optimize
    optimized, resize_action = optimize_image(raw)
    opt_w, opt_h = optimized.size
    optimized.save(out_dir / "original.png", "PNG")

    # Step 2: Grid overlay
    grid = generate_grid(optimized)
    grid.save(out_dir / "grid.png", "PNG")

    # Step 3: Blur
    blur = generate_blur(optimized)
    blur.save(out_dir / "blur.png", "PNG")

    # Step 4: Grayscale
    gray = generate_grayscale(optimized)
    gray.save(out_dir / "grayscale.png", "PNG")

    # Step 5: Deuteranopia
    skipped = []
    deuter = generate_deuteranopia(optimized)
    if deuter is not None:
        deuter.save(out_dir / "deuteranopia.png", "PNG")
    else:
        skipped.append("deuteranopia.png (numpy not installed)")

    # Step 6: Saliency
    sal = generate_saliency(optimized)
    if sal is not None:
        sal.save(out_dir / "saliency.png", "PNG")
    else:
        missing = []
        if not HAS_NUMPY:
            missing.append("numpy")
        if not HAS_CV2:
            missing.append("opencv-python")
        skipped.append(f"saliency.png ({', '.join(missing)} not installed)")

    # Step 7: Color analysis
    color_report = extract_color_analysis(optimized)

    # Step 8: Section crops
    sections = generate_sections(optimized, out_dir)

    # Step 10: Symmetry
    sym_img, sym_score, sym_strips = generate_symmetry(optimized)
    if sym_img is not None:
        sym_img.save(out_dir / "symmetry.png", "PNG")
    else:
        skipped.append("symmetry.png (numpy not installed)")

    # Step 11: Color harmony
    small_h = optimized.copy()
    small_h.thumbnail((200, 200), Image.LANCZOS)
    quantized_h = small_h.quantize(colors=PALETTE_K, method=Image.Quantize.MEDIANCUT)
    palette_h = quantized_h.getpalette()
    get_data_h = getattr(quantized_h, "get_flattened_data", quantized_h.getdata)
    counts_h = Counter(get_data_h())
    total_h = sum(counts_h.values())
    harmony_colors = []
    for idx, count in counts_h.most_common(PALETTE_K):
        r = palette_h[idx * 3]
        g = palette_h[idx * 3 + 1]
        b = palette_h[idx * 3 + 2]
        pct = (count / total_h) * 100
        harmony_colors.append((r, g, b, pct))
    harmony_colors.sort(key=lambda c: c[3], reverse=True)
    harmony_report = classify_color_harmony(harmony_colors)

    # Step 12: Visual complexity
    complexity_report = compute_visual_complexity(optimized)

    # Step 13: Per-cell colors
    cell_colors_report = extract_grid_cell_colors(optimized)

    # --- Assemble analysis.txt ---

    # Symmetry section
    sym_lines = ["", "", "## Symmetry Analysis", ""]
    if sym_score is not None and sym_strips is not None:
        sym_lines.append("- Method: per-strip bilateral comparison, strips aligned with grid rows")
        sym_lines.append(f"- Overall score: {sym_score} (0.0 = max asymmetry, 1.0 = perfect symmetry)")
        sym_lines.append("- Per-strip scores:")
        for i, s in enumerate(sym_strips):
            label = ""
            if i == 0:
                label = " (top)"
            elif i == len(sym_strips) - 1:
                label = " (bottom)"
            sym_lines.append(f"  Row {i + 1}: {s}{label}")
    else:
        sym_lines.append("- Skipped (requires numpy)")

    # Metadata section
    orig_tokens = int((orig_w * orig_h) / 750)
    opt_tokens = int((opt_w * opt_h) / 750)
    meta_lines = [
        "",
        "## Image Metadata",
        "",
        f"- Original dimensions: {orig_w}x{orig_h} (~{orig_tokens} tokens)",
        f"- Optimized dimensions: {opt_w}x{opt_h} (~{opt_tokens} tokens)",
        f"- Resize action: {resize_action}",
        f"- Orientation: {orientation}",
        f"- Aspect ratio: {orig_w/orig_h:.2f}:1" if orig_w >= orig_h else f"- Aspect ratio: 1:{orig_h/orig_w:.2f}",
        f"- Section crops: {len(sections)}",
    ]
    if sections:
        meta_lines.append(f"- Sections: {', '.join(sections)}")

    # Resolution warnings
    meta_lines.append("")
    meta_lines.append("## Resolution Quality")
    meta_lines.append("")
    min_orig_edge = min(orig_w, orig_h)
    if min_orig_edge < 300:
        meta_lines.append(
            f"- CRITICAL: Shortest edge ({min_orig_edge}px) is very low. "
            f"Small text and fine details will be unreliable. "
            f"Recommend a higher-resolution screenshot."
        )
    elif min_orig_edge < 448:
        meta_lines.append(
            f"- WARNING: Shortest edge ({min_orig_edge}px) is below 448px. "
            f"Image was upscaled to {opt_w}x{opt_h} but upscaling cannot add detail. "
            f"If this is a design tool export, re-export at 2x or 3x."
        )
    elif resize_action == "upscaled":
        meta_lines.append(
            f"- Upscaled from {orig_w}x{orig_h} to {opt_w}x{opt_h} to fill token budget."
        )
    elif resize_action == "downscaled":
        meta_lines.append(
            f"- Downscaled from {orig_w}x{orig_h} to {opt_w}x{opt_h} to fit processing limits."
        )
    else:
        meta_lines.append("- Image is within optimal range.")

    # Assemble
    full_report = (
        color_report
        + "\n".join(sym_lines)
        + "\n" + harmony_report
        + "\n" + complexity_report
        + "\n\n" + cell_colors_report
        + "\n" + "\n".join(meta_lines)
        + "\n"
    )
    (out_dir / "analysis.txt").write_text(full_report)

    # Summary
    files = ["original.png", "grid.png", "blur.png", "grayscale.png"]
    if deuter is not None:
        files.append("deuteranopia.png")
    if sal is not None:
        files.append("saliency.png")
    if sym_img is not None:
        files.append("symmetry.png")
    files.append("analysis.txt")
    if sections:
        files.extend([f"sections/{s}" for s in sections])

    print(f"Output directory: {out_dir}")
    print("Generated files:")
    for f in files:
        print(f"  {out_dir / f}")
    print(f"\nImage: {orig_w}x{orig_h} -> {opt_w}x{opt_h} [{resize_action}]")
    if sections:
        print(f"Section crops: {len(sections)}")
    if skipped:
        print("Skipped:")
        for s in skipped:
            print(f"  {s}")


if __name__ == "__main__":
    main()
