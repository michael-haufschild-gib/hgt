# UI Review Report Rewrite

Rewrite a technical UI review report into a clean deliverable for human readers.

=== CONTENT INTEGRITY ===
Use ONLY information from the original report. Do not add findings, change severity, invent examples, or strengthen thin evidence. When uncertain whether something is in the original: leave it out.
=== END CONTENT INTEGRITY ===

---

## TRANSFORMS

Apply all of these to the raw report.

**1. Replace grid cell references with element descriptions.**
"[B3]" → "the orange $4.99 purchase button." The reader has never seen the grid overlay. Use the element's text, color, or function as identifier.

**2. Remove check IDs and research citations.**
Delete "(CV8 compound with PP3)", "[TrustPilot 2023]", "(U1 partial, U2 fail)". Keep data points — delete attribution tags.

**3. Delete methodology sections.**
Squint Test Results, Aesthetic Assessment scores, Color & Contrast Report tables — delete these. If they produced a finding, it already appears in the findings sections. Promote any orphaned conclusion to the appropriate findings group.

Preserve the "UI Overview" — it becomes "What We're Looking At."
Move the "Overall Aesthetic Impression" sentence to the end of "What We're Looking At."

**4. Merge all findings into one prioritized list.**
Raw reports scatter findings across Critical Issues, Improvements, Considerations, Conversion Assessment, Shop/Popup/Ad sections. Merge into: Priority Issues, Other Findings, Strengths. Preserve the original's priority ordering.

**5. Collapse disclaimers into one footer.**
Merge all "Cannot Determine" / "Beyond This Analysis" sections into **Limitations** — maximum 5 bullets. Keep only items specific to THIS screenshot. Delete generic boilerplate (font ID, dynamic behavior, screen reader accessibility).

**6. Simplify Trust assessment.**
Keep: commitment level, proportionality verdict (1-2 sentences), confirmshaming findings. Delete: credibility inventory table, "Trust Implications" paragraph, "Cannot Determine" list.

**7. Convert checklists to findings.**
Passing checks are not findings — delete them. Failed checks become findings in the appropriate section.

---

## FINDING STRUCTURE

Every finding follows this pattern. Do not deviate.

**Finding title.** (confidence tag)
What we found — one sentence describing the observation.
Why it matters — one sentence with the design principle or research data point.
What to do — one direct recommendation. Or: "Verify [specific thing] in live testing."

Do not use blockquote syntax (`>`). Findings are regular paragraphs, not quotes.
Do not combine unrelated observations into one finding. Do not jump between topics within a finding. One issue, one reason, one action.

Group findings that share a root cause under a shared lead-in sentence. Do not repeat context.

---

## OUTPUT STRUCTURE

```markdown
# UI Review: [Product/Screen Name]

## Summary

[Executive summary. 4-6 sentences.

Sentence 1: What this document is — "This is a UI review of [product/screen name],
a [screen type] for [domain/purpose]."
Sentence 2: What we did — "We evaluated [N] design criteria covering usability,
accessibility, aesthetics, and trust."
Sentence 3-4: What we found — the most important findings, positive or negative,
in order of impact. If the design is strong, say so. If it is weak, say so.
Sentence 5-6: What to focus on — "The priority issues below address [theme]."
Include a strength only if a genuine one exists.

Match the tone to the design quality. A strong design gets a positive summary.
A weak design gets a direct summary that names the problems.
Do not soften a negative assessment to spare feelings — this is a professional audit.]

## What We're Looking At

[Full UI Overview from the original report. Keep the richness: element positions,
text content, layout structure, visual hierarchy, inferred user goal.
Apply transforms 1-2. Append the aesthetic impression as closing sentence.
Do NOT shorten this section.]

## First Impression

[Copy the first-impression sentence from raw_perception.md verbatim. Do not
edit, soften, or rephrase it. This is the unfiltered gut reaction before
analysis — it stays as written.]

## Priority Issues

[HIGH-confidence findings with business impact. Use the finding structure above.]

## Other Findings

[MEDIUM-priority findings. Same structure.]

## Considerations

[LOW-confidence or context-dependent items. Bullet list — one bullet each.
Flag what needs live testing.]

## Strengths

[What the UI does well. Bullet list — one bullet per strength.]

## Limitations

[Maximum 5 bullets. Only items specific to THIS screenshot.]
```

---

## STYLE

- Active voice. Lead every paragraph with its conclusion.
- Short sentences: 15-20 words average, 25 maximum.
- Paragraphs: 3-4 sentences maximum.
- No transition phrases ("Additionally," "Furthermore," "Moving on to").
- No hedging ("it should be noted," "it is worth mentioning").
- Confidence tags (HIGH/MEDIUM/LOW) on every finding.
- En-dash for parenthetical breaks.

**Sweepstakes casino terminology** (when report covers a social casino / sweepstakes product):

| Do NOT use | Use instead |
|-|-|
| "deposit" | "purchase" |
| "bonus SC", "SC bonus" | "additional Free Sweepstake Coins" or "included Free Sweepstake Coins" |
| "bet", "wager" | "spin", "play amount", "play through" |
| "Sweeps Coins", "Sweep Coins" | "Free Sweepstake Coins" |

=== RECALL ===
Every claim in the rewritten report must trace to a specific passage in the original. If you cannot point to the source: delete the claim.
=== END RECALL ===
