---
name: create-project-docs
description: "Create or refresh pattern-focused documentation for LLM agents. Bootstraps CLAUDE.md, docs/, and Serena memories from scratch — or audits existing docs (ADRs, docs/*, Serena memories, CLAUDE.md, AGENTS.md), updates stale content, and cleans up obsolete files (log-style memories, logs, test screenshots, test artifacts)."
argument-hint: "[optional: create | refresh]"
---

# Agent Documentation — Create or Refresh (Serena-Aware)

Maintain a **layered context architecture** for LLM coding agents. Core patterns go in always-loaded docs. Detailed examples and domain conventions go in Serena memories (loaded on-demand).

Two modes, auto-detected in Phase 0 (or forced via `$ARGUMENTS`):

- **CREATE** — no agent docs exist. Discover patterns, write the full doc stack (Phases 1–6).
- **REFRESH** — docs exist. Audit everything against the current codebase, update stale content, create missing pieces, delete obsolete docs, memories, and artifacts (Phases 1, R1–R4, 6).

## Context Architecture

| Layer | Location | Loaded | Budget |
|-------|----------|--------|--------|
| Identity, constraints, commands | `CLAUDE.md` | Always (root) | 50-100 lines |
| Core patterns, templates | `docs/*.md` (via `@import`) | Always | 150-300 lines each |
| Immutable style rules | `docs/meta/styleguide.md` (via `@import`) | Always | 60-100 lines |
| Decision records | `docs/adr/` (or `docs/decisions/`) | Never auto-loaded | No limit, append-only |
| Detailed examples, conventions | Serena memories | On demand | No limit |

**Goal**: Minimize always-loaded tokens. Move detailed examples to Serena memories. Wire cross-references so agents can load details when needed.

---

## Phase 0: Determine Mode

Check what exists:

| Check | Tool |
|-------|------|
| `CLAUDE.md`, `AGENTS.md` at root | Read |
| `docs/*.md`, `docs/meta/` | `mcp__serena__list_dir` |
| ADR dirs: `docs/adr/`, `docs/adrs/`, `docs/decisions/`, `docs/architecture/decisions/`, `adr/` | `mcp__serena__list_dir` |
| Serena memories | `mcp__serena__list_memories` |

- Nothing exists → **CREATE**.
- Docs or memories exist → **REFRESH**.
- Partial (e.g. CLAUDE.md exists but no `docs/`) → REFRESH what exists, CREATE what's missing — run both phase sets.

---

## Phase 1: Discover Patterns (both modes)

Use Serena tools for discovery. Do NOT use bash `cat`, `grep`, `find`, or `tree`.

| Need | Serena Tool |
|------|-------------|
| Folder structure | `mcp__serena__list_dir` |
| Base classes, interfaces, patterns | `mcp__serena__get_symbols_overview` |
| Specific abstractions | `mcp__serena__find_symbol` |
| Conventions, naming patterns | `mcp__serena__search_for_pattern` |

Also read: `package.json` (or equivalent), existing `CLAUDE.md`, existing `docs/`, existing `.claude/rules/`.

**Discover these patterns** (they become agent instructions):

1. **Folder structure**: Where does each type of code go?
2. **Naming conventions**: Files, classes, functions, tests
3. **Tech stack**: Language, framework, key libraries
4. **Base abstractions**: Classes/interfaces to extend
5. **Domain boundaries**: Import rules, isolation constraints
6. **Common workflows**: "How to create X" step-by-step procedures
7. **What to avoid**: Anti-patterns specific to this codebase

**Determine which optional docs to create**:

| Project has... | Create |
|---------------|--------|
| Frontend UI | `docs/frontend.md` |
| API endpoints | `docs/api.md` |
| Database/ORM | `docs/database.md` |
| Custom rendering | Domain-specific doc |

### REFRESH mode: additionally collect staleness evidence

| Evidence | How |
|----------|-----|
| Code changed since docs last touched | `git log -1 --format=%H -- docs/ CLAUDE.md`, then `git log --stat <sha>..HEAD -- src/` (or equivalent source root) |
| Commands drifted | Diff the CLAUDE.md command table against `package.json` scripts (or Makefile, justfile, etc.) |
| Dead references | Every file path, symbol, command, and import alias mentioned in any doc or memory — verify it still exists |
| New undocumented patterns | New top-level folders, new base abstractions, new test setups since the last doc update |

---

## CREATE — Phase 2: Write Always-Loaded Docs

### Required Docs (3)

1. **`docs/architecture.md`** (150-300 lines) — File placement, naming, code templates, decision trees
2. **`docs/testing.md`** (100-250 lines) — Test stack, placement rules, templates, commands
3. **`docs/meta/styleguide.md`** (60-100 lines) — Immutable style rules: CSS, imports, JSDoc

### Optional Domain Docs

Create only if the project needs them: `docs/frontend.md`, `docs/api.md`, `docs/database.md`.

### Do NOT Create `docs/development.md`

Commands and setup belong in `CLAUDE.md` (Commands table). A separate development doc wastes always-loaded tokens on content that rarely changes.

### Token Efficiency Rules

| Do | Do Not |
|----|--------|
| Provide the PATTERN for creating new things | List every existing file, component, or endpoint |
| State the current convention | Explain historical decisions |
| Use tables, bullets, decision trees | Write prose paragraphs |
| Reference Serena memories for details | Duplicate detailed examples inline |
| Keep each doc under its budget | Let any doc exceed 300 lines |

### Structure Template

Every always-loaded doc follows this structure:

```markdown
# [Topic] Guide for LLM Coding Agents

**Purpose**: Instructions for [specific task].
**Read This When**: [trigger conditions].
**Stack**: [key technologies]

## [Core Section]

[Table or decision tree — not prose]

## How to [Common Task]

**Template**:
[Copy-paste code template with placeholders]

**Steps**:
1. [Concrete step]
2. [Concrete step]

## Common Mistakes

- **Don't**: [anti-pattern]. **Do**: [correct pattern].

## On-Demand References

| Domain | Serena Memory |
|--------|---------------|
| [detail topic] | `memory_name` |
```

---

## CREATE — Phase 3: Write `docs/meta/styleguide.md`

This doc contains **immutable rules** — violations are code review rejections. Structure:

1. **CSS forbidden/required table** (if project uses CSS)
2. **Domain-specific rendering or styling rules** (if applicable)
3. **Import patterns** (direct vs barrel, with one example)
4. **JSDoc requirement** (one-liner + Serena memory reference)
5. **On-Demand References table** (pointing to Serena memories)

Keep under 100 lines. All detailed examples go in Serena memories.

---

## CREATE — Phase 4: Create Serena Memories

For each domain with conventions worth preserving, create a Serena memory:

```
mcp__serena__write_memory  name="memory_name"  content="..."
```

### Standard Memories (create if applicable)

| Memory Name | Content | When |
|------------|---------|------|
| `code_style_conventions` | File naming, TypeScript config, state management patterns | Always |
| `modern_css_standard` | CSS patterns with examples: `clamp()`, container queries, `:has()`, `oklch()`, logical properties | If CSS |
| `jsdoc_templates` | Component/hook/utility JSDoc templates with `@param`, `@returns`, `@example` | If JS/TS |
| `codebase_structure` | Detailed folder purpose map, key file locations, domain boundaries | Always |

### Project-Specific Memories

Create additional memories for domain-specific patterns. Examples from real projects:

- `webgpu_coding_guide` — WGSL shader conventions, bind group organization, pipeline patterns
- `api_patterns` — Endpoint structure, auth patterns, error handling
- `database_conventions` — ORM patterns, migration workflow, query optimization

### Memory Content Rules

- Include concrete code examples (this is where detail lives)
- Include anti-patterns with corrections
- Cross-reference related memories
- No token budget constraint (loaded on-demand only)
- **Never** create log-style memories: no session handoffs, no "what was done" records, no dated snapshots. Memories teach patterns; git history records events.

---

## CREATE — Phase 5: Wire `CLAUDE.md` (and `AGENTS.md`)

Ensure the project's `CLAUDE.md` ties everything together:

```markdown
# [Project Name]

## Identity
[One sentence: what this project is]

## Constraints (Immutable)
| Constraint | Rule |
|-----------|------|
| [key constraint] | [rule] |

## Required Reading
@docs/architecture.md
@docs/testing.md
@docs/meta/styleguide.md
[+ any domain docs]

## Commands
| Command | Purpose |
|---------|---------|
| `npm run dev` | Dev server (already running) |
| `npm test` | Unit tests |
| `npm run build` | Production build |
```

Do NOT duplicate doc content in CLAUDE.md. Use `@import` references only.

### AGENTS.md policy

If `AGENTS.md` exists (or the project is used with non-Claude agents like Codex): generate it from `CLAUDE.md`, replacing `@import` lines with plain markdown links (other tools do not resolve `@import`). The two files must never drift — regenerate `AGENTS.md` whenever `CLAUDE.md` changes. Do not maintain independent content in both.

---

## REFRESH — Phase R1: Audit Always-Loaded Docs

Process **every** doc — `CLAUDE.md`, `AGENTS.md`, every file in `docs/` (ADRs are handled in R2). No sampling: if there are N docs, audit N docs.

For each doc, classify every section:

| Verdict | Meaning | Action |
|---------|---------|--------|
| ACCURATE | Matches current codebase | Keep |
| STALE | Right topic, wrong details (paths, commands, patterns, budgets) | Update in place |
| OBSOLETE | Documents a removed feature, pattern, or file | Delete the section (or the whole doc) |
| MISSING | Pattern exists in code but is undocumented | Write it using the CREATE templates above |

Verification duties per doc:

- Verify every command against `package.json` scripts (or equivalent); fix or remove dead ones
- Verify every file path and import alias resolves; fix or remove dead references
- Confirm budgets (CLAUDE.md ≤ 100, architecture ≤ 300, testing ≤ 250, styleguide ≤ 100). Over budget → move detail into Serena memories, leave an On-Demand Reference
- Check cross-duplication: the same rule in two docs → keep one, reference from the other
- `docs/development.md` exists → fold commands into CLAUDE.md, delete the doc
- After CLAUDE.md changes: regenerate `AGENTS.md` per the policy in Phase 5

---

## REFRESH — Phase R2: ADRs

ADRs are **append-only records** — never rewrite the decision content of an accepted ADR.

1. Read **every** ADR. Verify its Status field (Proposed / Accepted / Superseded / Deprecated).
2. Code contradicts an accepted ADR → ask the user: did the decision change (write a new ADR, mark the old one `Superseded by ADR-NNN`) or did the code drift (flag as a violation)? Never decide silently.
3. Proposed ADRs whose subject has since been implemented → confirm adoption, update Status.
4. Significant architecture decisions visible in code with no ADR → draft new ADRs (sequential number, Status: Accepted, current date).

If no ADR directory exists, skip this phase — do not introduce ADR practice unprompted.

---

## REFRESH — Phase R3: Audit Serena Memories

`mcp__serena__list_memories`, then **read every memory**. No sampling. Classify each:

| Verdict | Signals | Action |
|---------|---------|--------|
| KEEP | Durable patterns, conventions, templates — still accurate | Nothing |
| UPDATE | Right topic, stale details | `mcp__serena__edit_memory` or rewrite via `write_memory` |
| MERGE | Two memories cover one domain | Merge into one, delete the other |
| DELETE | Log-style content (below) | `mcp__serena__delete_memory` |

**Log-style memories — always delete.** They accumulate over time and are the main rot source:

- Date-stamped names: `*_2026_*`, `session_*`, `*_handoff`, `*_log`
- "What was done" history: completed-task logs, fix records, migration journals
- PRD/review/planning notes for features that have since shipped (the code is now the source of truth)
- Stale snapshots: "current state as of [date]" inventories
- Anything an agent never needs in order to **write new code correctly**

The test: *does this memory teach a pattern or convention an agent must follow?* No → delete.

After cleanup:

- Every kept memory is referenced from at least one always-loaded doc's "On-Demand References" table
- No On-Demand References table points at a deleted or renamed memory

---

## REFRESH — Phase R4: Clean Up Obsolete Files

Scan for generated debris:

| Candidate | Typical locations |
|-----------|-------------------|
| Logs | `*.log`, `logs/`, `npm-debug.log*`, lint/build output dumps |
| Test artifacts | `test-results/`, `playwright-report/`, stale `coverage/`, `*.trace.zip` |
| Test screenshots/videos | screenshot dirs full of test-run output, `*.png`/`*.webm` from automation, `__diff_output__/` |
| Dead experiments | scratch files in the repo root, abandoned `dev-tools/` leftovers |

Safety rules, in order:

1. Run `git status --ignored` first. Gitignored **and** regenerable → delete directly.
2. Untracked but not ignored → list each to the user with a one-line reason; delete only after confirmation.
3. **Tracked** files → never delete without explicit user confirmation.
4. Anything referenced by name elsewhere (grep the repo and docs before deleting) → keep it, or fix the reference first.

---

## Phase 6: Verify (both modes)

### Always-loaded doc checklist

- [ ] Each doc is under its token budget (architecture: 300, testing: 250, styleguide: 100)
- [ ] Has copy-paste code templates
- [ ] Has decision trees for "where do I put X?"
- [ ] Uses imperative language ("Do this", not "You can")
- [ ] NO exhaustive listings of files, endpoints, or components
- [ ] References Serena memories for detailed content via "On-Demand References" table
- [ ] No duplication with other always-loaded docs

### Serena memory checklist

- [ ] Created/kept for each domain with detailed conventions
- [ ] Referenced from at least one always-loaded doc
- [ ] Contains concrete code examples
- [ ] No duplication between memories
- [ ] Zero log-style memories remain

### Cross-duplication checklist

- [ ] `architecture.md` does not repeat `testing.md` content
- [ ] `styleguide.md` does not repeat `architecture.md` content
- [ ] `CLAUDE.md` does not repeat doc content (uses `@import` only)
- [ ] `AGENTS.md` is in sync with `CLAUDE.md`
- [ ] Serena memories do not duplicate always-loaded doc content

### REFRESH-specific checklist

- [ ] Every doc, every memory, every ADR was read and classified — list any skipped and why
- [ ] No doc references a deleted memory, file, or command
- [ ] Deletion list for non-ignored files was shown to the user before removal

### Token budget verification

```
CLAUDE.md:        50-100 lines
architecture.md:  150-300 lines
testing.md:       100-250 lines
styleguide.md:    60-100 lines
frontend.md:      100-300 lines (if created)
────────────────────────────────
Total always-loaded: < 1000 lines
```

---

## Success Criteria

An LLM agent can:

1. Read `CLAUDE.md` and know the project identity, constraints, and commands
2. Read `docs/architecture.md` and know where to put new code
3. Read `docs/testing.md` and write a test from the template
4. Read `docs/meta/styleguide.md` and know immutable style rules
5. Load a Serena memory and get detailed examples for the current domain
6. Follow patterns without reading the full codebase

**Output summary (CREATE)**:

```
Created layered agent documentation:

Always-loaded:
- CLAUDE.md (X lines) — Identity, constraints, commands
- docs/architecture.md (X lines) — File placement, naming, templates
- docs/testing.md (X lines) — Test stack, templates, commands
- docs/meta/styleguide.md (X lines) — Immutable style rules
[+ any domain docs]

On-demand (Serena memories):
- code_style_conventions — Naming, TypeScript, state management
- modern_css_standard — CSS patterns with examples
- jsdoc_templates — JSDoc templates for components/hooks
- codebase_structure — Detailed folder map
[+ any project-specific memories]

Total always-loaded: ~X lines
Cross-duplication: verified zero
```

**Output summary (REFRESH)**:

```
Refreshed agent documentation:

Docs:    X updated, X sections removed, X created, X deleted (list)
ADRs:    X status updates, X new, X flagged for user decision (list)
Memories: X kept, X updated, X merged, X deleted (list deleted with reason)
Artifacts: X files deleted (gitignored), X removed after confirmation (list)
AGENTS.md: regenerated from CLAUDE.md

Total always-loaded: ~X lines (was ~X)
Cross-duplication: verified zero
Skipped: [none, or list with reasons]
```
