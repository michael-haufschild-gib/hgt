# Instruction File Authoring

## CLAUDE.md (Claude Code)

### Loading Mechanics
- Root CLAUDE.md always loads at session start.
- Subdirectory CLAUDE.md files load on demand only when Claude reads files in that directory.
- Files load by walking up the directory tree from the current working directory.
- CLAUDE.md is injected as a **user message** after the system prompt, not as part of the system prompt. For system-prompt-level authority, use `--append-system-prompt` (must be passed every invocation).

### Size and Modularity
- **Target under 200 lines per CLAUDE.md file.** Longer files consume context and reduce adherence.
- `@path/to/import` syntax supports recursive imports up to 5 hops deep, resolving relative to the containing file.
- Use @imports to keep the root file small and modular.

### Priority Order
- User-level rules (~/.claude/) load before project rules.
- Project rules load later → **later position = stronger recency attention = higher effective priority**.
- Enterprise managed policy CLAUDE.md at OS-level paths cannot be excluded.

### When to Split
If your project has distinct subsystems with different conventions (frontend, backend, shared lib), place a CLAUDE.md in each subdirectory. Root CLAUDE.md handles cross-cutting concerns only.

### Template: Minimal (~40 lines)

```markdown
# [Project Name]

## Mission
[One sentence: what this project is and does]

## Critical Rules
- [Most important constraint]
- [Second most important]
- [Third most important]

## Architecture
[2-3 sentences describing codebase layout]

## Conventions
@.claude/rules/code-style.md
@.claude/rules/testing.md

## When Compacting
Preserve: list of modified files, current task status, unresolved bugs.
Discard: file contents already read, tool outputs already processed.
```

### Template: Production (~90 lines)

```markdown
=== IMMUTABLE RULES ===
1. [Critical constraint 1]
2. [Critical constraint 2]
3. [Critical constraint 3]
=== END IMMUTABLE RULES ===

# [Project Name]

## Mission
[One sentence with scale context: "FastAPI backend serving 50K+ DAU"]

## Architecture
- src/api/ — Route handlers
- src/models/ — ORM models
- src/services/ — Business logic
- tests/ — Test suite

## Code Standards
@.claude/rules/style.md
@.claude/rules/testing.md
@.claude/rules/security.md

## Key Patterns
- [Pattern 1: e.g., "business logic in services/, never in handlers"]
- [Pattern 2]
- [Pattern 3]

## Session Management
On start: read progress.json, run tests, select next task.
During work: commit after each completed sub-task.
Before compaction: update progress.json with status and next steps.

## When Compacting
PRESERVE: modified file list, failing tests, current task, blockers.
DISCARD: file contents committed, passing test output, resolved issues.

## Reminders
- [Repeat most critical rule here — recency anchor]
```

### Required Sections for Long-Running Agents
1. **Session management** — startup sequence, during-work protocol, pre-compaction steps
2. **Compaction guidance** — explicit PRESERVE/DISCARD lists
3. **Constitutional block** at top — immutable rules that survive any context state

---

## AGENTS.md (OpenAI Codex)

- Maximum size: **32 KiB**.
- Format: Markdown with section headers and bullets.
- Discovery path: `~/.codex/AGENTS.override.md` first, then git root to cwd concatenation.
- Structure similar to CLAUDE.md but single file (no @imports, no conditional loading).

---

## Rules Files (.claude/rules/)

### Conditional Rules (load when working with matching files)
```yaml
---
paths:
  - "src/**/*.ts"
  - "src/**/*.tsx"
---
# TypeScript Rules
- Use strict mode
- No any types without explicit justification
```

### Unconditional Rules (load at every session start)
Files in `.claude/rules/` **without** `paths` frontmatter load unconditionally.

```markdown
# Code Quality
- Run tests before committing
- No TODO comments without linked issues
```

### Cursor Rules
`.cursorrules` file in project root. Similar structure to unconditional rules — flat markdown with constraints. No frontmatter, no conditional loading.

---

## Skills (.claude/skills/)

### 3-Tier Progressive Disclosure
1. **Frontmatter** (name, description) — loaded at startup into skill list
2. **SKILL.md body** — loaded when skill is invoked
3. **Reference files** — loaded only when SKILL.md explicitly reads them

### Description Budget
Skill descriptions scale at **2% of context window** with a 16,000 character fallback. Exceeding this causes truncation. Keep descriptions under one paragraph.

### Frontmatter Fields
```yaml
---
name: skill-name
description: One-paragraph description (loaded at startup — keep concise)
argument-hint: [optional argument description]
allowed-tools:
  - Read
  - Grep
  - Glob
  - Bash(specific commands)
disallowed-tools:
  - Edit
  - Write
# Optional:
# disable-model-invocation: true  (prevent auto-invocation)
# user-invocable: true            (default)
# context: fork                   (run in isolated subagent)
# agent: agent-name               (which agent handles forked execution)
---
```

### Substitutions
- `$ARGUMENTS` — full argument string from user
- `$ARGUMENTS[0]`, `$ARGUMENTS[1]` — positional args
- `$1`, `$2` — shorthand for positional
- `${CLAUDE_SESSION_ID}` — current session ID
- `${CLAUDE_SKILL_DIR}` — directory containing this SKILL.md
- `` !`command` `` — inline shell execution

### Template: Standard Skill

```markdown
---
name: review-code
description: Reviews code changes for quality, security, and adherence to project standards.
argument-hint: [file-path or git-range]
allowed-tools:
  - Read
  - Grep
  - Glob
  - Bash(git diff, git log, git show)
---

## Task
Review the code changes specified by $ARGUMENTS.

## Process
1. Read the changed files
2. Check against project rules in .claude/rules/
3. Identify: bugs, security issues, style violations, missing tests

## Output Format
| Severity | File:Line | Issue | Suggestion |
|-|-|-|-|

### Verdict
APPROVE / REQUEST_CHANGES / BLOCK
```

### Template: Skill with Context Fork (Isolated Execution)

```markdown
---
name: security-audit
description: Runs isolated security audit on specified files.
context: fork
agent: security-reviewer
allowed-tools:
  - Read
  - Grep
  - Glob
---

Audit files for security vulnerabilities: $ARGUMENTS

## Scope
- SQL injection, hardcoded credentials, missing validation, insecure deserialization

## Output
JSON: [{"file", "line", "vulnerability", "severity", "recommendation"}]
```

When `context:fork` is set, the skill runs in an isolated subagent context. The skill content becomes the task prompt for the agent specified in the `agent` field.

### Priority
Enterprise skills > personal (~/.claude/skills/) > project (.claude/skills/).
Plugin skills use namespace `plugin-name:skill-name` to avoid collisions.

### Commands vs Skills
`.claude/commands/name.md` and `.claude/skills/name/SKILL.md` both create `/name`. If both exist, the **skill takes precedence**.

### Best Practice
Do not write skills speculatively. Watch the model fail at a task, then write a skill that addresses the specific failure pattern. Start with evaluation, iterate collaboratively.
