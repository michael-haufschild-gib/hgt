# GPT-5.2 / GPT-5.4 Prompt Engineering

## Reasoning Effort
Levels: `none` (default for low-latency), `low`, `medium`, `high`, `xhigh`. Reasoning tokens are billed as output tokens and not visible via API. Reserve at least 25,000 tokens for reasoning and outputs.

In **chat/CLI interfaces** (ChatGPT, Codex): reasoning effort is not directly configurable. The model self-adjusts based on query complexity.

## Scope Discipline
GPT-5.2+ follows instructions with surgical precision. Poorly constructed prompts with contradictions damage GPT-5 more than other models — it spends reasoning tokens trying to reconcile contradictions.

Add to agent prompts:
> "Implement EXACTLY and ONLY what the user requests. No extra features, no added components, no embellishments."

## Output Contracts (GPT-5.4)
Define section order, length limits, and format. Completeness contracts track deliverables:
```
OUTPUT CONTRACT:
Section order: Summary > Analysis > Recommendations
Length limits: Summary <=3 sentences, Analysis <=500 words
Completeness: Track all deliverables, mark each [DONE] or [PENDING]
```

## Long-Context Protocol (>10K tokens)
```
For inputs >10K tokens:
1. Create a short internal outline of key sections
2. Restate constraints before answering
3. Anchor all claims to specific source sections
```

## ChatGPT Custom Instructions
- **Character limit**: 1,500 characters. Every word must earn its place.
- **Projects**: isolate project-specific instructions and memory. Project instructions override global custom instructions.
- **Memory**: two-tier — global (all conversations) + project-scoped.

## Instruction Hierarchy
Root > System > Developer > User > Guideline. Developer-level (custom instructions, project instructions) outweighs user messages when they conflict.

## Template: Custom Instructions (1500 chars max)

```
ROLE: [one-line role definition]

ALWAYS:
- [Critical behavior 1]
- [Critical behavior 2]
- [Critical behavior 3]

NEVER:
- [Forbidden action 1]
- [Forbidden action 2]

FORMAT: [default output format]
LENGTH: [default response length]
CONTEXT: [key facts about user/domain]
```

## Template: GPT-5.2 Agent Prompt

```
You are [role].

## Response format
- Default: 3-6 sentences or <=5 bullets
- Simple queries: <=2 sentences
- Complex analysis: structured sections with headers

## Scope discipline
Implement EXACTLY and ONLY what the user requests.
No extra features, no added components, no UX embellishments.

## Long-context protocol
For inputs >10K tokens:
1. Create a short internal outline of key sections
2. Restate constraints before answering
3. Anchor all claims to specific source sections
```

## Codex (OpenAI CLI)

- Instruction file: `AGENTS.md` (32 KiB max, Markdown)
- Discovery: `~/.codex/AGENTS.override.md` first, then git root to cwd concatenation
- Subagents: `.codex/agents/` TOML files, `max_threads=6`, `max_depth=1` defaults
- Sandbox: subagents inherit parent sandbox permissions

## Key Differences from Claude

| Behavior | GPT-5.2+ |
|-|-|
| Emphasis response | Contradictions waste reasoning tokens — eliminate all ambiguity |
| Data/instruction order | Internal outline for >10K inputs |
| Format control | Output contracts (section order, length, completeness) |
| Reasoning control | reasoning_effort (not available in chat) |
| Agentic quirk | Set tool call budgets; early-stop at ~70% convergence |
| Verbosity | 3-6 sentences default; simple Q&A <=2 sentences |
