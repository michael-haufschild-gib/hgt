# Context Engineering

## Core Principle

Context is a degrading signal. Performance drops 13.9-85% as input length increases, even with perfect retrieval. Maximum Effective Context Window falls far short of advertised limits. Adding information always has a cost, even when relevant.

Anthropic's definition: context engineering is finding the **smallest set of high-signal tokens** that maximize the likelihood of a desired outcome.

---

## Seven Canonical Strategies (Anthropic)

1. **System prompts at the right altitude.** Goldilocks zone between brittle hardcoded logic and vague guidance. Specific enough to constrain, flexible enough for edge cases.
2. **Tool design.** Self-contained tools with minimal overlap. Each works independently.
3. **Few-shot examples.** Curate diverse, canonical examples (1-2 max).
4. **Context compaction.** Preserve architectural decisions, unresolved bugs, implementation details. Discard redundant tool outputs.
5. **Structured note-taking.** Agents write notes to external files to track progress across compaction boundaries.
6. **Sub-agent architectures.** Focused tasks in separate context windows, returning condensed summaries.
7. **Just-in-time retrieval.** Maintain lightweight identifiers (file paths, queries, links) and pull information only when needed.

---

## Compaction

### What Survives
- CLAUDE.md — re-read from disk after compaction. Anything you want to survive MUST be in a file.
- Progress files, state files — external storage persists.

### What Is Lost
- Conversation-only instructions — gone after compaction.
- Tool output details — summarized away.
- Nuances from earlier messages — compressed.

### Best Practices
- Use `/compact` with focus: `/compact Focus on the API changes`.
- Add compaction guidance to CLAUDE.md: `When compacting always preserve the full list of modified files`.
- Optimize for recall first (capture everything relevant), then improve precision.

### Checkpointing for Long Tasks

```markdown
## Context Management
Checkpoint strategy:
1. Before starting: write task_state.md with {objective, scope, files_in_scope}
2. Every 10 steps: append steps completed, files modified, next steps
3. If compaction occurs: read task_state.md immediately
4. On completion: delete task_state.md
```

---

## State Persistence

**JSON vs Markdown**: Use JSON for structured state that agents must not accidentally modify. Models are less likely to overwrite JSON than Markdown. Feature lists, progress, config → JSON. Prose instructions → Markdown.

**Memory pointers**: Replace raw data with references (file paths, DB keys). Consumes ~7x fewer tokens than including data inline.

**External memory crossover**: A memory system becomes cheaper than long-context after ~10 interaction turns for persistent agents.

---

## Instruction Fade-Out

As conversations grow, models pay less attention to the original prompt. Countermeasures:

1. **File-based persistence** — CLAUDE.md survives compaction. Critical instructions belong in files.
2. **Event-driven reminders** — re-inject key instructions at trigger points (task completion, errors, milestones).
3. **Compaction guidance** — explicit PRESERVE/DISCARD lists in CLAUDE.md.
4. **Context awareness prompt** — for long-running agents: "Your context window will be automatically compacted. Do not stop tasks early."
5. **2-correction rule** — after two failed corrections, `/clear` and rewrite the prompt. Clean session with better prompt outperforms accumulated corrections.

---

## 200K vs 1M Context

| Aspect | 200K | 1M |
|-|-|-|
| Instruction files | Aggressive @imports, keep under 200 lines | More inline content possible, but degradation still applies |
| Reference files | Keep small, load on demand | Can be larger, but economy still matters |
| State management | Essential — compaction hits sooner | Still needed — effective context << 1M |
| Compaction frequency | More frequent | Less frequent but still occurs |

**Write for 200K compatibility.** It works at 1M too. The reverse is not true.

---

## System Prompt Altitude

The right altitude balances specific and vague:

```
## Task Constraints (specific, non-negotiable)
- Maximum response length: 500 words
- Always cite sources with [Author, Year]
- Never provide medical/legal/financial advice

## Behavioral Guidelines (directional, flexible)
- Prefer concrete examples over abstract explanations
- When uncertain, state uncertainty rather than guessing
- Match technical depth to user's expertise level
```

Too specific ("always respond in exactly 3 paragraphs") breaks on edge cases. Too vague ("be helpful") provides no constraint.

---

## Prompt Caching

Place static content first (cacheable), dynamic content last. Prompt caching reduces costs 41-80% and improves time-to-first-token 13-31%. Naive full-context caching can paradoxically increase latency.
