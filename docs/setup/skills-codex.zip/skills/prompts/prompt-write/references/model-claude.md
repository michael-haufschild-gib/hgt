# Claude 4.6 Prompt Engineering

## Breaking Changes (2025-2026)

| What Changed | Before | Now |
|-|-|-|
| Prefilled assistant turn | Supported (API) | Not available in chat/CLI. In API: still functional but not recommended — model resists manipulation via prefill. Use XML tags or structured output instead. |
| Anti-laziness directives | Sometimes helped | Harmful. "Be thorough", "think carefully", "don't be lazy" cause runaway thinking or rewrite loops. Delete all. |
| Think tool instruction | "Use the think tool to plan" | Remove — causes over-planning. Models think effectively without being told to. |
| Word "think" (Opus, extended thinking off) | Used freely | Replace with "consider", "believe", or "evaluate". |
| Subagent spawning (Opus) | Implicit | Opus over-spawns. Add explicit guidance on when NOT to use subagents. |
| Summaries after tool use | Implicit | Skipped by default. Request explicitly: "provide a quick summary of work done." |
| Extended thinking (Opus 4.6) | Manual with budget_tokens | Adaptive only (manual deprecated). Effort levels: low, medium, high (default), max. |

## Formatting Rules

- **XML tags** remain the recommended structuring mechanism for Claude.
- **Match prompt style to desired output**: prose prompt → prose output; markdown prompt → markdown output.
- **Soften tool language**: "Use X when [condition]" not "CRITICAL: You MUST use X". Claude 4.6 is more responsive to system prompts — aggressive language causes overtriggering.
- **Tell what to do, not what not to do** — positive instructions outperform negative constraints.
- Keep constraints local to the output they govern (short hop distance).

## Chat/CLI Constraints

In Claude Code, Cursor, and other chat/CLI interfaces:
- **No temperature control** — not exposed.
- **No prefilled assistant turns** — removed in 4.6 and not available in chat interfaces.
- **No system instruction parameter** — use CLAUDE.md files and rules files instead.
- **No reasoning_effort parameter** — Claude uses adaptive thinking automatically.
- **Context is managed via files**: CLAUDE.md, .claude/rules/, skills, reference files. Organize context through file architecture, not API parameters.

## Context Behavior

**Adaptive thinking.** Opus 4.6 calibrates thinking based on query complexity automatically. Use the effort parameter only via API; in chat/CLI, the model self-adjusts.

**Context awareness.** Claude 4.6 tracks remaining token budget throughout conversation. Add to long-running agent prompts:
> "Your context window will be automatically compacted as it approaches its limit. Do not stop tasks early due to token budget concerns."

**Multi-window workflow.** Use first context window to set up framework (write tests, create scripts), then iterate on todo-list in subsequent windows. Starting fresh from filesystem state often beats compaction — Claude is effective at discovering state from the local filesystem.

**Sonnet 4.6** supports both manual extended thinking (with `budget_tokens`) AND adaptive thinking. Choose manual for predictable cost, adaptive for variable cost. Keep thinking budget around 16K tokens for most tasks.

## Agent Templates

### Short Task

```xml
<system>
You are [role]. Your context window will be automatically compacted
as it approaches its limit. Do not stop tasks early.

<tools>
Use [tool_name] when [specific condition].
</tools>

<actions>
Safe (proceed without asking): edit files, run tests, read files.
Dangerous (ask for confirmation): delete files, force-push, post externally.
</actions>

After completing tool use, provide a brief summary of work done.
</system>
```

### Long Task (checkpointing required)

```xml
<system>
You are [role].

<context_management>
This task may exceed context limits before completion.

Checkpoint strategy:
1. Before starting: write task_state.md with {objective, scope, files_in_scope}.
2. Every 10 steps or at each major milestone: append to task_state.md.
3. If compaction occurs: read task_state.md immediately before continuing.
4. On completion: delete task_state.md.
</context_management>

<tools>
Use [tool_name] when [specific condition].
</tools>

<actions>
Safe: edit files, run tests, read files.
Dangerous: delete files, force-push, post externally.
</actions>

<subagents>
Use subagents for parallel independent tasks requiring isolated context.
Work directly for: single-file edits, sequential ops, shared-state tasks.
</subagents>

After completing tool use, provide a brief summary of work done.
</system>
```

## Tool Use Optimizations

| Technique | Token Impact | When to Use |
|-|-|-|
| Tool Search Tool | 85% reduction (~77K → ~8.7K) | Agent has many tools; load relevant tools per task |
| Programmatic Tool Calling | 37% reduction | Multi-tool workflows; Claude writes Python to orchestrate |
| Tool use examples in description | 72% → 90% accuracy | Complex parameters, nested objects, domain formats |

For tool-heavy agents: maximize description quality AND add validation layers. Higher model capability increases tool hallucination rates — a fundamental trade-off.
