# Tool Description Best Practices

## The Problem

97.1% of MCP tool descriptions contain at least one defect. 56% fail to state purpose clearly. Fixing descriptions yields +5.85pp task success and +15.12pp partial completion.

## Writing Rules

Write tool descriptions as you would explain to a new hire:

1. **State purpose first**, then parameters. Never just list parameters.
2. **Use unambiguous parameter names.** Avoid overloaded terms.
3. **Return semantic identifiers** (names, slugs), not UUIDs. Reduces retrieval hallucination.
4. **Add pagination/filtering** for tools returning large responses.
5. **Include 1-2 concrete examples** for tools with complex parameter handling. This improved accuracy from 72% to 90%.
6. **Document error conditions** — what the tool returns on failure.

## Critical Trade-Off

Higher model capability increases tool hallucination rates. This is a fundamental reliability-capability trade-off. For tool-heavy tasks:
- Maximize description quality
- Add validation layers
- Test format compliance separately from argument correctness (they are distinct failure modes)

## Provider Tool Limits

| Provider | Limit | Notes |
|-|-|-|
| Claude | No hard limit stated | Use Tool Search Tool for large libraries (85% token reduction) |
| GPT | Up to 100 tools, 20 args/tool | Enable strict mode for schema adherence |
| Gemini | 10-20 active functions | Use enums for constrained parameters |

## Template: MCP Tool Description

```json
{
  "name": "search_customers",
  "description": "Search for customers by name, email, or account ID. Returns matching customer records with contact details and account status. Use when the user asks to find, look up, or search for a customer.",
  "inputSchema": {
    "type": "object",
    "properties": {
      "query": {
        "type": "string",
        "description": "Search term: customer name, email address, or account ID (e.g., 'jane.doe@example.com' or 'ACC-12345')"
      },
      "limit": {
        "type": "integer",
        "description": "Maximum results to return (default: 10, max: 100)",
        "default": 10
      }
    },
    "required": ["query"]
  }
}
```
