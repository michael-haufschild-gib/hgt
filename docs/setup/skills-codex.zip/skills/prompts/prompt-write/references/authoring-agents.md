# Subagent and Multi-Agent Prompt Authoring

## Claude Code Subagent Configuration

### YAML Frontmatter Fields

```yaml
---
name: agent-name              # Required
description: What this agent does. Returns structured findings.  # Required
model: sonnet                 # Optional: sonnet/opus/haiku/inherit
tools:                        # Optional: allowed tools
  - Read
  - Grep
  - Glob
  - Bash(git diff, git log)
disallowedTools:              # Optional: blocked tools
  - Edit
  - Write
permissionMode: dontAsk       # Optional: default/acceptEdits/dontAsk/bypassPermissions
maxTurns: 20                  # Optional: limit execution turns
isolation: worktree            # Optional: git-isolated copy
skills:                        # Optional: skills available to this agent
  - skill-name
mcpServers:                    # Optional: scoped MCP servers (started on spawn, stopped on finish)
  - server-name
---

[Agent instructions here — this becomes the agent's system prompt]
```

### Built-In Subagent Types
- **Explore** — Haiku model, read-only, quick/medium/thorough
- **Plan** — inherits parent model, read-only
- **General-purpose** — inherits parent model, all tools

### Context Isolation
Subagents receive ONLY their system prompt (from YAML body) plus basic environment context. **No parent conversation history.** Only the final message returns to the parent. This means:
- Every subagent prompt must be self-contained.
- Include all necessary file paths, context, and constraints in the prompt.
- The subagent cannot ask the parent for clarification.

### Auto-Compaction
Triggers at ~95% capacity. Subagents cannot spawn other subagents (max depth = 1).

---

## The 5-Element Subagent Brief

Every subagent prompt MUST include all five elements:

```markdown
## 1. Objective
[One specific task. Not "look for issues" but "does function X handle case Y correctly?"]

## 2. File Paths
[Explicit list. The subagent has no prior knowledge of your codebase.]
- src/lib/math/transform.ts
- src/lib/math/trig.ts

## 3. Output Format
[Specify exactly what to return.]
Return: JSON with file, line, issue, severity.
Or: "no issues found" with evidence checked.

## 4. Tools and Mode
[Read-only or read-write. Which tools to use.]
Mode: research only, do not edit files.

## 5. Constraints
[What NOT to do. Boundaries prevent scope creep.]
- Do not read files beyond those listed
- Do not refactor surrounding code
- Final response under 2000 chars
```

### Template: Custom Subagent Definition

```yaml
---
name: code-reviewer
description: Reviews code changes for bugs, security, and style. Returns structured findings.
model: sonnet
tools:
  - Read
  - Grep
  - Glob
  - Bash(git diff, git log, git show)
disallowedTools:
  - Edit
  - Write
permissionMode: dontAsk
maxTurns: 20
---

You are a code reviewer. You receive a git range or file list and produce a structured review.

## Process
1. Run git diff for the specified range
2. Read each changed file
3. For each change, check: correctness, security, style, test coverage

## Output
Return JSON:
{
  "summary": "one-line assessment",
  "issues": [{"severity": "high|medium|low", "file": "path", "line": N, "issue": "desc", "suggestion": "fix"}],
  "verdict": "APPROVE|REQUEST_CHANGES|BLOCK"
}

## Constraints
- Do not modify any files
- Review only the specified changes
- Final response under 2000 chars
```

---

## Orchestrator Patterns

### Delegation Formula
Every delegation prompt includes: **objective + output format + tool/source guidance + task boundaries**.

### File-Based Artifact Passing
Subagents write work products to the filesystem and pass lightweight references to the coordinator. This reduces token transfer between agents.

```
Coordinator (hub)
├── spawns Researcher → writes /tmp/research/topic-a.json
├── spawns Analyst → writes /tmp/research/analysis.json
├── spawns Reviewer → writes /tmp/research/review.json
└── reads all artifacts, synthesizes final output
```

### Template: Orchestrator Command

```markdown
# Research Orchestrator

You coordinate research by delegating to specialist subagents.

## Process
1. Analyze the research question
2. Decompose into 2-4 independent sub-questions
3. Spawn one subagent per sub-question
4. Read all subagent artifacts from [output folder]
5. Synthesize findings into unified answer

## Delegation Template
For each subagent:
- OBJECTIVE: one specific sub-question
- SOURCES: which files/URLs to examine
- OUTPUT: write to [folder]/[subtopic].json
- FORMAT: {"findings": [...], "confidence": 0-1, "gaps": [...]}
- CONSTRAINTS: examine only listed sources, do not speculate

## Synthesis Rules
- Cross-reference findings across subagents
- Flag contradictions explicitly
- Rate overall confidence based on convergence
- Identify remaining gaps honestly
```

---

## Topologies

### Sequential Pipeline (simplest)
```
Input → Agent A → Agent B → Agent C → Output
```
Each agent processes and passes structured output forward. Use when the task has clear linear flow (extract → analyze → format).

### Hub-and-Spoke (moderate)
```
          → Specialist A →
Hub Agent → Specialist B → Hub Agent → Output
          → Specialist C →
```
Hub coordinates, specialists execute in parallel, hub synthesizes. Use when subtasks are independent and can run concurrently.

### Router-Solver (most flexible)
```
Input → Router → [selects solver] → Output
         ├── Solver A (code tasks)
         ├── Solver B (research tasks)
         └── Solver C (data tasks)
```
Router classifies and routes; only the selected solver runs. Minimizes wasted context. Use when inputs vary widely in type.

---

## Multi-Agent Quality Criteria

### 5 Context Quality Criteria
1. **Relevance** — every token in subagent context relates to its specific task
2. **Sufficiency** — subagent has everything needed without asking clarifying questions
3. **Isolation** — subagent does not see other subagents' context
4. **Economy** — minimum tokens necessary; use memory pointers (~7x fewer tokens) over raw data
5. **Provenance** — subagent knows where its information comes from

### Agent-as-Tool vs Handoff
- **Agent-as-tool**: Calling agent wraps specialists as functions. Only structured result returns. Caller stays in control. Use for analysis/research.
- **Handoff**: Full conversation history transfers to receiving agent. Receiving agent takes full control. Use when next agent needs complete conversational context.

### MAST Failure Taxonomy (14 modes, 3 categories)
**System design**: inadequate role specification, insufficient tool access, missing escalation paths, ambiguous boundaries.
**Inter-agent**: conflicting objectives, information loss in handoffs, inconsistent state, format mismatches.
**Verification**: missing completion criteria, absent quality checks, no rollback, silent failure propagation.

Prevention: define clear roles, specify output format contracts, include escalation instructions, use JSON for inter-agent communication.

### Token Economics: When to Delegate

| Signal | Action |
|-|-|
| Task reads 3+ files for one question | Delegate — subagent reads, returns summary |
| Task is isolated, no conversation dependency | Delegate — clean context |
| Task traces complex chains across 5+ files | Work in main context — sequential understanding |
| Task needs current conversation info | Work in main context — subagent cannot see it |
| Multiple independent investigations | Delegate 2-3 in parallel (not more) |

Benchmark a well-prompted single agent before building multi-agent systems. Multi-agent overhead (~15x tokens) is not always justified.

---

## Codex TOML Agents

```toml
# .codex/agents/code-reviewer.toml
name = "code-reviewer"
description = "Reviews code changes for bugs, security, and style."
model = "gpt-5"
sandbox_mode = "read_only"

[developer_instructions]
content = """
Review the specified code changes. Return structured findings.
Focus on: correctness, security, performance, maintainability.
Do not modify any files. Output JSON with findings array.
"""
```

- Location: `.codex/agents/`
- Defaults: `agents.max_threads = 6`, `agents.max_depth = 1`
- Subagents inherit parent sandbox permissions and file access.
