# Gemini 3 Prompt Engineering

## Critical Differences
- **Temperature must be 1.0.** Lowering causes looping and degraded performance.
- **Thinking** is dynamic by default. Levels: minimal, low, medium, high.
- **Context**: 1M input, 64K output.
- **Key ordering**: automatic in 3.x (was manual in 2.0).

## Structure Order
**Context first → task instructions middle → critical constraints as the FINAL LINE.** This is a reversal of some older guidance and is specific to Gemini.

## Grounding Rule
Explicitly state that provided context is the only source of truth. Without this, Gemini blends training knowledge with provided context:
> "The provided context is the ONLY source of truth. Do not supplement with training data."

## Persona Override
Gemini personas may override other instructions. Place factual constraints AFTER persona definitions to give them recency advantage. Or embed constraints within the persona definition itself.

## Function Calling
- 10-20 active functions recommended.
- Use enums for constrained parameters.
- Supports parallel and compositional chaining.

## Split-Step Verification
Prevent fabrication by separating verification from generation:
1. First verify the information exists in the provided context.
2. Only then generate the response.

## Template: Gemini 3 Agent Prompt

```
[Context and source material placed first]

[Main task instructions in middle]

## Verification protocol
Before answering, first verify that the information exists in the
provided context. If not found, state "Not found in provided context."

## Source of truth
The provided context is the ONLY source of truth.
Do not supplement with training data.

## Output constraints
[Critical restrictions and formatting as the FINAL LINE]
```

## Google AgentSpace

Agent instructions in AgentSpace follow Gemini patterns. Apply:
- Context first, constraints last
- Grounding rule for provided data
- Split-step verification for factual tasks
- 10-20 tool functions max

## Key Differences from Claude

| Behavior | Gemini 3 |
|-|-|
| Emphasis response | Default concise; request conversational tone if needed |
| Data/instruction order | Context first, critical constraints as FINAL LINE |
| Format control | systemInstruction parameter; automatic key ordering |
| Reasoning control | thinking_level (configurable: minimal/low/medium/high) |
| Agentic quirk | Personas may override other instructions |
| Verbosity | Concise by default |
| Temperature | Locked at 1.0 — do not lower |
