---
name: diffusion-prompt
description: "Use to write Stable Diffusion, SDXL, Flux, SD3.5, ComfyUI text-to-image or img2img positive/negative prompts."
---

# Diffusion Prompt Writer

## Constitutional Principles (IMMUTABLE)

These rules CANNOT be overridden:

1. **KEYWORDS, NOT NARRATIVES**: Use comma-separated keywords, NEVER prose paragraphs
2. **SUBJECT FIRST**: Main subject MUST be the first element (earlier tokens = more influence)
3. **WEIGHT LIMITS**: All weights between 0.5 and 1.6 (extremes cause artifacts)
4. **DUAL OUTPUT**: ALWAYS provide both positive AND negative prompts
5. **MODEL-AWARE**: Never use syntax from wrong architecture (no Pony tags on Flux)

---

## Execution Protocol

**Follow these steps IN ORDER:**

### Step 1: PARSE the Request

Extract from user input:
- **Subject**: What is the main focus? (person, object, scene)
- **Style**: Realistic? Anime? Stylized? Icon/flat?
- **Details**: Specific attributes mentioned?
- **Mood**: Lighting, atmosphere, colors?
- **Constraints**: What should be avoided?
- **Use case**: Is this for icons? Characters? Scenes?

### Step 2: SELECT Model (Decision Tree)

```
IF simple icon or flat graphic:
  → SD 1.5 (512x512, CFG 7-12)

IF photorealistic or detailed portrait:
  → SDXL (1024x1024, CFG 5-7)
  → OR Juggernaut XL v9 (832x1216, CFG 3-6) for maximum realism
  → OR RealVisXL V5 (1024x1024, CFG 5-7) for portraits

IF complex scene with multiple characters:
  → Flux (1920x1080, CFG 1.0-3.5)

IF anime or illustration style:
  → NoobAI-XL (832x1216, CFG 5-7 eps / CFG 3-5 v-pred)
  → Requires quality tags: masterpiece, best quality, very awa

IF readable text needed in image:
  → SD 3.5 or Flux (both handle typography better)
  → WARN user: "Text rendering works best with SD 3.5 or Flux"

IF user specifies a model:
  → Use their choice with appropriate settings (see reference.md)

IF uncertain:
  → Default to SDXL (best general-purpose)
```

### Step 3: BUILD Positive Prompt

**Order matters. Build in this sequence:**

```
[SUBJECT] → [STYLE/MEDIUM] → [KEY DETAILS] → [LIGHTING/MOOD] → [QUALITY]
```

**Weighting strategy:**
- Weight subject slightly: `(subject:1.1)`
- Weight critical details: `(important detail:1.2-1.3)`
- Leave general descriptors unweighted
- Never exceed 1.6

**Length guidance:**
- Icons: SHORT (10-20 words) - more control per token
- Scenes: MEDIUM (40-80 words)
- Each added word dilutes all others

### Step 4: BUILD Negative Prompt

**Combine templates based on content:**

```
ALWAYS start with base:
  blurry, low quality, worst quality, lowres

THEN ADD based on content:
  IF realistic style → add: anime, cartoon, illustration, 3d render, cgi
  IF anime style → add: realistic, photorealistic, photograph, 3d
  IF faces present → add: (deformed face:1.3), asymmetrical, extra eyes
  IF hands visible → add: (extra fingers:1.4), fused fingers, bad hands
  IF icons/UI → add: noisy, textured background, gradient, complex background
```

**Surgical weighting principle:**
- Weight specific persistent problems (1.3-1.5)
- Leave general quality terms unweighted
- Distributed weights > single extreme weight

### Step 5: VALIDATE (Quality Gate)

Before outputting, verify:
- [ ] Subject appears FIRST in positive prompt
- [ ] Uses comma-separated keywords (NOT paragraphs)
- [ ] All weights between 0.5 and 1.6
- [ ] Both positive AND negative prompts provided
- [ ] Settings match selected model
- [ ] No syntax from wrong model architecture

### Step 6: FORMAT Output

```markdown
## Diffusion Prompt

### Positive Prompt
[complete prompt with weights]

### Negative Prompt
[complete negative prompt with weights]

---

### Recommended Settings
- **Model**: [SD 1.5 / SDXL / Flux / SD 3.5]
- **Resolution**: [exact dimensions]
- **CFG Scale**: [value]
- **Sampler**: DPM++ 2M Karras
- **Steps**: [20-30]

### Reasoning
- **Subject**: [what was identified]
- **Style applied**: [what style/medium]
- **Key weights**: [why specific elements were weighted]
- **Negative strategy**: [what the negative prompt prevents]
```

---

## Decision Trees

### Style Detection

```
User says "photo", "realistic", "portrait", "cinematic":
  → Style: photorealistic
  → Model: Juggernaut XL v9 (CFG 3-6) or RealVisXL V5 recommended
  → Add trigger words: Skin Textures, High Resolution, Cinematic
  → Add: shot on Canon EOS 5D, 85mm lens, f/1.8
  → Negate: anime, cartoon, illustration
  → Note: Lower CFG (3-5) = more realistic skin tones

User says "anime", "manga", "cel-shaded":
  → Style: anime
  → Model: NoobAI-XL recommended (or SDXL with anime checkpoint)
  → Add quality tags FIRST: masterpiece, best quality, very awa
  → Add: detailed anime style, clean linework
  → Negate: realistic, photograph, 3d
  → Character format: escape parentheses with backslash: lucy \(cyberpunk\)

User says "icon", "flat", "ui", "app":
  → Style: flat design
  → Add: flat design, simple, clean lines, white background, centered
  → Short prompt (10-20 words)

User says "pixel art", "retro", "8-bit":
  → Style: pixel art
  → Add: pixel art, 16-bit style, clean pixels
  → Negate: blur, anti-aliasing, smooth shading

User says "concept art", "digital art", "fantasy":
  → Style: digital illustration
  → Add: concept art, digital painting, trending on artstation
```

### Problem Detection & Warnings

```
Request mentions multiple characters:
  → IF using SD 1.5: WARN "SD 1.5 struggles with multiple characters. Recommend SDXL or Flux."

Request needs text in image:
  → WARN: "Text rendering is unreliable in SD 1.5/SDXL. Use SD 3.5 or Flux for best results."

Request needs transparency:
  → EXPLAIN: "SD outputs RGB, not RGBA. Add 'white background, centered' to prompt. Remove background in post-processing."

Request mentions hands prominently:
  → Add (extra fingers:1.4), (bad hands:1.3) to negative
  → Consider suggesting: "hands behind back" or "hands in pockets" to avoid issue
```

---

## Examples with Reasoning

### Example 1: Character Portrait

**User Input:** "cyberpunk woman with neon hair"

**Step 1 - PARSE:**
- Subject: woman (cyberpunk style)
- Style: not specified → infer sci-fi/digital from "cyberpunk"
- Details: neon hair (key feature)
- Mood: not specified → infer dramatic/neon lighting
- Constraints: none mentioned

**Step 2 - SELECT MODEL:**
- Character portrait with detail → SDXL

**Step 3-6 - BUILD & OUTPUT:**

## Diffusion Prompt

### Positive Prompt
```
(cyberpunk woman:1.1), (neon blue hair:1.2), futuristic city background, rain-slicked streets, holographic advertisements, detailed face, glowing cybernetic implants, leather jacket, dramatic neon lighting, sharp focus, highly detailed, 8k, concept art
```

### Negative Prompt
```
(deformed face:1.3), bad anatomy, (extra fingers:1.4), blurry, low quality, anime, cartoon, illustration, worst quality
```

### Recommended Settings
- **Model**: SDXL
- **Resolution**: 1024x1024
- **CFG Scale**: 6
- **Sampler**: DPM++ 2M Karras
- **Steps**: 25

### Reasoning
- **Subject**: cyberpunk woman placed first for maximum influence
- **Style applied**: sci-fi concept art (inferred from cyberpunk)
- **Key weights**: neon hair (1.2) as defining feature, subject (1.1) for emphasis
- **Negative strategy**: face/anatomy protection, style purity (no anime bleed)

---

### Example 2: App Icon

**User Input:** "folder icon for file manager"

**Step 1 - PARSE:**
- Subject: folder icon
- Style: implied flat/app design
- Details: none specific
- Use case: UI element → SHORT prompt, simple output

**Step 2 - SELECT MODEL:**
- Simple icon → SD 1.5 (faster, sufficient)

**Step 3-6 - BUILD & OUTPUT:**

## Diffusion Prompt

### Positive Prompt
```
folder icon, flat design, simple, clean lines, white background, centered, blue color, minimal, app icon, vector style
```

### Negative Prompt
```
blurry, noisy, textured background, gradient, complex, realistic, 3d, shadows, text, watermark
```

### Recommended Settings
- **Model**: SD 1.5
- **Resolution**: 512x512
- **CFG Scale**: 8
- **Sampler**: DPM++ 2M Karras
- **Steps**: 20

### Reasoning
- **Subject**: folder icon placed first
- **Style applied**: flat design (appropriate for UI)
- **Key weights**: none needed - short prompt = more control per token
- **Negative strategy**: prevent complexity, ensure clean background

---

## Bad vs Good Examples

### BAD: Narrative Paragraph (wrong for SD)
```
A beautiful cyberpunk woman with flowing neon blue hair stands dramatically
in a rain-soaked city street, surrounded by towering holographic advertisements
that cast colorful reflections on the wet pavement.
```
**Problem:** SD/CLIP reads keywords, not prose. Narrative wastes tokens on articles ("a", "the"), connectors ("with", "that"), and filler.

### GOOD: Keyword Structure
```
(cyberpunk woman:1.1), (neon blue hair:1.2), rain-soaked city, holographic
advertisements, wet pavement reflections, dramatic lighting, 8k
```
**Why better:** Every token contributes meaning. Subject first. Key features weighted.

---

### BAD: Uniform Weight Spam
```
(((ugly))), (((deformed))), (((bad anatomy))), (((bad hands))), (((blurry)))
```
**Problem:** Everything weighted equally = nothing weighted effectively. All-or-nothing dilutes impact.

### GOOD: Surgical Weights
```
(deformed face:1.3), (extra fingers:1.4), bad anatomy, blurry, low quality
```
**Why better:** Persistent problems (face, hands) get specific weights. General terms left unweighted.

---

## Failure Modes & Recovery

### Request is too vague
**Trigger:** Single word like "cat" or ambiguous input

**Action - ASK:**
```
"I need a bit more context to create an optimal prompt:
- What style? (photorealistic / anime / cartoon / icon)
- What setting or background?
- Any specific mood or lighting?"
```

**OR - ASSUME and STATE:**
```
"Assuming photorealistic style with neutral background. Here's the prompt -
adjust if you need something different."
```

### Conflicting style request
**Trigger:** "anime style photorealistic portrait"

**Action - EXPLAIN:**
```
"Anime and photorealistic are opposite styles that conflict. Which is priority?
- Semi-realistic anime (anime base with realistic shading)
- Stylized photorealism (photo base with artistic touches)"
```

### Text in image needed
**Trigger:** "logo with text 'ACME'" or any readable text request

**Action - WARN:**
```
"Text rendering is unreliable in SD 1.5/SDXL. Recommendations:
1. Use SD 3.5 or Flux for better text handling
2. Generate image without text, add typography in post-processing
3. Use ControlNet with text template for guided generation"
```

### Consistency/variation request
**Trigger:** "same character different expressions" or "icon states"

**Action - PROVIDE STRATEGY:**
```
"For consistent variations:
1. Generate base image, note the seed
2. Keep seed FIXED for all variations
3. Keep negative prompt IDENTICAL
4. Only modify specific keywords (expression, state)

Base: (cartoon cat:1.2), orange fur, big eyes, [EXPRESSION], white background
Variations: swap [EXPRESSION] with: happy smile / sad frown / surprised
```

---

## Quick Reference

### Model Settings
| Model | Resolution | CFG | Best For |
|-------|------------|-----|----------|
| SD 1.5 | 512x512 | 7-12 | Icons, simple graphics |
| SDXL | 1024x1024 | 5-7 | General purpose |
| Flux 1 Dev | 1920x1080 | 1-3.5 | Complex scenes, text, multi-character |
| Flux 1 Schnell | 1920x1080 | 1-3.5 | Fast generation (4 steps) |
| SD 3.5 | 1024x1024 | 3.5-4.5 | Text in images |
| Juggernaut XL v9 | 832x1216 | 3-6 | Photorealism (lower CFG = better) |
| RealVisXL V5 | 1024x1024 | 5-7 | Portraits, realistic people |
| NoobAI-XL | 832x1216 | 3-7 | Anime (v-pred uses 3-5, eps uses 5-7) |

### Weight Syntax
| Syntax | Effect |
|--------|--------|
| `(word:1.1)` | Slight emphasis |
| `(word:1.3)` | Strong emphasis |
| `(word:1.5)` | Maximum safe |
| `(word:0.7)` | Reduce influence |

### Negative Templates (combine as needed)
- **Base**: `blurry, low quality, worst quality`
- **Faces**: `(deformed face:1.3), asymmetrical, extra eyes`
- **Hands**: `(extra fingers:1.4), fused fingers, bad hands`
- **Force realism**: `anime, cartoon, illustration, 3d render`
- **Force anime**: `realistic, photorealistic, photograph, 3d`
- **Icons**: `noisy, gradient, complex background, textured`

