# Diffusion Prompt Reference Tables

This file contains lookup tables for the diffusion-prompt skill. Load when you need specific values.

## Model Settings Quick Reference

### Base Models

| Model | Resolution | CFG | Steps | Sampler | Notes |
|-------|------------|-----|-------|---------|-------|
| SD 1.5 | 512x512 | 7-12 | 20-30 | DPM++ 2M Karras | Simple prompts, icons, single subjects |
| SDXL | 1024x1024 | 5-7 | 20-40 | DPM++ 2M Karras | Photorealism, detailed scenes, portraits |
| SD 3.5 Large | 1024x1024 | 3.5 | ~28 | DPM++ 2M Karras | Better typography, complex prompts |
| SD 3.5 Medium | 1024x1024 | 4.5 | ~40 | DPM++ 2M Karras | Use Skip Layer Guidance for anatomy |

### Flux Models

| Model | Resolution | CFG | Steps | Sampler | Notes |
|-------|------------|-----|-------|---------|-------|
| Flux 1 Dev | 1920x1080 | 1.0-3.5 | ~20 | Euler | Best text rendering, 12B params |
| Flux 1 Schnell | 1920x1080 | 1.0-3.5 | 4 | Euler | Speed variant, Apache 2.0, less detail |
| Flux 2 | 1920x1080 | 1.0-3.5 | ~20 | Euler | 32B params, single text encoder (Mistral) |

**Flux notes:** Uses Rectified Flow Transformer (not U-Net). Flux 2 uses single text encoder (simpler embeddings). Best prompt adherence of any model.

### Photorealistic Checkpoints (SDXL-based)

| Model | Resolution | CFG | Steps | Sampler | Notes |
|-------|------------|-----|-------|---------|-------|
| Juggernaut XL v9 | 832x1216 | 3-6 | 30-40 | DPM++ 2M Karras | Lower CFG = more realistic. VAE built-in |
| RealVisXL V5 | 1024x1024 | 5-7 | 30-50 | DPM++ SDE Karras | Sentence prompts preferred over tags |
| RealVisXL Lightning | 1024x1024 | 1-2 | 4-6 | DPM++ SDE Karras | Turbo variant |

### Anime Checkpoints (SDXL-based)

| Model | Resolution | CFG | Steps | Sampler | Notes |
|-------|------------|-----|-------|---------|-------|
| NoobAI-XL (eps) | 832x1216 | 5-7 | 28-35 | Euler A | Danbooru tags, quality tags required |
| NoobAI-XL (v-pred) | 832x1216 | 3-5 | 28-40 | Euler A | LOWER CFG required (v-prediction) |

**Resolution must be divisible by 64 for safety.**

---

## Checkpoint-Specific Prompting

### Juggernaut XL v9

**Trigger words (include in prompt):**
- `Skin Textures` - for detailed human/animal skin
- `High Resolution` or `High-Resolution` - quality boost
- `Cinematic` - film-like dynamic imagery

**Prompt order:** Subject → Action → Environment → Objects → Color → Style → Mood → Lighting

**Negative prompt:** `Naked, Nude, fake eyes, deformed eyes, bad eyes, cgi, 3D, digital, airbrushed`

**HiRes Fix:** 4xNMKD-Siax_200k, 15 steps, 0.25-0.32 denoise, 1.5x upscale

**Key insight:** CFG 3-5 produces more realistic skin than higher values.

---

### RealVisXL V5

**Prompting style:** SDXL prefers descriptive sentences, NOT tag lists like SD 1.5.

**Include in prompts:**
- Lighting: front lighting, back lighting, studio lighting, sunshine
- Camera: DSLR, Canon, 8K, ultra quality, sharp focus, depth of field
- Angles: low angle, high angle, profile angle

**Negative prompt:** `(worst quality, low quality, illustration, 3d, 2d, painting, cartoons, sketch), open mouth`

**Upscaling:** Factor 1.1-1.5x, use 4x-NMKD-Superscale-SP or 4x-UltraSharp

---

### NoobAI-XL (Anime)

**Quality tags (add to START of prompt):**
```
masterpiece, best quality, newest, absurdres, highres, very awa
```

**Prompt structure:**
```
[quality tags], [character count], [character name], [artist], [scene/camera], [action], [expression], [items]
```

**Character format:** `ganyu \(genshin impact\), genshin impact`
- Remove underscores from Danbooru tags
- Escape parentheses with backslash: `lucy_(cyberpunk)` → `lucy \(cyberpunk\)`

**Negative prompt:**
```
worst quality, low quality, lowres, nsfw, signature, watermark, bad hands, mutated hands
```

**Supported resolutions:**
768x1344, 832x1216, 896x1152, 1024x1024, 1152x896, 1216x832, 1344x768, 1024x1536, 1536x1024

**WARNING:** V-prediction models use LOWER CFG (3-5). Using 7-11 causes oversaturation and artifacts.

---

## Weight Syntax

| Syntax | Effect | When to Use |
|--------|--------|-------------|
| `(word)` | 1.1x | Slight emphasis |
| `((word))` | 1.21x | Moderate emphasis |
| `(word:1.3)` | Explicit 1.3x | Precise control (PREFERRED) |
| `[word]` | 0.91x | Slight reduction |
| `(word:0.7)` | Explicit 0.7x | Precise reduction |

**Safe range: 0.5 to 1.6. Values >1.9 cause artifacts.**

## Negative Prompt Templates

### Base (Always Include)
```
blurry, low quality, worst quality, lowres
```

### Anatomy Issues
```
bad anatomy, deformed, disfigured, mutated, extra limbs, missing limbs
```

### Face Problems
```
(deformed face:1.3), asymmetrical, extra eyes, distorted features, ugly
```

### Hand Problems
```
(extra fingers:1.4), (fused fingers:1.3), missing fingers, deformed hands, bad hands
```

### Force Photorealism (negate illustration styles)
```
anime, cartoon, illustration, drawing, painting, 3d render, cgi, stylized, flat colors, vector art
```

### Force Anime/Illustration (negate realism)
```
realistic, photorealistic, photograph, 3d, hyperrealistic, real life, detailed skin texture, pores
```

### Icons/UI Elements
```
noisy, textured background, gradient, complex background, watermark, text
```

### Pixel Art
```
blur, anti-aliasing, smooth shading, gradient, realistic, 3d
```

## Quality Enhancement Terms

### General Quality
- highly detailed, sharp focus, 8k, 4k resolution, masterpiece, best quality

### Photographic
- shot on Canon EOS 5D Mark IV, 85mm lens, f/1.8, shallow depth of field, bokeh, golden hour, studio lighting

### Digital Art
- trending on artstation, digital painting, concept art, detailed illustration

### Anime
- detailed anime style, high quality anime, clean linework, vibrant colors

## Sampler Recommendations

| Sampler | Steps | Use Case |
|---------|-------|----------|
| DPM++ 2M Karras | 20-30 | General purpose, fast |
| Euler a | 20-30 | Good variety, fast |
| DPM++ SDE Karras | 25-35 | More detailed, slower |
| DDIM | 50-100 | Older, rarely needed |

## BREAK Keyword Usage

Use BREAK to control 77-token chunk boundaries. Related concepts should stay in same chunk.

```
beautiful landscape, mountains, lake, sunset, golden hour
BREAK
detailed foliage, pine trees, wildflowers, rocks
BREAK
atmospheric fog, volumetric lighting, rays of light
```

## LoRA Syntax

```
<lora:filename:weight>
```
- Typical range: 0.5-1.0
- Include trigger words in prompt
- Stronger LoRAs need lower weights
