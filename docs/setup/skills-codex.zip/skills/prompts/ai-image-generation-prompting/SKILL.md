---
name: ai-image-generation-prompting
description: "Use to write or optimize Nano Banana/Gemini image prompts with clear subjects, style, composition, colors, and constraints."
---

# AI Image Generation Prompting for

## Overview

This skill transforms vague or incomplete image requests into production-ready prompts optimized for AI image generation like Chrome's Nano Banana (Gemini Image), DaLL·E, Midjourney, Z-Image, Xainflow.

## When to Use

Activate this skill when:
- User asks to "create a prompt for" an image
- User wants to optimize a prompt for Xainflow, Nano Banana, Gemini Image, or similar T2I models
- User provides a brief image description and needs it expanded
- User asks for help with text-to-image generation
- User mentions "Xainflow", "AI Image Generation",  "Nano Banana", "Gemini Image", or similar T2I models

## Constitutional Principles

These rules CANNOT be violated:

1. **NARRATIVE PARAGRAPHS**: Always output descriptive narrative paragraphs, NEVER comma-separated keyword lists
2. **DESCRIPTIVE LANGUAGE**: Use scene-painting descriptive language, NEVER instructional commands
3. **NO INSTRUCTION VERBS**: NEVER use "create", "generate", "make", "add", "build" - describe what EXISTS
4. **PRIORITY ORDERING**: Place the most important visual elements FIRST in the prompt
5. **COMPLETENESS**: Transform every user request into a production-ready prompt

## Prompt Architecture

Build prompts using this progressive structure:

### Layer 1: Subject Specification (REQUIRED)
The primary element(s) and their core characteristics. This MUST come first.

### Layer 2: Style & Aesthetic (REQUIRED)
Art style, design language, visual aesthetic direction.

### Layer 3: Technical Details (RECOMMENDED)
Resolution, quality modifiers, rendering specifics.

### Layer 4: Atmospheric Elements (OPTIONAL)
Lighting, mood, environmental effects, color atmosphere.

### Layer 5: Negative Guidance (WHEN NEEDED)
What to exclude for quality control.

## Optimization Techniques

### Hex Color Codes
When colors are specified or implied, use exact hex values:
- Format: `color name (#HEXCODE)`
- Example: "corporate blue (#2563EB)", "pure white (#FFFFFF)"

### Structured Formatting
For complex scenes, use dashed lists within the narrative:
```
Scene description introducing the setting.
- Element one with specific details
- Element two with positioning
- Element three with characteristics
Concluding atmospheric and quality details.
```

### Quality Enhancement Words
Include 2-4 of these when appropriate:
- "highly detailed"
- "professional photography"
- "HDR"
- "masterpiece"
- "8K resolution" / "4K resolution"
- "ray tracing"
- "cinematic lighting"

### Text Rendering
When text appears in the image:
- Place desired text in quotation marks within sentences
- Describe font characteristics, NEVER font names
- Use: "bold sans-serif", "elegant script", "thin monospace"
- NOT: "Helvetica", "Times New Roman", "Arial"

### UI/UX Prompts
When generating UI mockups:
- Include design system elements with spacing values
- Specify touch targets (44pt minimum for mobile)
- Use hex color palette throughout
- Describe component relationships and hierarchy

## Transformation Examples

### Simple Subject

**User Input:** "cat on a beach"

**Optimized Prompt:**
```
A majestic orange tabby cat sits serenely on a pristine white sand beach at golden hour. The cat's fur catches the warm sunlight, each whisker illuminated against the soft blue ocean backdrop. Gentle waves lap at the shore in the distance, creating a peaceful coastal atmosphere. The composition captures the cat in sharp focus against a naturally blurred background of sea and sky blending at the horizon. Professional wildlife photography, highly detailed fur texture, warm color palette with amber (#F59E0B) highlights and ocean teal (#0D9488) accents, 4K resolution, soft volumetric lighting.
```

### UI/UX Design

**User Input:** "login page for a fintech app"

**Optimized Prompt:**
```
A modern mobile fintech login interface presents elegant simplicity on a clean white (#FFFFFF) background. The centerpiece features a prominent sign-in button in confident corporate blue (#2563EB), creating strong visual hierarchy.
- Email input field with subtle gray (#E5E7EB) border and 16px rounded corners
- Password field with visibility toggle icon
- "Forgot Password?" link in muted blue (#3B82F6) below the fields
- Primary "Sign In" button spanning full width with 48pt touch target
- Biometric login options (Face ID, fingerprint) as secondary actions
Clean sans-serif typography, 8px grid spacing system, subtle shadows (0px 2px 8px rgba(0,0,0,0.08)) adding depth. Material Design 3 aesthetic, professional fintech branding, 4K resolution UI mockup.
```

### Character Design

**User Input:** "cyberpunk warrior"

**Optimized Prompt:**
```
A battle-hardened cyberpunk warrior stands in a dramatic three-quarter pose against a rain-slicked neon cityscape. Her asymmetrical bob haircut glows electric blue (#3B82F6) under the pulsing holographic advertisements above. Matte black tactical armor covers her torso with exposed circuitry patterns in hot pink (#EC4899) running along the seams. A sleek katana with a plasma-edged blade rests across her back, its handle wrapped in synthetic leather.
- Cybernetic left arm with visible chrome plating and data ports
- Scarred right eye replaced with a glowing red (#EF4444) optical implant
- Weathered jacket with corporate logos scratched off
The scene is bathed in contrasting neon reflections on wet concrete, atmospheric fog diffusing the harsh urban lights. Highly detailed character design, cinematic lighting, concept art quality, 8K resolution, masterpiece.
```

### Product Photography

**User Input:** "headphones product shot"

**Optimized Prompt:**
```
Premium over-ear wireless headphones float elegantly against a gradient background transitioning from deep charcoal (#1F2937) to slate gray (#475569). The headphones feature a matte black finish with rose gold (#F59E0B) accent rings on the ear cups and brushed aluminum headband. Soft memory foam ear cushions in supple leather catch the dramatic side lighting.
- Main light source from upper left creating defined shadows
- Subtle reflection on invisible surface below
- Product rotated 15 degrees to show both ear cup and headband detail
- Touch controls visible on right ear cup
Professional product photography, commercial advertising quality, studio lighting setup, highly detailed material textures, clean isolated background, 4K resolution, photorealistic rendering.
```

## Quality Gate

Before outputting the final prompt, verify:

- [ ] Prompt begins with descriptive subject, NOT an instruction verb
- [ ] Written as narrative paragraph(s), NOT keyword list
- [ ] Most important visual elements appear FIRST
- [ ] Includes at least 2 quality enhancement words
- [ ] Specific details replace vague descriptions
- [ ] Colors specified with hex codes where applicable
- [ ] Style/aesthetic clearly defined

## Output Format

Respond with:

```
## Optimized Nano Banana Prompt

[The complete, optimized prompt ready for direct use]

---

### Prompt Analysis
- **Subject**: [Primary subject identified]
- **Style**: [Artistic/design style applied]
- **Key Enhancements**: [2-3 improvements made]
- **Quality Modifiers**: [List of quality words used]
```

## Edge Cases

### Single word input
Expand into a complete scene with assumed context, style, and quality markers. Ask clarifying questions only if genuinely ambiguous (e.g., "bank" could be financial or river).

### Very long description
Reorganize for priority ordering, eliminate redundancy, enhance with quality modifiers, and structure into proper narrative format.

### Text in image
Apply text rendering rules: quote the text, describe font characteristics (not names), specify positioning and styling.

### Sprites or game assets
Include consistency parameters: viewing angle, lighting direction, color palette constraints, pixel dimensions if relevant.

